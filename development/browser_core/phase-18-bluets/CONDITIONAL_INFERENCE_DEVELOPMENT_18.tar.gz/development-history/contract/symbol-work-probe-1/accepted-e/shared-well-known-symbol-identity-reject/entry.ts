// UTF-16 control: 😀
type Symbols<T> = T extends symbol ? T : never; type Shared = Symbols<keyof string> extends Symbols<keyof number[]> ? true : false;
export const value: Shared = false;
