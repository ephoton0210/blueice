# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
preflight = repo / 'target/mapped-inference-design-20261113/mac-preflight-1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
measurement = json.loads((preflight / 'measurement.json').read_bytes())
manifest = json.loads((preflight / 'source-manifest.json').read_bytes())
assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
assert len(measurement['steps']) == 14 and all(step['exit'] == 0 for step in measurement['steps'])
assert sha(preflight / 'source-manifest.json') == measurement['sourceManifestSha256']
assert sha(repo / 'CLAUDE.md') == manifest['unrelatedClaudeSha256']
paths = subprocess.check_output([
    'git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
    'backend/', 'development/browser_core/phase-18-bluets/tools/',
], cwd=repo).decode().split('\0')
files = {name: sha(repo / name) for name in sorted(set(paths)) if name}
assert files == manifest['expectedFiles']
for step in measurement['steps']:
    assert sha(preflight / step['log']) == step['sha256']
assert sha(preflight / 'authoring-bluetsc') == measurement['compilerSha256']
subprocess.run(['git', 'add', '--', 'backend/bluets/',
                'development/browser_core/phase-18-bluets/tools/record_mapped_inference.cjs',
                'development/browser_core/phase-18-bluets/tools/verify_mapped_inference.cjs'], cwd=repo, check=True)
tree = subprocess.check_output(['git', 'write-tree'], cwd=repo).decode().strip()
backend_tree = subprocess.check_output(['git', 'rev-parse', tree + ':backend'], cwd=repo).decode().strip()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert parent == measurement['baseCommit']
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only', '--', 'CLAUDE.md'], cwd=repo)
backend = sorted((name for name in files if name.startswith('backend/')), key=lambda name: name.encode())
indexed = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(backend) == set(indexed)
fixture = repo / 'backend/bluets/tests/fixtures/mapped_inference'
contract = json.loads((fixture / 'FROZEN.json').read_bytes())
for name, digest in {**contract['sha256'], **contract['supplementarySha256']}.items():
    assert sha(fixture / name) == digest
tool_hashes = json.loads(subprocess.check_output([
    'node', '-e', "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))",
], cwd=repo))
frozen = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit': parent,
    'backendTree': backend_tree,
    'sourceRevision': 'backend-tree:' + backend_tree,
    'backendFiles': len(backend),
    'backendPathSetSha256': hashlib.sha256('\0'.join(backend).encode()).hexdigest(),
    'files': files,
    'preflight': str(preflight.relative_to(repo)),
    'preflightMeasurementSha256': sha(preflight / 'measurement.json'),
    'preflightManifestSha256': sha(preflight / 'source-manifest.json'),
    'originalFrozenInputs': contract['sha256'],
    'supplementaryFixtureSha256': contract['supplementarySha256'],
    'supplementaryInventoryCredit': 0,
    'oracleToolFilesExpected': len(tool_hashes),
    'expectedNativeSuites': 188,
    'expectedNativeFunctions': 1069,
    'scope': 'P0-D observer-aware final source frozen after complete authoring preflight. Full new-source acceptance required; no previous-source pass credit.',
}
with (root / 'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(frozen, indent=2) + '\n')
print(json.dumps({key: value for key, value in frozen.items() if key != 'files'}))
