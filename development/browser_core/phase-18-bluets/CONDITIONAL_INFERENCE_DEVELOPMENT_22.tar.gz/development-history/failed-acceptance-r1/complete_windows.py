# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import base64, datetime, importlib.util, json, os, subprocess, sys, time

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qga', root.parent / 'noinfer-acceptance-20261112/recovery/qga_transfer.py')
qga = importlib.util.module_from_spec(spec); spec.loader.exec_module(qga)
state_path = root / 'windows/complete-state.json'
assert not state_path.exists(), 'Inspect the existing VM supervisor before retry'
base = 'B:/BlueIce/gm3-20261109-360d7d921/'
state = {'pid': os.getpid(), 'stage': 'upload', 'conclusion': 'in_progress', 'observations': []}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')

try:
    save()
    with (root / 'windows/upload-driver.log').open('xb') as output:
        child = subprocess.Popen([sys.executable, '-B', str(root / 'upload_windows.py')], stdout=output, stderr=subprocess.STDOUT)
        state['uploadPid'] = child.pid; save(); code = child.wait()
    assert code == 0, 'Source upload/bootstrap launch failed; inspect upload state'
    bootstrap_pid = json.loads((root / 'windows/launch.json').read_bytes())['process']['pid']
    state.update(stage='waiting-bootstrap', bootstrapPid=bootstrap_pid); save()
    while True:
        try:
            result = qga.call({'execute': 'guest-exec-status', 'arguments': {'pid': bootstrap_pid}})
        except Exception as error:
            state['observations'].append({'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'error': repr(error)})
            save()
            # A consumed guest-exec status is not permission to launch again.
            # Retain a fresh physical bootstrap receipt and require it terminal.
            attempt = root / 'windows' / ('bootstrap-observation-' + str(len(state['observations'])) + '.json')
            try:
                qga.download(base + 'p0f-r1-bootstrap/measurement.json', attempt)
                observed = json.loads(attempt.read_bytes())
                if observed['conclusion'] != 'in_progress':
                    assert observed['conclusion'] == 'success' and observed['nodeExit'] == 0, observed
                    break
            except AssertionError:
                raise
            except Exception as observation_error:
                state['observations'][-1]['receiptError'] = repr(observation_error); save()
            time.sleep(10); continue
        state['lastGuestStatus'] = result; save()
        if result.get('exited'):
            for key in ['out-data', 'err-data']:
                if key in result: result[key] = base64.b64decode(result[key]).decode('utf-8-sig', errors='replace')
            (root / 'windows/bootstrap-terminal.json').write_text(json.dumps(result, indent=2) + '\n')
            assert result['exitcode'] == 0, result
            break
        time.sleep(10)
    state['stage'] = 'launching-evidence-package'; save()
    process = qga.call({'execute': 'guest-exec', 'arguments': {
        'path': 'C:\\Program Files\\Python312\\python.exe',
        'arg': ['-B', base + 'p0f-r1-package-evidence.py'], 'capture-output': True}})
    (root / 'windows/package-process.json').write_text(json.dumps({'process': process}, indent=2) + '\n')
    state.update(stage='receiving-evidence', packagePid=process['pid']); save()
    with (root / 'windows/finish-driver.log').open('xb') as output:
        child = subprocess.Popen([sys.executable, '-B', str(root / 'finish_windows.py')], stdout=output, stderr=subprocess.STDOUT)
        state['receiverPid'] = child.pid; save(); code = child.wait()
    assert code == 0, 'Windows archive reception/independent audit failed; inspect retained state'
    state.update(stage='complete', conclusion='success'); save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error)); save(); raise
