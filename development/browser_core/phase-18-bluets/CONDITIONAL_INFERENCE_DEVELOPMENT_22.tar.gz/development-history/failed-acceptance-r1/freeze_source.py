# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Freeze P0-F after affected-cohort and all-target quality gates pass."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
preflight = repo / 'target/conditional-inference-contract-20261114/preflight-4'
quality = preflight.parent / 'quality-1'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = lambda *args: subprocess.check_output(args, cwd=repo, text=True).strip()
read = lambda path: json.loads(path.read_bytes())
measured = read(preflight / 'measurement.json')
assert measured['conclusion'] == 'success' and measured['stage'] == 'complete'
expected_steps = ['library', 'nonnullable_awaited_first', 'conditional_inference',
                  'callable_utilities', 'receiver_utilities', 'gc1_object_generic_methods',
                  'noinfer', 'string_intrinsics', 'mapped_inference', 'symbolic_keys',
                  'jsx_checker_matrix', 'gt5_compositions']
assert [step['label'] for step in measured['steps']] == expected_steps
assert all(step['exit'] == 0 for step in measured['steps'])
for step in measured['steps']:
    assert sha(preflight / step['log']) == step['sha256'], step['label']
assert sha(preflight / 'bluetsc') == measured['compilerSha256']
for name, digest in read(preflight / 'source-manifest.json').items():
    assert sha(repo / name) == digest, name
checked = read(quality / 'measurement.json')
assert checked['conclusion'] == 'success' and checked['stage'] == 'complete'
assert [step['label'] for step in checked['steps']] == ['fmt', 'clippy']
for step in checked['steps']:
    assert step['exit'] == 0 and sha(quality / step['log']) == step['sha256']
assert sha(quality / 'files.json') == checked['filesManifestSha256']
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
    '--exclude-standard', '-z', '--', 'backend',
    'development/browser_core/phase-18-bluets/tools'], cwd=repo).decode().split('\0')
files = {name: sha(repo / name) for name in sorted(set(paths)) if name}
assert files == read(quality / 'files.json')
assert not command('git', 'diff', '--name-only', '--', 'backend',
                   'development/browser_core/phase-18-bluets/tools')
tree = command('git', 'write-tree')
backend_tree = command('git', 'rev-parse', tree + ':backend')
parent = command('git', 'rev-parse', 'HEAD')
assert parent == 'd4694f775e8d3e1ef2b45bc438ddaca7b8ac080c'
backend = sorted((name for name in files if name.startswith('backend/')), key=lambda name: name.encode())
indexed = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(backend) == set(indexed)
fixture = repo / 'backend/bluets/tests/fixtures/conditional_inference'
contract = read(fixture / 'FROZEN.json')
extra = read(fixture / 'ALIAS_CONTROLS_FROZEN.json')
for name, digest in {**contract['sha256'], **extra['sha256']}.items():
    assert sha(fixture / name) == digest, name
tools = json.loads(subprocess.check_output(['node', '-e',
    "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"], cwd=repo))
prior = read(root.parent / 'symbolic-keys-acceptance-20261113-r1/accepted-native/measurement.json')
assert prior['conclusion'] == 'success' and len(prior['suites']) == 189
new_test = repo / 'backend/bluets/tests/conditional_inference.rs'
assert new_test.read_text().count('#[test]') == 5
frozen = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit': parent, 'backendTree': backend_tree,
    'sourceRevision': 'backend-tree:' + backend_tree,
    'backendFiles': len(backend),
    'backendPathSetSha256': hashlib.sha256('\0'.join(backend).encode()).hexdigest(),
    'files': files, 'preflight': str(preflight.relative_to(repo)),
    'preflightMeasurementSha256': sha(preflight / 'measurement.json'),
    'preflightManifestSha256': sha(preflight / 'source-manifest.json'),
    'qualityMeasurementSha256': sha(quality / 'measurement.json'),
    'qualityManifestSha256': sha(quality / 'files.json'),
    'originalFrozenInputs': contract['sha256'],
    'supplementaryFixtureSha256': extra['sha256'],
    'supplementaryInventoryCredit': 0, 'oracleToolFilesExpected': len(tools),
    'expectedNativeSuites': len(prior['suites']) + 1,
    'expectedNativeFunctions': sum(s['passed'] for s in prior['suites']) + 5,
    'previousAssertions': 42320, 'addedAssertions': 396,
    'scope': 'P0-F finite conditional-inference contract; complete same-source acceptance still required. Prior-source passes receive no new-source credit. All 22 broad rows remain open.',
}
with (root / 'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(frozen, indent=2) + '\n')
print(json.dumps({key: value for key, value in frozen.items() if key != 'files'}))
