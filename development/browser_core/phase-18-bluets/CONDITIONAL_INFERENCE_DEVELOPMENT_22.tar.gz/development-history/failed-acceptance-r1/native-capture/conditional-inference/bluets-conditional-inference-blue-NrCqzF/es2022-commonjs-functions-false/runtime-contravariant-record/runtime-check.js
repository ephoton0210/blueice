"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; 
function identity(value){ return value; }
exports.result = identity({ a: "ok", b: 2 });

var check = module.exports.result;
if (JSON.stringify(check) !== JSON.stringify({ a: "ok", b: 2 })) throw new Error("unexpected runtime value");
