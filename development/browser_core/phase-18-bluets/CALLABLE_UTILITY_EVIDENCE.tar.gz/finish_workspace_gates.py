from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,shutil
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';root=Path('/private/tmp/bluets-utility-followup-20261110');frozen=json.loads((root/'frozen-source-preflight.json').read_text());revision=frozen['sourceRevision']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0')
state=json.loads((root/'repair-acceptance.json').read_text())
assert state['conclusion']=='failure' and state['stage']=='workspace-build' and state['steps'][-1]['label']=='workspace-build' and state['steps'][-1]['exit']==0
state.setdefault('driverSetupFailures',[]).append({'stage':'after-successful-workspace-build-before-tests','error':state['error'],'finishedAt':state.get('finishedAt'),'driver':'resume_repair_gates.py','driverSha256':hashlib.sha256((root/'resume_repair_gates.py').read_bytes()).hexdigest(),'trace':'recovery-driver.log','scope':'Orchestration NameError before any workspace test. Successful build and all prior source-bound Native observations retained.'})
state.update(conclusion='in_progress',stage='workspace-profile-binding');state.pop('error',None);state.pop('finishedAt',None)
cli=repo/'target/debug/bluetsc';env['RUST_TEST_THREADS']='4';env['BLUEICE_CALLABLE_SOURCE_REVISION']=revision;env['BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS']=str(root/'repair-workspace-capture/utilities')
def save():(root/'repair-acceptance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label;save();log=root/('repair-'+label+'.log')
 with log.open('wb') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':args,'exit':r.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
 if r.returncode:raise RuntimeError(f'{label}: exit {r.returncode}')
 return log
try:
 state['workspaceCompilerSha256']=hashlib.sha256(cli.read_bytes()).hexdigest();shutil.copy2(cli,root/'repair-workspace-cli');save();env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256']
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json')]:
  dest=root/'repair-workspace-capture'/suffix;dest.parent.mkdir(parents=True,exist_ok=True)
  if name.endswith('DIRECTORY'):dest.mkdir(exist_ok=True)
  env[name]=str(dest)
 log=run('workspace',['cargo','test','--workspace','--no-fail-fast','--locked','--offline']);rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',log.read_text(errors='replace'));assert rows and all(r[0]=='ok' and r[2]==r[4]=='0' for r in rows);state['workspace']={'passed':sum(int(r[1]) for r in rows),'failed':0,'ignored':sum(int(r[3]) for r in rows),'filtered':0,'groups':len(rows)};save()
 run('fmt-check',['cargo','fmt','--all','--','--check']);run('clippy',['cargo','clippy','--workspace','--all-targets','--features','blueice-bluets/windows-symlink-tests','--','-D','warnings'])
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))+sorted((repo/'differential-testing/bluets-projects').glob('*.test.cjs'));run('node-tools',['node','--test',*[str(p) for p in tests]]);run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,args)
 state.update(stage='local-complete-awaiting-windows-and-publication',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(conclusion='failure',error=repr(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
