from pathlib import Path
import json
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';m=json.loads((phase/'CALLABLE_UTILITY_MEASUREMENT.json').read_text());g=m['gates'];assert m['conclusion']=='completed-within-frozen-scope' and g['conclusion']=='success'
source=m['source']['sourceRevision'];native=m['nativeMeasurement'];workspace=g['workspace'];windows=m['windows']
p=phase/'TODO.md';s=p.read_text();a=s.index('**Latest completed follow-up:**');b=s.index('## Maintenance and real-project follow-up',a)
s=s[:a]+'''**Latest completed follow-up:** G-T7/G-T2 now supplies the frozen callable and
constructor utilities with full diagnostics, byte-exact declarations and isolated
consumers. [Current acceptance](CALLABLE_UTILITY_ACCEPTANCE.md) binds implementation,
complete gates and raw evidence to the same source. The earlier complete mitt,
defu and multi-source state evaluations remain dated evidence and also pass this
source's project regression checks. The 22 broader rows remain open.

'''+s[b:]
s=s.replace('- [ ] Supply `Parameters`','- [x] Supply `Parameters`',1).replace('- [ ] Require full primary/related diagnostics','- [x] Require full primary/related diagnostics',1).replace('- [ ] Complete the source-bound Native/local workspace','- [x] Complete the source-bound Native/local workspace',1)
mark='## Completed baseline (condensed)';addition=f'''Accepted on `{source}`: **{native['suites']} Native suites / {native['functions']:,}
tests**, **{workspace['passed']:,} local workspace passes**, both complete **8,407 ×
two** map reports, and Windows **82 core oracles + 25 paths + five complete
regression cohorts**. All previous 39,561 case identities/classifications remain;
156 new direct observations bring the generated inventory to 39,717. Nine owner
checks remain outside the direct denominator. [Measurements and scope limits](CALLABLE_UTILITY_ACCEPTANCE.md).

''';assert mark in s;s=s.replace(mark,addition+mark,1);p.write_text(s)
p=phase/'CALLABLE_UTILITY_FOLLOWUP.md';s=p.read_text();s=s.replace('The next concrete library gaps are `Parameters`, `ConstructorParameters` and', 'This package supplies `Parameters`, `ConstructorParameters` and');a=s.index('Status:');b=s.index('\n\nThis package supplies',a);s=s[:a]+'''Status: completed within the frozen scope. The later
[acceptance](CALLABLE_UTILITY_ACCEPTANCE.md) and [measurements](CALLABLE_UTILITY_MEASUREMENT.json)
retain the same-source complete gates, original failures and raw observations.'''+s[b:];s=s.replace('Focused evidence and the original failures will be retained with fresh complete\nacceptance. This package must pass','Focused evidence and the original failures are retained with fresh complete\nacceptance. This package requires');p.write_text(s)
p=phase/'COMPATIBILITY_INVENTORY.md';lines=p.read_text().splitlines();additions={
 'G-T7':' The [callable utility follow-up](CALLABLE_UTILITY_ACCEPTANCE.md) additionally supplies Parameters, ConstructorParameters and InstanceType through general conditional/infer operations: 156 full diagnostic observations across 52 forms and three profiles, 75 byte-exact declarations, 150 isolated consumers, 75 syntax checks and six executions per compiler output. Nine owner/local/runtime checks are separate. Other utility names, higher-rank constructor-pattern binders and unmeasured catalog/composition/flag combinations remain open.',
 'G-T2':' The [callable utility follow-up](CALLABLE_UTILITY_ACCEPTANCE.md) additionally measures final overload selection, bounded generic operands, receiver/rest/optional tuples, abstract constructor queries and explicit any/never inference, including equivalent owner aliases. Every frozen verdict/diagnostic and accepted declaration is exact; broader dependent/recursive/higher-rank compositions remain open.',
 'G-C1':' The [callable utility follow-up](CALLABLE_UTILITY_ACCEPTANCE.md) additionally measures complete constraint-signature causes, fixed-tuple versus variadic argument locations and contextual property origins across all 156 frozen observations, including CRLF/non-BMP coordinates. This does not close unmeasured CLI/recovery behavior.',
 'G-M3':f' The [callable utility follow-up](CALLABLE_UTILITY_ACCEPTANCE.md) repeats all 25 Windows paths, 82 core oracles and five regression cohorts against its {windows["verifiedSourceFiles"]:,}-file manifest, including all {windows["verifiedBackendFiles"]:,} canonical backend files.'}
for index,line in enumerate(lines):
 for id,addition in additions.items():
  if line.startswith('| '+id+' |'):
   split=line.rfind(' | [evidence]');assert split!=-1;line=line[:split]+addition+line[split:]
 if line.startswith('| G-E5 |'):line=line.replace('[current source-bound follow-up](PROJECT_FOLLOWUP_ACCEPTANCE.md)','[current source-bound follow-up](CALLABLE_UTILITY_ACCEPTANCE.md)')
 lines[index]=line
p.write_text('\n'.join(lines)+'\n')
p=phase/'PLAN.md';s=p.read_text();s+='''
## Callable utility follow-up — G-T7 / G-T2 (2026-11-11)

The [frozen package](CALLABLE_UTILITY_FOLLOWUP.md) supplies Parameters,
ConstructorParameters and InstanceType through the ordinary static library and
conditional/infer engine. All 156 verdict/full-diagnostic observations and 75
accepted declaration inventories agree with pinned TypeScript. Isolated Native
consumers, selected-edition syntax, runtime and separate owner controls pass.
[Current acceptance](CALLABLE_UTILITY_ACCEPTANCE.md) retains complete source-bound
Native/local/Windows commands, actual compiler/map bindings, immutable baseline
replay and raw evidence. The source/code and its corresponding measurements are
accepted together; broad rows remain open and full parity stays OFF.
''';p.write_text(s)
p=phase/'STANDARD_LIBRARY.md';s=p.read_text();mark='Broader generic inference, structural protocols, overloads, index signatures';addition='''The [callable utility follow-up](CALLABLE_UTILITY_ACCEPTANCE.md) adds original
Parameters, ConstructorParameters and InstanceType declarations to the same
content-hashed core layer in every selected edition. General conditional/infer
matching, including constructor signatures and generic operand bounds, supplies
their types; their names acquire no runtime binding. Its 52-form/three-profile
matrix requires all diagnostics, exact declarations, isolated consumers and
execution. Other utility names and unmeasured compositions remain open.

''';assert mark in s;s=s.replace(mark,addition+mark);p.write_text(s)
print('Updated completed finite facts; all22 broader feature rows remain open')
