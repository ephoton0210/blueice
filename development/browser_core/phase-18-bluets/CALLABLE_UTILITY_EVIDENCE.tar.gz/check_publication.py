from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-utility-followup-20261110');phase=repo/'development/browser_core/phase-18-bluets'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=read(phase/'CALLABLE_UTILITY_MEASUREMENT.json');assert m['conclusion']=='completed-within-frozen-scope';source=m['source']['sourceRevision'];assert source==read(root/'frozen-source-preflight.json')['sourceRevision']
assert m['gates']['conclusion']=='success' and all(x['exit']==0 for x in m['gates']['steps']);assert any(x['label']=='workspace-utility-oracles' for x in m['gates']['steps'])
index=subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip();backend=subprocess.check_output(['git','rev-parse',index+':backend'],cwd=repo,text=True).strip();assert source=='backend-tree:'+backend
old=json.loads(subprocess.check_output(['git','show','HEAD:development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json'],cwd=repo));new=read(phase/'COMPATIBILITY_CASES.json')
def cases(d):return {(s['harness'],c['id']):{k:c.get(k) for k in ['comparison','status','scope','reason']} for s in d['suites'] for c in s['cases']}
a=cases(old);b=cases(new);assert len(a)==39561 and len(b)==39717 and all(b.get(k)==v for k,v in a.items());added=set(b)-set(a);assert len(added)==156 and {x[0] for x in added}=={'backend/bluets/tests/callable_utilities.rs'}
manifest=read(phase/'CALLABLE_UTILITY_ARTIFACTS.json');assert manifest['sourceRevision']==source
for artifact in manifest['artifacts']:
 p=phase/artifact['path'];assert p.stat().st_size==artifact['bytes'] and sha(p)==artifact['sha256'] and p.stat().st_size<95*1024*1024
 with tarfile.open(p,'r:gz') as archive:
  names=archive.getnames();assert names and all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
  if p.name=='CALLABLE_UTILITY_RETIRED_A94.tar.gz':assert 'retired-a94/retirement.json' in names and 'retired-a94/windows/windows-failed-a94-evidence.tar.gz' in names
  if p.name=='CALLABLE_UTILITY_RETIRED_7B406.tar.gz':assert 'retired-7b406/retirement.json' in names and 'retired-7b406/windows/windows-evidence.tar.gz' in names
for name,key in [('cases.json','nativeInputSha256'),('reference.json','nativeReferenceSha256')]:assert sha(repo/'backend/bluets/tests/fixtures/callable_utilities'/name)==m['source'][key]
for p in [phase/'CALLABLE_UTILITY_ACCEPTANCE.md',phase/'CALLABLE_UTILITY_FOLLOWUP.md',repo/'backend/bluets/tests/fixtures/callable_utilities/README.md']:
 text=p.read_text();assert '{{' not in text
 for target in re.findall(r'\]\(([^)]+)\)',text):
  if ':' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).exists(),(p,target)
todo=(phase/'TODO.md').read_text();section=todo.split('### G-T7 / G-T2 — callable utility follow-up')[1].split('## Completed baseline')[0];assert section.count('- [x]')==3 and '- [ ]' not in section
receipt={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':source,'indexTree':index,'allOldCaseIdentitiesAndClassificationsPreserved':True,'oldCaseCount':len(a),'currentCaseCount':len(b),'addedHarness':'backend/bluets/tests/callable_utilities.rs','addedCases':len(added),'artifactsVerified':manifest['artifacts'],'frozenNativeInputAndReferenceUnchanged':True,'newMarkdownLinksResolved':True,'allThreeFiniteTodoItemsChecked':True,'broaderFeatureRowsRemainOpen':22,'conclusion':'success'}
(root/'publication-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
