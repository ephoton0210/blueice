// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root='/private/tmp/bluets-utility-followup-20261110',repo='/Users/ephoton/git/blueice-bluets',phase=path.join(repo,'development/browser_core/phase-18-bluets');
const runner=require(path.join(phase,'tools/measure_compatibility_cases.cjs')),hash=data=>crypto.createHash('sha256').update(data).digest('hex');
const canonical=path.join(root,'repair-native'),initial=JSON.parse(fs.readFileSync(path.join(canonical,'measurement.json')));
assert(!Object.keys(process.env).some(k=>(k.startsWith('BLUEICE_WRITE_')&&process.env[k]==='1')||k.startsWith('BLUETS_')),'recording/filter environment is forbidden');
assert.equal(initial.conclusion,'failure');assert(initial.suites.some(row=>row.harness==='backend/bluets/tests/ge5_generator_switch_family.rs'&&row.conclusion==='failure'));
const inventoryFile=path.join(phase,'COMPATIBILITY_SUITES.json'),catalogBytes=fs.readFileSync(inventoryFile),inventory=JSON.parse(catalogBytes);
const frozen=JSON.parse(fs.readFileSync(path.join(root,'frozen-final-oracle-tools.json'))).sha256;
assert.deepEqual(runner.toolHashes(),frozen);assert.deepEqual(initial.oracle_tools_sha256,frozen);
assert.equal(initial.source_revision,inventory.source_revision);assert.equal(initial.source_graph_sha256,inventory.source_graph_sha256);
assert.equal(hash(fs.readFileSync(path.join(root,'repair-native-cli'))),initial.compilerSha256);
const check=()=>{assert.deepEqual(runner.toolHashes(),frozen);assert.equal(hash(fs.readFileSync(inventoryFile)),hash(catalogBytes));guard.check();cp.execFileSync('cargo',['run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--','--check-staged'],{cwd:repo,stdio:'pipe'});guard.check();};
const artifacts=fs.readFileSync(path.join(canonical,'cargo-artifacts.jsonl'),'utf8');
fs.writeFileSync(path.join(root,'native-continuation-cargo-artifacts.jsonl'),artifacts);
const messages=artifacts.split(/\r?\n/).filter(Boolean).map(JSON.parse),guard=runner.compilerGuard(messages,initial.compilerSha256),binaries=runner.executables(messages,inventory);
const preserved=initial.suites.filter(row=>row.conclusion==='success'),receipts=[];
const initialCopy=path.join(root,'native-timeout-attempt');fs.mkdirSync(initialCopy,{recursive:true});
fs.copyFileSync(path.join(canonical,'measurement.json'),path.join(initialCopy,'measurement.json'));
fs.copyFileSync(path.join(root,'repair-acceptance.json'),path.join(initialCopy,'repair-acceptance.json'));
check();
for(const row of preserved){
 const suite=inventory.suites.find(suite=>suite.harness===row.harness),binary=binaries.find(binary=>binary.harness===row.harness);
 assert(suite&&binary);assert.equal(hash(fs.readFileSync(path.join(canonical,row.log))),row.log_sha256);
 assert.deepEqual(runner.summary(fs.readFileSync(path.join(canonical,row.log),'utf8'),row.test_names.length),{passed:row.passed,failed:0,ignored:0,filtered:0});
 assert.deepEqual(runner.testNames(cp.execFileSync(binary.executable,['--list'],{encoding:'utf8'})),row.test_names);
 assert.deepEqual(runner.testNames(cp.execFileSync(binary.executable,['--list','--ignored'],{encoding:'utf8'})),[...suite.ignored_tests].sort());
 receipts.push({harness:row.harness,testExecutableSha256:hash(fs.readFileSync(binary.executable)),logSha256:row.log_sha256,compiledCatalogRechecked:true});
}
const segments=[],all=[...preserved],already=new Set(preserved.map(row=>row.harness)),retry='backend/bluets/tests/ge5_generator_switch_family.rs';
async function segment(name,selected,jobs){
 const output=path.join(root,name);fs.mkdirSync(output);
 const report={...initial,suites:[],suite_jobs:jobs,started_at:new Date().toISOString(),finished_at:null,conclusion:'in_progress',error:undefined,collection_scope:'Source-bound continuation subset; this segment alone is not the complete case denominator.',collection_mode:'immutable-source-bound-subset',execution_order:selected.map(s=>s.harness),runner_script_sha256:hash(fs.readFileSync(__filename))};
 const environment={...process.env,RUST_TEST_THREADS:'1',BLUEICE_GE5_EXPECTED_COMPILER_SHA256:initial.compilerSha256,BLUEICE_CALLABLE_SOURCE_REVISION:initial.source_revision};
 for(const [key,suffix]of [['BLUEICE_GC3_REPORT_DIRECTORY','gc3'],['BLUEICE_GE5_ROLE_REPORT_DIRECTORY','reports'],['BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'],['BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent-observations'],['BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json']]){environment[key]=path.join(output,'captures',suffix);fs.mkdirSync(key.endsWith('DIRECTORY')?environment[key]:path.dirname(environment[key]),{recursive:true});}
 const save=()=>{fs.writeFileSync(path.join(output,'measurement.json'),JSON.stringify(report,null,2)+'\n');const current=path.join(output,'current.json');if(fs.existsSync(current))fs.copyFileSync(current,path.join(canonical,'current.json'));};
 save();check();
 try{await runner.runSuites({binaries:selected,inventory:{...inventory,suites:selected.map(binary=>inventory.suites.find(suite=>suite.harness===binary.harness))},output,root:repo,report,save,checkCompiler:guard.check,jobs,environment});check();report.finished_at=new Date().toISOString();report.conclusion='success';save();}
 catch(error){report.finished_at=new Date().toISOString();report.conclusion='failure';report.error=error.stack;save();throw error;}
 for(const row of report.suites){
  const label=name+'-'+row.log;fs.copyFileSync(path.join(output,row.log),path.join(canonical,label));
  assert.equal(hash(fs.readFileSync(path.join(canonical,label))),row.log_sha256);
  all.push({...row,log:label,source_segment:name});
 }
 segments.push({directory:name,measurementSha256:hash(fs.readFileSync(path.join(output,'measurement.json'))),suites:report.suites.length,suite_jobs:jobs,rust_test_threads:1,conclusion:'success'});
}
(async()=>{
 await segment('repair-native-isolated-family',binaries.filter(binary=>binary.harness===retry),1);
 await segment('repair-native-continuation',binaries.filter(binary=>!already.has(binary.harness)&&binary.harness!==retry),2);
 check();assert.equal(all.length,inventory.suites.length);assert.equal(new Set(all.map(row=>row.harness)).size,inventory.suites.length);
 const ordered=inventory.suites.map(suite=>all.find(row=>row.harness===suite.harness));
 assert(ordered.every(row=>row.conclusion==='success'&&row.failed===0&&row.ignored===0&&row.filtered===0));
 const final={...initial,initial_execution_plan:initial.execution_order,initial_attempt_execution_order:initial.suites.map(s=>s.harness),execution_order:all.map(s=>s.harness),execution_order_scope:'Successful suite observations in collection order; the original failed attempt order is retained separately.',suites:ordered,conclusion:'success',error:undefined,finished_at:new Date().toISOString(),collection_mode:'complete-catalog-across-immutable-source-bound-segments',continuation_script_sha256:hash(fs.readFileSync(__filename)),segments:[{directory:'repair-native',initialMeasurement:'native-timeout-attempt/measurement.json',retainedSuccessfulSuites:preserved.length,suite_jobs:4,rust_test_threads:1},...segments],continuationValidation:{sourceUnchanged:true,oracleToolsUnchanged:true,compilerUnchanged:true,retainedRows:receipts,reason:'One of the363 generator-switch configurations hit the unchanged1000ms VM timeout under four-suite parallel load. The entire failed363-configuration family reran alone on the original compiled artifact. Remaining suites use two workers. No source, expected output, tool or timeout budget changed; the original failure is retained.'}};
 fs.writeFileSync(path.join(canonical,'measurement.json'),JSON.stringify(final,null,2)+'\n');
 console.log(JSON.stringify({conclusion:final.conclusion,suites:ordered.length,functions:ordered.reduce((sum,row)=>sum+row.passed,0),segments:final.segments}));
})().catch(error=>{console.error(error);process.exitCode=1;});
