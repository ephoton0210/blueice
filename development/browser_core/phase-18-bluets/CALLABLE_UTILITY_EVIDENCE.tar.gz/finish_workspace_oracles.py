from pathlib import Path
import datetime,hashlib,json,os,subprocess
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-utility-followup-20261110')
state=json.loads((root/'repair-acceptance.json').read_text());assert state['conclusion']=='success' and state['workspace']['failed']==state['workspace']['filtered']==0
compiler=root/'repair-workspace-cli';digest=hashlib.sha256(compiler.read_bytes()).hexdigest();assert digest==state['workspaceCompilerSha256']
env=dict(os.environ,BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn',BLUEICE_CALLABLE_UTILITIES_COMPILER=str(compiler),BLUEICE_CALLABLE_SOURCE_REVISION=state['sourceRevision'],BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS=str(root/'repair-workspace-capture/utilities'),BLUEICE_GE5_EXPECTED_COMPILER_SHA256=digest,FORCE_COLOR='0')
command=['node',str(repo/'development/browser_core/phase-18-bluets/tools/verify_callable_utilities.cjs')];log=root/'repair-workspace-utility-oracles.log'
with log.open('wb') as output:result=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
state['steps'].append({'label':'workspace-utility-oracles','command':command,'exit':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'compilerSha256':digest,'sourceRevision':state['sourceRevision']})
if result.returncode:state.update(conclusion='failure',stage='workspace-utility-oracles')
else:state['additionalOracleCompletedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/'repair-acceptance.json').write_text(json.dumps(state,indent=2)+'\n');assert result.returncode==0
print('Actual workspace compiler utility declarations/consumers/syntax/runtime pass')
