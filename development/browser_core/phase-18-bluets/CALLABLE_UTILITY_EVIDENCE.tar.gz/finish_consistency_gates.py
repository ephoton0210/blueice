from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-utility-followup-20261110');phase=repo/'development/browser_core/phase-18-bluets'
state=json.loads((root/'repair-acceptance.json').read_text());frozen=json.loads((root/'frozen-source-preflight.json').read_text())
assert state['sourceRevision']==frozen['sourceRevision'] and state['conclusion']=='failure' and state['stage']=='python-tools'
assert state['error']=='''NameError("name 'cargo' is not defined")'''
assert state['workspace']['failed']==state['workspace']['filtered']==0
assert state['steps'][-1]['label']=='python-tools' and state['steps'][-1]['exit']==0 and all(row['exit']==0 for row in state['steps'])
receipt=root/'workspace-finalization-setup-failure';receipt.mkdir();shutil.copy2(root/'repair-acceptance.json',receipt/'state-before-resume.json');shutil.copy2(root/'workspace-driver.log',receipt/'trace.log');shutil.copy2(root/'finish_workspace_gates.py',receipt/'original-driver.py')
state.setdefault('driverSetupFailures',[]).append({'stage':'after-successful-workspace-fmt-clippy-node-python-before-consistency','error':state['error'],'finishedAt':state.get('finishedAt'),'driver':'finish_workspace_gates.py','driverSha256':hashlib.sha256((root/'finish_workspace_gates.py').read_bytes()).hexdigest(),'trace':'workspace-driver.log','scope':'Orchestration variable missing after all test/check processes passed. Resume only the four pending consistency commands; no test results replaced.'})
state.update(conclusion='in_progress',stage='final-consistency');state.pop('error',None);state.pop('finishedAt',None)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',FORCE_COLOR='0',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn')
cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
def save():(root/'repair-acceptance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,command):
 state['stage']=label;save();log=root/('repair-'+label+'.log')
 with log.open('wb') as out:result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':command,'exit':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
 if result.returncode:raise RuntimeError(label+' failed')
try:
 for label,command in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,command)
 state.update(stage='local-complete-awaiting-publication',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as error:
 state.update(conclusion='failure',error=repr(error),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
