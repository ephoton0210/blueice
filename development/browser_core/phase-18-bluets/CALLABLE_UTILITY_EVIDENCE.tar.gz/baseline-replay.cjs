const fs=require('fs'),path=require('path'),cp=require('child_process'),crypto=require('crypto');
const root=__dirname,repo='/Users/ephoton/git/blueice-bluets';
const compiler='/private/tmp/bluets-next-project-20261110/repair-native-cli';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const hash=sha(fs.readFileSync(compiler));if(hash!=='474b9499791c49cc8ca29572503b5d14dc619edea66d936286f71d50543ab1fd')throw Error('baseline compiler changed');
const folder=repo+'/backend/bluets/tests/fixtures/callable_utilities';
const bytes=fs.readFileSync(folder+'/cases.json'),input=JSON.parse(bytes),reference=JSON.parse(fs.readFileSync(folder+'/reference.json'));
if(sha(bytes)!==reference.inputSha256)throw Error('input changed');
const report={schema:1,sourceRevision:'backend-tree:afe0fa1eb02894b7d618fc90edaad8af4bee46b4',compilerSha256:hash,inputSha256:reference.inputSha256,cases:[]};
function canonical(v){v=v.typescript||v;return {code:v.code,message:v.message,file:v.span?.module||null,position:v.position||null,relatedInformation:(v.relatedInformation||[]).map(canonical)};}
for(const expected of reference.cases){
 const row=input.cases.find(x=>x.id===expected.form),profile=input.profiles.find(x=>x.id===expected.profile);
 const cwd=path.join(root,'baseline-replay',profile.id,row.id);fs.mkdirSync(cwd,{recursive:true});fs.writeFileSync(cwd+'/main.ts',row.source);fs.writeFileSync(cwd+'/tsconfig.json',JSON.stringify({compilerOptions:{...input.options,...profile.compilerOptions,outDir:'dist'},files:['main.ts']}));
 const r=cp.spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});if(r.error||r.status===null)throw r.error||Error('terminated');
 fs.writeFileSync(cwd+'/stdout.log',r.stdout);fs.writeFileSync(cwd+'/stderr.log',r.stderr);
 const actual={accepts:r.status===0,diagnostics:r.stderr.trim()?r.stderr.trim().split('\n').map(x=>canonical(JSON.parse(x))):[],declarations:fs.existsSync(cwd+'/dist')?Object.fromEntries(fs.readdirSync(cwd+'/dist').filter(x=>x.endsWith('.d.ts')).map(x=>[x,fs.readFileSync(cwd+'/dist/'+x,'utf8')])):{}};
 report.cases.push({id:expected.id,...actual,agrees:actual.accepts===expected.accepts&&JSON.stringify(actual.diagnostics)===JSON.stringify(expected.diagnostics)&&JSON.stringify(actual.declarations)===JSON.stringify(expected.declarations)});
}
if(sha(fs.readFileSync(compiler))!==hash)throw Error('compiler changed');
report.comparisons=report.cases.length;report.agreements=report.cases.filter(x=>x.agrees).length;report.accepted=report.cases.filter(x=>x.accepts).length;report.conclusion='completed-baseline';fs.writeFileSync(root+'/baseline-replay.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({comparisons:report.comparisons,agreements:report.agreements,accepted:report.accepted}));
