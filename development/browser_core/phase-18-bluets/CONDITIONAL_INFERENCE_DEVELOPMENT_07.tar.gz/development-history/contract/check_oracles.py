# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Replay permanent oracle adapters against one immutable candidate executable."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent.parent
output = root / 'oracles-current-1'
output.mkdir()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
compiler = output / 'actual-bluetsc'
shutil.copy2(repo / 'target/debug/bluetsc', compiler)
compiler.chmod(0o555)
source_manifest = root / 'preflight-2/source-manifest.json'
source = json.loads(source_manifest.read_text())
assert all(sha(repo / name) == digest for name, digest in source.items())
revision = 'source-manifest-sha256:' + sha(source_manifest)
environment = dict(os.environ,
    BLUEICE_BLUETSC_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'),
    BLUEICE_ACORN_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn'),
    BLUEICE_CONDITIONAL_INFERENCE_COMPILER=str(compiler),
    BLUEICE_CONDITIONAL_INFERENCE_EXPECTED_COMPILER_SHA256=sha(compiler),
    BLUEICE_CONDITIONAL_INFERENCE_OBSERVATIONS=str(output / 'observations'),
    BLUEICE_CONDITIONAL_INFERENCE_SOURCE_REVISION=revision)
state = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'sourceRevision': revision, 'compilerSha256': sha(compiler),
         'conclusion': 'in_progress', 'steps': []}
try:
    for script, args in [('record_conditional_inference.cjs', ['--verify']),
                         ('verify_conditional_inference.cjs', [])]:
        state['stage'] = script
        (output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
        log = output / (script + '.log')
        print('START', script, flush=True)
        command = ['node', str(repo / 'development/browser_core/phase-18-bluets/tools' / script), *args]
        with log.open('wb') as stream:
            result = subprocess.run(command, cwd=repo, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT)
        state['steps'].append({'script': script, 'command': command,
                               'exit': result.returncode, 'log': log.name,
                               'sha256': sha(log)})
        print('END', script, result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError(script + ' failed')
    assert all(sha(repo / name) == digest for name, digest in source.items())
    state.update(conclusion='success', stage='complete')
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
sys.exit(0 if state['conclusion'] == 'success' else 1)
