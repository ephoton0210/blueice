type ExternalInfer<T> = T extends { value: infer U } ? U : never;
