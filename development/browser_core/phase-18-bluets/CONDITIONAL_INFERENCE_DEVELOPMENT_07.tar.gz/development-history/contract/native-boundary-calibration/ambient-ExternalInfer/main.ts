export const result: ExternalInfer<{ value: string }> = "ok";
