type ExternalPair<T> = T extends [infer A, infer B] ? [A, B] : never;
