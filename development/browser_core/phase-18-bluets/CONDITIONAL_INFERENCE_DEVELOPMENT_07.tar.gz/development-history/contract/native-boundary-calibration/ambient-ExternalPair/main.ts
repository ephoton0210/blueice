export const result: ExternalPair<[string, number]> = ["ok", 2];
