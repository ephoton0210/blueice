type Infer<T> = T extends [...infer R, infer L] ? [R, L] : "miss";
declare const value: Infer<[string, number, boolean]>;
export const result = value;
