type Infer<T> = T extends readonly [infer A, infer B] ? [A, B] : never;
export const result: Infer<readonly [string, number]> = ["ok", 2];
