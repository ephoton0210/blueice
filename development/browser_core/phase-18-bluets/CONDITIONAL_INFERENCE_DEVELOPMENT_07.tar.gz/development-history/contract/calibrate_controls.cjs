// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Controls are calibrated independently and never enter direct agreement counts.
const fs = require('node:fs'), path = require('node:path');
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const root = __dirname, repo = path.resolve(root, '../..');
const implementation = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/lib/typescript.js');
const ts = require(implementation), sha = data => createHash('sha256').update(data).digest('hex');
const common = require(path.join(repo, 'development/browser_core/phase-18-bluets/tools/symbolic_keys/common.cjs'));
const input = fs.readFileSync(path.join(root, 'boundary-controls.json'));
const output = path.join(root, 'native-boundary-calibration');
fs.mkdirSync(output);
fs.writeFileSync(path.join(output, 'boundary-controls.json'), input);
fs.copyFileSync(__filename, path.join(output, 'calibrate_controls.cjs'));
const rows = [];
for (const row of JSON.parse(input).controls) {
    const cwd = path.join(output, row.id);
    fs.mkdirSync(cwd);
    fs.writeFileSync(path.join(cwd, 'main.ts'), row.source);
    const names = [path.join(cwd, 'main.ts')];
    if (row.declaration) {
        fs.writeFileSync(path.join(cwd, 'owner.d.ts'), row.declaration + '\n');
        names.push(path.join(cwd, 'owner.d.ts'));
    }
    const converted = ts.convertCompilerOptionsFromJson({strict: true, target: 'ES2022',
        module: 'CommonJS', lib: ['ES5'], types: [], noEmit: true}, cwd);
    assert.deepEqual(converted.errors, []);
    const program = ts.createProgram(names, converted.options);
    const diagnostics = ts.getPreEmitDiagnostics(program).map(value => common.diagnostic(ts, value, cwd));
    assert.equal(!diagnostics.length, row.kind !== 'runtime-authority', row.id);
    if (row.kind === 'runtime-authority') assert.deepEqual(diagnostics.map(value => value.code), [2693]);
    rows.push({id: row.id, accepts: !diagnostics.length, diagnostics});
}
const result = {typescript: ts.version, implementationSha256: sha(fs.readFileSync(implementation)),
    inputSha256: sha(input), controls: rows, directAgreementCredit: 0};
fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({controls: rows.length, accepts: rows.filter(row => row.accepts).length,
    rejects: rows.filter(row => !row.accepts).length, directAgreementCredit: 0}));
