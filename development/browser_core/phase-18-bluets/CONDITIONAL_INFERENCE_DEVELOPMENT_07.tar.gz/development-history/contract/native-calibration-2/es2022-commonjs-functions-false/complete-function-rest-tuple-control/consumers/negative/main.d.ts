export declare const result: [a: string, ...tail: number[]];
export declare const check: [a: string, ...tail: number[]];
