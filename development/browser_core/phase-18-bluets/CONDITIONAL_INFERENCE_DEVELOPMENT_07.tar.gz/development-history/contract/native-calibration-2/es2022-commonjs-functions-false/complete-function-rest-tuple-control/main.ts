type Infer<T> = T extends (...args: infer A) => void ? A : "miss";
declare const value: Infer<(a: string, ...tail: number[]) => void>;
export const result = value;
export const check: [a: string, ...tail: number[]] = result;
