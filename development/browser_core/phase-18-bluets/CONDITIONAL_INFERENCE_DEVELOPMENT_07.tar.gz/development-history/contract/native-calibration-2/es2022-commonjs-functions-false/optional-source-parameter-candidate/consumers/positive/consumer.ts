import { result } from "./main";
const output: string | undefined = result;
const input0: typeof result = "ok";
const input1: typeof result = undefined;
