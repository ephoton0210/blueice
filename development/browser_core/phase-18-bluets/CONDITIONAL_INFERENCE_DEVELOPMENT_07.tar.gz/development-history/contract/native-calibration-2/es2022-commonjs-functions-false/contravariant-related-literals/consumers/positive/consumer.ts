import { result } from "./main";
const output: "b" = result;
const input0: typeof result = "b";
