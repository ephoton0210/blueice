export declare const result: "miss";
export declare const check: "miss";
