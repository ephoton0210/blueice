export declare const result: never;
export declare const check: never;
