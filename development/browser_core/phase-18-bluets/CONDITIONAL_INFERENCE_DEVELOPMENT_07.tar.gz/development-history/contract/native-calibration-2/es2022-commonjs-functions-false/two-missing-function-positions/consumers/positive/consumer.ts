import { result } from "./main";
const output: [unknown, unknown] = result;
const input0: typeof result = [42, {}];
