type Infer<T> = T extends (a: infer A, b: infer B) => void ? [A, B] : "miss";
declare const value: Infer<(a: string) => void>;
export const result = value;
export const check: [string, unknown] = result;
