import { result } from "./main";
const output: 1 | 2 = result;
const input0: typeof result = 1;
const input1: typeof result = 2;
