import { result } from "./main";
const output: "last" = result;
const input0: typeof result = "last";
