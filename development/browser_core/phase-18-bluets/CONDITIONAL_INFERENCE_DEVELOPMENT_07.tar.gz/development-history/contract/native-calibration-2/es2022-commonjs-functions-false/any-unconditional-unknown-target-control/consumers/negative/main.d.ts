export declare const result: 1;
export declare const check: 1;
