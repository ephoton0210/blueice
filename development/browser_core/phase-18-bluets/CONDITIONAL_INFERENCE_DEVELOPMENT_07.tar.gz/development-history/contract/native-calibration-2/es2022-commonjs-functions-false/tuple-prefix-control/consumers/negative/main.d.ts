export declare const result: [string, [number, boolean]];
export declare const check: [string, [number, boolean]];
