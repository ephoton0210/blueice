import { result } from "./main";
const output: [a: string, ...tail: number[]] = result;
const input0: typeof result = ["ok", 1, 2];
