import { result } from "./main";
const output: [string, unknown] = result;
const input0: typeof result = ["ok", {}];
