type Infer<T> = T extends (x: infer U) => infer U ? U : "miss";
function identity<T>(value: T): T { return value; }
export const result = identity<Infer<(x: string) => "ok">>("ok");
