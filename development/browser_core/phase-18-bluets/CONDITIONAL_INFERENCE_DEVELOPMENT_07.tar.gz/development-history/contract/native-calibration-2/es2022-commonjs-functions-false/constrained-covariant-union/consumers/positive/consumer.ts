import { result } from "./main";
const output: "a" | "b" = result;
const input0: typeof result = "a";
const input1: typeof result = "b";
