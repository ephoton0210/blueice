import { result } from "./main";
const bad: typeof result = [["ok", "wrong"], true];
