export declare const result: "b";
export declare const check: "b";
