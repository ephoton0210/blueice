export declare const result: "a" | "b";
export declare const check: "a" | "b";
