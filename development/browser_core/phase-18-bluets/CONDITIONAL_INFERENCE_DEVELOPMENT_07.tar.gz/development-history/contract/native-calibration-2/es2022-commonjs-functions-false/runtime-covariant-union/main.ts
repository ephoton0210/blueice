type Infer<T> = T extends { a: infer U; b: infer U } ? U : "miss";
function identity<T>(value: T): T { return value; }
export const result = identity<Infer<{ a: string; b: number }>>("ok");
