import { result } from "./main";
const output: { a: string; b: number } = result;
const input0: typeof result = { a: "ok", b: 2 };
