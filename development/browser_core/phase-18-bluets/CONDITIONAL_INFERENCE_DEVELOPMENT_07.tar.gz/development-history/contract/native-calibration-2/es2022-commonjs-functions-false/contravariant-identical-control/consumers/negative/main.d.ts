export declare const result: string;
export declare const check: string;
