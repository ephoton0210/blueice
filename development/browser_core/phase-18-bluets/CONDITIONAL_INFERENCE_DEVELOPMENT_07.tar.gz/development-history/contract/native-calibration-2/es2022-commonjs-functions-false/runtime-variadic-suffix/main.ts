type Infer<T> = T extends [...infer R, infer L] ? [R, L] : "miss";
function identity<T>(value: T): T { return value; }
export const result = identity<Infer<[string, number, boolean]>>([["ok", 2], true]);
