export declare const result: 2;
export declare const check: 2;
