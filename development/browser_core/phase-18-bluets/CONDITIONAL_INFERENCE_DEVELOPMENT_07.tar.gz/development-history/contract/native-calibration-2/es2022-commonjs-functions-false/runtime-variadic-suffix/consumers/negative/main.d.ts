export declare const result: [[string, number], boolean];
