type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";
function identity<T>(value: T): T { return value; }
export const result = identity<Infer<{ a: (x: "a" | "b") => void; b: (x: "b" | "c") => void }>>("b");
