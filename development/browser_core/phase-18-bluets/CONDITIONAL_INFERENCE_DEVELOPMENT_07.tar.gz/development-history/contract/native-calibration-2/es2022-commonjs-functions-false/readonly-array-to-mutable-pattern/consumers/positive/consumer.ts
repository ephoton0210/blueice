import { result } from "./main";
const output: "miss" = result;
const input0: typeof result = "miss";
