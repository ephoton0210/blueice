type Infer<T> = T extends (a: infer A, b: infer B) => void ? [A, B] : "miss";
declare const value: Infer<() => void>;
export const result = value;
export const check: [unknown, unknown] = result;
