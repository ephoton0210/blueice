export declare const result: "b";
