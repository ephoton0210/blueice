import { result } from "./main";
const output: never = result;
