export declare const result: [unknown, unknown];
export declare const check: [unknown, unknown];
