import { result } from "./main";
const output: "ok" = result;
const input0: typeof result = "ok";
