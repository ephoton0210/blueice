export declare const result: "ok";
export declare const check: "ok";
