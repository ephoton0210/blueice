type Infer<T> = T extends (infer U)[] ? U : "miss";
declare const value: Infer<readonly string[]>;
export const result = value;
export const check: "miss" = result;
