"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.result = void 0;
function identity(value) { return value; }
exports.result = identity("ok");

var check = module.exports.result;
if (JSON.stringify(check) !== JSON.stringify("ok")) throw new Error("unexpected runtime value");
