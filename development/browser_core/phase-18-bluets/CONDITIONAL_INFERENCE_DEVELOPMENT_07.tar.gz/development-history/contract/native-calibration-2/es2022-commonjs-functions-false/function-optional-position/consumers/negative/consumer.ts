import { result } from "./main";
const bad: string = result;
