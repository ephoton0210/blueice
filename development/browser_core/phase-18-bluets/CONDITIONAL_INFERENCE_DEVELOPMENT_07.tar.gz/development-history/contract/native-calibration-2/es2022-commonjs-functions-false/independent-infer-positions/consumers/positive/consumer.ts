import { result } from "./main";
const output: [string, number] = result;
const input0: typeof result = ["ok", 2];
