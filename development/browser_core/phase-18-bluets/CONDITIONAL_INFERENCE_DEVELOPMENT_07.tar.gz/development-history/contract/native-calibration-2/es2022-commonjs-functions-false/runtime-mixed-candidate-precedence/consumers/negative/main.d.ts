export declare const result: "ok";
