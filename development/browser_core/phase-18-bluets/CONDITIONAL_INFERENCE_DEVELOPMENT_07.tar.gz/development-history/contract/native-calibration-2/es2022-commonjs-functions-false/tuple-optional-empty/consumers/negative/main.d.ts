export declare const result: [unknown, unknown[]];
