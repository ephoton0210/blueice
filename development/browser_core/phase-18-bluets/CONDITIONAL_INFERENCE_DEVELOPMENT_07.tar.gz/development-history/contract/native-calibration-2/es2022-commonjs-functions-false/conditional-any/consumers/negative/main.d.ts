export declare const result: 1 | 2;
export declare const check: 1 | 2;
