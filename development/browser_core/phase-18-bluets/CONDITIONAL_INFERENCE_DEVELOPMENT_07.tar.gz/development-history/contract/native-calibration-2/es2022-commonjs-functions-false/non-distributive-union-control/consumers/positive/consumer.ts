import { result } from "./main";
const output: 2 = result;
const input0: typeof result = 2;
