type Infer<T> = T extends { a: (infer U)[]; b: (infer U)[] } ? U : "miss";
declare const value: Infer<{ a: string[]; b: number[] }>;
export const result = value;
export const check: string | number = result;
