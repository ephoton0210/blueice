import { result } from "./main";
const output: string | number = result;
const input0: typeof result = "ok";
const input1: typeof result = 2;
