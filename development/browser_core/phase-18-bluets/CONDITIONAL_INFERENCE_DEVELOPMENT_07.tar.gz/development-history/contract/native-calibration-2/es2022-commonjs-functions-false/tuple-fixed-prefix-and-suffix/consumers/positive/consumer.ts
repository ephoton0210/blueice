import { result } from "./main";
const output: [boolean] = result;
const input0: typeof result = [true];
