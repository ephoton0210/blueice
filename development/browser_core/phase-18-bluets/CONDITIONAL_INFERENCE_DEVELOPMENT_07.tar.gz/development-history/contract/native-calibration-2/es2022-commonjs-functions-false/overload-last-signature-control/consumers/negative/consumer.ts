import { result } from "./main";
const bad: typeof result = "first";
