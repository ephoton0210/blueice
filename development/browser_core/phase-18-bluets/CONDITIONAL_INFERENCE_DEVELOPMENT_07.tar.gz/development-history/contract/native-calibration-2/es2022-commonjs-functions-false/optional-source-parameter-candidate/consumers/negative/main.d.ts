export declare const result: string | undefined;
export declare const check: string | undefined;
