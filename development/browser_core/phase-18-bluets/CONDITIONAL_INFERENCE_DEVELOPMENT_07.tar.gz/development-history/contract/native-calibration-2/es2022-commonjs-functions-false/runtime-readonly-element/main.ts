type Infer<T> = T extends readonly (infer U)[] ? U : "miss";
function identity<T>(value: T): T { return value; }
export const result = identity<Infer<readonly string[]>>("ok");
