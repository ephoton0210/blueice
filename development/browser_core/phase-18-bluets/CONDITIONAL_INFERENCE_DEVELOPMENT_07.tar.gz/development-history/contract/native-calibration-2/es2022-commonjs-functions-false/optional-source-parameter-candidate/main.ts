type Infer<T> = T extends (a: infer A) => void ? A : "miss";
declare const value: Infer<(a?: string) => void>;
export const result = value;
export const check: string | undefined = result;
