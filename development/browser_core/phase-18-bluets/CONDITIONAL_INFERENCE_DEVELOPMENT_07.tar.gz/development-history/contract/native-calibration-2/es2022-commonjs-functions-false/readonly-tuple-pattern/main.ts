type Infer<T> = T extends readonly [infer A, infer B] ? [A, B] : "miss";
declare const value: Infer<readonly [string, number]>;
export const result = value;
export const check: [string, number] = result;
