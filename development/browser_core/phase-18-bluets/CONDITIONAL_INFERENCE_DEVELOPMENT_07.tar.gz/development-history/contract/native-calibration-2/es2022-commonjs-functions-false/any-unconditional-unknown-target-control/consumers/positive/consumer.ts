import { result } from "./main";
const output: 1 = result;
const input0: typeof result = 1;
