export declare const result: [string, number];
export declare const check: [string, number];
