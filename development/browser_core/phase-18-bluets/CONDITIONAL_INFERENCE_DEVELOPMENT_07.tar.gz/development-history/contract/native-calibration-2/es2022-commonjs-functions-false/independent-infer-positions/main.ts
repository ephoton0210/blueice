type Infer<T> = T extends (x: infer A) => infer B ? [A, B] : "miss";
declare const value: Infer<(x: string) => number>;
export const result = value;
export const check: [string, number] = result;
