type Infer<T> = T extends { a: (f: (x: infer U) => void) => void; b: (f: (x: infer U) => void) => void } ? U : "miss";
declare const value: Infer<{ a: (f: (x: string) => void) => void; b: (f: (x: number) => void) => void }>;
export const result = value;
export const check: string | number = result;
