export declare const result: {
    a: string;
} & {
    b: number;
};
export declare const check: {
    a: string;
    b: number;
};
