import { result } from "./main";
const output: [[string, number], boolean] = result;
const input0: typeof result = [["ok", 2], true];
