type Infer<T> = T extends [string, ...infer R, number] ? R : "miss";
declare const value: Infer<[string, boolean, number]>;
export const result = value;
export const check: [boolean] = result;
