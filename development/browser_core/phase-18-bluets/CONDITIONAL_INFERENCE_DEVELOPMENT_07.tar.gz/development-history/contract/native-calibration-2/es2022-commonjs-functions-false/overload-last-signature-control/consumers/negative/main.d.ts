export declare const result: "last";
export declare const check: "last";
