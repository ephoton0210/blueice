export declare const result: [string, unknown];
export declare const check: [string, unknown];
