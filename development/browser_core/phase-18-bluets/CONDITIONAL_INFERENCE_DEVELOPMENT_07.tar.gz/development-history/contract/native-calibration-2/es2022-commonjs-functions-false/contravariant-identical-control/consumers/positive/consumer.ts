import { result } from "./main";
const output: string = result;
const input0: typeof result = "ok";
