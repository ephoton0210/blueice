type Infer<T> = T extends [...infer R, infer L] ? [R, L] : "miss";
declare const value: Infer<[]>;
export const result = value;
export const check: "miss" = result;
