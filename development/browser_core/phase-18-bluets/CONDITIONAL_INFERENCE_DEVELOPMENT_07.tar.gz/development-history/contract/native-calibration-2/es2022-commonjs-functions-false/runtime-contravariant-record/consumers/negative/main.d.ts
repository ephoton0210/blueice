export declare const result: {
    a: string;
} & {
    b: number;
};
