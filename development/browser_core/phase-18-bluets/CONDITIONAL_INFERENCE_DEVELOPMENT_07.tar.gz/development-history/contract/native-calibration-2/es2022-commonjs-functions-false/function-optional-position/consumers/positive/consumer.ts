import { result } from "./main";
const output: unknown = result;
const input0: typeof result = { any: true };
