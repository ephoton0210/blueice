export declare const result: [boolean];
export declare const check: [boolean];
