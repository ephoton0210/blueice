// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Native-only calibration; preserve each attempt before production changes.
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path');
const {createHash} = require('node:crypto');
const root = __dirname, repo = path.resolve(root, '../..');
const oracle = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules');
process.env.BLUEICE_BLUETSC_ORACLE = path.join(oracle, 'typescript/bin/tsc');
process.env.BLUEICE_ACORN_ORACLE = path.join(oracle, 'acorn/bin/acorn');
const common = require(path.join(repo, 'development/browser_core/phase-18-bluets/tools/symbolic_keys/common.cjs'));
const {writeSources} = require(path.join(repo, 'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const ctx = common.context(), ts = ctx.ts;
const sha = data => createHash('sha256').update(data).digest('hex');
const inputFile = path.join(root, 'cases.json');
const input = JSON.parse(fs.readFileSync(inputFile)), inputSha256 = sha(fs.readFileSync(inputFile));
const output = path.join(root, process.argv[2] || 'native-calibration-1');
fs.mkdirSync(output);
fs.copyFileSync(inputFile, path.join(output, 'cases.json'));
fs.copyFileSync(__filename, path.join(output, 'calibrate.cjs'));
fs.copyFileSync(path.join(root, 'author.py'), path.join(output, 'author.py'));
const journal = path.join(output, 'observations.jsonl');
const rows = [], libraries = new Map();
let current = null;

try {
    for (const profile of input.profiles) {
        for (const entry of input.cases) {
            const id = profile.id + '/' + entry.id;
            current = {id, phase: 'compile'};
            const cwd = path.join(output, id);
            fs.mkdirSync(cwd, {recursive: true});
            writeSources(cwd, entry);
            const options = {...input.options, ...profile.compilerOptions};
            const config = {compilerOptions: options, files: ['main.ts', ...Object.keys(entry.files)]};
            fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify(config, null, 2) + '\n');
            const parsed = ts.parseJsonConfigFileContent(config, ts.sys, cwd);
            assert.deepEqual(parsed.errors, []);
            const program = ts.createProgram(parsed.fileNames, parsed.options);
            const before = ts.getPreEmitDiagnostics(program), emitted = program.emit();
            const diagnostics = ts.sortAndDeduplicateDiagnostics([...before, ...emitted.diagnostics])
                .map(row => common.diagnostic(ts, row, cwd));
            for (const source of program.getSourceFiles()) {
                if (source.isDeclarationFile && source.fileName.startsWith(path.dirname(ctx.implementation)))
                    libraries.set(path.basename(source.fileName), sha(fs.readFileSync(source.fileName)));
            }
            const accepts = !diagnostics.length;
            const outputs = common.inventory(path.join(cwd, 'dist'));
            const declarations = Object.fromEntries(Object.entries(outputs).filter(([name]) => name.endsWith('.d.ts')));
            assert(accepts || Object.keys(outputs).length === 0, id + ': rejection published outputs');
            const row = {id, accepts, diagnostics, declarations,
                authoredVerdictAgrees: accepts === (entry.nativeExpectedAcceptsByProfile?.[profile.id]
                    ?? entry.nativeExpectedAccepts)};
            fs.writeFileSync(path.join(cwd, 'observation-before-consumers.json'), JSON.stringify(row, null, 2) + '\n');
            current.phase = 'consumers-syntax-runtime';
            if (accepts) Object.assign(row, common.downstream(ctx, cwd, profile, entry, options, outputs));
            rows.push(row);
            fs.appendFileSync(journal, JSON.stringify(row) + '\n');
            if (rows.length % 24 === 0) console.log('CALIBRATED', rows.length, '/', input.cases.length * input.profiles.length);
        }
    }
    assert.equal(sha(fs.readFileSync(inputFile)), inputSha256);
    const result = {schema: 1, typescript: ts.version,
        implementationSha256: sha(fs.readFileSync(ctx.implementation)),
        libraries: Object.fromEntries(libraries), inputSha256,
        comparisons: rows.length, accepted: rows.filter(row => row.accepts).length,
        rejected: rows.filter(row => !row.accepts).length,
        declarationFiles: rows.reduce((n, row) => n + Object.keys(row.declarations).length, 0),
        consumers: rows.reduce((n, row) => n + Object.keys(row.consumers || {}).length, 0),
        syntax: rows.reduce((n, row) => n + Object.keys(row.javascriptSha256 || {}).length, 0),
        runtime: rows.filter(row => row.runtime).length,
        verdictCalibrationQuestions: rows.filter(row => !row.authoredVerdictAgrees).map(row => row.id),
        cases: rows};
    fs.writeFileSync(path.join(output, 'reference.json'), JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
    console.log(JSON.stringify({...result, cases: undefined}));
} catch (error) {
    fs.writeFileSync(path.join(output, 'failure.json'), JSON.stringify({current, error: error.stack,
        completed: rows.length, inputSha256, implementationSha256: sha(fs.readFileSync(ctx.implementation))}, null, 2) + '\n');
    throw error;
}
