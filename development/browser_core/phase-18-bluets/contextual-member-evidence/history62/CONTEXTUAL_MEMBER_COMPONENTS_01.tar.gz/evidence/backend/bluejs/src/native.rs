// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Native call identities and String algorithms from ECMA-262 edition 17.
//! Heap/receiver dispatch stays in the VM; these operations preserve code
//! units and bound string growth before allocating the result.

use crate::{
    heap::{ArrayIteratorKind, TemporalKind, TypedArrayKind},
    primitive, JsString, ObjectId, RuntimeError, Value,
};
use unicode_normalization::UnicodeNormalization;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum AtomicOp {
    Add,
    And,
    CompareExchange,
    Exchange,
    Load,
    Or,
    Store,
    Sub,
    Xor,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum TypedArrayMethod {
    At,
    CopyWithin,
    Every,
    Fill,
    Filter,
    Find,
    FindIndex,
    FindLast,
    FindLastIndex,
    Map,
    LastIndexOf,
    ForEach,
    Includes,
    IndexOf,
    Join,
    Reduce,
    ToLocaleString,
    ReduceRight,
    Reverse,
    Slice,
    Some,
    Sort,
    ToReversed,
    ToSorted,
    With,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Uint8ArrayMethod {
    SetFromBase64,
    SetFromHex,
    ToBase64,
    ToHex,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum NumberMethod {
    ToString,
    LocaleString,
    Fixed,
    Exponential,
    Precision,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum WeakCollectionMethod {
    Add,
    Delete,
    Get,
    GetOrInsert,
    GetOrInsertComputed,
    Has,
    Set,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum MapMethod {
    Clear,
    Delete,
    Entries,
    ForEach,
    Get,
    GetOrInsert,
    GetOrInsertComputed,
    Has,
    Keys,
    Set,
    Values,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SetMethod {
    Add,
    Clear,
    Delete,
    Entries,
    ForEach,
    Has,
    Values,
    Union,
    Intersection,
    Difference,
    SymmetricDifference,
    IsSubsetOf,
    IsSupersetOf,
    IsDisjointFrom,
}

/// The lazy iterator helpers share one native dispatcher. Keeping the method
/// selector as payload avoids growing the global NativeFunction discriminant,
/// whose size is part of each native heap object's footprint.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum IteratorHelperMethod {
    Concat,
    Zip,
    ZipKeyed,
    Chunks,
    Windows,
    Map,
    Filter,
    FlatMap,
    Take,
    Drop,
    Includes,
    Join,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum DateMethod {
    Get(DatePart),
    GetYear,
    GetTime,
    Set(DateSetter),
    SetTime,
    ToIsoString,
    ToJson,
    ToDateString,
    ToString,
    ToTimeString,
    ToLocaleDateString,
    ToLocaleString,
    ToLocaleTimeString,
    ToPrimitive,
    /// `Date.prototype.toTemporalInstant`: ECMA-262's one Temporal member
    /// that lives on a non-Temporal prototype.
    ToTemporalInstant,
    ToUtcString,
    ValueOf,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum DateSetter {
    Date,
    FullYear,
    Hours,
    Milliseconds,
    Minutes,
    Month,
    Seconds,
    Year,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum DatePart {
    Date,
    Day,
    FullYear,
    Hours,
    Milliseconds,
    Minutes,
    Month,
    Seconds,
    TimezoneOffset,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum NativeFunction {
    /// A realm-private embedding callback stored in [`crate::Vm`].
    Host(u32),
    /// A realm-private callback whose opaque key is materialized as a rooted
    /// JavaScript object by the VM, never as a page-visible numeric value.
    HostObjectFactory(u32),
    /// A callback invoked only after the receiver resolves to this family's
    /// VM-minted opaque wrapper.
    HostObjectMethod(u32),
    /// An exact two-wrapper operation returning its original child wrapper.
    HostObjectPairMethod(u32),
    /// VM-owned click-listener registration on one exact host-object family.
    HostClickListenerAdd(u32),
    HostClickListenerRemove(u32),
    /// Can cancel only the currently dispatching VM-owned click event.
    HostClickPreventDefault,
    Function,
    /// The intrinsic constructor reached through an async function's
    /// `constructor` property. It is deliberately not installed as a global.
    AsyncFunction,
    /// The intrinsic `%GeneratorFunction%` and `%AsyncGeneratorFunction%`
    /// constructors (no globals): they compile `function*` / `async function*`
    /// from their arguments.
    GeneratorFunction,
    AsyncGeneratorFunction,
    String,
    Array,
    Date,
    DateNow,
    DateParse,
    DateUtc,
    DateMethod(DateMethod),
    TemporalConstructor(TemporalKind),
    TemporalFrom(TemporalKind),
    /// Shared by `PlainDate`, `PlainDateTime` and `ZonedDateTime`. Like every
    /// Temporal native that several prototypes share, it carries the type of
    /// the prototype it was installed on, which is the type its receiver must
    /// be (`NativeFunction::temporal_receiver_kind`).
    TemporalWithCalendar(TemporalKind),
    TemporalPlainToZonedDateTime(TemporalKind),
    TemporalInstantToZonedDateTimeIso,
    TemporalGetter(TemporalKind, TemporalGetter),
    TemporalZonedDateTimeToLocaleString,
    TemporalInstantAdd,
    TemporalInstantSubtract,
    TemporalInstantRound,
    TemporalInstantUntil,
    TemporalInstantSince,
    TemporalInstantEquals,
    TemporalInstantCompare,
    TemporalInstantToString,
    TemporalInstantToLocaleString,
    TemporalInstantToJson,
    TemporalInstantValueOf,
    TemporalFromEpochMilliseconds,
    TemporalFromEpochNanoseconds,
    TemporalPlainTimeAdd,
    TemporalPlainTimeSubtract,
    TemporalPlainTimeRound,
    TemporalPlainTimeUntil,
    TemporalPlainTimeSince,
    TemporalPlainTimeEquals,
    TemporalPlainTimeCompare,
    TemporalPlainTimeWith,
    TemporalPlainTimeToString,
    TemporalPlainTimeToJson,
    TemporalPlainTimeToLocaleString,
    TemporalPlainTimeValueOf,
    TemporalNowInstant,
    TemporalNowTimeZoneId,
    TemporalNowPlainDateIso,
    TemporalNowPlainDateTimeIso,
    TemporalNowPlainTimeIso,
    TemporalNowZonedDateTimeIso,
    TemporalDurationWith,
    TemporalDurationNegated,
    TemporalDurationAbs,
    TemporalDurationAdd,
    TemporalDurationSubtract,
    TemporalDurationRound,
    TemporalDurationTotal,
    TemporalDurationCompare,
    TemporalDurationToString,
    TemporalDurationToJson,
    TemporalDurationToLocaleString,
    TemporalDurationValueOf,
    /// `Temporal.PlainDate.prototype.with`/`Temporal.PlainDateTime.prototype.with`,
    /// dispatched on the receiver's own `TemporalKind`. The payload is the
    /// type of the prototype the function is installed on, so a
    /// `PlainDateTime` receiver of `PlainDate.prototype.with` is still a
    /// brand-check failure.
    TemporalDateWith(TemporalKind),
    TemporalDateAdd(TemporalKind),
    TemporalDateSubtract(TemporalKind),
    TemporalDateUntil(TemporalKind),
    TemporalDateSince(TemporalKind),
    TemporalDateEquals(TemporalKind),
    TemporalDateCompare(TemporalKind),
    TemporalDateToString(TemporalKind),
    TemporalDateToJson(TemporalKind),
    TemporalDateToLocaleString(TemporalKind),
    TemporalDateValueOf,
    TemporalPlainDateToPlainDateTime,
    TemporalPlainDateToPlainYearMonth,
    TemporalPlainDateToPlainMonthDay,
    TemporalPlainDateTimeToPlainDate,
    TemporalPlainDateTimeToPlainTime,
    TemporalPlainDateTimeWithPlainTime,
    TemporalPlainDateTimeRound,
    /// `Temporal.PlainYearMonth.prototype.*` (Phase 26 Stage 2's
    /// `plain_year_month.rs`/`plain_month_day.rs` slice).
    TemporalYearMonthWith,
    TemporalYearMonthAdd,
    TemporalYearMonthSubtract,
    TemporalYearMonthUntil,
    TemporalYearMonthSince,
    TemporalYearMonthEquals,
    TemporalYearMonthCompare,
    TemporalYearMonthToString,
    TemporalYearMonthToJson,
    TemporalYearMonthToLocaleString,
    TemporalYearMonthValueOf,
    TemporalYearMonthToPlainDate,
    /// `Temporal.PlainMonthDay.prototype.*`. Deliberately no `Add`/
    /// `Subtract`/`Until`/`Since`/`Compare` variants -- the pinned Test262
    /// corpus has no such fixtures for this type (a month-day pair has no
    /// well-ordered total order in general), matching Gecko's own
    /// `PlainMonthDay.cpp`, which defines no such methods either.
    TemporalMonthDayWith,
    TemporalMonthDayEquals,
    TemporalMonthDayToString,
    TemporalMonthDayToJson,
    TemporalMonthDayToLocaleString,
    TemporalMonthDayValueOf,
    TemporalMonthDayToPlainDate,
    /// `Temporal.ZonedDateTime.prototype.*` (Phase 26 Stage 2's
    /// `zoned_date_time.rs` slice, third and final Stage 2 type).
    TemporalZonedDateTimeWith,
    TemporalZonedDateTimeWithTimeZone,
    TemporalZonedDateTimeWithPlainTime,
    TemporalZonedDateTimeAdd,
    TemporalZonedDateTimeSubtract,
    TemporalZonedDateTimeRound,
    TemporalZonedDateTimeUntil,
    TemporalZonedDateTimeSince,
    TemporalZonedDateTimeEquals,
    TemporalZonedDateTimeCompare,
    TemporalZonedDateTimeToString,
    TemporalZonedDateTimeToJson,
    TemporalZonedDateTimeValueOf,
    TemporalZonedDateTimeToInstant,
    TemporalZonedDateTimeToPlainDate,
    TemporalZonedDateTimeToPlainTime,
    TemporalZonedDateTimeToPlainDateTime,
    TemporalZonedDateTimeStartOfDay,
    TemporalZonedDateTimeGetTimeZoneTransition,
    ArrayBuffer,
    ArrayBufferByteLength,
    ArrayBufferDetached,
    ArrayBufferMaxByteLength,
    ArrayBufferResizable,
    ArrayBufferResize,
    ArrayBufferTransfer,
    ArrayBufferTransferToFixedLength,
    ArrayBufferSlice,
    ArrayBufferImmutable,
    ArrayBufferTransferToImmutable,
    ArrayBufferSliceToImmutable,
    ArrayBufferIsView,
    ArrayBufferSpecies,
    SharedArrayBuffer,
    SharedArrayBufferByteLength,
    SharedArrayBufferMaxByteLength,
    SharedArrayBufferGrowable,
    SharedArrayBufferGrow,
    SharedArrayBufferSlice,
    SharedArrayBufferSpecies,
    Atomics(AtomicOp),
    AtomicsIsLockFree,
    AtomicsNotify,
    AtomicsPause,
    AtomicsWait,
    AtomicsWaitAsync,
    DataView,
    DataViewBuffer,
    DataViewByteLength,
    DataViewByteOffset,
    DataViewGet {
        width: usize,
        signed: bool,
        floating: bool,
        bigint: bool,
    },
    DataViewSet {
        width: usize,
        signed: bool,
        floating: bool,
        bigint: bool,
    },
    TypedArray(TypedArrayKind),
    /// The abstract `%TypedArray%` constructor. It exists only as the common
    /// prototype of concrete typed-array constructors and must not construct.
    TypedArrayIntrinsic,
    TypedArrayBuffer,
    TypedArrayByteLength,
    TypedArrayByteOffset,
    TypedArrayLength,
    TypedArraySet,
    TypedArraySubarray,
    TypedArraySpecies,
    TypedArrayToStringTag,
    TypedArrayIterator(ArrayIteratorKind),
    TypedArrayMethod(TypedArrayMethod),
    TypedArrayFrom,
    TypedArrayOf,
    Uint8ArrayFromBase64,
    Uint8ArrayFromHex,
    Uint8ArrayMethod(Uint8ArrayMethod),
    Proxy,
    ProxyRevocable,
    ProxyRevoker(ObjectId),
    Map,
    MapMethod(MapMethod),
    /// `Map.groupBy(items, callback)`.
    MapGroupBy,
    MapSize,
    Set,
    SetMethod(SetMethod),
    SetSize,
    WeakMap,
    WeakSet,
    WeakRef,
    WeakRefDeref,
    FinalizationRegistry,
    FinalizationRegistryRegister,
    FinalizationRegistryUnregister,
    WeakCollectionMethod {
        map: bool,
        method: WeakCollectionMethod,
    },
    ArrayIsArray,
    ArrayAt,
    ArrayFill,
    ArrayCopyWithin,
    ArrayToReversed,
    ArrayToSorted,
    ArrayToSpliced,
    ArrayWith,
    ArrayFlat,
    ArrayFlatMap,
    ArrayOf,
    ArraySpecies,
    /// The `get [Symbol.species]` accessor of `Map`, `Set` and `Promise`,
    /// which (like `ArraySpecies`) just returns its receiver.
    CollectionSpecies,
    ArrayFrom,
    ArrayFromAsync,
    /// A settled Await inside an `Array.fromAsync` run: `state` is the run's
    /// heap-resident state record.
    ArrayFromAsyncResume {
        state: ObjectId,
        rejected: bool,
    },
    ArrayForEach,
    ArrayFilter,
    ArrayMap,
    ArrayFind,
    ArrayFindIndex,
    ArrayFindLast,
    ArrayFindLastIndex,
    ArrayEvery,
    ArraySome,
    ArrayIncludes,
    ArrayReduce,
    ArrayReduceRight,
    ArrayPush,
    ArrayPop,
    ArrayShift,
    ArrayUnshift,
    ArrayReverse,
    ArrayIndexOf,
    ArrayLastIndexOf,
    ArraySlice,
    ArraySplice,
    ArraySort,
    ArrayToLocaleString,
    NumberMethod(NumberMethod),
    Eval,
    IsNaN,
    IsFinite,
    ParseInt,
    ParseFloat,
    EncodeUri {
        component: bool,
    },
    DecodeUri {
        component: bool,
    },
    /// Annex B.2.1 `escape` (`false`) and `unescape` (`true`).
    Escape {
        decode: bool,
    },
    JsonParse,
    JsonStringify,
    JsonRawJson,
    JsonIsRawJson,
    Math(MathMethod),
    Error(&'static str),
    ErrorToString,
    /// `Error.isError`.
    ErrorIsError,
    /// The `get`/`set` halves of the `Error.prototype.stack` accessor.
    ErrorStackGetter,
    ErrorStackSetter,
    /// Test262 exposes this otherwise non-global intrinsic through `$262`.
    AbstractModuleSource,
    AbstractModuleSourceToStringTag,
    Test262(&'static str),
    ToLocaleLowerCase,
    ToLocaleUpperCase,
    LocaleCompare,
    Collator,
    /// The common construction/call boundary of the mandatory ECMA-402
    /// number and date-time services. Formatting algorithms are installed by
    /// their owning implementation slice.
    IntlService(IntlService),
    Locale,
    CanonicalLocales,
    SupportedValuesOf,
    SupportedLocales,
    CollatorCompareGetter,
    CollatorCompare,
    CollatorResolvedOptions,
    DisplayNamesSupportedLocales,
    DisplayNamesOf,
    DisplayNamesResolvedOptions,
    DurationFormatSupportedLocales,
    DurationFormatFormat,
    DurationFormatFormatToParts,
    DurationFormatResolvedOptions,
    NumberFormatSupportedLocales,
    NumberFormatFormatGetter,
    NumberFormatFormat,
    NumberFormatFormatToParts,
    NumberFormatFormatRange,
    NumberFormatFormatRangeToParts,
    NumberFormatResolvedOptions,
    DateTimeFormatSupportedLocales,
    DateTimeFormatFormatGetter,
    DateTimeFormatFormat,
    DateTimeFormatFormatToParts,
    DateTimeFormatFormatRange,
    DateTimeFormatFormatRangeToParts,
    DateTimeFormatResolvedOptions,
    ListFormatSupportedLocales,
    ListFormatFormat,
    ListFormatFormatToParts,
    ListFormatResolvedOptions,
    PluralRulesSupportedLocales,
    PluralRulesSelect,
    PluralRulesSelectRange,
    PluralRulesResolvedOptions,
    SegmenterSupportedLocales,
    SegmenterResolvedOptions,
    SegmenterSegment,
    SegmentsContaining,
    SegmentsIterator,
    SegmentIteratorNext,
    RelativeTimeFormatSupportedLocales,
    RelativeTimeFormatFormat,
    RelativeTimeFormatFormatToParts,
    RelativeTimeFormatResolvedOptions,
    LocaleToString,
    LocaleMaximize,
    LocaleMinimize,
    LocaleGetter(LocaleGetter),
    LocaleInfo(LocaleInfo),
    FromCharCode,
    FromCodePoint,
    Raw,
    Split,
    Replace,
    ReplaceAll,
    Call,
    Apply,
    Bind,
    HasInstance,
    ReflectApply,
    ReflectConstruct,
    FunctionToString,
    ThrowTypeError,
    /// Getters of the legacy own `caller` / `arguments` accessors that a
    /// sloppy ordinary function carries.
    LegacyFunctionCaller,
    LegacyFunctionArguments,
    Empty,
    ObjectToString,
    ObjectToLocaleString,
    ObjectValueOf,
    ObjectIsPrototypeOf,
    /// Annex B legacy accessor helpers on `%Object.prototype%`.
    ObjectDefineAccessor {
        getter: bool,
    },
    ObjectLookupAccessor {
        getter: bool,
    },
    ObjectPrototypeGetter,
    ObjectPrototypeSetter,
    ArrayToString,
    ArrayConcat,
    ArrayJoin,
    ArrayIterator(ArrayIteratorKind),
    ArrayIteratorNext,
    /// `%MapIteratorPrototype%.next` (`map`) or `%SetIteratorPrototype%.next`:
    /// one function per kind, so each rejects the other kind's iterators.
    CollectionIteratorNext {
        map: bool,
    },
    GeneratorNext,
    GeneratorReturn,
    GeneratorThrow,
    AsyncGeneratorNext,
    AsyncGeneratorReturn,
    AsyncGeneratorThrow,
    Promise,
    /// One half of a promise's resolving-function pair (CreateResolvingFunctions).
    /// `state` is the heap record holding the pair's shared [[AlreadyResolved]]
    /// flag, so whichever function runs first disables both.
    PromiseResolvingFunction {
        promise: ObjectId,
        fulfill: bool,
        state: ObjectId,
    },
    /// The executor supplied while `NewPromiseCapability(C)` invokes a
    /// user-provided constructor. The storage object keeps its resolve/reject
    /// pair alive and observable for the enclosing static Promise method.
    PromiseCapabilityExecutor {
        storage: ObjectId,
    },
    AsyncFromSyncFulfill {
        target: ObjectId,
        done: bool,
    },
    AsyncFromSyncReject {
        target: ObjectId,
        record: ObjectId,
    },
    PromiseThen,
    PromiseCatch,
    PromiseFinally,
    PromiseResolve,
    PromiseReject,
    PromiseAll,
    PromiseRace,
    PromiseAny,
    PromiseAllSettled,
    /// `Promise.allKeyed` (`settled: false`) and `Promise.allSettledKeyed`.
    PromiseAllKeyed {
        settled: bool,
    },
    PromiseTry,
    /// A resolve/reject element function of `Promise.all`, `allSettled` or
    /// `any`. `state` is the heap record shared by one combinator call.
    PromiseElement {
        state: ObjectId,
        index: u32,
        kind: PromiseElementKind,
    },
    /// The `thenFinally` (`catch: false`) / `catchFinally` function that
    /// `Promise.prototype.finally` passes to `then`; `state` holds the
    /// `onFinally` callback and the species constructor.
    PromiseFinallyFunction {
        state: ObjectId,
        catch: bool,
    },
    /// The value thunk (`thrower: false`) or thrower function `finally`
    /// hands to its inner `then`; `state` holds the value or reason.
    PromiseValueThunk {
        state: ObjectId,
        thrower: bool,
    },
    PromiseWithResolvers,
    /// The `addInitializer` function of a decorator's context object. `state`
    /// is the heap record holding that decorator application's `finished`
    /// flag and the list of extra initializers it appends to.
    DecoratorAddInitializer {
        state: ObjectId,
    },
    /// `access.get`, `access.set` or `access.has` of a decorator's context
    /// object; `state` holds the private-name owner (or `undefined`) and the
    /// property key or private name it reaches.
    DecoratorAccess {
        op: DecoratorAccessOp,
        state: ObjectId,
    },
    Test262Done,
    Symbol,
    SymbolFor,
    SymbolKeyFor,
    SymbolToString,
    SymbolValueOf,
    SymbolDescription,
    BigInt,
    BigIntToString,
    BigIntValueOf,
    BigIntToLocaleString,
    BigIntAsIntN,
    BigIntAsUintN,
    NumberIsFinite,
    NumberIsInteger,
    NumberIsSafeInteger,
    NumberIsNaN,
    PrimitiveConstructor(bool),
    PrimitiveMethod {
        boolean: bool,
        string: bool,
    },
    Object,
    ObjectMethod(ObjectMethod),
    /// The abstract `Iterator` constructor. It is exposed as a function but
    /// rejects both call and construct evaluation.
    Iterator,
    IteratorFrom,
    IteratorHelper(IteratorHelperMethod),
    IteratorHelperNext,
    IteratorHelperReturn,
    IteratorWrapperNext,
    IteratorWrapperReturn,
    IteratorToArray,
    IteratorForEach,
    IteratorEvery,
    IteratorSome,
    IteratorFind,
    IteratorReduce,
    StringIterator,
    IteratorNext,
    IteratorSelf,
    IteratorDispose,
    IteratorConstructorGetter,
    IteratorConstructorSetter,
    IteratorToStringTagGetter,
    IteratorToStringTagSetter,
    AsyncIteratorSelf,
    /// `%AsyncIteratorPrototype% [ @@asyncDispose ] ( )`.
    AsyncIteratorDispose,
    Pattern(PatternMethod),
    RegExp,
    RegExpEscape,
    RegExpMethod(RegExpMethod),
    RegExpGetter(&'static str),
    /// Annex B legacy static accessors of `%RegExp%`.
    RegExpLegacyGetter(LegacyRegExpStatic),
    RegExpLegacySetter(LegacyRegExpStatic),
    RegExpIteratorNext,
    StringMethod(StringMethod),
    /// The `DisposableStack`/`AsyncDisposableStack` constructors (Explicit
    /// Resource Management). `is_async` selects which brand's internal
    /// slot/prototype the constructor and its methods observe.
    DisposableStack {
        is_async: bool,
    },
    DisposableStackDispose {
        is_async: bool,
    },
    DisposableStackUse {
        is_async: bool,
    },
    DisposableStackAdopt {
        is_async: bool,
    },
    DisposableStackDefer {
        is_async: bool,
    },
    DisposableStackMove {
        is_async: bool,
    },
    DisposableStackDisposedGetter {
        is_async: bool,
    },
    /// The `ShadowRealm` constructor. Its own isolated realm/child `Vm` is
    /// tracked on the host `Vm`, not this tag.
    ShadowRealm,
    ShadowRealmEvaluate,
    ShadowRealmImportValue,
    /// A `WrappedFunctionCreate` exotic callable facade. Its
    /// `[[WrappedTargetFunction]]`/`[[Realm]]` bookkeeping lives in the
    /// owning `Vm`'s `shadow_wrapped_functions` table, keyed by this
    /// object's own identity, so no data belongs on the tag itself.
    ShadowRealmWrappedFunction,
}

/// Which member of a decorator context's `access` object a
/// `NativeFunction::DecoratorAccess` is.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum DecoratorAccessOp {
    Get,
    Set,
    Has,
}

/// Which of a Promise combinator's element functions a
/// `NativeFunction::PromiseElement` is.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum PromiseElementKind {
    /// `Promise.all`'s resolve element: stores the value.
    AllResolve,
    /// `Promise.allSettled`'s onFulfilled: stores `{ status: "fulfilled", value }`.
    AllSettledFulfill,
    /// `Promise.allSettled`'s onRejected: stores `{ status: "rejected", reason }`.
    AllSettledReject,
    /// `Promise.any`'s reject element: stores the reason.
    AnyReject,
}

/// Failures particular to the URI encode/decode abstract operations.  The VM
/// turns malformed input into the realm's `URIError` object, while preserving
/// its normal resource-limit reporting for an oversized result.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum UriCodingError {
    Malformed,
    StringLimit { limit: usize },
}

impl NativeFunction {
    /// Native closures can carry heap identities outside ordinary property
    /// storage.  Keep those identities visible to both allocation protection
    /// and tracing, just like captured JavaScript closures.
    pub(crate) fn references(self) -> Vec<ObjectId> {
        match self {
            Self::ProxyRevoker(proxy) => vec![proxy],
            Self::PromiseResolvingFunction { promise, state, .. } => vec![promise, state],
            Self::PromiseCapabilityExecutor { storage } => vec![storage],
            Self::ArrayFromAsyncResume { state, .. } => vec![state],
            Self::AsyncFromSyncFulfill { target, .. } => vec![target],
            Self::AsyncFromSyncReject { target, record } => vec![target, record],
            Self::PromiseElement { state, .. }
            | Self::PromiseFinallyFunction { state, .. }
            | Self::PromiseValueThunk { state, .. }
            | Self::DecoratorAddInitializer { state }
            | Self::DecoratorAccess { state, .. } => vec![state],
            _ => Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum MathMethod {
    Abs,
    Acos,
    Acosh,
    Asin,
    Asinh,
    Atan,
    Atanh,
    Atan2,
    Ceil,
    Cbrt,
    Cos,
    Cosh,
    Exp,
    Expm1,
    F16round,
    Floor,
    Fround,
    Hypot,
    Imul,
    Log,
    Log1p,
    Log2,
    Log10,
    Max,
    Min,
    Pow,
    Random,
    Round,
    Sign,
    Sin,
    Sinh,
    Sqrt,
    Tan,
    Tanh,
    Trunc,
    SumPrecise,
    Clz32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ObjectMethod {
    Assign,
    FromEntries,
    GroupBy,
    HasOwn,
    Is,
    GetOwnPropertyDescriptor,
    GetOwnPropertyDescriptors,
    DefineProperty,
    DefineProperties,
    Keys,
    Values,
    Entries,
    GetOwnPropertyNames,
    GetOwnPropertySymbols,
    GetPrototypeOf,
    SetPrototypeOf,
    Create,
    OwnKeys,
    IsExtensible,
    PreventExtensions,
    Seal,
    Freeze,
    IsSealed,
    IsFrozen,
    ReflectGet,
    ReflectGetOwnPropertyDescriptor,
    ReflectGetPrototypeOf,
    ReflectDefineProperty,
    ReflectSet,
    ReflectDeleteProperty,
    ReflectPreventExtensions,
    ReflectSetPrototypeOf,
    ReflectIsExtensible,
    ReflectHas,
    HasOwnProperty,
    PropertyIsEnumerable,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum LocaleGetter {
    BaseName,
    Language,
    Script,
    Region,
    Variants,
    Calendar,
    Collation,
    HourCycle,
    CaseFirst,
    Numeric,
    NumberingSystem,
    FirstDayOfWeek,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum TemporalGetter {
    CalendarId,
    DurationYears,
    DurationMonths,
    DurationWeeks,
    DurationDays,
    DurationHours,
    DurationMinutes,
    DurationSeconds,
    DurationMilliseconds,
    DurationMicroseconds,
    DurationNanoseconds,
    DurationSign,
    DurationBlank,
    Year,
    Month,
    MonthCode,
    Day,
    Era,
    EraYear,
    MonthsInYear,
    EpochMilliseconds,
    EpochNanoseconds,
    Hour,
    Minute,
    Second,
    Millisecond,
    Microsecond,
    Nanosecond,
    TimeZoneId,
    DayOfWeek,
    DayOfYear,
    WeekOfYear,
    YearOfWeek,
    DaysInWeek,
    DaysInMonth,
    DaysInYear,
    InLeapYear,
    OffsetNanoseconds,
    Offset,
    HoursInDay,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum LocaleInfo {
    Calendars,
    Collations,
    HourCycles,
    NumberingSystems,
    TextInfo,
    TimeZones,
    WeekInfo,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum IntlService {
    Number,
    DateTime,
    DisplayNames,
    Duration,
    List,
    Plural,
    RelativeTime,
    Segmenter,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum PatternMethod {
    Match,
    MatchAll,
    Search,
}

/// The legacy static RegExp properties, one per internal slot of `%RegExp%`
/// (`RegExp.$1`-`$9` are `Paren(1)`-`Paren(9)`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum LegacyRegExpStatic {
    Input,
    LastMatch,
    LastParen,
    LeftContext,
    RightContext,
    Paren(u8),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RegExpMethod {
    Exec,
    /// Annex B `RegExp.prototype.compile`.
    Compile,
    Test,
    ToString,
    Match,
    MatchAll,
    Search,
    Split,
    Replace,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum StringMethod {
    At,
    CharAt,
    CharCodeAt,
    CodePointAt,
    Concat,
    EndsWith,
    Includes,
    IndexOf,
    LastIndexOf,
    StartsWith,
    Slice,
    Substring,
    IsWellFormed,
    ToWellFormed,
    ToString,
    ValueOf,
    PadStart,
    PadEnd,
    Repeat,
    Trim,
    TrimStart,
    TrimEnd,
    Normalize,
    ToLowerCase,
    ToUpperCase,
    Substr,
    Html {
        tag: &'static str,
        attribute: &'static str,
    },
}

pub(crate) const STRING_METHODS: &[(&str, u32, StringMethod)] = &[
    ("at", 1, StringMethod::At),
    ("charAt", 1, StringMethod::CharAt),
    ("charCodeAt", 1, StringMethod::CharCodeAt),
    ("codePointAt", 1, StringMethod::CodePointAt),
    ("concat", 1, StringMethod::Concat),
    ("endsWith", 1, StringMethod::EndsWith),
    ("includes", 1, StringMethod::Includes),
    ("indexOf", 1, StringMethod::IndexOf),
    ("lastIndexOf", 1, StringMethod::LastIndexOf),
    ("startsWith", 1, StringMethod::StartsWith),
    ("slice", 2, StringMethod::Slice),
    ("substring", 2, StringMethod::Substring),
    ("isWellFormed", 0, StringMethod::IsWellFormed),
    ("toWellFormed", 0, StringMethod::ToWellFormed),
    ("toString", 0, StringMethod::ToString),
    ("valueOf", 0, StringMethod::ValueOf),
    ("padStart", 1, StringMethod::PadStart),
    ("padEnd", 1, StringMethod::PadEnd),
    ("repeat", 1, StringMethod::Repeat),
    ("trim", 0, StringMethod::Trim),
    ("trimStart", 0, StringMethod::TrimStart),
    ("trimEnd", 0, StringMethod::TrimEnd),
    ("normalize", 0, StringMethod::Normalize),
    ("toLowerCase", 0, StringMethod::ToLowerCase),
    ("toUpperCase", 0, StringMethod::ToUpperCase),
    ("substr", 2, StringMethod::Substr),
    (
        "anchor",
        1,
        StringMethod::Html {
            tag: "a",
            attribute: "name",
        },
    ),
    (
        "big",
        0,
        StringMethod::Html {
            tag: "big",
            attribute: "",
        },
    ),
    (
        "blink",
        0,
        StringMethod::Html {
            tag: "blink",
            attribute: "",
        },
    ),
    (
        "bold",
        0,
        StringMethod::Html {
            tag: "b",
            attribute: "",
        },
    ),
    (
        "fixed",
        0,
        StringMethod::Html {
            tag: "tt",
            attribute: "",
        },
    ),
    (
        "fontcolor",
        1,
        StringMethod::Html {
            tag: "font",
            attribute: "color",
        },
    ),
    (
        "fontsize",
        1,
        StringMethod::Html {
            tag: "font",
            attribute: "size",
        },
    ),
    (
        "italics",
        0,
        StringMethod::Html {
            tag: "i",
            attribute: "",
        },
    ),
    (
        "link",
        1,
        StringMethod::Html {
            tag: "a",
            attribute: "href",
        },
    ),
    (
        "small",
        0,
        StringMethod::Html {
            tag: "small",
            attribute: "",
        },
    ),
    (
        "strike",
        0,
        StringMethod::Html {
            tag: "strike",
            attribute: "",
        },
    ),
    (
        "sub",
        0,
        StringMethod::Html {
            tag: "sub",
            attribute: "",
        },
    ),
    (
        "sup",
        0,
        StringMethod::Html {
            tag: "sup",
            attribute: "",
        },
    ),
];

pub(crate) fn argument(args: &[Value], index: usize) -> &Value {
    args.get(index).unwrap_or(&Value::Undefined)
}

pub(crate) fn integer(value: &Value) -> Result<f64, RuntimeError> {
    let number = primitive::number(value)?;
    Ok(if number.is_nan() { 0.0 } else { number.trunc() })
}

pub(crate) fn uint32(number: f64) -> u32 {
    primitive::to_uint32(number)
}

pub(crate) fn length(value: &Value) -> Result<f64, RuntimeError> {
    Ok(integer(value)?.clamp(0.0, 9007199254740991.0))
}

pub(crate) fn append(
    result: &mut JsString,
    part: &JsString,
    limit: usize,
) -> Result<(), RuntimeError> {
    if result
        .byte_len()
        .checked_add(part.byte_len())
        .is_none_or(|bytes| bytes > limit)
    {
        return Err(RuntimeError::StringLimit { limit });
    }
    result.push_str(part);
    Ok(())
}

pub(crate) fn from_codes(
    args: &[Value],
    points: bool,
    limit: usize,
) -> Result<Value, RuntimeError> {
    let mut result = JsString::default();
    for value in args {
        let number = primitive::number(value)?;
        let code = if points {
            if !(0.0..=0x10ffff as f64).contains(&number) || number.fract() != 0.0 {
                return Err(RuntimeError::RangeError("invalid String code point".into()));
            }
            number as u32
        } else if !number.is_finite() {
            0
        } else {
            number.trunc().rem_euclid(65536.0) as u32
        };
        let mut part = JsString::default();
        part.push_code_point(code);
        append(&mut result, &part, limit)?;
    }
    Ok(Value::String(result))
}

fn uri_append(output: &mut Vec<u16>, units: &[u16], limit: usize) -> Result<(), UriCodingError> {
    let available_units = limit / std::mem::size_of::<u16>();
    if output.len().saturating_add(units.len()) > available_units {
        return Err(UriCodingError::StringLimit { limit });
    }
    output.extend_from_slice(units);
    Ok(())
}

fn uri_hex(unit: u16) -> Option<u8> {
    match unit {
        0x30..=0x39 => Some((unit - 0x30) as u8),
        0x61..=0x66 => Some((unit - 0x61 + 10) as u8),
        0x41..=0x46 => Some((unit - 0x41 + 10) as u8),
        _ => None,
    }
}

fn uri_percent_byte(units: &[u16], index: usize) -> Result<u8, UriCodingError> {
    if units.get(index) != Some(&u16::from(b'%')) {
        return Err(UriCodingError::Malformed);
    }
    let high = units
        .get(index + 1)
        .and_then(|unit| uri_hex(*unit))
        .ok_or(UriCodingError::Malformed)?;
    let low = units
        .get(index + 2)
        .and_then(|unit| uri_hex(*unit))
        .ok_or(UriCodingError::Malformed)?;
    Ok((high << 4) | low)
}

fn uri_unescaped(code_point: u32, component: bool) -> bool {
    matches!(code_point, 0x41..=0x5a | 0x61..=0x7a | 0x30..=0x39)
        || matches!(
            code_point,
            0x2d | 0x5f | 0x2e | 0x21 | 0x7e | 0x2a | 0x27 | 0x28 | 0x29
        )
        || (!component
            && matches!(
                code_point,
                0x3b | 0x2f | 0x3f | 0x3a | 0x40 | 0x26 | 0x3d | 0x2b | 0x24 | 0x2c | 0x23
            ))
}

fn uri_reserved(byte: u8) -> bool {
    b";/?:@&=+$,#".contains(&byte)
}

/// ECMA-262 §19.2.6.6 / §19.2.6.7 Encode.
pub(crate) fn encode_uri(
    string: &JsString,
    component: bool,
    limit: usize,
) -> Result<JsString, UriCodingError> {
    let units = string.as_code_units();
    let mut output = Vec::with_capacity(units.len());
    let mut index = 0;
    while let Some(&unit) = units.get(index) {
        let (code_point, width) = match unit {
            0xd800..=0xdbff => {
                let Some(&low) = units.get(index + 1) else {
                    return Err(UriCodingError::Malformed);
                };
                if !(0xdc00..=0xdfff).contains(&low) {
                    return Err(UriCodingError::Malformed);
                }
                (
                    0x10000 + ((u32::from(unit) - 0xd800) << 10) + (u32::from(low) - 0xdc00),
                    2,
                )
            }
            0xdc00..=0xdfff => return Err(UriCodingError::Malformed),
            _ => (u32::from(unit), 1),
        };
        if uri_unescaped(code_point, component) {
            uri_append(&mut output, &units[index..index + width], limit)?;
        } else {
            let scalar = char::from_u32(code_point).expect("URI code point is a Unicode scalar");
            let mut buffer = [0; 4];
            for byte in scalar.encode_utf8(&mut buffer).bytes() {
                const HEX: &[u8; 16] = b"0123456789ABCDEF";
                uri_append(
                    &mut output,
                    &[
                        u16::from(b'%'),
                        u16::from(HEX[(byte >> 4) as usize]),
                        u16::from(HEX[(byte & 0x0f) as usize]),
                    ],
                    limit,
                )?;
            }
        }
        index += width;
    }
    Ok(JsString::from_code_units(output))
}

/// ECMA-262 §19.2.6.4 / §19.2.6.5 Decode.  This deliberately performs
/// strict UTF-8 validation instead of accepting Rust's replacement-character
/// conversion, because malformed percent octets must throw `URIError`.
pub(crate) fn decode_uri(
    string: &JsString,
    component: bool,
    limit: usize,
) -> Result<JsString, UriCodingError> {
    let units = string.as_code_units();
    let mut output = Vec::with_capacity(units.len());
    let mut index = 0;
    while let Some(&unit) = units.get(index) {
        if unit != u16::from(b'%') {
            uri_append(&mut output, &[unit], limit)?;
            index += 1;
            continue;
        }

        let start = index;
        let first = uri_percent_byte(units, start)?;
        if first < 0x80 {
            index += 3;
            if !component && uri_reserved(first) {
                uri_append(&mut output, &units[start..index], limit)?;
            } else {
                uri_append(&mut output, &[u16::from(first)], limit)?;
            }
            continue;
        }

        let octets = match first {
            0xc2..=0xdf => 2,
            0xe0..=0xef => 3,
            0xf0..=0xf4 => 4,
            _ => return Err(UriCodingError::Malformed),
        };
        let mut bytes = [0; 4];
        bytes[0] = first;
        for (offset, slot) in bytes.iter_mut().enumerate().take(octets).skip(1) {
            let byte = uri_percent_byte(units, start + offset * 3)?;
            if !(0x80..=0xbf).contains(&byte) {
                return Err(UriCodingError::Malformed);
            }
            *slot = byte;
        }
        let decoded =
            std::str::from_utf8(&bytes[..octets]).map_err(|_| UriCodingError::Malformed)?;
        let mut encoded = [0; 2];
        let utf16_width = decoded
            .chars()
            .next()
            .expect("a valid non-empty UTF-8 sequence has a character")
            .encode_utf16(&mut encoded)
            .len();
        uri_append(&mut output, &encoded[..utf16_width], limit)?;
        index = start + octets * 3;
    }
    Ok(JsString::from_code_units(output))
}

/// ECMA-262 §B.2.1.1 `escape`: code units outside the unescaped set become
/// `%XX` (below 256) or `%uXXXX`, always with upper-case hexadecimal digits.
pub(crate) fn escape(string: &JsString, limit: usize) -> Result<JsString, UriCodingError> {
    const HEX: &[u8; 16] = b"0123456789ABCDEF";
    let mut output = Vec::with_capacity(string.as_code_units().len());
    for &unit in string.as_code_units() {
        let unescaped = match u8::try_from(unit) {
            Ok(byte) => byte.is_ascii_alphanumeric() || b"@*_+-./".contains(&byte),
            Err(_) => false,
        };
        if unescaped {
            uri_append(&mut output, &[unit], limit)?;
            continue;
        }
        let digits = [
            u16::from(HEX[usize::from((unit >> 12) & 0xf)]),
            u16::from(HEX[usize::from((unit >> 8) & 0xf)]),
            u16::from(HEX[usize::from((unit >> 4) & 0xf)]),
            u16::from(HEX[usize::from(unit & 0xf)]),
        ];
        if unit < 256 {
            uri_append(&mut output, &[0x25, digits[2], digits[3]], limit)?;
        } else {
            uri_append(
                &mut output,
                &[0x25, 0x75, digits[0], digits[1], digits[2], digits[3]],
                limit,
            )?;
        }
    }
    Ok(JsString::from_code_units(output))
}

/// ECMA-262 §B.2.1.2 `unescape`: `%uXXXX` and `%XX` sequences decode to one
/// code unit; a `%` that does not start a complete sequence is kept as is.
pub(crate) fn unescape(string: &JsString, limit: usize) -> Result<JsString, UriCodingError> {
    let units = string.as_code_units();
    let mut output = Vec::with_capacity(units.len());
    let mut index = 0;
    while let Some(&unit) = units.get(index) {
        let decoded = (unit == u16::from(b'%'))
            .then(|| {
                let hex = |from: usize, count: usize| -> Option<u16> {
                    units
                        .get(from..from + count)?
                        .iter()
                        .try_fold(0u16, |value, &digit| {
                            Some((value << 4) | u16::from(uri_hex(digit)?))
                        })
                };
                if units.get(index + 1) == Some(&u16::from(b'u')) {
                    if let Some(value) = hex(index + 2, 4) {
                        return Some((value, 6));
                    }
                }
                hex(index + 1, 2).map(|value| (value, 3))
            })
            .flatten();
        match decoded {
            Some((value, width)) => {
                uri_append(&mut output, &[value], limit)?;
                index += width;
            }
            None => {
                uri_append(&mut output, &[unit], limit)?;
                index += 1;
            }
        }
    }
    Ok(JsString::from_code_units(output))
}

pub(crate) fn substitution(
    string: &JsString,
    matched: &JsString,
    position: usize,
    template: &JsString,
    limit: usize,
) -> Result<JsString, RuntimeError> {
    let units = template.as_code_units();
    let mut index = 0;
    let mut result = JsString::default();
    while index < units.len() {
        let expansion = if units[index] == u16::from(b'$') {
            match units.get(index + 1).copied() {
                Some(0x24) => Some(&units[index..index + 1]),
                Some(0x26) => Some(matched.as_code_units()),
                Some(0x60) => Some(&string.as_code_units()[..position]),
                Some(0x27) => Some(&string.as_code_units()[position + matched.len()..]),
                _ => None, // No captures for a String search; $n and $<name> stay literal.
            }
        } else {
            None
        };
        let part = expansion.unwrap_or(&units[index..index + 1]);
        append(
            &mut result,
            &JsString::from_code_units(part.to_vec()),
            limit,
        )?;
        index += if expansion.is_some() { 2 } else { 1 };
    }
    Ok(result)
}

pub(crate) fn string_method(
    method: StringMethod,
    receiver: &Value,
    args: &[Value],
    limit: usize,
) -> Result<Value, RuntimeError> {
    use StringMethod::*;
    if matches!(receiver, Value::Undefined | Value::Null) {
        return Err(RuntimeError::TypeError(
            "String method requires a non-null receiver".into(),
        ));
    }
    if matches!(method, ToString | ValueOf) && !matches!(receiver, Value::String(_)) {
        return Err(RuntimeError::TypeError(
            "String value method requires a String receiver".into(),
        ));
    }
    let mut string = primitive::string(receiver)?;
    let units = string.as_code_units();
    let len = units.len();
    let first = argument(args, 0);
    let second = argument(args, 1);
    Ok(match method {
        At | CharAt | CharCodeAt | CodePointAt => {
            let mut index = integer(first)?;
            if method == At && index < 0.0 {
                index += len as f64;
            }
            if index < 0.0 || index >= len as f64 {
                match method {
                    CharAt => Value::String(JsString::default()),
                    CharCodeAt => Value::Number(f64::NAN),
                    _ => Value::Undefined,
                }
            } else {
                let index = index as usize;
                let unit = units[index];
                if method == CharCodeAt || method == CodePointAt {
                    let point = if method == CodePointAt
                        && (0xd800..=0xdbff).contains(&unit)
                        && matches!(units.get(index + 1), Some(next) if (0xdc00..=0xdfff).contains(next))
                    {
                        (u32::from(unit) - 0xd800) * 0x400 + u32::from(units[index + 1]) - 0xdc00
                            + 0x10000
                    } else {
                        u32::from(unit)
                    };
                    Value::Number(f64::from(point))
                } else {
                    Value::String(JsString::from_code_units(vec![unit]))
                }
            }
        }
        Slice | Substring => {
            let start = integer(first)?;
            let end = if matches!(second, Value::Undefined) {
                len as f64
            } else {
                integer(second)?
            };
            let start = if method == Slice && start < 0.0 {
                len as f64 + start
            } else {
                start
            };
            let end = if method == Slice && end < 0.0 {
                len as f64 + end
            } else {
                end
            };
            let (start, end) = (
                start.clamp(0.0, len as f64) as usize,
                end.clamp(0.0, len as f64) as usize,
            );
            let (start, end) = if method == Substring {
                (start.min(end), start.max(end))
            } else {
                (start, end.max(start))
            };
            Value::String(JsString::from_code_units(units[start..end].to_vec()))
        }
        IndexOf | LastIndexOf | Includes | StartsWith | EndsWith => {
            // Observable conversions and IsRegExp have run in VM dispatch.
            let search = primitive::string(first)?;
            let needle = search.as_code_units();
            let position = if method == LastIndexOf {
                let number = primitive::number(second)?;
                if number.is_nan() {
                    f64::INFINITY
                } else {
                    number.trunc()
                }
            } else if method == EndsWith && matches!(second, Value::Undefined) {
                len as f64
            } else {
                integer(second)?
            };
            let position = position.clamp(0.0, len as f64) as usize;
            match method {
                StartsWith => Value::Bool(units[position..].starts_with(needle)),
                EndsWith => Value::Bool(units[..position].ends_with(needle)),
                _ => {
                    let mut index = None;
                    if needle.len() <= len {
                        if method == LastIndexOf {
                            for candidate in (0..=position.min(len - needle.len())).rev() {
                                if units[candidate..].starts_with(needle) {
                                    index = Some(candidate);
                                    break;
                                }
                            }
                        } else {
                            for candidate in position..=len - needle.len() {
                                if units[candidate..].starts_with(needle) {
                                    index = Some(candidate);
                                    break;
                                }
                            }
                        }
                    }
                    if method == Includes {
                        Value::Bool(index.is_some())
                    } else {
                        Value::Number(match index {
                            Some(index) => index as f64,
                            None => -1.0,
                        })
                    }
                }
            }
        }
        Concat => {
            for arg in args {
                append(&mut string, &primitive::string(arg)?, limit)?;
            }
            Value::String(string)
        }
        IsWellFormed => {
            let mut well_formed = true;
            for scalar in char::decode_utf16(units.iter().copied()) {
                if scalar.is_err() {
                    well_formed = false;
                    break;
                }
            }
            Value::Bool(well_formed)
        }
        ToWellFormed => {
            let mut result = JsString::default();
            for scalar in char::decode_utf16(units.iter().copied()) {
                result.push_code_point(scalar.unwrap_or('\u{fffd}') as u32);
            }
            Value::String(result)
        }
        ToString | ValueOf => Value::String(string),
        PadStart | PadEnd => {
            let target = length(first)?;
            debug_assert!(
                target > len as f64,
                "short padding requests return before filler conversion in VM dispatch"
            );
            let fill = if matches!(second, Value::Undefined) {
                JsString::from(" ")
            } else {
                primitive::string(second)?
            };
            if fill.is_empty() {
                return Ok(Value::String(string));
            }
            if target > (limit / 2) as f64 {
                return Err(RuntimeError::StringLimit { limit });
            }
            let padding: Vec<_> = fill
                .as_code_units()
                .iter()
                .copied()
                .cycle()
                .take(target as usize - len)
                .collect();
            let padding = JsString::from_code_units(padding);
            if method == PadStart {
                let mut result = padding;
                result.push_str(&string);
                Value::String(result)
            } else {
                string.push_str(&padding);
                Value::String(string)
            }
        }
        Repeat => {
            let count = integer(first)?;
            if count < 0.0 || count == f64::INFINITY {
                return Err(RuntimeError::RangeError(
                    "invalid String repeat count".into(),
                ));
            }
            if count == 0.0 || string.is_empty() {
                return Ok(Value::String(JsString::default()));
            }
            if count > (limit / string.byte_len()) as f64 {
                return Err(RuntimeError::StringLimit { limit });
            }
            Value::String(JsString::from_code_units(units.repeat(count as usize)))
        }
        Trim | TrimStart | TrimEnd => {
            let mut start = 0;
            if method != TrimEnd {
                while start < len
                    && char::from_u32(u32::from(units[start])).is_some_and(primitive::whitespace)
                {
                    start += 1;
                }
            }
            let mut end = len;
            if method != TrimStart {
                while end > start
                    && char::from_u32(u32::from(units[end - 1])).is_some_and(primitive::whitespace)
                {
                    end -= 1;
                }
            }
            Value::String(JsString::from_code_units(units[start..end].to_vec()))
        }
        Normalize | ToLowerCase | ToUpperCase => {
            let form = match method {
                ToLowerCase => "lower".into(),
                ToUpperCase => "upper".into(),
                _ => {
                    let form = if matches!(first, Value::Undefined) {
                        JsString::from("NFC")
                    } else {
                        primitive::string(first)?
                    };
                    if form != "NFC" && form != "NFD" && form != "NFKC" && form != "NFKD" {
                        return Err(RuntimeError::RangeError(
                            "invalid String normalization form".into(),
                        ));
                    }
                    form.to_utf8().expect("validated ASCII normalization form")
                }
            };
            Value::String(unicode_transform(&string, &form, limit)?)
        }
        Substr => {
            let start = integer(first)?;
            let start = (if start < 0.0 {
                len as f64 + start
            } else {
                start
            })
            .clamp(0.0, len as f64) as usize;
            let count = if matches!(second, Value::Undefined) {
                len as f64
            } else {
                integer(second)?
            };
            let count = count.clamp(0.0, (len - start) as f64) as usize;
            Value::String(JsString::from_code_units(
                units[start..start + count].to_vec(),
            ))
        }
        Html { tag, attribute } => {
            let mut result: JsString = format!("<{tag}").into();
            if !attribute.is_empty() {
                let value = primitive::string(first)?;
                append(&mut result, &format!(" {attribute}=\"").into(), limit)?;
                for &unit in value.as_code_units() {
                    let escaped = if unit == u16::from(b'"') {
                        "&quot;".into()
                    } else {
                        JsString::from_code_units(vec![unit])
                    };
                    append(&mut result, &escaped, limit)?;
                }
                append(&mut result, &"\"".into(), limit)?;
            }
            append(&mut result, &">".into(), limit)?;
            append(&mut result, &string, limit)?;
            append(&mut result, &format!("</{tag}>").into(), limit)?;
            Value::String(result)
        }
    })
}

fn unicode_transform(
    string: &JsString,
    form: &str,
    limit: usize,
) -> Result<JsString, RuntimeError> {
    let mut result = JsString::default();
    let mut run = String::new();
    for scalar in char::decode_utf16(string.as_code_units().iter().copied()) {
        match scalar {
            Ok(scalar) => run.push(scalar),
            Err(error) => {
                transform_run(&run, form, &mut result, limit)?;
                run.clear();
                append(
                    &mut result,
                    &JsString::from_code_units(vec![error.unpaired_surrogate()]),
                    limit,
                )?;
            }
        }
    }
    transform_run(&run, form, &mut result, limit)?;
    Ok(result)
}

fn transform_run(
    run: &str,
    form: &str,
    result: &mut JsString,
    limit: usize,
) -> Result<(), RuntimeError> {
    // Case conversion uses the complete run for contextual mappings
    // (notably final sigma); normalization streams expanded code points.
    let case = match form {
        "lower" => run.to_lowercase(),
        "upper" => run.to_uppercase(),
        _ => String::new(),
    };
    let scalars: Box<dyn Iterator<Item = char> + '_> = match form {
        "NFC" => Box::new(run.nfc()),
        "NFD" => Box::new(run.nfd()),
        "NFKC" => Box::new(run.nfkc()),
        "NFKD" => Box::new(run.nfkd()),
        _ => Box::new(case.chars()),
    };
    for scalar in scalars {
        let mut part = JsString::default();
        part.push_code_point(scalar as u32);
        append(result, &part, limit)?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::JsSymbol;

    const ROOMY: usize = 1 << 20;

    fn text(value: &str) -> Value {
        Value::String(value.into())
    }

    fn symbol() -> Value {
        Value::Symbol(JsSymbol::well_known("iterator"))
    }

    fn units(code_units: &[u16]) -> JsString {
        JsString::from_code_units(code_units.to_vec())
    }

    #[test]
    fn numeric_argument_helpers_reject_symbols() {
        for message in [
            integer(&symbol()).unwrap_err().to_string(),
            length(&symbol()).unwrap_err().to_string(),
        ] {
            assert!(message.starts_with("TypeError"), "{message}");
        }
        assert_eq!(integer(&Value::Number(f64::NAN)), Ok(0.0));
        assert_eq!(integer(&Value::Number(-2.7)), Ok(-2.0));
        assert_eq!(uint32(4294967297.0), 1);
        assert_eq!(length(&Value::Number(-5.0)), Ok(0.0));
    }

    #[test]
    fn from_codes_builds_units_and_points_and_rejects_invalid_points() {
        let numbers = |values: &[f64]| values.iter().map(|v| Value::Number(*v)).collect::<Vec<_>>();
        assert_eq!(
            from_codes(
                &numbers(&[65.0, 66.0, 65601.5, f64::NAN, f64::INFINITY]),
                false,
                ROOMY
            ),
            Ok(Value::String(units(&[65, 66, 65, 0, 0])))
        );
        assert_eq!(
            from_codes(&numbers(&[65.0, 128512.0]), true, ROOMY),
            Ok(Value::String(units(&[65, 0xd83d, 0xde00])))
        );
        for invalid in [-1.0, 1114112.0, 1.5, f64::NAN] {
            assert_eq!(
                from_codes(&numbers(&[invalid]), true, ROOMY),
                Err(RuntimeError::RangeError("invalid String code point".into())),
                "{invalid}"
            );
        }
        assert_eq!(
            from_codes(&numbers(&[65.0, 66.0]), false, 2),
            Err(RuntimeError::StringLimit { limit: 2 })
        );
    }

    #[test]
    fn growing_a_string_past_the_limit_fails_at_every_step() {
        use StringMethod::*;
        let mixed = Value::String(units(&[0x73, 0xe9, 0xd800, 0x7a]));
        let calls: Vec<(StringMethod, Vec<Value>)> = vec![
            (
                Html {
                    tag: "a",
                    attribute: "name",
                },
                vec![text("x\"y")],
            ),
            (
                Html {
                    tag: "b",
                    attribute: "",
                },
                vec![],
            ),
            (Concat, vec![text("def"), text("ghi")]),
            (Normalize, vec![text("NFD")]),
            (ToLowerCase, vec![]),
            (ToUpperCase, vec![]),
        ];
        for limit in 0..=90 {
            for (method, args) in &calls {
                let result = string_method(*method, &mixed, args, limit);
                if let Err(error) = result {
                    assert_eq!(error, RuntimeError::StringLimit { limit });
                }
            }
        }
        for limit in 0..=8 {
            let result = from_codes(&[Value::Number(65.0), Value::Number(66.0)], false, limit);
            if let Err(error) = result {
                assert_eq!(error, RuntimeError::StringLimit { limit });
            }
        }
    }

    #[test]
    fn uri_encoding_escapes_reserved_characters_only_for_components() {
        let source = JsString::from("a b/\u{e9}\u{1F600}");
        let encode = |component| encode_uri(&source, component, ROOMY).unwrap();
        assert_eq!(encode(false), JsString::from("a%20b/%C3%A9%F0%9F%98%80"));
        assert_eq!(encode(true), JsString::from("a%20b%2F%C3%A9%F0%9F%98%80"));
    }

    #[test]
    fn uri_encoding_rejects_unpaired_surrogates() {
        for malformed in [units(&[0xd800]), units(&[0xd800, 0x61]), units(&[0xdc00])] {
            assert_eq!(
                encode_uri(&malformed, false, ROOMY),
                Err(UriCodingError::Malformed)
            );
        }
    }

    #[test]
    fn uri_decoding_handles_every_utf8_width_and_reserved_set() {
        let decode = |input: &str, component| decode_uri(&JsString::from(input), component, ROOMY);
        assert_eq!(decode("abc", false), Ok(JsString::from("abc")));
        assert_eq!(decode("%41", false), Ok(JsString::from("A")));
        assert_eq!(decode("%2F%3b", false), Ok(JsString::from("%2F%3b")));
        assert_eq!(decode("%2F%3b", true), Ok(JsString::from("/;")));
        assert_eq!(decode("%C3%A9", false), Ok(JsString::from("\u{e9}")));
        assert_eq!(decode("%E2%82%AC", false), Ok(JsString::from("\u{20ac}")));
        assert_eq!(
            decode("%F0%9F%98%80", false),
            Ok(JsString::from("\u{1F600}"))
        );
    }

    #[test]
    fn uri_decoding_rejects_malformed_percent_sequences() {
        for input in [
            "%",
            "%4",
            "%4Z",
            "%Z1",
            "%80",
            "%C0",
            "%F8",
            "%C3",
            "%C3x",
            "%C3%41",
            "%E0%80%80",
            "%F5%80%80%80",
            "%ED%A0%80",
        ] {
            assert_eq!(
                decode_uri(&JsString::from(input), false, ROOMY),
                Err(UriCodingError::Malformed),
                "{input}"
            );
        }
    }

    #[test]
    fn uri_coding_reports_the_string_limit_at_every_append() {
        let encoded = JsString::from("a b\u{e9}%41%C3%A9%2F%zz");
        let decodable = JsString::from("a%41%C3%A9%2F");
        for limit in 0..=60 {
            for result in [
                encode_uri(&encoded, false, limit),
                decode_uri(&decodable, false, limit),
                decode_uri(&decodable, true, limit),
                escape(&encoded, limit),
                unescape(&encoded, limit),
                escape(&JsString::from("\u{4e2d}"), limit),
            ] {
                if let Err(error) = result {
                    assert_eq!(error, UriCodingError::StringLimit { limit });
                }
            }
        }
    }

    #[test]
    fn escape_and_unescape_round_trip_annex_b_forms() {
        let source = JsString::from("a b\u{e9}\u{4e2d}@*_+-./");
        let escaped = escape(&source, ROOMY).unwrap();
        assert_eq!(escaped, JsString::from("a%20b%E9%u4E2D@*_+-./"));
        assert_eq!(unescape(&escaped, ROOMY), Ok(source));
        assert_eq!(
            unescape(&JsString::from("%u00e9%e9%zz%u12%"), ROOMY),
            Ok(JsString::from("\u{e9}\u{e9}%zz%u12%"))
        );
    }

    #[test]
    fn replacement_patterns_expand_and_respect_the_limit() {
        let string = JsString::from("xaby");
        let matched = JsString::from("ab");
        let template = JsString::from("$$|$&|$`|$'|$1|$");
        assert_eq!(
            substitution(&string, &matched, 1, &template, ROOMY),
            Ok(JsString::from("$|ab|x|y|$1|$"))
        );
        for limit in 0..=40 {
            if let Err(error) = substitution(&string, &matched, 1, &template, limit) {
                assert_eq!(error, RuntimeError::StringLimit { limit });
            }
        }
    }
}
