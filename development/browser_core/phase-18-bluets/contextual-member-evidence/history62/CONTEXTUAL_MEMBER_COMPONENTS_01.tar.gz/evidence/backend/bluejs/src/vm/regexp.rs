// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use super::*;
use crate::native::{LegacyRegExpStatic, RegExpMethod};
use crate::regexp::{advance, RegExp};
use std::rc::Rc;

#[cfg(any(test, coverage))]
#[path = "../../tests/fixtures/regexp_builder_boundaries.rs"]
mod builder_boundaries;

impl Vm {
    pub(super) fn regexp_global(&mut self) -> Result<Value, RuntimeError> {
        if let Some(&id) = self.globals.get("RegExp") {
            return Ok(Value::Object(id));
        }
        let function_prototype = self.function_prototype()?;
        let constructor = self.with_roots(|heap| {
            heap.alloc_native_function(NativeFunction::RegExp, "RegExp", function_prototype)
        })?;
        let root = self.heap.root(constructor)?;
        let result = (|| {
            let object_prototype = self.object_prototype;
            let prototype = self.with_roots(|heap| heap.alloc_object(Some(object_prototype)))?;
            self.define_data(
                constructor,
                "prototype",
                Value::Object(prototype),
                false,
                false,
                false,
            )?;
            self.define_data(
                constructor,
                "name",
                Value::String("RegExp".into()),
                false,
                false,
                true,
            )?;
            self.define_data(
                constructor,
                "length",
                Value::Number(2.0),
                false,
                false,
                true,
            )?;
            self.define_data(
                prototype,
                "constructor",
                Value::Object(constructor),
                true,
                false,
                true,
            )?;
            self.install_native(
                constructor,
                function_prototype,
                "escape",
                1,
                NativeFunction::RegExpEscape,
            )?;
            for (name, method) in [
                ("exec", RegExpMethod::Exec),
                ("test", RegExpMethod::Test),
                ("toString", RegExpMethod::ToString),
                ("compile", RegExpMethod::Compile),
            ] {
                self.install_native(
                    prototype,
                    function_prototype,
                    name,
                    match method {
                        RegExpMethod::ToString => 0,
                        RegExpMethod::Compile => 2,
                        _ => 1,
                    },
                    NativeFunction::RegExpMethod(method),
                )?;
            }
            for (name, length, method) in [
                ("match", 1, RegExpMethod::Match),
                ("matchAll", 1, RegExpMethod::MatchAll),
                ("search", 1, RegExpMethod::Search),
                ("replace", 2, RegExpMethod::Replace),
                ("split", 2, RegExpMethod::Split),
            ] {
                self.install_symbol_native(
                    prototype,
                    function_prototype,
                    name,
                    length,
                    NativeFunction::RegExpMethod(method),
                )?;
            }
            for name in [
                "source",
                "flags",
                "global",
                "ignoreCase",
                "multiline",
                "dotAll",
                "unicode",
                "unicodeSets",
                "sticky",
                "hasIndices",
            ] {
                self.install_getter(
                    prototype,
                    function_prototype,
                    name.into(),
                    &format!("get {name}"),
                    NativeFunction::RegExpGetter(name),
                )?;
            }
            self.install_getter(
                constructor,
                function_prototype,
                JsSymbol::well_known("species").into(),
                "get [Symbol.species]",
                NativeFunction::RegExpGetter("species"),
            )?;
            self.install_legacy_accessors(constructor, function_prototype)?;
            if let Some(&global) = self.globals.get("globalThis") {
                self.define_data(
                    global,
                    "RegExp",
                    Value::Object(constructor),
                    true,
                    false,
                    true,
                )?;
            }
            Ok(Value::Object(constructor))
        })();
        match result {
            Ok(value) => {
                self.globals.insert("RegExp".into(), constructor);
                Ok(value)
            }
            Err(error) => {
                self.release_root(root);
                Err(error)
            }
        }
    }

    pub(super) fn regexp_escape(&mut self, value: &Value) -> Result<Value, RuntimeError> {
        let Value::String(string) = value else {
            return Err(RuntimeError::TypeError(
                "RegExp.escape requires a String".into(),
            ));
        };
        let mut result = JsString::default();
        for (index, scalar) in
            char::decode_utf16(string.as_code_units().iter().copied()).enumerate()
        {
            self.charge_step()?;
            let point = scalar.map_or_else(|e| u32::from(e.unpaired_surrogate()), |c| c as u32);
            let part = crate::regexp::escape_code_point(point, index == 0);
            native::append(&mut result, &part, self.config.max_string_bytes)?;
        }
        Ok(Value::String(result))
    }

    pub(super) fn install_getter(
        &mut self,
        owner: ObjectId,
        prototype: ObjectId,
        key: PropertyName,
        name: &str,
        native: NativeFunction,
    ) -> Result<(), RuntimeError> {
        let id = self.with_roots(|heap| heap.alloc_native_function(native, name, prototype))?;
        let base = self.stack.len();
        self.stack.push(Value::Object(id));
        let result = (|| {
            self.define_data(id, "name", Value::String(name.into()), false, false, true)?;
            self.define_data(id, "length", Value::Number(0.0), false, false, true)?;
            self.with_roots(|heap| {
                heap.define_own_property(
                    owner,
                    key,
                    PropertyDescriptor {
                        get: Some(Value::Object(id)),
                        set: Some(Value::Undefined),
                        enumerable: Some(false),
                        configurable: Some(true),
                        ..Default::default()
                    },
                )
            })?;
            Ok(())
        })();
        self.stack.truncate(base);
        result
    }

    /// RegExpCreate and regular expression literals: an ordinary `%RegExp%`
    /// allocation that is never a construction on behalf of some `new.target`.
    pub(super) fn regexp_create(
        &mut self,
        pattern: &Value,
        flags: &Value,
    ) -> Result<Value, RuntimeError> {
        let pattern_is_regexp = self.is_regexp(pattern)?;
        self.regexp_allocate(pattern, pattern_is_regexp, flags, false)
    }

    /// ECMA-262 §22.2.4.1 RegExp ( pattern, flags ), called or constructed.
    pub(super) fn regexp_constructor(
        &mut self,
        pattern: &Value,
        flags: &Value,
        construct: bool,
    ) -> Result<Value, RuntimeError> {
        let pattern_is_regexp = self.is_regexp(pattern)?;
        if !construct && *flags == Value::Undefined && pattern_is_regexp {
            let constructor = self.get_property(pattern, &"constructor".into())?;
            if constructor == self.regexp_global()? {
                return Ok(pattern.clone());
            }
        }
        self.regexp_allocate(pattern, pattern_is_regexp, flags, construct)
    }

    /// The (source, flags) of a pattern that has a [[RegExpMatcher]] slot,
    /// including one living in a Test262 child realm.
    fn regexp_slots(&self, pattern: &Value) -> Result<Option<(JsString, String)>, RuntimeError> {
        let Value::Object(id) = pattern else {
            return Ok(None);
        };
        Ok(self
            .heap
            .regexp(*id)?
            .map(|regexp| (regexp.source.clone(), regexp.flags.clone()))
            .or(self.test262_foreign_regexp_data(*id)?))
    }

    /// RegExpAlloc + RegExpInitialize for the constructor's steps 3-10.
    /// `construct` selects `self.new_target` as NewTarget; otherwise NewTarget
    /// is `%RegExp%` itself. `pattern_is_regexp` must already have been
    /// computed (IsRegExp is observable and precedes the slot reads).
    ///
    /// The observable order is: read `source`/`flags` of a regexp-like
    /// pattern, RegExpAlloc's `newTarget.prototype` lookup, and only then
    /// ToString of the pattern and of the flags (RegExpInitialize).
    fn regexp_allocate(
        &mut self,
        pattern: &Value,
        pattern_is_regexp: bool,
        flags: &Value,
        construct: bool,
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let result = (|| {
            let (source, flags) =
                if let Some((source, existing_flags)) = self.regexp_slots(pattern)? {
                    (
                        Value::String(source),
                        if *flags == Value::Undefined {
                            Value::String(existing_flags.into())
                        } else {
                            flags.clone()
                        },
                    )
                } else if pattern_is_regexp {
                    let source = self.get_property(pattern, &"source".into())?;
                    self.stack.push(source.clone());
                    let flags = if *flags == Value::Undefined {
                        self.get_property(pattern, &"flags".into())?
                    } else {
                        flags.clone()
                    };
                    (source, flags)
                } else {
                    (pattern.clone(), flags.clone())
                };
            self.stack.push(source.clone());
            self.stack.push(flags.clone());
            let constructor = self.regexp_global()?;
            let prototype = self
                .heap
                .get(
                    constructor
                        .object_id()
                        .expect("RegExp is an intrinsic constructor"),
                    "prototype",
                )
                .expect("the rooted intrinsic constructor owns an immutable data prototype")
                .object_id()
                .expect("RegExp construction installs its object prototype");
            let prototype = if construct {
                self.constructor_prototype(prototype)?
            } else {
                prototype
            };
            self.stack.push(Value::Object(prototype));
            let source = if source == Value::Undefined {
                JsString::default()
            } else {
                self.coerce_string(&source)?
            };
            let flags = if flags == Value::Undefined {
                JsString::default()
            } else {
                self.coerce_string(&flags)?
            };
            // ToString(source) already enforced the configured string limit.
            // Converting flags cannot change that immutable source or limit.
            let mut regexp =
                RegExp::compile_with_timeout(source, &flags, self.config.regex_timeout)?;
            regexp.legacy_features = !construct || self.new_target == constructor;
            let object = self.with_roots(|heap| heap.alloc_regexp(Rc::new(regexp), prototype))?;
            self.stack.push(Value::Object(object));
            self.define_data(object, "lastIndex", Value::Number(0.0), true, false, false)?;
            Ok(Value::Object(object))
        })();
        self.stack.truncate(base);
        result
    }

    /// B.2.4.1 RegExp.prototype.compile ( pattern, flags ). A RegExp object
    /// always lives in the realm whose VM runs this method (a foreign
    /// receiver is an opaque facade without a matcher slot), so the
    /// specification's realm comparison holds by construction.
    fn regexp_compile(
        &mut self,
        receiver: ObjectId,
        pattern: &Value,
        flags: &Value,
    ) -> Result<Value, RuntimeError> {
        let Some(current) = self.heap.regexp(receiver)? else {
            return Err(RuntimeError::TypeError(
                "RegExp.prototype.compile requires a RegExp".into(),
            ));
        };
        if !current.legacy_features {
            return Err(RuntimeError::TypeError(
                "RegExp.prototype.compile is unavailable on a RegExp subclass instance".into(),
            ));
        }
        let (source, flags) = if let Some((source, existing_flags)) = self.regexp_slots(pattern)? {
            if *flags != Value::Undefined {
                return Err(RuntimeError::TypeError(
                    "RegExp.prototype.compile cannot take flags with a RegExp pattern".into(),
                ));
            }
            (source, existing_flags.into())
        } else {
            (
                if *pattern == Value::Undefined {
                    JsString::default()
                } else {
                    self.coerce_string(pattern)?
                },
                if *flags == Value::Undefined {
                    JsString::default()
                } else {
                    self.coerce_string(flags)?
                },
            )
        };
        self.check_string(&Value::String(source.clone()))?;
        let regexp = RegExp::compile_with_timeout(source, &flags, self.config.regex_timeout)?;
        self.heap.set_regexp(receiver, Rc::new(regexp))?;
        self.set_required(&Value::Object(receiver), "lastIndex", Value::Number(0.0))?;
        Ok(Value::Object(receiver))
    }

    /// Installs the Annex B legacy static accessors on `%RegExp%`.
    fn install_legacy_accessors(
        &mut self,
        constructor: ObjectId,
        function_prototype: ObjectId,
    ) -> Result<(), RuntimeError> {
        use LegacyRegExpStatic::*;
        let base = self.stack.len();
        let result = (|| {
            let mut read_only = vec![
                ("lastMatch", LastMatch),
                ("$&", LastMatch),
                ("lastParen", LastParen),
                ("$+", LastParen),
                ("leftContext", LeftContext),
                ("$`", LeftContext),
                ("rightContext", RightContext),
                ("$'", RightContext),
            ];
            let digits: Vec<String> = (1..=9).map(|digit| format!("${digit}")).collect();
            for (index, name) in digits.iter().enumerate() {
                read_only.push((name.as_str(), Paren(index as u8 + 1)));
            }
            for (name, which) in read_only {
                self.install_getter(
                    constructor,
                    function_prototype,
                    name.into(),
                    &format!("get {name}"),
                    NativeFunction::RegExpLegacyGetter(which),
                )?;
            }
            for name in ["input", "$_"] {
                let getter = self.with_roots(|heap| {
                    heap.alloc_native_function(
                        NativeFunction::RegExpLegacyGetter(Input),
                        &format!("get {name}"),
                        function_prototype,
                    )
                })?;
                self.stack.push(Value::Object(getter));
                let setter = self.with_roots(|heap| {
                    heap.alloc_native_function(
                        NativeFunction::RegExpLegacySetter(Input),
                        &format!("set {name}"),
                        function_prototype,
                    )
                })?;
                self.stack.push(Value::Object(setter));
                for (function, function_name, length) in [
                    (getter, format!("get {name}"), 0.0),
                    (setter, format!("set {name}"), 1.0),
                ] {
                    self.define_data(
                        function,
                        "name",
                        Value::String(function_name.as_str().into()),
                        false,
                        false,
                        true,
                    )?;
                    self.define_data(
                        function,
                        "length",
                        Value::Number(length),
                        false,
                        false,
                        true,
                    )?;
                }
                self.with_roots(|heap| {
                    heap.define_own_property(
                        constructor,
                        PropertyName::from(name),
                        PropertyDescriptor {
                            get: Some(Value::Object(getter)),
                            set: Some(Value::Object(setter)),
                            enumerable: Some(false),
                            configurable: Some(true),
                            ..Default::default()
                        },
                    )
                })?;
                self.stack.pop();
                self.stack.pop();
            }
            Ok(())
        })();
        self.stack.truncate(base);
        result
    }

    /// GetLegacyRegExpStaticProperty (RegExp legacy features proposal).
    pub(super) fn regexp_legacy_get(
        &mut self,
        which: LegacyRegExpStatic,
        receiver: &Value,
    ) -> Result<Value, RuntimeError> {
        if *receiver != self.regexp_global()? {
            return Err(RuntimeError::TypeError(
                "legacy RegExp static property requires %RegExp% as receiver".into(),
            ));
        }
        match self.regexp_legacy.get(which) {
            Some(string) => Ok(Value::String(string)),
            None => Err(RuntimeError::TypeError(
                "legacy RegExp static property is unavailable after a non-legacy match".into(),
            )),
        }
    }

    /// SetLegacyRegExpStaticProperty for `RegExp.input` / `RegExp.$_`.
    pub(super) fn regexp_legacy_set(
        &mut self,
        which: LegacyRegExpStatic,
        receiver: &Value,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        debug_assert_eq!(which, LegacyRegExpStatic::Input);
        if *receiver != self.regexp_global()? {
            return Err(RuntimeError::TypeError(
                "legacy RegExp static property requires %RegExp% as receiver".into(),
            ));
        }
        let string = self.coerce_string(value)?;
        self.regexp_legacy.set_input(string);
        Ok(Value::Undefined)
    }

    pub(super) fn regexp_getter(
        &mut self,
        name: &str,
        receiver: &Value,
    ) -> Result<Value, RuntimeError> {
        if name == "species" {
            return Ok(receiver.clone());
        }
        if !matches!(receiver, Value::Object(_)) {
            return Err(RuntimeError::TypeError(
                "RegExp getter requires an object".into(),
            ));
        }
        if name == "flags" {
            let mut flags = String::new();
            for (property, flag) in [
                ("hasIndices", 'd'),
                ("global", 'g'),
                ("ignoreCase", 'i'),
                ("multiline", 'm'),
                ("dotAll", 's'),
                ("unicode", 'u'),
                ("unicodeSets", 'v'),
                ("sticky", 'y'),
            ] {
                let enabled = self.get_property(receiver, &property.into())?;
                if self
                    .to_boolean(&enabled)
                    .expect("the flag getter returned a live value and ToBoolean runs no user code")
                {
                    flags.push(flag);
                }
            }
            return Ok(Value::String(flags.into()));
        }
        // A RegExp owned by another realm still has [[OriginalSource]] and
        // [[OriginalFlags]]; any other foreign object (including that
        // realm's own %RegExp.prototype%) is not a RegExp of this getter's
        // realm and takes the same TypeError path as a local one.
        let Some((regexp_source, regexp_flags)) = self.regexp_slots(receiver)? else {
            let constructor = self.globals["RegExp"];
            if self
                .heap
                .get(constructor, "prototype")
                .expect("the cached RegExp constructor has its permanent root")
                == *receiver
            {
                return Ok(if name == "source" {
                    Value::String("(?:)".into())
                } else {
                    Value::Undefined
                });
            }
            return Err(RuntimeError::TypeError(
                "RegExp getter requires a RegExp".into(),
            ));
        };
        if name == "source" {
            if regexp_source.is_empty() {
                return Ok(Value::String("(?:)".into()));
            }
            // EscapeRegExpPattern: `/` and line terminators must be escaped so
            // that "/" + source + "/" reparses as the same pattern. A `/` in a
            // character class needs no escape, and a backslash that already
            // precedes a line terminator is absorbed into that terminator's
            // escape (`\<LF>` is `\n`, not a backslash followed by `\n`).
            let unicode_sets = regexp_flags.contains('v');
            let mut units = Vec::with_capacity(regexp_source.as_code_units().len());
            let (mut escaped, mut class_depth) = (false, 0usize);
            for &unit in regexp_source.as_code_units() {
                let terminator = match unit {
                    0x0a => Some("\\n"),
                    0x0d => Some("\\r"),
                    0x2028 => Some("\\u2028"),
                    0x2029 => Some("\\u2029"),
                    _ => None,
                };
                if let Some(escape) = terminator {
                    if escaped {
                        units.pop();
                    }
                    units.extend(escape.encode_utf16());
                    escaped = false;
                    continue;
                }
                if escaped {
                    units.push(unit);
                    escaped = false;
                    continue;
                }
                match unit {
                    0x5c => {
                        units.push(unit);
                        escaped = true;
                    }
                    0x2f if class_depth == 0 => units.extend("\\/".encode_utf16()),
                    0x5b => {
                        if unicode_sets || class_depth == 0 {
                            class_depth += 1;
                        }
                        units.push(unit);
                    }
                    0x5d => {
                        if class_depth > 0 {
                            class_depth = if unicode_sets { class_depth - 1 } else { 0 };
                        }
                        units.push(unit);
                    }
                    _ => units.push(unit),
                }
            }
            let source = JsString::from_code_units(units);
            self.check_string(&Value::String(source.clone()))?;
            return Ok(Value::String(source));
        }
        let flag = match name {
            "global" => 'g',
            "ignoreCase" => 'i',
            "multiline" => 'm',
            "dotAll" => 's',
            "unicode" => 'u',
            "unicodeSets" => 'v',
            "sticky" => 'y',
            _ => 'd',
        };
        Ok(Value::Bool(regexp_flags.contains(flag)))
    }

    pub(super) fn set_required(
        &mut self,
        receiver: &Value,
        key: &str,
        value: Value,
    ) -> Result<(), RuntimeError> {
        let object = receiver
            .object_id()
            .expect("the RegExp algorithm validated its object receiver before required writes");
        self.object_set_or_throw(object, &key.into(), &value)
    }

    pub(super) fn require_global_pattern(&mut self, pattern: &Value) -> Result<(), RuntimeError> {
        if self.is_regexp(pattern)? {
            let flags = self.get_property(pattern, &"flags".into())?;
            if matches!(flags, Value::Null | Value::Undefined) {
                return Err(RuntimeError::TypeError(
                    "RegExp flags must not be nullish".into(),
                ));
            }
            if !self
                .coerce_string(&flags)?
                .as_code_units()
                .contains(&u16::from(b'g'))
            {
                return Err(RuntimeError::TypeError(
                    "String method requires a global RegExp".into(),
                ));
            }
        }
        Ok(())
    }

    pub(super) fn regexp_exec(
        &mut self,
        receiver: &Value,
        string: &JsString,
        builtin: bool,
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let outcome = (|| {
            if !builtin {
                let exec = self.get_property(receiver, &"exec".into())?;
                if self
                    .is_callable(&exec)
                    .expect("the exec getter returned a live value in this realm")
                {
                    let result = self.call_native(
                        exec,
                        receiver.clone(),
                        vec![Value::String(string.clone())],
                        false,
                    )?;
                    return if matches!(result, Value::Null | Value::Object(_)) {
                        Ok(result)
                    } else {
                        Err(RuntimeError::TypeError(
                            "RegExp exec must return object or null".into(),
                        ))
                    };
                }
            }
            let Value::Object(id) = receiver else {
                return Err(RuntimeError::TypeError(
                    "RegExp exec requires a RegExp".into(),
                ));
            };
            if self.heap.regexp(*id)?.is_none() {
                return Err(RuntimeError::TypeError(
                    "RegExp exec requires a RegExp".into(),
                ));
            }
            // RegExpAllocate publishes the matcher only after defining its
            // non-configurable own data property. Reading it cannot invoke
            // an accessor or a prototype trap; ToLength below remains observable.
            let last_index = self
                .heap
                .get_own(*id, "lastIndex")
                .expect("the matcher-slot query validated this retained RegExp")
                .expect("RegExpAllocate installs a non-configurable own lastIndex data property");
            let last_index = self.coerce_length(&last_index)?;
            // ToLength(lastIndex) can run user code that recompiles the RegExp
            // (`compile`): RegExpBuiltinExec reads [[OriginalFlags]] and
            // [[RegExpMatcher]] only after it.
            let regexp = self
                .heap
                .regexp(*id)
                .expect("the validated RegExp receiver remains rooted during lastIndex coercion")
                .expect("a RegExp keeps its matcher slot for its whole life");
            let stateful = regexp.flags.contains(['g', 'y']);
            let start = if stateful { last_index as usize } else { 0 };
            self.charge_step()?;
            let matched = if start > string.len() {
                None
            } else {
                regexp
                    .find(string, start, self.config.regex_timeout)?
                    .filter(|m| !regexp.flags.contains('y') || m.start() == start)
            };
            let Some(matched) = matched else {
                if stateful {
                    self.set_required(receiver, "lastIndex", Value::Number(0.0))?;
                }
                return Ok(Value::Null);
            };
            if stateful {
                self.set_required(receiver, "lastIndex", Value::Number(matched.end() as f64))?;
            }
            if regexp.legacy_features {
                self.regexp_legacy.update(
                    string,
                    matched.start(),
                    matched.end(),
                    matched.groups().skip(1).collect(),
                );
            } else {
                self.regexp_legacy.invalidate();
            }
            let values = matched
                .groups()
                .map(|range| {
                    range.map_or(Value::Undefined, |range| {
                        Value::String(JsString::from_code_units(
                            string.as_code_units()[range].to_vec(),
                        ))
                    })
                })
                .collect();
            let array = self.array_from(values)?;
            self.stack.push(array.clone());
            let array_id = array.object_id().unwrap();
            self.with_roots(|heap| {
                heap.set(array_id, "index", Value::Number(matched.start() as f64))
            })?;
            self.with_roots(|heap| heap.set(array_id, "input", Value::String(string.clone())))?;
            let named: Vec<_> = matched
                .named_groups()
                .map(|(name, range)| (name.to_string(), range))
                .collect();
            let groups = if named.is_empty() {
                Value::Undefined
            } else {
                let object = self.with_roots(|heap| heap.alloc_object(None))?;
                self.stack.push(Value::Object(object));
                for (name, range) in &named {
                    let value = range.as_ref().map_or(Value::Undefined, |r| {
                        Value::String(JsString::from_code_units(
                            string.as_code_units()[r.clone()].to_vec(),
                        ))
                    });
                    self.with_roots(|heap| heap.set(object, name.as_str(), value))?;
                }
                self.stack.pop();
                Value::Object(object)
            };
            self.with_roots(|heap| heap.set(array_id, "groups", groups))?;
            if regexp.flags.contains('d') {
                let mut pairs = Vec::new();
                for range in matched.groups() {
                    let pair = if let Some(range) = range {
                        self.array_from(vec![
                            Value::Number(range.start as f64),
                            Value::Number(range.end as f64),
                        ])?
                    } else {
                        Value::Undefined
                    };
                    self.stack.push(pair.clone());
                    pairs.push(pair);
                }
                let indices = self.array_from(pairs)?;
                self.stack.push(indices.clone());
                let groups = if named.is_empty() {
                    Value::Undefined
                } else {
                    let object = self.with_roots(|heap| heap.alloc_object(None))?;
                    self.stack.push(Value::Object(object));
                    for (name, _) in named {
                        let capture = regexp.capture_names.iter().find(|(candidate, index)| {
                            candidate == &name && matched.group(*index).is_some()
                        });
                        let pair = if let Some((_, index)) = capture {
                            self.heap
                                .get(indices.object_id().unwrap(), index.to_string())
                                .expect("the fresh indices array is still on the VM stack")
                        } else {
                            Value::Undefined
                        };
                        self.with_roots(|heap| heap.set(object, name, pair))?;
                    }
                    Value::Object(object)
                };
                self.with_roots(|heap| heap.set(indices.object_id().unwrap(), "groups", groups))?;
                self.with_roots(|heap| heap.set(array_id, "indices", indices))?;
            }
            Ok(array)
        })();
        self.stack.truncate(base);
        outcome
    }

    pub(super) fn regexp_method(
        &mut self,
        method: RegExpMethod,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let outcome = (|| {
            use RegExpMethod::*;
            let Value::Object(object) = receiver else {
                return Err(RuntimeError::TypeError(
                    "RegExp method requires an object".into(),
                ));
            };
            if method == Exec && self.heap.regexp(*object)?.is_none() {
                return Err(RuntimeError::TypeError(
                    "RegExp exec requires a RegExp".into(),
                ));
            }
            let string = if matches!(method, Compile | ToString) {
                JsString::default()
            } else {
                self.coerce_string(native::argument(args, 0))?
            };
            match method {
                Compile => self.regexp_compile(
                    *object,
                    native::argument(args, 0),
                    native::argument(args, 1),
                ),
                Exec => self.regexp_exec(receiver, &string, true),
                Test => Ok(Value::Bool(
                    self.regexp_exec(receiver, &string, false)? != Value::Null,
                )),
                Search => {
                    let previous = self.get_property(receiver, &"lastIndex".into())?;
                    self.stack.push(previous.clone());
                    if !crate::heap::same_value(&previous, &Value::Number(0.0)) {
                        self.set_required(receiver, "lastIndex", Value::Number(0.0))?;
                    }
                    let result = self.regexp_exec(receiver, &string, false)?;
                    self.stack.push(result.clone());
                    let current = self.get_property(receiver, &"lastIndex".into())?;
                    if !crate::heap::same_value(&previous, &current) {
                        self.set_required(receiver, "lastIndex", previous)?;
                    }
                    if result == Value::Null {
                        Ok(Value::Number(-1.0))
                    } else {
                        self.get_property(&result, &"index".into())
                    }
                }
                Match => {
                    let flags = self.get_property(receiver, &"flags".into())?;
                    let flags = self.coerce_string(&flags)?;
                    if !flags.as_code_units().contains(&u16::from(b'g')) {
                        return self.regexp_exec(receiver, &string, false);
                    }
                    let unicode = flags
                        .as_code_units()
                        .iter()
                        .any(|&c| c == u16::from(b'u') || c == u16::from(b'v'));
                    self.set_required(receiver, "lastIndex", Value::Number(0.0))?;
                    let mut results = Vec::new();
                    loop {
                        self.charge_step()?;
                        let result = self.regexp_exec(receiver, &string, false)?;
                        if result == Value::Null {
                            break;
                        }
                        self.stack.push(result.clone());
                        let matched = self.get_property(&result, &"0".into())?;
                        let matched = self.coerce_string(&matched)?;
                        if matched.is_empty() {
                            self.advance_last_index(receiver, &string, unicode)?;
                        }
                        results.push(Value::String(matched));
                    }
                    if results.is_empty() {
                        Ok(Value::Null)
                    } else {
                        self.array_from(results)
                    }
                }
                MatchAll => {
                    let constructor = self.regexp_species_constructor(receiver)?;
                    self.stack.push(constructor.clone());
                    let flags = self.get_property(receiver, &"flags".into())?;
                    let flags = self.coerce_string(&flags)?;
                    let matcher = self.call_native(
                        constructor,
                        Value::Undefined,
                        vec![receiver.clone(), Value::String(flags.clone())],
                        true,
                    )?;
                    self.stack.push(matcher.clone());
                    let last_index = self.get_property(receiver, &"lastIndex".into())?;
                    let last_index = self.coerce_length(&last_index)?;
                    self.set_required(&matcher, "lastIndex", Value::Number(last_index))?;
                    let global = flags.as_code_units().contains(&u16::from(b'g'));
                    let unicode = flags
                        .as_code_units()
                        .iter()
                        .any(|&c| c == u16::from(b'u') || c == u16::from(b'v'));
                    let prototype = self.regexp_iterator_prototype()?;
                    Ok(Value::Object(self.with_roots(|heap| {
                        heap.alloc_regexp_iterator(
                            matcher.object_id().unwrap(),
                            string,
                            global,
                            unicode,
                            prototype,
                        )
                    })?))
                }
                Split => self.regexp_split(receiver, &string, native::argument(args, 1)),
                Replace => self.regexp_replace(receiver, &string, native::argument(args, 1)),
                ToString => {
                    let source = self.get_property(receiver, &"source".into())?;
                    let source = self.coerce_string(&source)?;
                    let flags = self.get_property(receiver, &"flags".into())?;
                    let flags = self.coerce_string(&flags)?;
                    let mut result = JsString::from("/");
                    for part in [source, "/".into(), flags] {
                        native::append(&mut result, &part, self.config.max_string_bytes)?;
                    }
                    Ok(Value::String(result))
                }
            }
        })();
        self.stack.truncate(base);
        outcome
    }

    fn advance_last_index(
        &mut self,
        receiver: &Value,
        string: &JsString,
        unicode: bool,
    ) -> Result<(), RuntimeError> {
        let index = self.get_property(receiver, &"lastIndex".into())?;
        let index = self.coerce_length(&index)? as usize;
        self.set_required(
            receiver,
            "lastIndex",
            Value::Number(advance(string, index, unicode) as f64),
        )
    }

    fn regexp_species_constructor(&mut self, receiver: &Value) -> Result<Value, RuntimeError> {
        let constructor = self.get_property(receiver, &"constructor".into())?;
        if constructor != Value::Undefined {
            if !matches!(constructor, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "RegExp constructor must be an object".into(),
                ));
            }
            let species =
                self.get_property(&constructor, &JsSymbol::well_known("species").into())?;
            if !matches!(species, Value::Undefined | Value::Null) {
                if !self
                    .is_constructor(&species)
                    .expect("the species getter returned a live value in this realm")
                {
                    return Err(RuntimeError::TypeError(
                        "RegExp species must be a constructor".into(),
                    ));
                }
                return Ok(species);
            }
        }
        self.regexp_global()
    }

    fn regexp_iterator_prototype(&mut self) -> Result<ObjectId, RuntimeError> {
        if let Some(prototype) = self.regexp_iterator_prototype {
            return Ok(prototype);
        }
        let function_prototype = self.function_prototype()?;
        let iterator_base = self.base_iterator_prototype()?;
        let prototype = self.with_roots(|heap| heap.alloc_object(Some(iterator_base)))?;
        let root = self.heap.root(prototype)?;
        let result = (|| {
            self.install_native(
                prototype,
                function_prototype,
                "next",
                0,
                NativeFunction::RegExpIteratorNext,
            )?;
            self.define_data(
                prototype,
                JsSymbol::well_known("toStringTag"),
                Value::String("RegExp String Iterator".into()),
                false,
                false,
                true,
            )?;
            Ok(prototype)
        })();
        if result.is_err() {
            self.release_root(root);
        } else {
            self.regexp_iterator_prototype = Some(prototype);
        }
        result
    }

    pub(super) fn regexp_iterator_next(&mut self, receiver: &Value) -> Result<Value, RuntimeError> {
        let Value::Object(id) = receiver else {
            return Err(RuntimeError::TypeError(
                "RegExp iterator next requires an iterator".into(),
            ));
        };
        let Some((matcher, string, global, unicode, done)) = self.heap.regexp_iterator(*id)? else {
            return Err(RuntimeError::TypeError(
                "RegExp iterator next requires an iterator".into(),
            ));
        };
        if done {
            return self.iterator_result(Value::Undefined, true);
        }
        let matcher = Value::Object(matcher);
        let result = self.regexp_exec(&matcher, &string, false)?;
        self.stack.push(result.clone());
        if result == Value::Null {
            self.heap.finish_regexp_iterator(*id);
            return self.iterator_result(Value::Undefined, true);
        }
        if !global {
            self.heap.finish_regexp_iterator(*id);
        } else {
            let matched = self.get_property(&result, &"0".into())?;
            if self.coerce_string(&matched)?.is_empty() {
                self.advance_last_index(&matcher, &string, unicode)?;
            }
        }
        self.iterator_result(result, false)
    }

    fn regexp_split(
        &mut self,
        receiver: &Value,
        string: &JsString,
        limit: &Value,
    ) -> Result<Value, RuntimeError> {
        let constructor = self.regexp_species_constructor(receiver)?;
        self.stack.push(constructor.clone());
        let flags = self.get_property(receiver, &"flags".into())?;
        let mut flags = self.coerce_string(&flags)?;
        let unicode = flags
            .as_code_units()
            .iter()
            .any(|&c| c == u16::from(b'u') || c == u16::from(b'v'));
        if !flags.as_code_units().contains(&u16::from(b'y')) {
            flags.push_str(&"y".into());
        }
        let splitter = self.call_native(
            constructor,
            Value::Undefined,
            vec![receiver.clone(), Value::String(flags)],
            true,
        )?;
        self.stack.push(splitter.clone());
        let limit = if *limit == Value::Undefined {
            u32::MAX
        } else {
            native::uint32(self.coerce_number(limit)?)
        } as usize;
        let mut values = Vec::new();
        if limit == 0 {
            return self.array_from(values);
        }
        if string.is_empty() {
            if self.regexp_exec(&splitter, string, false)? == Value::Null {
                values.push(Value::String(string.clone()));
            }
            return self.array_from(values);
        }
        let mut start = 0;
        let mut position = 0;
        while position < string.len() {
            self.charge_step()?;
            self.set_required(&splitter, "lastIndex", Value::Number(position as f64))?;
            let result = self.regexp_exec(&splitter, string, false)?;
            if result == Value::Null {
                position = advance(string, position, unicode);
                continue;
            }
            self.stack.push(result.clone());
            let end = self.get_property(&splitter, &"lastIndex".into())?;
            let end = (self.coerce_length(&end)? as usize).min(string.len());
            if end == start {
                position = advance(string, position, unicode);
                continue;
            }
            values.push(Value::String(JsString::from_code_units(
                string.as_code_units()[start..position].to_vec(),
            )));
            if values.len() == limit {
                return self.array_from(values);
            }
            start = end;
            let length = self.get_property(&result, &"length".into())?;
            let length = self.coerce_length(&length)? as u64;
            for index in 1..length {
                self.charge_step()?;
                let value = self.get_property(&result, &index.to_string().into())?;
                self.stack.push(value.clone());
                values.push(value);
                if values.len() == limit {
                    return self.array_from(values);
                }
            }
            position = start;
        }
        values.push(Value::String(JsString::from_code_units(
            string.as_code_units()[start..].to_vec(),
        )));
        self.array_from(values)
    }

    fn regexp_replace(
        &mut self,
        receiver: &Value,
        string: &JsString,
        replacement: &Value,
    ) -> Result<Value, RuntimeError> {
        let root_base = self.stack.len();
        let result = (|| {
            let callable = self.is_callable(replacement)?;
            let template = if callable {
                JsString::default()
            } else {
                self.coerce_string(replacement)?
            };
            let flags = self.get_property(receiver, &"flags".into())?;
            let flags = self.coerce_string(&flags)?;
            let global = flags.as_code_units().contains(&u16::from(b'g'));
            let unicode = flags
                .as_code_units()
                .iter()
                .any(|&c| c == u16::from(b'u') || c == u16::from(b'v'));
            if global {
                self.set_required(receiver, "lastIndex", Value::Number(0.0))?;
            }
            let mut results = Vec::new();
            loop {
                self.charge_step()?;
                let result = self.regexp_exec(receiver, string, false)?;
                if result == Value::Null {
                    break;
                }
                self.stack.push(result.clone());
                results.push(result.clone());
                if !global {
                    break;
                }
                let matched = self.get_property(&result, &"0".into())?;
                if self.coerce_string(&matched)?.is_empty() {
                    self.advance_last_index(receiver, string, unicode)?;
                }
            }
            let mut output = JsString::default();
            let mut next = 0;
            for result in results {
                let length = self.get_property(&result, &"length".into())?;
                let length = self.coerce_length(&length)? as usize;
                let matched = self.get_property(&result, &"0".into())?;
                let matched = self.coerce_string(&matched)?;
                let position = self.get_property(&result, &"index".into())?;
                let position = native::integer(&Value::Number(self.coerce_number(&position)?))
                    .expect("ToIntegerOrInfinity cannot fail for the converted Number")
                    .clamp(0.0, string.len() as f64) as usize;
                let mut captures = Vec::new();
                for index in 1..length {
                    self.charge_step()?;
                    let capture = self.get_property(&result, &index.to_string().into())?;
                    captures.push(if capture == Value::Undefined {
                        Value::Undefined
                    } else {
                        Value::String(self.coerce_string(&capture)?)
                    });
                }
                let groups = self.get_property(&result, &"groups".into())?;
                self.stack.push(groups.clone());
                let replacement = if callable {
                    let mut args = vec![Value::String(matched.clone())];
                    args.extend(captures.iter().cloned());
                    args.extend([
                        Value::Number(position as f64),
                        Value::String(string.clone()),
                    ]);
                    if groups != Value::Undefined {
                        args.push(groups);
                    }
                    let result =
                        self.call_native(replacement.clone(), Value::Undefined, args, false)?;
                    self.coerce_string(&result)?
                } else {
                    self.capture_substitution(
                        string, &matched, position, &captures, &groups, &template,
                    )?
                };
                if position >= next {
                    native::append(
                        &mut output,
                        &JsString::from_code_units(string.as_code_units()[next..position].to_vec()),
                        self.config.max_string_bytes,
                    )?;
                    native::append(&mut output, &replacement, self.config.max_string_bytes)?;
                    next = (position + matched.len()).min(string.len());
                }
            }
            native::append(
                &mut output,
                &JsString::from_code_units(string.as_code_units()[next..].to_vec()),
                self.config.max_string_bytes,
            )?;
            Ok(Value::String(output))
        })();
        self.stack.truncate(root_base);
        result
    }

    fn capture_substitution(
        &mut self,
        string: &JsString,
        matched: &JsString,
        position: usize,
        captures: &[Value],
        groups: &Value,
        template: &JsString,
    ) -> Result<JsString, RuntimeError> {
        if *groups != Value::Undefined {
            self.coerce_object(groups)?;
        }
        let units = template.as_code_units();
        let mut index = 0;
        let mut result = JsString::default();
        while index < units.len() {
            self.charge_step()?;
            let mut consumed = 1;
            let mut part = JsString::from_code_units(vec![units[index]]);
            if units[index] == u16::from(b'$') {
                match units.get(index + 1).copied() {
                    Some(0x24) => {
                        consumed = 2;
                    }
                    Some(0x26) => {
                        part = matched.clone();
                        consumed = 2;
                    }
                    Some(0x60) => {
                        part =
                            JsString::from_code_units(string.as_code_units()[..position].to_vec());
                        consumed = 2;
                    }
                    Some(0x27) => {
                        part = JsString::from_code_units(
                            string.as_code_units()[(position + matched.len()).min(string.len())..]
                                .to_vec(),
                        );
                        consumed = 2;
                    }
                    Some(digit @ 0x30..=0x39) => {
                        let mut number = (digit - 0x30) as usize;
                        if let Some(second @ 0x30..=0x39) = units.get(index + 2).copied() {
                            let candidate = number * 10 + (second - 0x30) as usize;
                            if candidate > 0 && candidate <= captures.len() {
                                number = candidate;
                                consumed = 3;
                            }
                        }
                        if number > 0 && number <= captures.len() {
                            consumed = consumed.max(2);
                            part = if let Value::String(capture) = &captures[number - 1] {
                                capture.clone()
                            } else {
                                JsString::default()
                            };
                        }
                    }
                    Some(0x3c) if *groups != Value::Undefined => {
                        if let Some(end) = units[index + 2..].iter().position(|&u| u == 0x3e) {
                            let key = JsString::from_code_units(
                                units[index + 2..index + 2 + end].to_vec(),
                            );
                            let value = self.get_property(groups, &key.into())?;
                            part = if value == Value::Undefined {
                                JsString::default()
                            } else {
                                self.coerce_string(&value)?
                            };
                            consumed = end + 3;
                        }
                    }
                    _ => {}
                }
            }
            native::append(&mut result, &part, self.config.max_string_bytes)?;
            index += consumed;
        }
        Ok(result)
    }
}
