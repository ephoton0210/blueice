// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use super::*;

/// Internal name of the wrapper declaration `dynamic_function_constructor`
/// compiles; it is not a valid identifier, so no source can refer to it.
const DYNAMIC_FUNCTION_BINDING: &str = "*anonymous*";

#[cfg(any(test, coverage))]
#[path = "../../../tests/fixtures/dynamic_function_boundaries.rs"]
mod boundary_tests;

/// The four CreateDynamicFunction kinds.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(in super::super) enum DynamicFunctionKind {
    Normal,
    Async,
    Generator,
    AsyncGenerator,
}

/// Operations whose dispatch requires an object record. Keeping this type
/// separate makes the three non-coercing operations impossible below the
/// ToObject boundary.
#[derive(Clone, Copy, PartialEq, Eq)]
enum CoercingObjectMethod {
    Assign,
    HasOwn,
    GetOwnPropertyDescriptor,
    GetOwnPropertyDescriptors,
    DefineProperty,
    DefineProperties,
    Keys,
    Values,
    Entries,
    GetOwnPropertyNames,
    GetOwnPropertySymbols,
    GetPrototypeOf,
    SetPrototypeOf,
    Create,
    OwnKeys,
    IsExtensible,
    PreventExtensions,
    Seal,
    Freeze,
    IsSealed,
    IsFrozen,
    ReflectGet,
    ReflectGetOwnPropertyDescriptor,
    ReflectGetPrototypeOf,
    ReflectDefineProperty,
    ReflectSet,
    ReflectDeleteProperty,
    ReflectPreventExtensions,
    ReflectSetPrototypeOf,
    ReflectIsExtensible,
    ReflectHas,
    HasOwnProperty,
    PropertyIsEnumerable,
}

impl Vm {
    /// ECMA-262 Function constructor. Dynamic function source is compiled in
    /// the realm's global environment rather than inheriting the native
    /// caller's active lexical bindings.
    pub(in super::super) fn function_constructor(
        &mut self,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        self.dynamic_function_constructor(args, DynamicFunctionKind::Normal)
    }

    /// Constructor path for `%AsyncFunction%`. Dynamic functions compile
    /// against the realm global environment; the async form then takes the
    /// same Promise/continuation path as a source async function.
    pub(in super::super) fn async_function_constructor(
        &mut self,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        self.dynamic_function_constructor(args, DynamicFunctionKind::Async)
    }

    /// CreateDynamicFunction ( constructor, newTarget, kind, parameterArgs,
    /// bodyArg ) for all four kinds: the source text is a wrapper declaration
    /// of the matching kind, compiled by the ordinary compiler, and the
    /// resulting closure gets the kind's own prototype and, for generators,
    /// its own `prototype` object.
    pub(in super::super) fn dynamic_function_constructor(
        &mut self,
        args: &[Value],
        kind: DynamicFunctionKind,
    ) -> Result<Value, RuntimeError> {
        let async_function = matches!(
            kind,
            DynamicFunctionKind::Async | DynamicFunctionKind::AsyncGenerator
        );
        let generator = matches!(
            kind,
            DynamicFunctionKind::Generator | DynamicFunctionKind::AsyncGenerator
        );
        let mut parameters = String::new();
        for (index, argument) in args.iter().take(args.len().saturating_sub(1)).enumerate() {
            if index != 0 {
                parameters.push(',');
            }
            parameters.push_str(&crate::source_encoding::encode(
                &self.coerce_string(argument)?,
            ));
        }
        let prefix = match kind {
            DynamicFunctionKind::Normal => "function anonymous(",
            DynamicFunctionKind::Async => "async function anonymous(",
            DynamicFunctionKind::Generator => "function* anonymous(",
            DynamicFunctionKind::AsyncGenerator => "async function* anonymous(",
        };
        let body = match args.last() {
            Some(body) => crate::source_encoding::encode(&self.coerce_string(body)?),
            None => String::new(),
        };
        // Dynamic parameter text is parsed as its own grammar production.
        // Preserve that boundary in the generated wrapper: a trailing
        // single-line comment belongs to the parameters, not to the closing
        // parenthesis that follows them.
        let wrapper =
            |parameters: &str, body: &str| format!("{prefix}{parameters}\n) {{\n{body}\n}}");
        // Annex B HTML-like comments are removed from the parameters for
        // parsing; the text of the function keeps them (see below).
        let parsed_parameters = strip_dynamic_function_html_comments(&parameters);
        // The parameters must parse as FormalParameters and the body as a
        // FunctionBody, each on its own. Only the joined wrapper is compiled,
        // but text that leaves a comment, template or bracket open across the
        // boundary can still make the joined source parse (`Function("/*",
        // "*/) {")`), so each side is also checked against an empty other side.
        let parse_wrapper = |source: &str| -> Result<crate::ast::Function, RuntimeError> {
            let program = crate::parser::parse_encoded(source)
                .map_err(|error| RuntimeError::SyntaxError(error.message))?;
            // Anything but the one wrapper declaration means the text closed
            // the function early (`Function("} function f() {")`).
            match program.body.as_slice() {
                [crate::ast::Stmt::FunctionDecl(function)] => Ok(function.clone()),
                _ => Err(RuntimeError::SyntaxError(
                    "Function source must be exactly one function".into(),
                )),
            }
        };
        parse_wrapper(&wrapper(&parsed_parameters, ""))?;
        if !parsed_parameters.is_empty() {
            parse_wrapper(&wrapper("", &body))?;
        }
        let mut function = parse_wrapper(&wrapper(&parsed_parameters, &body))?;
        // The wrapper declaration only gives the function its `name`
        // property. CreateDynamicFunction binds no such name in the
        // function's scope, so rename the declaration to an internal
        // identifier no source can spell: `anonymous` in the body then
        // resolves like any free identifier.
        function.name = Some(DYNAMIC_FUNCTION_BINDING.into());
        // The wrapper is exactly the source text CreateDynamicFunction
        // prescribes, except that the parsed parameters had their Annex B
        // HTML-like comments removed: the function's text keeps them.
        if parsed_parameters != parameters {
            function.source_text = crate::ast::SourceText::whole(wrapper(&parameters, &body));
        }
        let program = crate::ast::Program {
            body: vec![crate::ast::Stmt::FunctionDecl(function)],
        };
        let code = crate::compile(&program)
            .map_err(|error| RuntimeError::SyntaxError(error.to_string()))?;
        let child = code
            .functions
            .first()
            .cloned()
            .expect("Function wrapper compiles one function declaration");

        debug_assert_eq!(child.async_function, async_function);
        debug_assert_eq!(child.generator, generator);
        let default_prototype = match kind {
            DynamicFunctionKind::Normal => self.function_prototype()?,
            DynamicFunctionKind::Async => self.async_function_prototype()?,
            DynamicFunctionKind::Generator => self.generator_function_prototype()?,
            DynamicFunctionKind::AsyncGenerator => self.async_generator_function_prototype()?,
        };
        // CreateDynamicFunction selects its function object's prototype with
        // GetPrototypeFromConstructor for every dynamic function kind. In
        // particular, `%AsyncFunction%` must observe a revoked Proxy
        // newTarget rather than silently using its default prototype.
        let function_prototype = if self.new_target != Value::Undefined {
            self.constructor_prototype(default_prototype)?
        } else {
            default_prototype
        };
        // Compiling the wrapper declaration produces a single capture for
        // its declaration name. It is an implementation detail of using the
        // ordinary compiler, not a capture of the Function caller.
        let stack_base = self.stack.len();
        let function: Result<ObjectId, RuntimeError> = (|| {
            let mut captures = Vec::with_capacity(child.captures.len());
            for _ in &child.captures {
                let cell = self.with_roots(|heap| heap.alloc_object(None))?;
                self.stack.push(Value::Object(cell));
                captures.push(cell);
            }
            let function = self.with_roots(|heap| {
                heap.alloc_closure(
                    child.clone(),
                    captures.clone(),
                    Value::Undefined,
                    function_prototype,
                )
            })?;
            self.stack.push(Value::Object(function));
            for (&slot, &cell) in child.captures.iter().zip(&captures) {
                // The wrapper has exactly one root declaration and no
                // executable root body. Every captured root binding is its
                // internal declaration name, never a caller's local binding.
                assert_eq!(code.bindings[slot as usize].name, DYNAMIC_FUNCTION_BINDING);
                let value = Value::Object(function);
                self.with_roots(|heap| heap.set(cell, "value", value))?;
            }
            Ok(function)
        })();
        self.stack.truncate(stack_base);
        let function = function?;
        self.stack.push(Value::Object(function));
        let result: Result<(), RuntimeError> = (|| {
            self.define_data(
                function,
                "name",
                Value::String("anonymous".into()),
                false,
                false,
                true,
            )?;
            self.define_data(
                function,
                "length",
                Value::Number(child.function_length as f64),
                false,
                false,
                true,
            )?;
            if child.constructible
                && !child.strict
                && !child.arrow
                && !child.generator
                && !child.async_function
            {
                self.install_legacy_function_properties(function)?;
            }
            if generator {
                // A generator function owns the prototype its instances
                // inherit from; it has no `constructor` back-link.
                let base_prototype = if async_function {
                    self.async_generator_prototype().expect(
                        "AsyncGeneratorFunction initialization retained its generator prototype",
                    )
                } else {
                    self.generator_prototype()
                        .expect("GeneratorFunction initialization retained its generator prototype")
                };
                let prototype = self.with_roots(|heap| heap.alloc_object(Some(base_prototype)))?;
                self.define_data(
                    function,
                    "prototype",
                    Value::Object(prototype),
                    true,
                    false,
                    false,
                )?;
            } else if child.constructible {
                let object_prototype = self.object_prototype;
                let prototype =
                    self.with_roots(|heap| heap.alloc_object(Some(object_prototype)))?;
                self.define_data(
                    function,
                    "prototype",
                    Value::Object(prototype),
                    true,
                    false,
                    false,
                )?;
                self.define_data(
                    prototype,
                    "constructor",
                    Value::Object(function),
                    true,
                    false,
                    true,
                )?;
            }
            Ok(())
        })();
        self.stack.truncate(stack_base);
        result?;
        Ok(Value::Object(function))
    }

    pub(in super::super) fn coerce_object(
        &mut self,
        value: &Value,
    ) -> Result<ObjectId, RuntimeError> {
        match value {
            Value::Object(id) => Ok(*id),
            Value::String(s) => {
                let (_, prototype) = self.string_intrinsics()?;
                Ok(self.with_roots(|heap| heap.alloc_string(s.clone(), Some(prototype)))?)
            }
            Value::Null | Value::Undefined => Err(RuntimeError::TypeError(
                "cannot convert null or undefined to Object".into(),
            )),
            _ => {
                let constructor = self.global(match value {
                    Value::Symbol(_) => "Symbol",
                    Value::Bool(_) => "Boolean",
                    Value::BigInt(_) => "BigInt",
                    _ => "Number",
                })?;
                let prototype = self
                    .heap
                    .get(
                        constructor
                            .object_id()
                            .expect("primitive boxing selects an intrinsic constructor"),
                        "prototype",
                    )
                    .expect("the intrinsic owns a permanently rooted immutable data prototype")
                    .object_id()
                    .expect("primitive constructors install an object prototype");
                Ok(self.with_roots(|heap| heap.alloc_boxed_primitive(value.clone(), prototype))?)
            }
        }
    }

    pub(in super::super) fn object_method(
        &mut self,
        method: ObjectMethod,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let first = native::argument(args, 0);
        if method == ObjectMethod::IsExtensible && !matches!(first, Value::Object(_)) {
            return Ok(Value::Bool(false));
        }
        if matches!(method, ObjectMethod::IsSealed | ObjectMethod::IsFrozen)
            && !matches!(first, Value::Object(_))
        {
            return Ok(Value::Bool(true));
        }
        if matches!(
            method,
            ObjectMethod::PreventExtensions | ObjectMethod::Seal | ObjectMethod::Freeze
        ) && !matches!(first, Value::Object(_))
        {
            return Ok(first.clone());
        }
        if matches!(
            method,
            ObjectMethod::DefineProperty
                | ObjectMethod::DefineProperties
                | ObjectMethod::OwnKeys
                | ObjectMethod::ReflectGet
                | ObjectMethod::ReflectGetOwnPropertyDescriptor
                | ObjectMethod::ReflectDefineProperty
                | ObjectMethod::ReflectSet
                | ObjectMethod::ReflectDeleteProperty
                | ObjectMethod::ReflectPreventExtensions
                | ObjectMethod::ReflectGetPrototypeOf
                | ObjectMethod::ReflectSetPrototypeOf
                | ObjectMethod::ReflectIsExtensible
                | ObjectMethod::ReflectHas
        ) && !matches!(first, Value::Object(_))
        {
            return Err(RuntimeError::TypeError(
                "operation requires an object".into(),
            ));
        }
        // Object.prototype.hasOwnProperty and propertyIsEnumerable perform
        // ToPropertyKey before ToObject(this).  The conversion may call
        // user code, so its abrupt completion must win over a nullish
        // receiver error.
        let property_query_key = if matches!(
            method,
            ObjectMethod::PropertyIsEnumerable | ObjectMethod::HasOwnProperty
        ) {
            Some(self.coerce_property_key(first)?)
        } else {
            None
        };
        let method = match method {
            ObjectMethod::Is => {
                return Ok(Value::Bool(same_value(
                    native::argument(args, 0),
                    native::argument(args, 1),
                )))
            }
            ObjectMethod::FromEntries => return self.object_from_entries_method(first),
            ObjectMethod::GroupBy => {
                return self.object_group_by_method(first, native::argument(args, 1))
            }
            ObjectMethod::Assign => CoercingObjectMethod::Assign,
            ObjectMethod::HasOwn => CoercingObjectMethod::HasOwn,
            ObjectMethod::GetOwnPropertyDescriptor => {
                CoercingObjectMethod::GetOwnPropertyDescriptor
            }
            ObjectMethod::GetOwnPropertyDescriptors => {
                CoercingObjectMethod::GetOwnPropertyDescriptors
            }
            ObjectMethod::DefineProperty => CoercingObjectMethod::DefineProperty,
            ObjectMethod::DefineProperties => CoercingObjectMethod::DefineProperties,
            ObjectMethod::Keys => CoercingObjectMethod::Keys,
            ObjectMethod::Values => CoercingObjectMethod::Values,
            ObjectMethod::Entries => CoercingObjectMethod::Entries,
            ObjectMethod::GetOwnPropertyNames => CoercingObjectMethod::GetOwnPropertyNames,
            ObjectMethod::GetOwnPropertySymbols => CoercingObjectMethod::GetOwnPropertySymbols,
            ObjectMethod::GetPrototypeOf => CoercingObjectMethod::GetPrototypeOf,
            ObjectMethod::SetPrototypeOf => CoercingObjectMethod::SetPrototypeOf,
            ObjectMethod::Create => CoercingObjectMethod::Create,
            ObjectMethod::OwnKeys => CoercingObjectMethod::OwnKeys,
            ObjectMethod::IsExtensible => CoercingObjectMethod::IsExtensible,
            ObjectMethod::PreventExtensions => CoercingObjectMethod::PreventExtensions,
            ObjectMethod::Seal => CoercingObjectMethod::Seal,
            ObjectMethod::Freeze => CoercingObjectMethod::Freeze,
            ObjectMethod::IsSealed => CoercingObjectMethod::IsSealed,
            ObjectMethod::IsFrozen => CoercingObjectMethod::IsFrozen,
            ObjectMethod::ReflectGet => CoercingObjectMethod::ReflectGet,
            ObjectMethod::ReflectGetOwnPropertyDescriptor => {
                CoercingObjectMethod::ReflectGetOwnPropertyDescriptor
            }
            ObjectMethod::ReflectGetPrototypeOf => CoercingObjectMethod::ReflectGetPrototypeOf,
            ObjectMethod::ReflectDefineProperty => CoercingObjectMethod::ReflectDefineProperty,
            ObjectMethod::ReflectSet => CoercingObjectMethod::ReflectSet,
            ObjectMethod::ReflectDeleteProperty => CoercingObjectMethod::ReflectDeleteProperty,
            ObjectMethod::ReflectPreventExtensions => {
                CoercingObjectMethod::ReflectPreventExtensions
            }
            ObjectMethod::ReflectSetPrototypeOf => CoercingObjectMethod::ReflectSetPrototypeOf,
            ObjectMethod::ReflectIsExtensible => CoercingObjectMethod::ReflectIsExtensible,
            ObjectMethod::ReflectHas => CoercingObjectMethod::ReflectHas,
            ObjectMethod::HasOwnProperty => CoercingObjectMethod::HasOwnProperty,
            ObjectMethod::PropertyIsEnumerable => CoercingObjectMethod::PropertyIsEnumerable,
        };
        use CoercingObjectMethod::*;
        let object = if matches!(method, PropertyIsEnumerable | HasOwnProperty) {
            self.coerce_object(receiver)?
        } else if method == Create {
            let prototype = match first {
                Value::Null => None,
                Value::Object(id) => Some(*id),
                _ => {
                    return Err(RuntimeError::TypeError(
                        "Object.create prototype must be object or null".into(),
                    ))
                }
            };
            self.with_roots(|heap| heap.alloc_object(prototype))?
        } else {
            self.coerce_object(first)?
        };
        let root_base = self.stack.len();
        let result = (|| {
            self.stack.push(Value::Object(object));
            match method {
                Assign => {
                    let base = self.stack.len();
                    let result = (|| {
                        for source in args.iter().skip(1) {
                            if matches!(source, Value::Undefined | Value::Null) {
                                continue;
                            }
                            let source = self.coerce_object(source)?;
                            self.stack.push(Value::Object(source));
                            for key in self.object_own_property_keys(source)? {
                                let Some(descriptor) =
                                    self.object_get_own_property(source, &key)?
                                else {
                                    continue;
                                };
                                if descriptor.enumerable != Some(true) {
                                    continue;
                                }
                                let value = self.get_property(&Value::Object(source), &key)?;
                                self.stack.push(value.clone());
                                if !self.ordinary_set_with_receiver(
                                    object,
                                    &Value::Object(object),
                                    &key,
                                    &value,
                                )? {
                                    return Err(RuntimeError::TypeError(
                                        "cannot assign property".into(),
                                    ));
                                }
                                self.stack.pop();
                            }
                            self.stack.pop();
                        }
                        Ok(Value::Object(object))
                    })();
                    self.stack.truncate(base);
                    result
                }
                HasOwn => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    Ok(Value::Bool(
                        self.object_get_own_property(object, &key)?.is_some(),
                    ))
                }
                GetOwnPropertyDescriptors => {
                    // Object.getOwnPropertyDescriptors observes the object's
                    // internal methods directly.  In particular, it does not
                    // call the public Object.getOwnPropertyDescriptor property:
                    // replacing that property must not affect this operation.
                    // Keeping the walk at this boundary also preserves Proxy
                    // trap order and lets primitive inputs use their ordinary
                    // temporary wrapper without exposing it to JavaScript.
                    let prototype = self.object_prototype;
                    let descriptors = self.with_roots(|heap| heap.alloc_object(Some(prototype)))?;
                    self.stack.push(Value::Object(descriptors));
                    for key in self.object_own_property_keys(object)? {
                        let Some(descriptor) = self.object_get_own_property(object, &key)? else {
                            continue;
                        };
                        let descriptor_object =
                            self.with_roots(|heap| heap.alloc_object(Some(prototype)))?;
                        self.stack.push(Value::Object(descriptor_object));
                        for (name, value) in [
                            ("value", descriptor.value),
                            ("writable", descriptor.writable.map(Value::Bool)),
                            ("get", descriptor.get),
                            ("set", descriptor.set),
                            ("enumerable", descriptor.enumerable.map(Value::Bool)),
                            ("configurable", descriptor.configurable.map(Value::Bool)),
                        ] {
                            if let Some(value) = value {
                                self.with_roots(|heap| heap.set(descriptor_object, name, value))?;
                            }
                        }
                        let defined = self.object_define_own_property(
                            descriptors,
                            key,
                            PropertyDescriptor::data(
                                Value::Object(descriptor_object),
                                true,
                                true,
                                true,
                            ),
                        )?;
                        assert!(
                        defined,
                        "a fresh extensible ordinary descriptor record accepts each unique own key"
                    );
                        self.stack.pop();
                    }
                    Ok(Value::Object(descriptors))
                }
                DefineProperties => {
                    let properties = self.coerce_object(native::argument(args, 1))?;
                    self.stack.push(Value::Object(properties));
                    let mut descriptors = Vec::new();
                    for key in self.object_own_property_keys(properties)? {
                        if self
                            .object_get_own_property(properties, &key)?
                            .is_none_or(|descriptor| descriptor.enumerable != Some(true))
                        {
                            continue;
                        }
                        let descriptor_object =
                            self.get_property(&Value::Object(properties), &key)?;
                        self.stack.push(descriptor_object.clone());
                        descriptors.push((key, self.read_descriptor(&descriptor_object)?));
                    }
                    for (key, mut descriptor) in descriptors {
                        if key == "length"
                            && self.heap.is_array(object).expect(
                                "ToObject retained this live target during descriptor conversion",
                            )
                        {
                            if let Some(value) = &descriptor.value {
                                descriptor.value = Some(self.array_length_value(value)?);
                            }
                        }
                        if !self.object_define_own_property(object, key, descriptor)? {
                            return Err(RuntimeError::TypeError("cannot redefine property".into()));
                        }
                    }
                    Ok(Value::Object(object))
                }
                ReflectGet => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    let receiver = args.get(2).cloned().unwrap_or(Value::Object(object));
                    self.get_object_property(object, &receiver, &key)
                }
                GetOwnPropertyDescriptor
                | ReflectGetOwnPropertyDescriptor
                | DefineProperty
                | ReflectDefineProperty => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    if matches!(method, DefineProperty | ReflectDefineProperty) {
                        let mut descriptor = self.read_descriptor(native::argument(args, 2))?;
                        if key == "length"
                            && self.heap.is_array(object).expect(
                                "ToObject retained this live target during descriptor conversion",
                            )
                        {
                            if let Some(value) = &descriptor.value {
                                descriptor.value = Some(self.array_length_value(value)?);
                            }
                        }
                        let defined = self.object_define_own_property(object, key, descriptor)?;
                        if method == ReflectDefineProperty {
                            return Ok(Value::Bool(defined));
                        }
                        if !defined {
                            return Err(RuntimeError::TypeError("cannot redefine property".into()));
                        }
                        return Ok(Value::Object(object));
                    }
                    let Some(descriptor) = self.object_get_own_property(object, &key)? else {
                        return Ok(Value::Undefined);
                    };
                    let prototype = self.object_prototype;
                    let result = self.with_roots(|heap| heap.alloc_object(Some(prototype)))?;
                    self.stack.push(Value::Object(result));
                    for (name, value) in [
                        ("value", descriptor.value),
                        ("writable", descriptor.writable.map(Value::Bool)),
                        ("get", descriptor.get),
                        ("set", descriptor.set),
                        ("enumerable", descriptor.enumerable.map(Value::Bool)),
                        ("configurable", descriptor.configurable.map(Value::Bool)),
                    ] {
                        if let Some(value) = value {
                            self.with_roots(|heap| heap.set(result, name, value))?;
                        }
                    }
                    Ok(Value::Object(result))
                }
                PropertyIsEnumerable => {
                    let key = property_query_key.expect("property query key was coerced");
                    // [[GetOwnProperty]], not the raw heap record: a lazily
                    // materialized intrinsic global is a real own property that
                    // merely has not been created yet, and an exotic object
                    // (e.g. a Proxy) must have its own trap observed here
                    // exactly as `Object.hasOwn`/`Object.getOwnPropertyDescriptor`
                    // already do.
                    Ok(Value::Bool(
                        self.object_get_own_property(object, &key)?
                            .is_some_and(|descriptor| descriptor.enumerable == Some(true)),
                    ))
                }
                HasOwnProperty => {
                    let key = property_query_key.expect("property query key was coerced");
                    Ok(Value::Bool(
                        self.object_get_own_property(object, &key)?.is_some(),
                    ))
                }
                Keys | Values | Entries | GetOwnPropertyNames | GetOwnPropertySymbols | OwnKeys => {
                    // Each entry array is created before the final result array.
                    // Keep already-created object values on the VM stack while a
                    // later getter or allocation can trigger collection.
                    let base = self.stack.len();
                    let result = (|| {
                        let keys = self.object_own_property_keys(object)?;
                        let mut values = Vec::new();
                        for key in keys {
                            if matches!(method, Keys | Values | Entries) {
                                // EnumerableOwnProperties filters to String keys
                                // before it invokes [[GetOwnProperty]].  A Proxy
                                // descriptor trap must therefore never observe a
                                // symbol that Object.keys/values/entries will omit.
                                if !matches!(key, PropertyName::String(_)) {
                                    continue;
                                }
                                // EnumerableOwnProperties snapshots keys, but obtains
                                // a descriptor for each key immediately before it
                                // observes the value.  An earlier getter can delete
                                // a later key, in which case it is simply omitted.
                                let Some(descriptor) =
                                    self.object_get_own_property(object, &key)?
                                else {
                                    continue;
                                };
                                if descriptor.enumerable != Some(true) {
                                    continue;
                                }
                            }
                            if method == GetOwnPropertyNames
                                && !matches!(key, PropertyName::String(_))
                                || method == GetOwnPropertySymbols
                                    && !matches!(key, PropertyName::Symbol(_))
                            {
                                continue;
                            }
                            let value = if method == Values {
                                self.get_property(&Value::Object(object), &key)?
                            } else if method == Entries {
                                let value = self.get_property(&Value::Object(object), &key)?;
                                self.array_from(vec![key.value(), value])?
                            } else {
                                key.value()
                            };
                            if matches!(value, Value::Object(_)) {
                                self.stack.push(value.clone());
                            }
                            values.push(value);
                        }
                        self.array_from(values)
                    })();
                    self.stack.truncate(base);
                    result
                }
                GetPrototypeOf | ReflectGetPrototypeOf => Ok(self
                    .object_get_prototype(object)?
                    .map_or(Value::Null, Value::Object)),
                SetPrototypeOf | ReflectSetPrototypeOf => {
                    let prototype = match native::argument(args, 1) {
                        Value::Null => None,
                        Value::Object(id) => Some(*id),
                        _ => {
                            return Err(RuntimeError::TypeError(
                                "prototype must be object or null".into(),
                            ))
                        }
                    };
                    let changed = self.object_set_prototype(object, prototype)?;
                    if method == ReflectSetPrototypeOf {
                        return Ok(Value::Bool(changed));
                    }
                    if !changed {
                        return Err(RuntimeError::TypeError(
                            "cannot set object prototype".into(),
                        ));
                    }
                    Ok(first.clone())
                }
                Create => {
                    let properties = native::argument(args, 1);
                    if *properties != Value::Undefined {
                        let properties = self.coerce_object(properties)?;
                        self.stack.push(Value::Object(properties));
                        let mut descriptors = Vec::new();
                        for key in self.object_own_property_keys(properties)? {
                            if self
                                .object_get_own_property(properties, &key)?
                                .is_some_and(|d| d.enumerable == Some(true))
                            {
                                let value = self.get_property(&Value::Object(properties), &key)?;
                                self.stack.push(value.clone());
                                descriptors.push((key, self.read_descriptor(&value)?));
                            }
                        }
                        for (key, descriptor) in descriptors {
                            let defined =
                                self.object_define_own_property(object, key, descriptor)?;
                            assert!(defined, "Object.create defines validated descriptors with unique keys on a fresh extensible ordinary object");
                        }
                    }
                    Ok(Value::Object(object))
                }
                IsExtensible | ReflectIsExtensible => {
                    Ok(Value::Bool(self.object_is_extensible(object)?))
                }
                PreventExtensions => {
                    if !self.object_prevent_extensions(object)? {
                        return Err(RuntimeError::TypeError(
                            "cannot prevent object extensions".into(),
                        ));
                    }
                    Ok(Value::Object(object))
                }
                ReflectPreventExtensions => {
                    Ok(Value::Bool(self.object_prevent_extensions(object)?))
                }
                ReflectSet => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    let value = native::argument(args, 2).clone();
                    let receiver = args.get(3).cloned().unwrap_or(Value::Object(object));
                    Ok(Value::Bool(self.ordinary_set_with_receiver(
                        object, &receiver, &key, &value,
                    )?))
                }
                ReflectDeleteProperty => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    Ok(Value::Bool(self.object_delete(object, &key)?))
                }
                ReflectHas => {
                    let key = self.coerce_property_key(native::argument(args, 1))?;
                    Ok(Value::Bool(self.has_property(object, &key)?))
                }
                Seal | Freeze => {
                    // SetIntegrityLevel makes the object non-extensible before
                    // attempting its per-property descriptor changes. This is
                    // observable for integer-indexed exotics: a resizable or
                    // length-tracking TypedArray rejects the first step, while a
                    // fixed non-empty view becomes non-extensible and then
                    // rejects redefining its indexed properties.
                    if !self.object_prevent_extensions(object)? {
                        return Err(RuntimeError::TypeError(
                            "cannot make object non-extensible".into(),
                        ));
                    }
                    let keys = self.object_own_property_keys(object)?;
                    for key in keys {
                        let Some(current) = self.object_get_own_property(object, &key)? else {
                            continue;
                        };
                        let descriptor = PropertyDescriptor {
                            configurable: Some(false),
                            writable: (method == Freeze && current.value.is_some())
                                .then_some(false),
                            ..Default::default()
                        };
                        if !self.object_define_own_property(object, key, descriptor)? {
                            return Err(RuntimeError::TypeError(
                                "cannot make object non-extensible".into(),
                            ));
                        }
                    }
                    Ok(first.clone())
                }
                IsSealed | IsFrozen => {
                    if self.object_is_extensible(object)? {
                        return Ok(Value::Bool(false));
                    }
                    for key in self.object_own_property_keys(object)? {
                        let Some(descriptor) = self.object_get_own_property(object, &key)? else {
                            continue;
                        };
                        if descriptor.configurable != Some(false)
                            || (method == IsFrozen
                                && descriptor.value.is_some()
                                && descriptor.writable != Some(false))
                        {
                            return Ok(Value::Bool(false));
                        }
                    }
                    Ok(Value::Bool(true))
                }
            }
        })();
        self.stack.truncate(root_base);
        result
    }

    pub(in super::super) fn read_descriptor(
        &mut self,
        value: &Value,
    ) -> Result<PropertyDescriptor, RuntimeError> {
        let Value::Object(object) = value else {
            return Err(RuntimeError::TypeError(
                "descriptor must be an object".into(),
            ));
        };
        let base = self.stack.len();
        let result = (|| {
            let mut descriptor = PropertyDescriptor::default();
            for name in [
                "enumerable",
                "configurable",
                "value",
                "writable",
                "get",
                "set",
            ] {
                if !self.has_property(*object, &name.into())? {
                    continue;
                }
                let property = self.get_property(value, &name.into())?;
                // Later descriptor getters may allocate and collect earlier values.
                self.stack.push(property.clone());
                match name {
                    "enumerable" => {
                        descriptor.enumerable = Some(
                            self.to_boolean(&property)
                                .expect("a descriptor Get produces a live JavaScript value"),
                        )
                    }
                    "configurable" => {
                        descriptor.configurable = Some(
                            self.to_boolean(&property)
                                .expect("a descriptor Get produces a live JavaScript value"),
                        )
                    }
                    "writable" => {
                        descriptor.writable = Some(
                            self.to_boolean(&property)
                                .expect("a descriptor Get produces a live JavaScript value"),
                        )
                    }
                    "value" => descriptor.value = Some(property),
                    _ => {
                        if property != Value::Undefined
                            && !self
                                .is_callable(&property)
                                .expect("the descriptor's accessor value stays rooted after Get")
                        {
                            return Err(RuntimeError::TypeError(
                                "accessor must be callable or undefined".into(),
                            ));
                        }
                        if name == "get" {
                            descriptor.get = Some(property);
                        } else {
                            descriptor.set = Some(property);
                        }
                    }
                }
            }
            if descriptor.accessor()
                && (descriptor.value.is_some() || descriptor.writable.is_some())
            {
                return Err(RuntimeError::TypeError(
                    "invalid mixed property descriptor".into(),
                ));
            }
            Ok(descriptor)
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super) fn string_iterator_prototype(&mut self) -> Result<ObjectId, RuntimeError> {
        if let Some(prototype) = self.iterator_prototype {
            return Ok(prototype);
        }
        let function_prototype = self.function_prototype()?;
        let iterator_base = self.base_iterator_prototype()?;
        let prototype = self.with_roots(|heap| heap.alloc_object(Some(iterator_base)))?;
        let root = self.heap.root(prototype)?;
        let result = (|| {
            self.install_native(
                prototype,
                function_prototype,
                "next",
                0,
                NativeFunction::IteratorNext,
            )?;
            self.define_data(
                prototype,
                JsSymbol::well_known("toStringTag"),
                Value::String("String Iterator".into()),
                false,
                false,
                true,
            )?;
            Ok(prototype)
        })();
        if result.is_err() {
            self.release_root(root);
        } else {
            self.iterator_prototype = Some(prototype);
        }
        result
    }

    pub(in super::super) fn install_symbol_native(
        &mut self,
        owner: ObjectId,
        prototype: ObjectId,
        symbol: &str,
        length: u32,
        native: NativeFunction,
    ) -> Result<(), RuntimeError> {
        let name = format!("[Symbol.{symbol}]");
        let id = self.with_roots(|heap| heap.alloc_native_function(native, &name, prototype))?;
        let base = self.stack.len();
        self.stack.push(Value::Object(id));
        let result = (|| {
            self.define_data(
                id,
                "name",
                Value::String(format!("[Symbol.{symbol}]").into()),
                false,
                false,
                true,
            )?;
            self.define_data(
                id,
                "length",
                Value::Number(length as f64),
                false,
                false,
                true,
            )?;
            // Function.prototype @@hasInstance is the immutable Symbol method.
            let mutable = native != NativeFunction::HasInstance;
            self.define_data(
                owner,
                JsSymbol::well_known(symbol),
                Value::Object(id),
                mutable,
                false,
                mutable,
            )?;
            Ok(())
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super) fn string_pattern(
        &mut self,
        method: PatternMethod,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        if matches!(receiver, Value::Null | Value::Undefined) {
            return Err(RuntimeError::TypeError(
                "String method requires a non-null receiver".into(),
            ));
        }
        let pattern = native::argument(args, 0);
        let symbol = match method {
            PatternMethod::Match => "match",
            PatternMethod::MatchAll => "matchAll",
            PatternMethod::Search => "search",
        };
        // `String.prototype.{match,matchAll,search}` only obtains a symbol
        // hook from an Object argument. `GetMethod` would box a primitive and
        // incorrectly observe a hook installed on (for example)
        // `Number.prototype[Symbol.match]`; the standard methods must instead
        // create a RegExp from that primitive.
        if matches!(pattern, Value::Object(_)) {
            if method == PatternMethod::MatchAll {
                self.require_global_pattern(pattern)?;
            }
            let method = self.get_method(pattern, &JsSymbol::well_known(symbol).into())?;
            if method != Value::Undefined {
                return self.call_native(method, pattern.clone(), vec![receiver.clone()], false);
            }
        }
        let string = self.coerce_string(receiver)?;
        let regexp = self.regexp_create(
            pattern,
            &if method == PatternMethod::MatchAll {
                Value::String("g".into())
            } else {
                Value::Undefined
            },
        )?;
        let base = self.stack.len();
        self.stack.push(regexp.clone());
        let result = (|| {
            let function = self.get_property(&regexp, &JsSymbol::well_known(symbol).into())?;
            self.call_native(function, regexp, vec![Value::String(string)], false)
        })();
        self.stack.truncate(base);
        result
    }
}
