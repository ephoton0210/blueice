// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use super::*;

#[cfg(any(test, coverage))]
#[path = "../../../tests/fixtures/object_internal.rs"]
mod boundary_tests;

impl Vm {
    /// `%Object.prototype%.hasOwnProperty` and `.propertyIsEnumerable` are
    /// installed on first ordinary lookup. Every reflective internal method
    /// on that object ([[GetOwnProperty]], [[DefineOwnProperty]], [[Delete]],
    /// [[OwnPropertyKeys]]) must see them as the ordinary own properties they
    /// are: without this a first `Object.defineProperty` would define a fresh
    /// non-configurable property, and a first `delete` would report success
    /// yet leave the method to be installed again by the next lookup. `key` is
    /// `None` for [[OwnPropertyKeys]].
    pub(in super::super) fn materialize_object_prototype_methods(
        &mut self,
        object: ObjectId,
        key: Option<&PropertyName>,
    ) -> Result<(), RuntimeError> {
        if object != self.object_prototype {
            return Ok(());
        }
        if key.is_none_or(|key| key == "propertyIsEnumerable") {
            self.property_is_enumerable_intrinsic()?;
        }
        if key.is_none_or(|key| key == "hasOwnProperty") {
            self.has_own_property_intrinsic()?;
        }
        Ok(())
    }

    /// [[GetOwnProperty]] dispatch used by descriptor APIs, Proxy invariants,
    /// and receiver-aware [[Set]].  Ordinary heap records stay below this
    /// boundary; every Proxy operation re-enters through the VM so its trap
    /// may call JavaScript while roots remain registered.
    pub(in super::super) fn object_get_own_property(
        &mut self,
        object: ObjectId,
        key: &PropertyName,
    ) -> Result<Option<PropertyDescriptor>, RuntimeError> {
        let proxy = self.heap.proxy(object)?.is_some();
        let base = self.stack.len();
        self.stack.push(Value::Object(object));
        let result = (|| {
            if !proxy && self.test262_foreign_reference(object).is_some() {
                return self.test262_foreign_get_own_property(object, key);
            }
            self.trigger_deferred_namespace(object, Some(key))?;
            // Intrinsic globals are lazily initialized, but reflective descriptor
            // operations must observe the same own properties as ordinary Get.
            self.materialize_global_object_property(object, key)?;
            // Keep the lazily-installed Iterator helper visible to every
            // [[GetOwnProperty]] consumer. Test262's descriptor harness reaches
            // this internal operation through both public reflection APIs and its
            // host fast paths, so materializing only at public call sites made the
            // same property inconsistently observable.
            self.materialize_iterator_helper_property(object, key)?;
            // These %Object.prototype% methods are installed on first ordinary
            // lookup. [[GetOwnProperty]] is also observable through descriptor
            // APIs, however, so it must not expose a transient lazy-intrinsic
            // absence to Object.getOwnPropertyDescriptor.
            self.materialize_object_prototype_methods(object, Some(key))?;
            // Likewise, %Function.prototype%'s constructor is installed while
            // materializing %Function%. A reflective lookup needs the same
            // observable property that `fn.constructor` receives through [[Get]].
            if key == "constructor" && object == self.function_prototype()? {
                self.global("Function")?;
            }
            if proxy {
                return self.proxy_get_own_property(object, key);
            }
            // A foreign/reverse facade is intentionally an empty local object
            // (see `test262_transport_value`'s doc comment), so without this
            // check every own-property query -- `Object.keys`/`getOwnProperty
            // Descriptor`/`hasOwnProperty`/`in`/spread/`for-in`/JSON.stringify,
            // all of which ultimately reach [[GetOwnProperty]] -- would report
            // every real own property as absent.
            if self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_get_own_property(object, key);
            }
            // A live namespace may still expose an uninitialized export.
            // Preserve that ReferenceError as well as the rooted receiver.
            self.heap
                .get_own_property_descriptor(object, key)
                .map_err(Into::into)
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super) fn object_define_own_property(
        &mut self,
        object: ObjectId,
        key: PropertyName,
        descriptor: PropertyDescriptor,
    ) -> Result<bool, RuntimeError> {
        let proxy = self.heap.proxy(object)?.is_some();
        let base = self.stack.len();
        self.stack.push(Value::Object(object));
        self.stack.extend(
            [
                descriptor.value.as_ref(),
                descriptor.get.as_ref(),
                descriptor.set.as_ref(),
            ]
            .into_iter()
            .flatten()
            .cloned(),
        );
        let result = (|| {
            self.trigger_deferred_namespace(object, Some(&key))?;
            if proxy {
                return self.proxy_define_own_property(object, key, descriptor);
            }
            self.materialize_object_prototype_methods(object, Some(&key))?;
            if self.test262_foreign_reference(object).is_some() {
                return self.test262_foreign_define_own_property(object, key, descriptor);
            }
            if self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_define_own_property(object, key, descriptor);
            }
            if let Some(numeric) = self
                .heap
                .typed_array_numeric_key(object, &key)
                .expect("the receiver remains rooted after its initial heap validation")
            {
                return self.typed_array_define_own_property(object, numeric, descriptor);
            }
            self.with_roots(|heap| heap.define_own_property(object, key, descriptor))
        })();
        self.stack.truncate(base);
        result
    }

    /// IntegerIndexedElementSet and the compatible portion of
    /// IntegerIndexedObject.[[DefineOwnProperty]].  A canonical numeric key
    /// never becomes an ordinary property, even when it is invalid or outside
    /// the fixed view range.
    pub(in super::super) fn typed_array_define_own_property(
        &mut self,
        object: ObjectId,
        numeric: TypedArrayNumericKey,
        descriptor: PropertyDescriptor,
    ) -> Result<bool, RuntimeError> {
        let TypedArrayNumericKey::Index(index) = numeric else {
            return Ok(false);
        };
        let (buffer, _, length, kind) = self.heap.typed_array_info(object)?;
        if self
            .heap
            .buffer_is_detached(buffer)
            .expect("the validated TypedArray owns a live backing buffer")
            || index >= length
        {
            return Ok(false);
        }
        if self
            .heap
            .buffer_is_immutable(buffer)
            .expect("the validated TypedArray owns a live backing buffer")
        {
            // Immutable-buffer elements behave as permanently frozen data
            // properties: only a descriptor compatible with the current
            // { value, writable: false, enumerable: true, configurable: false }
            // succeeds, and `descriptor.value` is compared as given (SameValue)
            // rather than converted, so redefining an element never writes.
            let current = PropertyDescriptor::data(
                self.heap
                    .typed_array_index_value(object, index)
                    .expect(
                        "the immutable view and its checked index cannot change without user code",
                    )
                    .expect("a valid integer index has a value"),
                false,
                true,
                false,
            );
            return Ok(compatible_property_descriptor(
                false,
                Some(&current),
                &descriptor,
            ));
        }
        if descriptor.accessor()
            || descriptor.configurable == Some(false)
            || descriptor.enumerable == Some(false)
            || descriptor.writable == Some(false)
        {
            return Ok(false);
        }
        let Some(value) = descriptor.value else {
            return Ok(true);
        };
        let value = self.typed_array_element_value(kind, &value)?;
        // IntegerIndexedElementSet converts first. A conversion may detach the
        // backing buffer; in that case the already-valid DefineOwnProperty
        // operation still succeeds without writing a byte.
        if self
            .heap
            .buffer_is_detached(buffer)
            .expect("the rooted TypedArray retains its backing buffer across conversion")
        {
            return Ok(true);
        }
        self.with_roots(|heap| heap.typed_array_set_index(object, index, &value))
    }

    pub(in super::super) fn object_delete(
        &mut self,
        object: ObjectId,
        key: &PropertyName,
    ) -> Result<bool, RuntimeError> {
        let proxy = self.heap.proxy(object)?.is_some();
        let base = self.stack.len();
        self.stack.push(Value::Object(object));
        let result = (|| {
            self.trigger_deferred_namespace(object, Some(key))?;
            // Lazy global intrinsics still have their specified own-property
            // descriptors when observed through [[Delete]]. Without this, deleting
            // an as-yet-unread `globalThis.undefined` incorrectly looked like a
            // successful deletion of an absent property.
            self.materialize_global_object_property(object, key)?;
            // Likewise a lazily installed Iterator helper exists to be deleted.
            self.materialize_iterator_helper_property(object, key)?;
            if proxy {
                return self.proxy_delete(object, key);
            }
            if self.test262_foreign_reference(object).is_some() {
                return self.test262_foreign_delete(object, key);
            }
            if self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_delete(object, key);
            }
            self.materialize_object_prototype_methods(object, Some(key))?;
            let deleted = self
                .heap
                .delete(object, key)
                .expect("the validated receiver remains rooted during materialization");
            if deleted {
                if let Some(cell) = self.global_property_cell(object, key) {
                    // Property deletion and DeleteBinding invalidate the same
                    // object-environment binding. Captured eval references must
                    // resolve outward after either public operation.
                    let name = key
                        .clone()
                        .into_string()
                        .expect("a property-backed global binding has a string key")
                        .to_utf8()
                        .expect("global_property_cell validated this binding name");
                    let binding = self
                        .global_bindings
                        .remove(&name)
                        .expect("global_property_cell found this published binding");
                    self.heap
                        .delete(cell, "value")
                        .expect("removing the rooted global binding's value cannot allocate");
                    self.release_root(binding._root);
                }
            }
            Ok(deleted)
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super) fn object_own_property_keys(
        &mut self,
        object: ObjectId,
    ) -> Result<Vec<PropertyName>, RuntimeError> {
        let proxy = self.heap.proxy(object)?.is_some();
        let base = self.stack.len();
        self.stack.push(Value::Object(object));
        let result = (|| {
            self.trigger_deferred_namespace(object, None)?;
            // A Test262 child-realm facade has no mirrored ordinary properties.
            // Its [[OwnPropertyKeys]] must be performed in the target Realm so
            // reflection sees the complete intrinsic surface and its key order.
            if !proxy && self.test262_foreign_reference(object).is_some() {
                return self.test262_foreign_own_property_keys(object);
            }
            if !proxy && self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_own_property_keys(object);
            }
            self.materialize_object_prototype_methods(object, None)?;
            // Global built-ins are initialized on demand to keep ordinary realms
            // compact. [[OwnPropertyKeys]] is nevertheless a reflective view of
            // the realm record, so it must expose every standard global property
            // even when no direct identifier/property access has initialized
            // them yet: the same set `Object.preventExtensions(globalThis)`
            // creates before it closes the object.
            if self.globals.get("globalThis") == Some(&object) {
                for name in ["undefined", "NaN", "Infinity"]
                    .iter()
                    .chain(super::super::execution::LAZY_STANDARD_GLOBALS)
                {
                    self.materialize_lexical_global(object, name)?;
                }
            }
            if proxy {
                return self.proxy_own_keys(object);
            }
            Ok(self
                .heap
                .own_property_keys(object)
                .expect("the validated receiver remains rooted during materialization"))
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super) fn object_is_extensible(
        &mut self,
        object: ObjectId,
    ) -> Result<bool, RuntimeError> {
        if self.heap.proxy(object)?.is_some() {
            return self.proxy_is_extensible(object);
        }
        if self.test262_foreign_reference(object).is_some() {
            return self.test262_foreign_is_extensible(object);
        }
        Ok(self
            .heap
            .is_extensible(object)
            .expect("the preceding proxy lookup validated this live ordinary object"))
    }

    pub(in super::super) fn object_get_prototype(
        &mut self,
        object: ObjectId,
    ) -> Result<Option<ObjectId>, RuntimeError> {
        if self.heap.proxy(object)?.is_some() {
            return self.proxy_get_prototype(object);
        }
        if self.test262_foreign_reference(object).is_some() {
            return self.test262_foreign_get_prototype(object);
        }
        if self.test262_reverse_reference(object).is_some() {
            return self.test262_reverse_get_prototype(object);
        }
        Ok(self
            .heap
            .prototype(object)
            .expect("the preceding proxy lookup validated this live ordinary object"))
    }

    pub(in super::super) fn object_set_prototype(
        &mut self,
        object: ObjectId,
        prototype: Option<ObjectId>,
    ) -> Result<bool, RuntimeError> {
        if self.heap.proxy(object)?.is_some() {
            return self.proxy_set_prototype(object, prototype);
        }
        // A foreign/reverse facade's *local* heap record has no bearing on
        // the real membrane target's own [[Prototype]] (see
        // `test262_transport_value`'s doc comment on why it is
        // intentionally empty): `self.heap.set_prototype` below would only
        // ever mutate the facade's own, otherwise-unobserved local slot.
        // Forward this to the real object's own [[SetPrototypeOf]] instead.
        if self.test262_foreign_reference(object).is_some() {
            return self.test262_foreign_set_prototype(object, prototype);
        }
        if self.test262_reverse_reference(object).is_some() {
            return self.test262_reverse_set_prototype(object, prototype);
        }
        // OrdinarySetPrototypeOf's cycle check walks [[GetPrototypeOf]]
        // through every ordinary object, including the facades of other
        // Realms, which the heap-level check below cannot see through.
        if !self.test262_foreign_values.is_empty() {
            let mut current = prototype;
            while let Some(candidate) = current {
                if candidate == object {
                    return Ok(false);
                }
                if self.heap.proxy(candidate)?.is_some() {
                    break;
                }
                self.charge_step()?;
                current = if self.test262_foreign_reference(candidate).is_some() {
                    self.test262_foreign_get_prototype(candidate)?
                } else {
                    self.heap
                        .prototype(candidate)
                        .expect("the preceding proxy lookup validated this ordinary candidate")
                };
            }
        }
        // %Object.prototype% is the Immutable Prototype Exotic Object.  Its
        // current null prototype is accepted as a no-op, but no distinct
        // value may replace it even though the record is otherwise
        // extensible.
        if object == self.object_prototype {
            return Ok(prototype
                == self
                    .heap
                    .prototype(object)
                    .expect("Object.prototype is a permanent VM root"));
        }
        match self.heap.set_prototype(object, prototype) {
            Ok(()) => Ok(true),
            Err(HeapError::ReadOnlyProperty | HeapError::PrototypeCycle) => Ok(false),
            Err(error) => Err(error.into()),
        }
    }

    pub(in super::super) fn object_prevent_extensions(
        &mut self,
        object: ObjectId,
    ) -> Result<bool, RuntimeError> {
        if self.heap.proxy(object)?.is_some() {
            return self.proxy_prevent_extensions(object);
        }
        if self.test262_foreign_reference(object).is_some() {
            return self.test262_foreign_prevent_extensions(object);
        }
        if self
            .heap
            .is_typed_array(object)
            .expect("the proxy lookup validated this live ordinary object")
            && !self
                .heap
                .typed_array_prevent_extensions_allowed(object)
                .expect("the rooted TypedArray retains its backing buffer during this pure query")
        {
            return Ok(false);
        }
        if self.globals.get("globalThis") == Some(&object) {
            // The standard globals are created on first use. A non-extensible
            // global object cannot gain them later, and they belong to it from
            // the start, so create them before the object is closed.
            for name in ["undefined", "NaN", "Infinity"]
                .iter()
                .chain(super::super::execution::LAZY_STANDARD_GLOBALS)
            {
                self.materialize_lexical_global(object, name)?;
            }
        }
        self.heap.prevent_extensions(object).expect(
            "the validated ordinary object is rooted and changing extensibility does not allocate",
        );
        Ok(true)
    }

    /// Calls an accessor or Proxy trap while an object internal method runs.
    /// Keep its exception in the callback's Realm before a membrane returns,
    /// while preserving ordinary local host API error representations.
    fn call_object_callback(
        &mut self,
        callee: Value,
        receiver: Value,
        args: Vec<Value>,
    ) -> Result<Value, RuntimeError> {
        let result = self.call_native(callee, receiver, args, false);
        if !crate::vm::realm_reentrancy::has_foreign_caller(self.object_prototype.heap) {
            return result;
        }
        result.map_err(|error| match self.error_value(error) {
            Ok(value) => RuntimeError::Thrown(value),
            Err(error) => error,
        })
    }

    /// OrdinarySet with an explicit receiver.  It is deliberately expressed
    /// in terms of the object-operation boundary above, so a Proxy can occur
    /// either as the target or in the prototype chain without being skipped.
    pub(in super::super) fn ordinary_set_with_receiver(
        &mut self,
        target: ObjectId,
        receiver: &Value,
        key: &PropertyName,
        value: &Value,
    ) -> Result<bool, RuntimeError> {
        if self.heap.proxy(target)?.is_some() {
            return self.proxy_set(target, receiver, key, value);
        }
        // A foreign facade is intentionally an empty local object. Its
        // [[Set]] must therefore run in the target Realm, with both the
        // explicit receiver and value transported through the membrane.
        if self.test262_foreign_reference(target).is_some() {
            return self.test262_foreign_set_with_receiver(target, receiver, key, value);
        }
        // Symmetric case: a reverse facade is likewise an empty local
        // object standing in for a real object owned by a Test262 *parent*
        // realm. Its [[Set]] must run back in that parent.
        if self.test262_reverse_reference(target).is_some() {
            return self.test262_reverse_set_with_receiver(target, receiver, key, value);
        }
        // Module Namespace Exotic Objects have a distinct [[Set]] internal
        // method: it returns false for every property key, including a
        // writable-looking live export whose assigned value is unchanged.
        // Falling through OrdinarySet incorrectly accepts that same-value
        // DefineOwnProperty operation.
        if self
            .heap
            .is_module_namespace(target)
            .expect("the preceding proxy read validated the rooted target")
        {
            return Ok(false);
        }
        if let Some(numeric) = self
            .heap
            .typed_array_numeric_key(target, key)
            .expect("the preceding heap lookup retains this live view and its buffer")
        {
            // An immutable backing buffer fails every canonical-numeric
            // assignment outright: no conversion, no receiver distinction.
            if self
                .heap
                .typed_array_is_immutable(target)
                .expect("the preceding heap lookup retains this live view and its buffer")
            {
                return Ok(false);
            }
            let valid = match numeric {
                TypedArrayNumericKey::Index(index) => self
                    .heap
                    .typed_array_index_value(target, index)
                    .expect("the preceding heap lookup retains this live view and its buffer")
                    .is_some(),
                TypedArrayNumericKey::Invalid => false,
            };
            if receiver == &Value::Object(target) {
                // TypedArraySetElement performs ToNumber before checking
                // IsValidIntegerIndex. Thus an own assignment to `"-0"`, a
                // fractional canonical key, or an out-of-bounds index still
                // observes a throwing value conversion. A different receiver
                // has the separate OrdinarySet path below and must *not*
                // convert an invalid key's value.
                let (_, _, _, kind) = self
                    .heap
                    .typed_array_info(target)
                    .expect("the preceding heap lookup retains this live view and its buffer");
                let value = self.typed_array_element_value(kind, value)?;
                if let TypedArrayNumericKey::Index(index) = numeric {
                    // IsValidIntegerIndex follows ToNumber. In particular,
                    // converting the right-hand side can grow a resizable
                    // backing buffer and turn a previously out-of-bounds
                    // index into a valid element.
                    if self
                        .heap
                        .typed_array_index_value(target, index)
                        .expect("the preceding heap lookup retains this live view and its buffer")
                        .is_some()
                    {
                        self.heap.typed_array_set_index(target, index, &value)
                            .expect("the rooted mutable view writes a normalized primitive or skips an invalid index");
                    }
                }
                return Ok(true);
            }
            // Invalid canonical numeric indices terminate the exotic [[Set]]
            // without coercion. A valid index with a distinct Receiver instead
            // follows OrdinarySet below and stores the original value there.
            if !valid {
                return Ok(true);
            }
        }
        let mut current = Some(target);
        while let Some(object) = current {
            if self
                .heap
                .proxy(object)
                .expect("the target or returned prototype is live in this realm")
                .is_some()
            {
                return self.proxy_set(object, receiver, key, value);
            }
            // The prototype-chain walk below stops early for a *local*
            // proxy (above), but never previously stopped for an ancestor
            // that is itself a reverse-membrane facade of a genuine parent
            // Proxy -- that ancestor is a plain, empty local object, so the
            // walk would otherwise silently skip past its real [[Set]]
            // (including a parent Proxy trap) and keep walking as if it had
            // no own properties at all. `OrdinarySet` always fully
            // delegates once it reaches *any* exotic [[Set]], so mirror the
            // proxy check immediately above with the reverse-facade one.
            if self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_set_with_receiver(object, receiver, key, value);
            }
            if object != target {
                if let Some(numeric) = self
                    .heap
                    .typed_array_numeric_key(object, key)
                    .expect("the preceding heap lookup retains this live view and its buffer")
                {
                    if self
                        .heap
                        .typed_array_is_immutable(object)
                        .expect("the preceding heap lookup retains this live view and its buffer")
                    {
                        return Ok(false);
                    }
                    let valid = matches!(numeric, TypedArrayNumericKey::Index(index) if self
                        .heap
                        .typed_array_index_value(object, index).expect("the rooted integer-indexed view retains its backing buffer")
                        .is_some());
                    if receiver == &Value::Object(object) {
                        // OrdinarySet reached an Integer-Indexed exotic in
                        // the prototype chain. Its [[Set]] target is this
                        // `object`, not the initial ordinary receiver. The
                        // SameValue branch therefore still performs ToNumber
                        // for any canonical numeric key before validity is
                        // tested.
                        let (_, _, _, kind) = self.heap.typed_array_info(object).expect(
                            "the preceding heap lookup retains this live view and its buffer",
                        );
                        let value = self.typed_array_element_value(kind, value)?;
                        if let TypedArrayNumericKey::Index(index) = numeric {
                            // The prototype exotic's index is likewise
                            // checked after value conversion, because a
                            // resizable buffer may have grown in that step.
                            if self.heap.typed_array_index_value(object, index).expect("the preceding heap lookup retains this live view and its buffer").is_some() {
                                self.heap.typed_array_set_index(object, index, &value)
                                    .expect("the rooted mutable view writes a normalized primitive or skips an invalid index");
                            }
                        }
                        return Ok(true);
                    }
                    if !valid {
                        return Ok(true);
                    }
                }
            }
            if let Some(descriptor) = self.object_get_own_property(object, key)? {
                if descriptor.accessor() {
                    let setter = descriptor.set.unwrap_or(Value::Undefined);
                    if setter == Value::Undefined {
                        return Ok(false);
                    }
                    if !self.is_callable(&setter).expect(
                        "the retained own descriptor contains a live setter value in this realm",
                    ) {
                        return Err(RuntimeError::TypeError(
                            "property setter is not callable".into(),
                        ));
                    }
                    self.call_object_callback(setter, receiver.clone(), vec![value.clone()])?;
                    return Ok(true);
                }
                if descriptor.writable == Some(false) {
                    return Ok(false);
                }
                break;
            }
            current = self.object_get_prototype(object)?;
        }
        let Value::Object(receiver) = receiver else {
            return Ok(false);
        };
        // OrdinarySetWithOwnDescriptor must first observe Receiver's
        // [[GetOwnProperty]] even when the receiver is a Proxy.  Defining
        // directly skipped that trap and broke descriptor-sensitive proxy
        // forwarding.  Use the shared boundary before choosing the update.
        let own = self.object_get_own_property(*receiver, key)?;
        if let Some(own) = &own {
            if own.accessor() || own.writable == Some(false) {
                return Ok(false);
            }
        }
        let stored = if key == "length"
            && self
                .heap
                .is_array(*receiver)
                .expect("GetOwnProperty validated and retained this receiver")
        {
            self.array_length_value(value)?
        } else {
            value.clone()
        };
        let descriptor = if own.is_some() {
            PropertyDescriptor {
                value: Some(stored),
                ..Default::default()
            }
        } else {
            PropertyDescriptor::data(stored, true, true, true)
        };
        if self
            .heap
            .proxy(*receiver)
            .expect("GetOwnProperty validated and retained this receiver")
            .is_some()
        {
            return self.proxy_define_own_property(*receiver, key.clone(), descriptor);
        }
        let succeeded = self.object_define_own_property(*receiver, key.clone(), descriptor)?;
        if succeeded {
            // Reflect.set and membrane [[Set]] use this Boolean boundary
            // directly. Keep a property-backed global binding in step with
            // the successful data-property write, as ordinary assignment does.
            if let Some(cell) = self.global_property_cell(*receiver, key) {
                self.with_roots(|heap| heap.set(cell, "value", value.clone()))?;
            }
        }
        Ok(succeeded)
    }

    /// Set(O, P, V, true). Keep the Boolean [[Set]] result until this VM can
    /// create a refusal error; another object's Realm does not choose Throw.
    pub(in super::super) fn object_set_or_throw(
        &mut self,
        object: ObjectId,
        key: &PropertyName,
        value: &Value,
    ) -> Result<(), RuntimeError> {
        let receiver = Value::Object(object);
        let base = self.stack.len();
        self.stack.extend([receiver.clone(), value.clone()]);
        let result = self.ordinary_set_with_receiver(object, &receiver, key, value);
        self.stack.truncate(base);
        if result? {
            Ok(())
        } else {
            Err(RuntimeError::TypeError(
                "property cannot be assigned".into(),
            ))
        }
    }

    pub(in super::super) fn get_from_prototype(
        &mut self,
        start: ObjectId,
        receiver: &Value,
        key: &PropertyName,
    ) -> Result<Value, RuntimeError> {
        let mut current = Some(start);
        while let Some(object) = current {
            self.materialize_iterator_helper_property(object, key)?;
            if self.heap.proxy(object)?.is_some() {
                return self.proxy_get(object, receiver, key);
            }
            // A foreign/reverse facade is intentionally an empty local
            // object (see `test262_transport_value`'s own doc comment), so
            // without this check the loop below would silently treat it as
            // having no own properties at all and walk straight past it --
            // correct only when the *walk itself* continues into the real
            // membrane target (`object_get_prototype`, below, already does
            // that), but wrong the moment a property is genuinely an own
            // property of that real target: this happens whenever `start`
            // itself is a facade, notably `super_get`'s `base` (a foreign
            // or reverse [[HomeObject]] prototype) reached without ever
            // going through `get_object_property`'s own top-level check.
            if self.test262_foreign_reference(object).is_some() {
                return self.test262_foreign_get(object, receiver, key);
            }
            if self.test262_reverse_reference(object).is_some() {
                return self.test262_reverse_get(object, receiver, key);
            }
            if let Some(numeric) = self
                .heap
                .typed_array_numeric_key(object, key)
                .expect("the preceding proxy query validated this live prototype")
            {
                return match numeric {
                    TypedArrayNumericKey::Index(index) => Ok(self
                        .heap
                        .typed_array_index_value(object, index)
                        .expect(
                            "the validated integer-indexed prototype retains its backing buffer",
                        )
                        .unwrap_or(Value::Undefined)),
                    TypedArrayNumericKey::Invalid => Ok(Value::Undefined),
                };
            }
            if let Some(desc) = self.object_get_own_property(object, key)? {
                if desc.accessor() {
                    let getter = desc.get.unwrap_or(Value::Undefined);
                    return if matches!(getter, Value::Undefined) {
                        Ok(Value::Undefined)
                    } else {
                        self.call_object_callback(getter, receiver.clone(), Vec::new())
                    };
                }
                return Ok(desc.value.unwrap_or(Value::Undefined));
            }
            current = self
                .heap
                .prototype(object)
                .expect("Proxy and membrane cases returned above; this prototype read is pure");
        }
        Ok(Value::Undefined)
    }

    pub(in super::super) fn constructor_prototype(
        &mut self,
        default: ObjectId,
    ) -> Result<ObjectId, RuntimeError> {
        self.constructor_prototype_for(default, None)
    }

    /// This realm's `%Intrinsic.prototype%` for the constructor named
    /// `intrinsic`: a global constructor's name, `Intl.X`, or one of the
    /// function-kind constructors that have no global binding.
    pub(in super::super) fn intrinsic_prototype(
        &mut self,
        intrinsic: &str,
    ) -> Result<Value, RuntimeError> {
        let constructor = match intrinsic {
            "AsyncFunction" => return Ok(Value::Object(self.async_function_prototype()?)),
            "GeneratorFunction" => {
                return Ok(Value::Object(self.generator_function_prototype()?));
            }
            "AsyncGeneratorFunction" => {
                return Ok(Value::Object(self.async_generator_function_prototype()?));
            }
            name if name.starts_with("Intl.") => {
                self.intl_global()?;
                Value::Object(self.globals[&format!("%{name}%")])
            }
            name if name.starts_with("Temporal.") => {
                self.temporal_global()?;
                Value::Object(self.globals[&format!("%{name}%")])
            }
            name => self.global(name)?,
        };
        self.get_property(&constructor, &"prototype".into())
    }

    /// `GetPrototypeFromConstructor` with the fallback intrinsic named by the
    /// caller. A constructor that knows which intrinsic `default` is (the
    /// Error family, whose prototypes carry no distinguishing identity here)
    /// passes its global's name so a foreign new target's realm can supply
    /// the matching prototype; `None` recognizes `default` by identity.
    pub(in super::super) fn constructor_prototype_for(
        &mut self,
        default: ObjectId,
        intrinsic_name: Option<&str>,
    ) -> Result<ObjectId, RuntimeError> {
        let target = self.new_target.clone();
        let prototype = self.get_property(&target, &"prototype".into())?;
        if let Some(prototype) = prototype.object_id() {
            return Ok(prototype);
        }
        // GetPrototypeFromConstructor obtains the constructor's realm when
        // `prototype` is not an object. Besides selecting the fallback
        // intrinsic, that walk must observe a Proxy revoked by a `prototype`
        // getter. BlueJS stores same-realm intrinsics in this VM, so the
        // caller-supplied default is already the correct fallback after the
        // validation walk completes.
        if let Some(realm) = self.validate_function_realm(target)? {
            if let Some(intrinsic) = intrinsic_name {
                return self.test262_foreign_default_prototype(realm, intrinsic);
            }
            // Identify the already-selected intrinsic from this realm's
            // caches. Prototype fallback must not build unrelated constructors:
            // a foreign Object newTarget does not require twelve TypedArrays,
            // both collection families, or any weak/disposal prototypes.
            let intrinsic = [
                (Some(self.object_prototype), "Object"),
                (self.function_intrinsic_prototype, "Function"),
                (Some(self.array_prototype), "Array"),
                (self.string_intrinsics.map(|(_, prototype)| prototype), "String"),
                (self.map_prototype, "Map"),
                (self.set_prototype, "Set"),
                (self.weak_map_prototype, "WeakMap"),
                (self.weak_set_prototype, "WeakSet"),
                (self.weak_ref_prototype, "WeakRef"),
                (self.finalization_registry_prototype, "FinalizationRegistry"),
                (self.disposable_stack_prototype, "DisposableStack"),
                (self.async_disposable_stack_prototype, "AsyncDisposableStack"),
                (self.date_prototype, "Date"),
                (self.iterator_base, "Iterator"),
                (self.promise_prototype, "Promise"),
                (self.shadow_realm_prototype, "ShadowRealm"),
                (self.generator_function_prototype, "GeneratorFunction"),
                (self.async_function_prototype, "AsyncFunction"),
                (self.async_generator_function_prototype, "AsyncGeneratorFunction"),
            ].into_iter().find_map(|(prototype, name)| (prototype == Some(default)).then_some(name))
            .or_else(|| {
                [
                    "Boolean", "Number", "ArrayBuffer", "SharedArrayBuffer", "DataView",
                    "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Uint16Array",
                    "Int32Array", "Uint32Array", "Float16Array", "Float32Array", "Float64Array",
                    "BigInt64Array", "BigUint64Array", "RegExp",
                    "%Intl.Collator%", "%Intl.DateTimeFormat%", "%Intl.NumberFormat%",
                    "%Intl.Locale%", "%Intl.DisplayNames%", "%Intl.DurationFormat%",
                    "%Intl.ListFormat%", "%Intl.PluralRules%", "%Intl.RelativeTimeFormat%",
                    "%Intl.Segmenter%",
                    "%Temporal.Instant%", "%Temporal.Duration%", "%Temporal.PlainDate%",
                    "%Temporal.PlainTime%", "%Temporal.PlainDateTime%", "%Temporal.PlainYearMonth%",
                    "%Temporal.PlainMonthDay%", "%Temporal.ZonedDateTime%",
                ].into_iter().find_map(|name| {
                    let constructor = self.globals.get(name)?;
                    let prototype = self.heap.get_own(*constructor, "prototype")
                        .expect("a cached intrinsic constructor is rooted and owns an ordinary prototype property")
                        .and_then(|value| value.object_id());
                    (prototype == Some(default)).then(|| name.strip_prefix('%')
                        .and_then(|name| name.strip_suffix('%')).unwrap_or(name))
                })
            });
            if let Some(intrinsic) = intrinsic {
                return self.test262_foreign_default_prototype(realm, intrinsic);
            }
        }
        Ok(default)
    }

    /// The validation portion of GetFunctionRealm for constructors owned by
    /// this VM. Bound functions and Proxy exotic objects delegate to their
    /// targets; `Heap::proxy` raises a TypeError when the Proxy has been
    /// revoked. All remaining callable forms belong to this realm and can use
    /// the intrinsic supplied by `constructor_prototype`.
    fn validate_function_realm(
        &self,
        mut function: Value,
    ) -> Result<Option<ObjectId>, RuntimeError> {
        loop {
            let object = function
                .object_id()
                .ok_or_else(|| RuntimeError::TypeError("constructor must be callable".into()))?;
            if let Some(bound) = self.heap.bound_function(object)? {
                function = Value::Object(bound.target);
                continue;
            }
            if let Some((target, _)) = self.heap.proxy(object)? {
                function = Value::Object(target);
                continue;
            }
            if let Some((realm, _, _, _)) = self.test262_foreign_reference(object) {
                return Ok(Some(realm));
            }
            if self
                .heap
                .closure(object)
                .expect("the preceding bound-function lookup validated this live object")
                .is_some()
                || self
                    .heap
                    .native_function(object)
                    .expect("the preceding bound-function lookup validated this live object")
                    .is_some()
            {
                return Ok(None);
            }
            return Err(RuntimeError::TypeError(
                "constructor must be callable".into(),
            ));
        }
    }

    pub(in super::super) fn proxy_constructor(
        &mut self,
        args: &[Value],
        construct: bool,
    ) -> Result<Value, RuntimeError> {
        if !construct {
            return Err(RuntimeError::TypeError(
                "Proxy constructor requires 'new'".into(),
            ));
        }
        let target = native::argument(args, 0)
            .object_id()
            .ok_or_else(|| RuntimeError::TypeError("Proxy target must be an object".into()))?;
        let handler = native::argument(args, 1)
            .object_id()
            .ok_or_else(|| RuntimeError::TypeError("Proxy handler must be an object".into()))?;
        let capabilities = self.value_capabilities(target)?;
        let callable = capabilities.callable;
        let constructible = capabilities.constructible;
        // A Proxy's ordinary prototype slot is never consulted by its
        // internal methods; [[GetPrototypeOf]] delegates to the target.
        // Using Object.prototype also allows ProxyCreate to wrap an already
        // revoked Proxy, as required by the specification.
        let prototype = Some(self.object_prototype);
        Ok(Value::Object(self.with_roots(|heap| {
            heap.alloc_proxy(target, handler, prototype, callable, constructible)
        })?))
    }

    pub(in super::super) fn proxy_revocable(
        &mut self,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let target = native::argument(args, 0)
            .object_id()
            .ok_or_else(|| RuntimeError::TypeError("Proxy target must be an object".into()))?;
        let handler = native::argument(args, 1)
            .object_id()
            .ok_or_else(|| RuntimeError::TypeError("Proxy handler must be an object".into()))?;
        let capabilities = self.value_capabilities(target)?;
        let callable = capabilities.callable;
        let constructible = capabilities.constructible;
        let proxy_prototype = Some(self.object_prototype);
        let proxy = self.with_roots(|heap| {
            heap.alloc_proxy(target, handler, proxy_prototype, callable, constructible)
        })?;
        let base = self.stack.len();
        self.stack.push(Value::Object(proxy));
        let result = (|| {
            let function_prototype = self.function_prototype()?;
            let revoke = self.with_roots(|heap| {
                heap.alloc_native_function(
                    NativeFunction::ProxyRevoker(proxy),
                    "",
                    function_prototype,
                )
            })?;
            self.stack.push(Value::Object(revoke));
            self.define_data(revoke, "length", Value::Number(0.0), false, false, true)?;
            self.define_data(revoke, "name", Value::String("".into()), false, false, true)?;
            let object_prototype = self.object_prototype;
            let result = self.with_roots(|heap| heap.alloc_object(Some(object_prototype)))?;
            self.stack.push(Value::Object(result));
            self.define_data(result, "proxy", Value::Object(proxy), true, true, true)?;
            self.define_data(result, "revoke", Value::Object(revoke), true, true, true)?;
            Ok(Value::Object(result))
        })();
        self.stack.truncate(base);
        result
    }

    /// Returns a Proxy trap value, preserving the handler as the call
    /// receiver.  Proxy objects retain both target and handler as heap edges,
    /// so the rooted proxy itself keeps the arguments live across this lookup.
    pub(in super::super) fn proxy_trap(
        &mut self,
        handler: ObjectId,
        name: &str,
    ) -> Result<Value, RuntimeError> {
        // GetMethod treats both `undefined` and `null` as absent. All Proxy
        // internal methods share this lookup, so this is the single forwarding
        // boundary for null-valued traps.
        let trap = self.get_property(&Value::Object(handler), &name.into())?;
        Ok(if trap == Value::Null {
            Value::Undefined
        } else {
            trap
        })
    }

    /// Implements Proxy.[[Get]] including the non-configurable-property
    /// invariants.  `receiver` is deliberately separate from `proxy`: this
    /// is what makes inherited Proxy properties and Reflect.get faithful.
    pub(in super::super) fn proxy_get(
        &mut self,
        proxy: ObjectId,
        receiver: &Value,
        key: &PropertyName,
    ) -> Result<Value, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.get_object_property(proxy, receiver, key);
        };
        let trap = self.proxy_trap(handler, "get")?;
        if trap == Value::Undefined {
            return self.get_object_property(target, receiver, key);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy get trap must be callable".into(),
            ));
        }
        let result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![Value::Object(target), key.value(), receiver.clone()],
        )?;
        // The trap's result is held nowhere else, and checking the invariants
        // below can run a Proxy target's own traps.
        let base = self.stack.len();
        self.stack.push(result.clone());
        let checked = (|| {
            if let Some(descriptor) = self.object_get_own_property(target, key)? {
                if descriptor.configurable == Some(false) {
                    if descriptor.writable == Some(false)
                        && descriptor
                            .value
                            .as_ref()
                            .is_some_and(|value| !same_value(value, &result))
                    {
                        return Err(RuntimeError::TypeError(
                            "Proxy get trap violated a non-writable property invariant".into(),
                        ));
                    }
                    if descriptor.accessor()
                        && descriptor.get == Some(Value::Undefined)
                        && result != Value::Undefined
                    {
                        return Err(RuntimeError::TypeError(
                            "Proxy get trap violated an accessor invariant".into(),
                        ));
                    }
                }
            }
            Ok(())
        })();
        self.stack.truncate(base);
        checked?;
        Ok(result)
    }

    /// Implements Proxy.[[HasProperty]] and its non-configurable and
    /// non-extensible target invariants.
    pub(in super::super) fn proxy_has(
        &mut self,
        proxy: ObjectId,
        key: &PropertyName,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.has_property(proxy, key);
        };
        let trap = self.proxy_trap(handler, "has")?;
        if trap == Value::Undefined {
            return self.has_property(target, key);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy has trap must be callable".into(),
            ));
        }
        let result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![Value::Object(target), key.value()],
        )?;
        let result = self
            .to_boolean(&result)
            .expect("ToBoolean cannot fail for the live result of a trap");
        if !result {
            if let Some(descriptor) = self.object_get_own_property(target, key)? {
                if descriptor.configurable == Some(false) || !self.object_is_extensible(target)? {
                    return Err(RuntimeError::TypeError(
                        "Proxy has trap hid a required target property".into(),
                    ));
                }
            }
        }
        Ok(result)
    }

    /// Implements Proxy.[[Set]]. The actual data-property write is shared by
    /// ordinary property assignment and Reflect.set, which keeps the supplied
    /// receiver visible to prototype accessors and Proxy traps.
    pub(in super::super) fn proxy_set(
        &mut self,
        proxy: ObjectId,
        receiver: &Value,
        key: &PropertyName,
        value: &Value,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.ordinary_set_with_receiver(proxy, receiver, key, value);
        };
        let trap = self.proxy_trap(handler, "set")?;
        if trap == Value::Undefined {
            return self.ordinary_set_with_receiver(target, receiver, key, value);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy set trap must be callable".into(),
            ));
        }
        let trap_result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![
                Value::Object(target),
                key.value(),
                value.clone(),
                receiver.clone(),
            ],
        )?;
        if !self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap")
        {
            return Ok(false);
        }
        if let Some(descriptor) = self.object_get_own_property(target, key)? {
            if descriptor.configurable == Some(false)
                && ((descriptor.writable == Some(false)
                    && descriptor
                        .value
                        .as_ref()
                        .is_some_and(|current| !same_value(current, value)))
                    || (descriptor.accessor() && descriptor.set == Some(Value::Undefined)))
            {
                return Err(RuntimeError::TypeError(
                    "Proxy set trap violated a target property invariant".into(),
                ));
            }
        }
        Ok(true)
    }

    pub(in super::super) fn proxy_delete(
        &mut self,
        proxy: ObjectId,
        key: &PropertyName,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return Ok(self
                .heap
                .delete(proxy, key)
                .expect("the pure proxy lookup validated the ordinary deletion target"));
        };
        let trap = self.proxy_trap(handler, "deleteProperty")?;
        if trap == Value::Undefined {
            return self.object_delete(target, key);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy deleteProperty trap must be callable".into(),
            ));
        }
        let trap_result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![Value::Object(target), key.value()],
        )?;
        if !self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap")
        {
            return Ok(false);
        }
        if let Some(descriptor) = self.object_get_own_property(target, key)? {
            if descriptor.configurable == Some(false) || !self.object_is_extensible(target)? {
                return Err(RuntimeError::TypeError(
                    "Proxy deleteProperty trap removed a required target property".into(),
                ));
            }
        }
        Ok(true)
    }

    pub(in super::super) fn proxy_own_keys(
        &mut self,
        proxy: ObjectId,
    ) -> Result<Vec<PropertyName>, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.heap.own_property_keys(proxy).map_err(Into::into);
        };
        let trap = self.proxy_trap(handler, "ownKeys")?;
        if trap == Value::Undefined {
            return self.object_own_property_keys(target);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy ownKeys trap must be callable".into(),
            ));
        }
        let result =
            self.call_object_callback(trap, Value::Object(handler), vec![Value::Object(target)])?;
        let object = self.coerce_object(&result)?;
        self.stack.push(Value::Object(object));
        let length = self.get_property(&Value::Object(object), &"length".into())?;
        let length = self.coerce_length(&length)? as u64;
        let mut keys = Vec::new();
        for index in 0..length {
            let value = self.get_property(&Value::Object(object), &index.to_string().into())?;
            let key = match value {
                Value::String(string) => PropertyName::String(string),
                Value::Symbol(symbol) => PropertyName::Symbol(symbol),
                _ => {
                    self.stack.pop();
                    return Err(RuntimeError::TypeError(
                        "Proxy ownKeys trap result contains a non-property key".into(),
                    ));
                }
            };
            if keys.contains(&key) {
                self.stack.pop();
                return Err(RuntimeError::TypeError(
                    "Proxy ownKeys trap returned a duplicate key".into(),
                ));
            }
            keys.push(key);
        }
        self.stack.pop();
        let target_keys = self.object_own_property_keys(target)?;
        let mut non_configurable = Vec::new();
        for key in &target_keys {
            if self
                .object_get_own_property(target, key)?
                .is_some_and(|descriptor| descriptor.configurable == Some(false))
            {
                non_configurable.push(key.clone());
            }
        }
        if non_configurable.iter().any(|key| !keys.contains(key)) {
            return Err(RuntimeError::TypeError(
                "Proxy ownKeys trap omitted a non-configurable key".into(),
            ));
        }
        if !self.object_is_extensible(target)?
            && (keys.len() != target_keys.len()
                || target_keys.iter().any(|key| !keys.contains(key)))
        {
            return Err(RuntimeError::TypeError(
                "Proxy ownKeys trap disagreed with a non-extensible target".into(),
            ));
        }
        Ok(keys)
    }

    pub(in super::super) fn descriptor_object(
        &mut self,
        descriptor: &PropertyDescriptor,
    ) -> Result<Value, RuntimeError> {
        let prototype = self.object_prototype;
        let object = self.with_roots(|heap| heap.alloc_object(Some(prototype)))?;
        self.stack.push(Value::Object(object));
        let result = (|| {
            for (name, value) in [
                ("value", descriptor.value.clone()),
                ("writable", descriptor.writable.map(Value::Bool)),
                ("get", descriptor.get.clone()),
                ("set", descriptor.set.clone()),
                ("enumerable", descriptor.enumerable.map(Value::Bool)),
                ("configurable", descriptor.configurable.map(Value::Bool)),
            ] {
                if let Some(value) = value {
                    self.with_roots(|heap| heap.set(object, name, value))?;
                }
            }
            Ok(Value::Object(object))
        })();
        self.stack.pop();
        result
    }

    pub(in super::super) fn proxy_get_own_property(
        &mut self,
        proxy: ObjectId,
        key: &PropertyName,
    ) -> Result<Option<PropertyDescriptor>, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self
                .heap
                .get_own_property_descriptor(proxy, key)
                .map_err(Into::into);
        };
        let trap = self.proxy_trap(handler, "getOwnPropertyDescriptor")?;
        if trap == Value::Undefined {
            return self.object_get_own_property(target, key);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy getOwnPropertyDescriptor trap must be callable".into(),
            ));
        }
        let result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![Value::Object(target), key.value()],
        )?;
        // The trap's result descriptor object is held nowhere else, and the
        // target's own descriptor and extensibility are read through traps of
        // their own when the target is a Proxy.
        let base = self.stack.len();
        self.stack.push(result.clone());
        let outcome = (|| {
            let target_descriptor = self.object_get_own_property(target, key)?;
            let extensible = self.object_is_extensible(target)?;
            if result == Value::Undefined {
                if target_descriptor
                    .as_ref()
                    .is_some_and(|descriptor| descriptor.configurable == Some(false))
                    || (!extensible && target_descriptor.is_some())
                {
                    return Err(RuntimeError::TypeError(
                        "Proxy getOwnPropertyDescriptor trap hid a required target property".into(),
                    ));
                }
                return Ok(None);
            }
            let descriptor = complete_property_descriptor(self.read_descriptor(&result)?);
            if !compatible_property_descriptor(extensible, target_descriptor.as_ref(), &descriptor)
            {
                return Err(RuntimeError::TypeError(
                    "Proxy getOwnPropertyDescriptor trap returned an incompatible descriptor"
                        .into(),
                ));
            }
            if descriptor.configurable == Some(false)
                && target_descriptor
                    .as_ref()
                    .is_none_or(|current| current.configurable != Some(false))
            {
                return Err(RuntimeError::TypeError(
                    "Proxy getOwnPropertyDescriptor trap reported a new non-configurable property"
                        .into(),
                ));
            }
            // Proxy.[[GetOwnProperty]] has one stricter invariant than ordinary
            // ValidateAndApplyPropertyDescriptor: a trap may not report a
            // non-configurable target's writable data property as non-writable.
            // The general compatibility predicate correctly permits the ordinary
            // transition, so enforce this Proxy-specific observation separately.
            if descriptor.configurable == Some(false)
                && descriptor.writable == Some(false)
                && target_descriptor.as_ref().is_some_and(|current| {
                    current.configurable == Some(false) && current.writable == Some(true)
                })
            {
                return Err(RuntimeError::TypeError(
                    "Proxy getOwnPropertyDescriptor trap made a target property non-writable"
                        .into(),
                ));
            }
            Ok(Some(descriptor))
        })();
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super) fn proxy_define_own_property(
        &mut self,
        proxy: ObjectId,
        key: PropertyName,
        descriptor: PropertyDescriptor,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.with_roots(|heap| heap.define_own_property(proxy, key, descriptor));
        };
        let trap = self.proxy_trap(handler, "defineProperty")?;
        if trap == Value::Undefined {
            return self.object_define_own_property(target, key, descriptor);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy defineProperty trap must be callable".into(),
            ));
        }
        // The trap may be a function created by the handler's own `get`, held
        // nowhere else: keep it alive while the descriptor record is built.
        let base = self.stack.len();
        self.stack.push(trap.clone());
        let descriptor_value = self.descriptor_object(&descriptor);
        self.stack.truncate(base);
        let descriptor_value = descriptor_value?;
        // The descriptor record is observable by the trap. Root it across
        // the call because a trap can allocate (or invoke assertions that
        // allocate) before it reads the third argument.
        self.stack.push(descriptor_value.clone());
        let trap_result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![Value::Object(target), key.value(), descriptor_value],
        );
        self.stack.truncate(base);
        let trap_result = trap_result?;
        if !self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap")
        {
            return Ok(false);
        }
        let target_descriptor = self.object_get_own_property(target, &key)?;
        let extensible = self.object_is_extensible(target)?;
        if !compatible_property_descriptor(extensible, target_descriptor.as_ref(), &descriptor) {
            return Err(RuntimeError::TypeError(
                "Proxy defineProperty trap reported an incompatible property".into(),
            ));
        }
        if descriptor.configurable == Some(false)
            && target_descriptor
                .as_ref()
                .is_none_or(|current| current.configurable != Some(false))
        {
            return Err(RuntimeError::TypeError(
                "Proxy defineProperty trap reported a new non-configurable property".into(),
            ));
        }
        // A successful defineProperty trap cannot make a non-configurable,
        // writable target property non-writable. Ordinary descriptor
        // compatibility permits that transition, so Proxy.[[DefineOwnProperty]]
        // requires this additional invariant check.
        if target_descriptor.as_ref().is_some_and(|current| {
            current.configurable == Some(false)
                && current.writable == Some(true)
                && descriptor.writable == Some(false)
        }) {
            return Err(RuntimeError::TypeError(
                "Proxy defineProperty trap made a target property non-writable".into(),
            ));
        }
        Ok(true)
    }

    pub(in super::super) fn proxy_is_extensible(
        &mut self,
        proxy: ObjectId,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.heap.is_extensible(proxy).map_err(Into::into);
        };
        let trap = self.proxy_trap(handler, "isExtensible")?;
        if trap == Value::Undefined {
            return self.object_is_extensible(target);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy isExtensible trap must be callable".into(),
            ));
        }
        let trap_result =
            self.call_object_callback(trap, Value::Object(handler), vec![Value::Object(target)])?;
        let result = self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap");
        if result != self.object_is_extensible(target)? {
            return Err(RuntimeError::TypeError(
                "Proxy isExtensible trap disagreed with its target".into(),
            ));
        }
        Ok(result)
    }

    pub(in super::super) fn proxy_get_prototype(
        &mut self,
        proxy: ObjectId,
    ) -> Result<Option<ObjectId>, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return self.heap.prototype(proxy).map_err(Into::into);
        };
        let trap = self.proxy_trap(handler, "getPrototypeOf")?;
        if trap == Value::Undefined {
            return self.object_get_prototype(target);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy getPrototypeOf trap must be callable".into(),
            ));
        }
        let result =
            self.call_object_callback(trap, Value::Object(handler), vec![Value::Object(target)])?;
        let prototype = match result {
            Value::Null => None,
            Value::Object(object) => Some(object),
            _ => {
                return Err(RuntimeError::TypeError(
                    "Proxy getPrototypeOf trap must return an object or null".into(),
                ))
            }
        };
        // A fresh prototype is held nowhere else, and reading the target's
        // extensibility and prototype can run a Proxy target's own traps.
        let base = self.stack.len();
        self.stack.push(result);
        let checked = (|| {
            if !self.object_is_extensible(target)?
                && prototype != self.object_get_prototype(target)?
            {
                return Err(RuntimeError::TypeError(
                    "Proxy getPrototypeOf trap disagreed with a non-extensible target".into(),
                ));
            }
            Ok(())
        })();
        self.stack.truncate(base);
        checked?;
        Ok(prototype)
    }

    pub(in super::super) fn proxy_set_prototype(
        &mut self,
        proxy: ObjectId,
        prototype: Option<ObjectId>,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return match self.heap.set_prototype(proxy, prototype) {
                Ok(()) => Ok(true),
                Err(HeapError::ReadOnlyProperty | HeapError::PrototypeCycle) => Ok(false),
                Err(error) => Err(error.into()),
            };
        };
        let trap = self.proxy_trap(handler, "setPrototypeOf")?;
        if trap == Value::Undefined {
            return self.object_set_prototype(target, prototype);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy setPrototypeOf trap must be callable".into(),
            ));
        }
        let trap_result = self.call_object_callback(
            trap,
            Value::Object(handler),
            vec![
                Value::Object(target),
                prototype.map_or(Value::Null, Value::Object),
            ],
        )?;
        if !self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap")
        {
            return Ok(false);
        }
        if !self.object_is_extensible(target)? && prototype != self.object_get_prototype(target)? {
            return Err(RuntimeError::TypeError(
                "Proxy setPrototypeOf trap changed a non-extensible target".into(),
            ));
        }
        Ok(true)
    }

    pub(in super::super) fn proxy_prevent_extensions(
        &mut self,
        proxy: ObjectId,
    ) -> Result<bool, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            self.heap
                .prevent_extensions(proxy)
                .expect("the pure proxy lookup validated the ordinary target");
            return Ok(true);
        };
        let trap = self.proxy_trap(handler, "preventExtensions")?;
        if trap == Value::Undefined {
            return self.object_prevent_extensions(target);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(
                "Proxy preventExtensions trap must be callable".into(),
            ));
        }
        let trap_result =
            self.call_object_callback(trap, Value::Object(handler), vec![Value::Object(target)])?;
        if !self
            .to_boolean(&trap_result)
            .expect("ToBoolean cannot fail for the live result of a trap")
        {
            return Ok(false);
        }
        if self.object_is_extensible(target)? {
            return Err(RuntimeError::TypeError(
                "Proxy preventExtensions trap left its target extensible".into(),
            ));
        }
        Ok(true)
    }

    /// Proxy.[[Call]] and Proxy.[[Construct]].  The outer call frame retains
    /// the Proxy as `newTarget`, so forwarding a construct without a trap
    /// preserves the required allocation prototype.
    pub(in super::super) fn proxy_call(
        &mut self,
        proxy: ObjectId,
        receiver: Value,
        args: Vec<Value>,
        construct: bool,
    ) -> Result<Value, RuntimeError> {
        let Some((target, handler)) = self.heap.proxy(proxy)? else {
            return Err(RuntimeError::TypeError(
                "Proxy target is unavailable".into(),
            ));
        };
        let name = if construct { "construct" } else { "apply" };
        let trap = self.proxy_trap(handler, name)?;
        if trap == Value::Undefined {
            return self.dispatch_call(Value::Object(target), receiver, args, construct);
        }
        if !self
            .is_callable(&trap)
            .expect("GetMethod returned a live value in this realm")
        {
            return Err(RuntimeError::TypeError(format!(
                "Proxy {name} trap must be callable"
            )));
        }
        // As with the other traps, the trap function itself may be unrooted.
        let base = self.stack.len();
        self.stack.push(trap.clone());
        let arguments = self.array_from(args);
        self.stack.truncate(base);
        let arguments = arguments?;
        let values = if construct {
            vec![Value::Object(target), arguments, self.new_target.clone()]
        } else {
            vec![Value::Object(target), receiver, arguments]
        };
        let result = self.call_object_callback(trap, Value::Object(handler), values)?;
        if construct && !matches!(result, Value::Object(_)) {
            return Err(RuntimeError::TypeError(
                "Proxy construct trap must return an object".into(),
            ));
        }
        Ok(result)
    }
}
