// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use serde_json::{json, Value};
use std::io::{Read, Write};
use std::process::{Command, Stdio};

fn adapter(requests: &[Value], fault: Option<(&str, &std::path::Path)>) -> Vec<Value> {
    let mut command = Command::new(env!("CARGO_BIN_EXE_bluejs-test262"));
    if let Some((mode, path)) = fault {
        command
            .env("BLUEJS_REGEXP_WORKER", path)
            .env("BLUEJS_FAULT_MODE", mode);
    }
    let mut child = command
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    let mut input = child.stdin.take().unwrap();
    for request in requests {
        writeln!(input, "{request}").unwrap();
    }
    drop(input);
    let result = child.wait_with_output().unwrap();
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    let mut lines = std::str::from_utf8(&result.stdout).unwrap().lines();
    assert_eq!(lines.next(), Some("{\"ready\":1}"));
    lines
        .map(|line| serde_json::from_str(line).unwrap())
        .collect()
}

#[test]
fn adapter_preserves_phases_limits_and_fresh_realms() {
    let cases = [
        (json!({"source":"globalThis.x=42", "mode":"sloppy"}), "ok"),
        (
            json!({"source":"assert.sameValue(typeof x,'undefined')", "mode":"strict"}),
            "ok",
        ),
        (
            json!({"source":"assert(true)", "mode":"raw"}),
            "ReferenceError",
        ),
        (
            json!({"source":"$262.createRealm()", "mode":"raw"}),
            "unsupported",
        ),
        (json!({"source":"1", "mode":"module"}), "ok"),
        (
            json!({"source":"1", "mode":"sloppy", "asynchronous":true}),
            "timeout",
        ),
        (
            json!({"source":"let x;let x;", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"let =", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        // The adapter must distinguish early errors it can establish from a
        // valid production whose execution is not implemented yet.  These
        // assignment-target negatives exercise grammar that used to stop at
        // an arbitrary subset-parser error.
        (
            json!({"source":"([...rest, value] = input)", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"(x ??= y) = 1", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"x?.y = 1", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"x ** y = 1", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"({ break } = input)", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"\"use strict\"; ({ implements } = input)", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"x ??= y", "mode":"sloppy"}),
            "ReferenceError",
        ),
        (json!({"source":"x?.y", "mode":"sloppy"}), "ReferenceError"),
        (
            json!({"source":"x ** y", "mode":"sloppy"}),
            "ReferenceError",
        ),
        (
            json!({"source":"switch() {}", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"try{}catch([...rest, next]){}", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"try{}catch({...rest, next}){}", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"try{}catch(eval){}", "mode":"strict", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"try{}", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"catch", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"try{}finally(){}", "mode":"sloppy", "parse_only":true}),
            "SyntaxError",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "parse_only":true}),
            "ok",
        ),
        (json!({"source":"try{}catch(e){}", "mode":"sloppy"}), "ok"),
        (
            json!({"source":"1", "mode":"sloppy", "bytecode_limit":0}),
            "resource_error",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "includes":["assert.js","other.js"]}),
            "unsupported",
        ),
        // Only `sta.js` and `assert.js` are native. The property helpers have
        // to be supplied as harness sources, and are `unsupported` without.
        (
            json!({"source":"verifyProperty(Math,'PI',{value:Math.PI,writable:false,enumerable:false,configurable:false});isConstructor(function(){})", "mode":"sloppy", "includes":["propertyHelper.js","isConstructor.js"]}),
            "unsupported",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "includes":["isConstructor.js"]}),
            "unsupported",
        ),
        (
            json!({"source":"addOffset(2) === 5", "mode":"sloppy", "includes":["helpers.js"], "harness_sources":["var offset=3; function addOffset(value){return value+offset}"]}),
            "ok",
        ),
        (
            json!({"source":"1", "mode":"strict", "includes":["helpers.js"], "harness_sources":["let ="]}),
            "unsupported",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "includes":["helpers.js"], "harness_sources":["try{}catch(e){}"]}),
            "ok",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "includes":["helpers.js"], "harness_sources":["throw 1"]}),
            "ThrownValue",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "heap_limit":1000}),
            "harness_error",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "heap_limit":0}),
            "harness_error",
        ),
        (json!({"source":"null.x", "mode":"sloppy"}), "TypeError"),
        (
            json!({"source":"'a'.repeat(-1)", "mode":"sloppy"}),
            "RangeError",
        ),
        (
            json!({"source":"new RegExp('[')", "mode":"sloppy"}),
            "SyntaxError",
        ),
        (
            json!({"source":"assert(false)", "mode":"sloppy"}),
            "Test262Error",
        ),
        (json!({"source":"throw 1", "mode":"sloppy"}), "ThrownValue"),
        (
            json!({"source":"1", "mode":"sloppy", "instruction_budget":0}),
            "resource_error",
        ),
        (
            json!({"source":"for(;;){}", "mode":"sloppy"}),
            "resource_error",
        ),
        (
            json!({"source":"'abc'.repeat(20)", "mode":"sloppy", "string_limit":100}),
            "resource_error",
        ),
        (
            json!({"source":"new RegExp('(a+)+$').test('a'.repeat(40)+'!')", "mode":"sloppy", "regex_timeout_ms":40}),
            "timeout",
        ),
        (json!(null), "harness_error"),
        (
            json!({"source":"1", "mode":"raw", "includes":["other.js"]}),
            "ok",
        ),
        (
            json!({"source":"with({}){var f=function(){return 3;};}assert.sameValue(f(),3)", "mode":"sloppy"}),
            "ok",
        ),
        (
            json!({"source":"function f(a=b,b=2){}f()", "mode":"sloppy"}),
            "ReferenceError",
        ),
        (
            json!({"source":"function f(a=1,get=()=>a){var a=2;return get();}assert.sameValue(f(),1)", "mode":"sloppy"}),
            "ok",
        ),
        (
            json!({"source":"class Base{constructor(value){this.value=value}method(){return this.value}}class C extends Base{constructor(){super(3)}method(){return super.method()}static field=1;static{this.block=2}}let value=new C;assert.sameValue(value.method(),3);assert.sameValue(C.field,1);assert.sameValue(C.block,2)", "mode":"sloppy"}),
            "ok",
        ),
        (
            json!({"source":"class Base{set value(value){this.saved=value}}class C extends Base{constructor(){super()}store(){super.value=2;return this.saved}}assert.sameValue(new C().store(),2)", "mode":"sloppy"}),
            "ok",
        ),
        (
            json!({"source":"class C extends null{constructor(){super()}}new C", "mode":"sloppy"}),
            "TypeError",
        ),
        (
            json!({"source":"let value=$262.IsHTMLDDA;assert.sameValue(!value,true);assert.sameValue(value==null,true);assert.sameValue(typeof value,'undefined');switch(value){case undefined:throw 1;case null:throw 2;case value:break}", "mode":"sloppy", "is_html_dda":true}),
            "ok",
        ),
        (
            json!({"source":"async function work(){}work()", "mode":"sloppy"}),
            "ok",
        ),
        (
            json!({"source":"async function* values(){yield await Promise.resolve(7)}let iterator=values();iterator.next().then(result=>{assert.sameValue(result.value,7);assert.sameValue(result.done,false);return iterator.next()}).then(result=>{assert.sameValue(result.done,true);$DONE()},$DONE)", "mode":"sloppy", "asynchronous":true}),
            "ok",
        ),
        (
            json!({"source":"async function* values(){yield 2;yield 3}async function total(){let sum=0;for await(let value of values())sum+=value;return sum}total().then(sum=>{assert.sameValue(sum,5);$DONE()},$DONE)", "mode":"sloppy", "asynchronous":true}),
            "ok",
        ),
        (
            json!({"source":"1", "mode":"sloppy", "includes":["helpers.js"], "harness_sources":["async function work(){}work()"]}),
            "ok",
        ),
    ];
    let requests: Vec<_> = cases.iter().map(|(request, _)| request.clone()).collect();
    let replies = adapter(&requests, None);
    assert_eq!(replies.len(), cases.len());
    for (reply, (request, expected)) in replies.iter().zip(&cases) {
        assert_eq!(reply["kind"], *expected, "{request}: {reply}");
    }
    assert_eq!(replies[6]["phase"], "parse");
}

#[test]
fn adapter_exercises_temporal_and_module_error_paths_in_the_real_process() {
    let cases = [
        ("Temporal.PlainDate.from('\\ud800')", "sloppy", "RangeError"),
        (
            "Temporal.PlainDateTime.from('\\ud800')",
            "sloppy",
            "RangeError",
        ),
        (
            "Temporal.Now.plainDateISO('Not/A_Zone')",
            "sloppy",
            "RangeError",
        ),
        (
            "new Temporal.Instant(0n).toZonedDateTimeISO('Not/A_Zone')",
            "sloppy",
            "RangeError",
        ),
        (
            "Temporal.PlainDate.from('2000-01-01').toZonedDateTime('Not/A_Zone')",
            "sloppy",
            "RangeError",
        ),
        ("import * as 0 from './m.js';", "module", "SyntaxError"),
        ("export default function (", "module", "SyntaxError"),
        ("export default ;", "module", "SyntaxError"),
        ("export var value = 1 extra;", "module", "SyntaxError"),
        (
            "@decorator export d\\u0065fault class C {}",
            "module",
            "SyntaxError",
        ),
    ];
    let requests: Vec<_> = cases
        .iter()
        .map(|(source, mode, _)| json!({"source":source,"mode":mode}))
        .collect();
    let replies = adapter(&requests, None);
    assert_eq!(replies.len(), cases.len());
    for (reply, (source, mode, kind)) in replies.iter().zip(cases) {
        assert_eq!(reply["kind"], kind, "{mode}: {source}: {reply}");
    }
}

#[test]
fn adapter_reports_invalid_requested_modules_at_resolution() {
    for invalid_source in ["0++;", "break;"] {
        let replies = adapter(
            &[json!({
                "source":"import './invalid.js'",
                "mode":"module",
                "module_path":"entry.js",
                "module_sources":{"invalid.js":invalid_source},
            })],
            None,
        );
        assert_eq!(
            replies[0]["phase"], "resolution",
            "{invalid_source}: {replies:?}"
        );
        assert_eq!(
            replies[0]["kind"], "SyntaxError",
            "{invalid_source}: {replies:?}"
        );
    }
}

#[test]
fn adapter_executes_number_format_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let n=new Intl.NumberFormat('th-u-nu-thai',{useGrouping:false,minimumFractionDigits:2,maximumFractionDigits:2});assert.sameValue(n.format(1007.5),'๑๐๐๗.๕๐');assert.sameValue(n.resolvedOptions().numberingSystem,'thai');assert.sameValue(Intl.NumberFormat.supportedLocalesOf(['zz','th-u-nu-thai']).join(','),'th-u-nu-thai')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_supported_values_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "assert(Intl.supportedValuesOf('numberingSystem').includes('latn'));let currencies=Intl.supportedValuesOf('currency');assert.sameValue(currencies.length,307);assert.sameValue(currencies[0],'ADP');assert.sameValue(currencies[currencies.length-1],'ZWR');assert(currencies.includes('EUR')&&currencies.includes('JPY')&&currencies.includes('USD'))",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_list_format_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let f=new Intl.ListFormat('es',{type:'conjunction',style:'long'});assert.sameValue(f.format(['España','Suiza','Italia']),'España, Suiza e Italia');let p=f.formatToParts(['A','B']);assert.sameValue(p.length,3);assert.sameValue(p[0].type,'element');assert.sameValue(p[1].type,'literal');assert.sameValue(Intl.ListFormat.supportedLocalesOf(['zz','es']).join(','),'es')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_duration_format_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let f=new Intl.DurationFormat('en',{style:'digital',fractionalDigits:3});assert.sameValue(f.format({hours:1,minutes:2,seconds:3,milliseconds:4}),'1:02:03.004');let p=f.formatToParts({hours:1,minutes:2,seconds:3,milliseconds:4});assert.sameValue(p[0].type,'integer');assert.sameValue(p[0].unit,'hour');assert.sameValue(p[5].type,'decimal');assert.sameValue(p[6].type,'fraction');assert.sameValue(f.resolvedOptions().style,'digital');assert.sameValue(Intl.DurationFormat.supportedLocalesOf(['zz','en']).join(','),'en')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_plural_rules_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let p=new Intl.PluralRules('en',{type:'ordinal'});assert.sameValue(p.select(2),'two');assert.sameValue(p.selectRange(1,2),'two');assert.sameValue(p.resolvedOptions().type,'ordinal');assert.sameValue(Intl.PluralRules.supportedLocalesOf(['zz','en']).join(','),'en')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_segmenter_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let s=new Intl.Segmenter('en',{granularity:'word'});let values=[];for(let item of s.segment('A 2'))values.push(item.segment+':'+item.isWordLike);assert.sameValue(values.join('|'),'A:true| :false|2:true');assert.sameValue(s.segment('A').containing(0).index,0);assert.sameValue(Intl.Segmenter.supportedLocalesOf(['zz','en']).join(','),'en')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_display_names_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let d=new Intl.DisplayNames('en',{type:'language'});assert.sameValue(d.of('fr'),'French');assert.sameValue(d.of('cde-ab-abcde'),'cde (AB, ABCDE)');assert.sameValue(d.resolvedOptions().type,'language');assert.sameValue(Intl.DisplayNames.supportedLocalesOf(['zz','en']).join(','),'en')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[test]
fn adapter_executes_relative_time_format_through_the_json_lines_interface() {
    let replies = adapter(
        &[json!({
            "source": "let r=new Intl.RelativeTimeFormat('en',{numeric:'auto'});assert.sameValue(r.format(-0,'day'),'today');assert.sameValue(r.formatToParts(2,'hours')[1].unit,'hour');assert.sameValue(r.resolvedOptions().numeric,'auto');assert.sameValue(Intl.RelativeTimeFormat.supportedLocalesOf(['zz','en']).join(','),'en')",
            "mode": "sloppy",
        })],
        None,
    );
    assert_eq!(replies, vec![json!({"kind":"ok", "phase":"runtime"})]);
}

#[cfg(unix)]
#[test]
fn regex_protocol_faults_and_missing_helper_fail_closed() {
    use std::os::unix::fs::PermissionsExt;
    let directory = std::env::temp_dir().join(format!("bluejs-regex-fault-{}", std::process::id()));
    std::fs::create_dir_all(&directory).unwrap();
    let script = directory.join("worker.py");
    std::fs::write(&script, include_bytes!("fixtures/regex_fault.py")).unwrap();
    std::fs::set_permissions(&script, std::fs::Permissions::from_mode(0o700)).unwrap();
    for mode in [
        "early_exit",
        "bad_ready",
        "after_ready_exit",
        "closed_before_ready",
        "malformed",
        "truncated_reply",
        "oversized",
        "invalid_range",
        "compile_reply",
        "match_reply",
    ] {
        let replies = adapter(
            &[json!({"source":"new RegExp('a').test('a')", "mode":"sloppy"})],
            Some((mode, &script)),
        );
        assert_eq!(replies[0]["kind"], "worker_error", "{mode}: {replies:?}");
    }
    let long_pattern = adapter(
        &[json!({
            "source": "new RegExp('a'.repeat(100000)).test('a')",
            "mode": "sloppy"
        })],
        Some(("close_after_header", &script)),
    );
    assert_eq!(long_pattern[0]["kind"], "worker_error", "{long_pattern:?}");
    let missing = directory.join("missing");
    for source in ["/a/", "new RegExp('a')"] {
        let replies = adapter(
            &[json!({"source":source,"mode":"sloppy"})],
            Some(("unused", &missing)),
        );
        assert_eq!(replies[0]["kind"], "worker_error");
    }
    std::fs::remove_dir_all(directory).unwrap();
}

#[cfg(unix)]
#[test]
fn regex_helper_reports_closed_output_during_frame_header_and_body() {
    use std::os::fd::OwnedFd;
    use std::os::unix::net::UnixStream;

    let (read, write) = UnixStream::pair().unwrap();
    drop(read);
    let mut child = Command::new(env!("CARGO_BIN_EXE_bluejs-regexp-worker"))
        .stdin(Stdio::null())
        .stdout(Stdio::from(OwnedFd::from(write)))
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    assert!(!child.wait().unwrap().success());

    let (mut output, write) = UnixStream::pair().unwrap();
    let mut child = Command::new(env!("CARGO_BIN_EXE_bluejs-regexp-worker"))
        .stdin(Stdio::piped())
        .stdout(Stdio::from(OwnedFd::from(write)))
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    let mut input = child.stdin.take().unwrap();
    let mut length = [0; 4];
    output.read_exact(&mut length).unwrap();
    let mut ready = vec![0; u32::from_le_bytes(length) as usize];
    output.read_exact(&mut ready).unwrap();
    assert_eq!(ready, b"bluejs-regexp-worker/1");

    let patterns = vec![(vec![97u16], String::new()); 100_000];
    let request = serde_json::to_vec(&json!({
        "operation": "validate",
        "patterns": patterns,
    }))
    .unwrap();
    input
        .write_all(&(request.len() as u32).to_le_bytes())
        .unwrap();
    input.write_all(&request).unwrap();
    input.flush().unwrap();
    output.read_exact(&mut length).unwrap();
    assert!(u32::from_le_bytes(length) > 100_000);
    drop(output);
    drop(input);
    assert!(!child.wait().unwrap().success());
}

#[test]
fn helper_rejects_oversized_frames_and_handles_out_of_range_starts() {
    let mut child = Command::new(env!("CARGO_BIN_EXE_bluejs-regexp-worker"))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    let mut input = child.stdin.take().unwrap();
    let mut output = child.stdout.take().unwrap();
    fn read_frame(output: &mut impl Read) -> Vec<u8> {
        let mut size = [0; 4];
        output.read_exact(&mut size).unwrap();
        let mut bytes = vec![0; u32::from_le_bytes(size) as usize];
        output.read_exact(&mut bytes).unwrap();
        bytes
    }
    assert_eq!(read_frame(&mut output), b"bluejs-regexp-worker/1");
    let request =
        serde_json::to_vec(&json!({"source":[97],"flags":"","input":[97],"start":2})).unwrap();
    input
        .write_all(&(request.len() as u32).to_le_bytes())
        .unwrap();
    input.write_all(&request).unwrap();
    input.flush().unwrap();
    assert_eq!(
        serde_json::from_slice::<Value>(&read_frame(&mut output)).unwrap(),
        json!({"Found":null})
    );
    input
        .write_all(&(16 * 1024 * 1024u32 + 1).to_le_bytes())
        .unwrap();
    drop(input);
    assert!(!child.wait().unwrap().success());
}

#[test]
fn helper_process_reuses_cached_requests_and_exits_after_shutdown() {
    let mut child = Command::new(env!("CARGO_BIN_EXE_bluejs-regexp-worker"))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    let mut input = child.stdin.take().unwrap();
    let mut output = child.stdout.take().unwrap();
    let mut read_frame = || {
        let mut size = [0; 4];
        output.read_exact(&mut size).unwrap();
        let mut bytes = vec![0; u32::from_le_bytes(size) as usize];
        output.read_exact(&mut bytes).unwrap();
        bytes
    };
    assert_eq!(read_frame(), b"bluejs-regexp-worker/1");
    let mut request = |value: Value| {
        let bytes = serde_json::to_vec(&value).unwrap();
        input
            .write_all(&(bytes.len() as u32).to_le_bytes())
            .unwrap();
        input.write_all(&bytes).unwrap();
        input.flush().unwrap();
        serde_json::from_slice::<Value>(&read_frame()).unwrap()
    };
    assert_eq!(
        request(json!({"operation":"compile","source":[97],"flags":""})),
        json!("Compiled")
    );
    let first = request(json!({
        "operation":"find","source":null,"flags":null,"input":[97,98,97],"start":0
    }));
    assert_eq!(first["Found"]["captures"][0], json!({"start":0,"end":1}));
    let reused = request(json!({
        "operation":"find","source":null,"flags":null,"input":null,"start":2
    }));
    assert_eq!(reused["Found"]["captures"][0], json!({"start":2,"end":3}));
    assert_eq!(
        request(json!({
            "operation":"validate","patterns":[[[97],""],[[40],""]]
        })),
        json!({"Validated":[true,false]})
    );
    let bytes = serde_json::to_vec(&json!({"operation":"shutdown"})).unwrap();
    input
        .write_all(&(bytes.len() as u32).to_le_bytes())
        .unwrap();
    input.write_all(&bytes).unwrap();
    drop(input);
    assert!(child.wait().unwrap().success());
}

#[test]
fn compilation_deadline_and_transport_limit_are_enforced() {
    let replies = adapter(
        &[
            // A literal run can compile within a millisecond on fast hosts.
            // Repeated branches force uncached compilation work while keeping
            // the request below the frame limit and the positive deadline intact.
            json!({"source":"new RegExp('(a|b)'.repeat(100000))", "mode":"sloppy", "regex_timeout_ms":1}),
            json!({"source":"new RegExp('漢'.repeat(3000000))", "mode":"sloppy", "string_limit":8000000}),
            json!({"source":"assert(/a/.test('a'))", "mode":"sloppy"}),
        ],
        None,
    );
    assert_eq!(replies[0]["kind"], "timeout", "{replies:?}");
    assert_eq!(replies[1]["kind"], "worker_error", "{replies:?}");
    assert_eq!(replies[2]["kind"], "ok", "{replies:?}");
}

/// `propertyHelper.js` and `isConstructor.js` reach the adapter as ordinary
/// harness sources, exactly as the runner supplies them from the corpus.
#[test]
fn adapter_runs_the_upstream_property_helpers_as_harness_sources() {
    let sources = json!([
        include_str!(
            "../../../development/browser_core/reference/test262/harness/propertyHelper.js"
        ),
        include_str!(
            "../../../development/browser_core/reference/test262/harness/isConstructor.js"
        ),
    ]);
    let includes = json!(["propertyHelper.js", "isConstructor.js"]);
    let cases = [
        (
            "verifyProperty(Math,'PI',{value:Math.PI,writable:false,enumerable:false,configurable:false});assert(isConstructor(function(){}))",
            "sloppy",
            "ok",
        ),
        (
            "verifyProperty(Math,'PI',{value:Math.PI,writable:false,enumerable:false,configurable:false});assert(isConstructor(function(){}))",
            "strict",
            "ok",
        ),
        // The helper deletes a configurable property it has verified unless
        // `restore` is passed, and a genuinely mismatching descriptor fails.
        (
            "var o={x:1};verifyProperty(o,'x',{configurable:true});assert.sameValue(Object.hasOwn(o,'x'),false)",
            "sloppy",
            "ok",
        ),
        (
            "var o={x:1};verifyProperty(o,'x',{configurable:true},{restore:true});assert.sameValue(o.x,1)",
            "strict",
            "ok",
        ),
        ("verifyProperty(Math,'PI',{writable:true})", "sloppy", "Test262Error"),
        ("verifyProperty(Math,'PI',{writable:true})", "strict", "Test262Error"),
        ("isConstructor({})", "sloppy", "Test262Error"),
        // A property reported configurable that `delete` leaves in place is
        // rejected because the upstream helper really deletes.
        (
            "verifyProperty(new Proxy({x:1},{deleteProperty(){return false}}),'x',{configurable:true})",
            "sloppy",
            "Test262Error",
        ),
    ];
    let requests: Vec<_> = cases
        .iter()
        .map(|(source, mode, _)| {
            json!({"source":source, "mode":mode, "includes":includes, "harness_sources":sources})
        })
        .collect();
    let replies = adapter(&requests, None);
    assert_eq!(replies.len(), cases.len());
    for (reply, (source, mode, expected)) in replies.iter().zip(&cases) {
        assert_eq!(reply["kind"], *expected, "{mode}: {source}: {reply}");
    }
    assert!(
        replies[4]["message"]
            .as_str()
            .is_some_and(|message| message.contains("PI descriptor should be writable")),
        "{}",
        replies[4]
    );
}
