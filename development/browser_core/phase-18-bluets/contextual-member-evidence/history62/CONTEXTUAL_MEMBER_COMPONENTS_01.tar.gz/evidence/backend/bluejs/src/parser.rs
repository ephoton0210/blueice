// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Recursive-descent parser: [`crate::token::Token`] stream -> [`Program`].
//! Scoped to exactly `phase-2-mvp-scope/PLAN.md`'s "MVP JS scope
//! (decided)" section -- see `ast.rs`'s own doc comment for what's
//! deliberately absent.
//!
//! **Precedence, as a plain top-down chain of functions** (each tier
//! calls the next-tighter one, matching this codebase's other
//! from-scratch parsers' style, e.g. `blueice-css`'s `parser.rs`,
//! rather than a table-driven Pratt parser): assignment (and arrow
//! functions, detected here since they share `AssignmentExpression`'s
//! grammar slot) -> conditional (`?:`) -> nullish (`??`) -> logical OR
//! -> logical AND -> bitwise OR -> bitwise XOR -> bitwise AND -> equality
//! -> relational -> shift -> additive -> multiplicative -> unary -> postfix
//! update (`++`/`--`) -> left-hand-side (`new`/member/call chains) -> primary.
//! ECMAScript §13.13 keeps
//! unparenthesized coalescing and logical AND/OR in separate productions;
//! grammar-level flags enforce that distinction before parentheses are
//! discarded from the AST.
//!
//! **`for`-loop head disambiguation** follows the standard technique
//! real engines use: parse the head with the `in` operator temporarily
//! disabled (`no_in`) so `for (x in y)` doesn't get misparsed as the
//! expression `x in y`, then look at what follows to decide whether
//! it's a classic `for`, a `for-in`, or a contextual `for-of` (`of`
//! isn't a reserved keyword in real ECMAScript either -- recognized
//! here the same way, as a plain identifier whose name happens to be
//! `"of"` in exactly this grammar position).
//!
//! **Template literal placeholders are parsed by recursion, not by
//! consuming a pre-built token stream**: [`crate::token::Token::Template`]
//! carries each `${...}` placeholder as raw source text (see
//! `token.rs`'s own doc comment for why), and [`Parser::parse_template`]
//! below re-tokenizes/re-parses each one independently via
//! [`Parser::parse_template_placeholder`] -- a fresh [`Parser`] over just that
//! substring (inheriting the enclosing function's generator/async/strict
//! context), required to consume it entirely as one expression.

use crate::ast::*;
use crate::token::{Keyword, LexError, Punct, SpannedToken, Token, Tokenizer};

mod editions;
mod expressions;
mod functions;
mod module;
mod module_items;
mod patterns;
mod statements;
#[cfg(test)]
mod tests;

pub use editions::SyntaxEdition;
pub use module::{parse_module, parse_module_with_debug_spans, parse_module_with_edition};

#[derive(Debug, Clone, PartialEq)]
pub struct ParseError {
    pub message: String,
    /// Resource failures during literal validation are not SyntaxErrors.
    pub resource: Option<crate::RuntimeError>,
    /// True only when the parser recognized a specified syntax error. Other
    /// parse failures may still be unsupported valid grammar in this subset.
    pub known_syntax: bool,
}

/// One exact top-level statement range in the original host source. The
/// half-open byte offsets exclude leading trivia and include the statement's
/// final consumed token. This is parser provenance, not a bytecode safe point.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ParsedStatementSpan {
    pub start_byte: usize,
    pub end_byte: usize,
}

/// An identifier expression's exact source token, captured when the parser
/// constructs the expression rather than guessed from a later text search.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParsedIdentifierSpan {
    pub start_byte: usize,
    pub end_byte: usize,
    pub name: String,
}

impl From<LexError> for ParseError {
    fn from(e: LexError) -> ParseError {
        ParseError {
            message: e.message,
            resource: None,
            known_syntax: e.known_syntax,
        }
    }
}

/// Parses one classic Script. `source` is ordinary host text: to run source
/// that may hold an unpaired surrogate, see [`parse_encoded`].
pub fn parse(source: &str) -> Result<Program, ParseError> {
    parse_with_edition(source, SyntaxEdition::EsNext)
}

/// Parses a Script and records one exact source range for each returned
/// top-level AST statement, in the same order as `Program::body`. These
/// ranges alone do not authorize debugger binding of nested expressions.
pub fn parse_with_top_level_spans(
    source: &str,
) -> Result<(Program, Vec<ParsedStatementSpan>), ParseError> {
    parse_with_debug_spans(source).map(|(program, statements, _)| (program, statements))
}

/// Parses a Script with exact top-level statement and identifier-expression
/// token spans. Callers must still prove a unique compiler-recorded safe point
/// before allowing a debugger action at any identifier token.
pub fn parse_with_debug_spans(
    source: &str,
) -> Result<(Program, Vec<ParsedStatementSpan>, Vec<ParsedIdentifierSpan>), ParseError> {
    let escaped = crate::source_encoding::escape(source);
    let (program, spans, identifiers) =
        parse_encoded_script(&escaped, SyntaxEdition::EsNext, true)?;
    let source_bytes = crate::source_encoding::escaped_character_source_bytes(source);
    let spans = spans
        .into_iter()
        .map(|(start, end)| ParsedStatementSpan {
            start_byte: source_bytes[start],
            end_byte: source_bytes[end],
        })
        .collect();
    let identifiers = identifiers
        .into_iter()
        .map(|(start, end, name)| ParsedIdentifierSpan {
            start_byte: source_bytes[start],
            end_byte: source_bytes[end],
            name,
        })
        .collect();
    Ok((program, spans, identifiers))
}

/// Parses Script syntax restricted to the selected output edition. Built-in
/// runtime APIs are independent of this grammar selection.
pub fn parse_with_edition(source: &str, edition: SyntaxEdition) -> Result<Program, ParseError> {
    parse_encoded_with_edition(&crate::source_encoding::escape(source), edition)
}

/// [`parse`] over *lexer text* (see [`crate::source_encoding`]), the form in
/// which the source of `eval`, `Function` and `ShadowRealm.prototype.evaluate`
/// reaches the parser, since a JavaScript string may hold unpaired surrogates.
pub(crate) fn parse_encoded(source: &str) -> Result<Program, ParseError> {
    parse_encoded_with_edition(source, SyntaxEdition::EsNext)
}

fn parse_encoded_with_edition(source: &str, edition: SyntaxEdition) -> Result<Program, ParseError> {
    parse_encoded_script(source, edition, false).map(|(program, _, _)| program)
}

type EncodedScriptWithDebugSpans = (Program, Vec<(usize, usize)>, Vec<(usize, usize, String)>);

fn parse_encoded_script(
    source: &str,
    edition: SyntaxEdition,
    capture_spans: bool,
) -> Result<EncodedScriptWithDebugSpans, ParseError> {
    let mut parser = Parser::new_script(source);
    parser.capture_debug_identifiers = capture_spans;
    parser.select_edition(edition)?;
    let mut body = Vec::new();
    let mut spans = Vec::new();
    let mut prologue = DirectivePrologue::default();
    while !parser.at_eof() {
        let start = parser.token_start();
        body.push(parser.parse_prologue_statement(&mut prologue)?);
        if capture_spans {
            spans.push((start, parser.positions[parser.pos]));
        }
    }
    let program = Program { body };
    if contains_super_call_outside_class(&program)
        || contains_super_property_outside_class(&program)
    {
        return Err(parser.syntax_error("super is not valid in script code"));
    }
    crate::compiler::validate_private_early_errors(&program)
        .map_err(|error| parser.syntax_error(error.to_string()))?;
    parser.validate_edition()?;
    editions::validate_body(&program.body, edition)?;
    Ok((program, spans, parser.debug_identifier_spans))
}

/// Parses direct-eval source (lexer text) before its caller applies context-sensitive
/// `super` early errors. At script top level those expressions are invalid,
/// but a direct eval inherits the calling method's `[[HomeObject]]`. Eval
/// code is strict when the calling code is (`strict`) or when its own
/// directive prologue says so.
pub(crate) fn parse_eval(source: &str, strict: bool) -> Result<Program, ParseError> {
    let mut parser = Parser::new_script(source);
    parser.strict = strict;
    let mut body = Vec::new();
    let mut prologue = DirectivePrologue::default();
    while !parser.at_eof() {
        body.push(parser.parse_prologue_statement(&mut prologue)?);
    }
    Ok(Program { body })
}

/// State of the Directive Prologue (§11.2.1) while a Script, eval code or a
/// function body is parsed statement by statement.
struct DirectivePrologue {
    /// Every statement so far has been an ExpressionStatement consisting
    /// solely of a string literal.
    open: bool,
    /// A directive so far used a legacy octal or non-octal decimal escape,
    /// which a later Use Strict Directive makes an early error.
    legacy_octal: bool,
}

impl Default for DirectivePrologue {
    fn default() -> Self {
        DirectivePrologue {
            open: true,
            legacy_octal: false,
        }
    }
}

// Preserve source positions so the parser can select the RegExp lexical goal
// at PrimaryExpression and rescan the suffix. A speculative division scan may
// encounter regex-only characters; defer that lexical error until consumed.
fn tokenize_all(tokenizer: &mut Tokenizer) -> (Vec<SpannedToken>, Vec<usize>) {
    let mut tokens = Vec::new();
    let mut positions = Vec::new();
    loop {
        positions.push(tokenizer.position());
        match tokenizer.next_spanned() {
            Ok(spanned) => {
                let done = spanned.token == Token::Eof;
                tokens.push(spanned);
                if done {
                    return (tokens, positions);
                }
            }
            Err(error) => {
                tokens.push(SpannedToken {
                    token: Token::Invalid(error.message),
                    start: tokenizer.position(),
                    newline_before: false,
                    identifier_escaped: false,
                    legacy_octal_escape: false,
                    string_escaped: false,
                });
                positions.push(tokenizer.position());
                tokens.push(SpannedToken {
                    token: Token::Eof,
                    start: tokenizer.position(),
                    newline_before: false,
                    identifier_escaped: false,
                    legacy_octal_escape: false,
                    string_escaped: false,
                });
                return (tokens, positions);
            }
        }
    }
}

/// Parses `source` as one standalone expression, to exercise expression
/// parsing in tests without wrapping every fixture in a statement.
#[cfg(test)]
fn parse_expression_from_source(source: &str) -> Result<Expr, ParseError> {
    let mut parser = Parser::new(source);
    let expr = parser.parse_expression()?;
    if !parser.at_eof() {
        return Err(parser.error("unexpected trailing tokens after expression"));
    }
    Ok(expr)
}

pub(crate) fn closes_template_placeholder(source: &str) -> bool {
    // The placeholder is parsed again inside its enclosing function, where
    // `yield` and `await` may be operators. Its closing brace is the same in
    // every such context, so accept a candidate that parses in any of them.
    [(0, 0), (1, 0), (0, 1)]
        .into_iter()
        .any(|(generator_depth, async_depth)| {
            let mut parser = Parser::new(source);
            parser.generator_depth = generator_depth;
            parser.async_depth = async_depth;
            parser.parse_expression().is_ok() && parser.eat_punct(Punct::RBrace) && parser.at_eof()
        })
}

/// A label on a function declaration in a StatementList (Annex B.3.2) has no
/// effect: the declaration is hoisted and scoped exactly like an unlabelled
/// one, and no `break` can name a label that has no statements. Dropping the
/// labels lets every later phase treat the two forms alike. (A labelled
/// function in a statement position, `if (x) l: function f() {}`, is not a
/// list item and stays rejected.)
fn unlabel_function_declaration(statement: Stmt) -> Stmt {
    let Stmt::Labelled { label, item } = statement else {
        return statement;
    };
    match unlabel_function_declaration(*item) {
        function @ Stmt::FunctionDecl(_) => function,
        other => Stmt::Labelled {
            label,
            item: Box::new(other),
        },
    }
}

/// The words reserved only in strict mode code (§13.1.1), which the tokenizer
/// keeps as plain identifiers.
fn is_strict_reserved_word(name: &str) -> bool {
    matches!(
        name,
        "implements"
            | "interface"
            | "let"
            | "package"
            | "private"
            | "protected"
            | "public"
            | "static"
            | "yield"
    )
}

/// Whether a function body's Directive Prologue holds a Use Strict Directive.
/// Only a bare string statement is a directive: the parser wraps a
/// `use strict`-valued statement that is not one in `Expr::Parenthesized`.
fn function_body_has_use_strict(body: &[Stmt]) -> bool {
    body.iter()
        .take_while(|stmt| matches!(stmt, Stmt::Expr(Expr::String(_))))
        .any(|stmt| matches!(stmt, Stmt::Expr(Expr::String(value)) if value == "use strict"))
}

fn keyword_as_str(k: Keyword) -> &'static str {
    match k {
        Keyword::Var => "var",
        Keyword::Let => "let",
        Keyword::Const => "const",
        Keyword::Function => "function",
        Keyword::Return => "return",
        Keyword::If => "if",
        Keyword::Else => "else",
        Keyword::For => "for",
        Keyword::While => "while",
        Keyword::Do => "do",
        Keyword::Switch => "switch",
        Keyword::Case => "case",
        Keyword::Default => "default",
        Keyword::Break => "break",
        Keyword::Continue => "continue",
        Keyword::Throw => "throw",
        Keyword::Try => "try",
        Keyword::Catch => "catch",
        Keyword::Finally => "finally",
        Keyword::New => "new",
        Keyword::Typeof => "typeof",
        Keyword::Void => "void",
        Keyword::Delete => "delete",
        Keyword::Instanceof => "instanceof",
        Keyword::In => "in",
        Keyword::True => "true",
        Keyword::False => "false",
        Keyword::Null => "null",
        Keyword::This => "this",
    }
}

/// A plain identifier or member expression -- the ordinary assignment-target
/// and `++`/`--` operand shapes.
fn is_valid_ref_target(expr: &Expr) -> bool {
    matches!(expr, Expr::Identifier(_) | Expr::Member { .. })
        || matches!(expr, Expr::Parenthesized(inner) if is_valid_ref_target(inner))
}

/// Parentheses are normally erased from the executable AST, but they end an
/// OptionalChain.  Keep them around an optional suffix so the compiler can
/// distinguish `base?.value.more` from `(base?.value).more`.
fn optional_chain_expression(expr: &Expr) -> bool {
    match expr {
        Expr::OptionalMember { .. } | Expr::OptionalCall { .. } => true,
        Expr::Member { object, .. } | Expr::Call { callee: object, .. } => {
            optional_chain_expression(object)
        }
        _ => false,
    }
}

/// Grouping is not generally observable in the executable AST. It is kept
/// only while parsing an enclosing assignment so that AssignmentTargetType
/// can distinguish `(name)` from an IdentifierReference for name inference.
fn unparenthesize(expr: Expr) -> Expr {
    match expr {
        Expr::Parenthesized(expr) => unparenthesize(*expr),
        expr => expr,
    }
}

/// Builds a `SourceText` for a source of `len` bytes: its offsets are `u32`,
/// so a longer source keeps no per-function text (the default, empty one).
#[cfg(test)]
fn source_text_within(len: usize, build: impl FnOnce() -> SourceText) -> SourceText {
    if len > u32::MAX as usize {
        return SourceText::default();
    }
    build()
}

/// Wraps an expression statement's expression in `Expr::Parenthesized`, which
/// evaluates the same but is no longer a bare string statement; any other
/// statement is returned unchanged.
#[cfg(test)]
fn parenthesize_expression_statement(statement: Stmt) -> Stmt {
    match statement {
        Stmt::Expr(expression) => Stmt::Expr(Expr::Parenthesized(Box::new(expression))),
        other => other,
    }
}

fn is_assignment_operator(token: &Token) -> bool {
    matches!(
        token,
        Token::Punct(
            Punct::Assign
                | Punct::PlusAssign
                | Punct::MinusAssign
                | Punct::StarAssign
                | Punct::SlashAssign
                | Punct::PercentAssign
                | Punct::ShiftLeftAssign
                | Punct::ShiftRightAssign
                | Punct::UnsignedShiftRightAssign
                | Punct::AndAssign
                | Punct::XorAssign
                | Punct::OrAssign
                | Punct::AndAndAssign
                | Punct::OrOrAssign
                | Punct::QuestionQuestionAssign
        )
    )
}

/// Annex B's optional web-compat extension recognizes only CallExpression
/// targets. In sloppy code they are evaluated and then throw ReferenceError;
/// strict code still rejects them during static semantics.
fn is_annex_b_call_assignment_target(expr: &Expr) -> bool {
    matches!(expr, Expr::Call { .. })
}

/// Converts an already-parsed expression into a `for-in`/`for-of` head.
/// Assignment references use the same target form as destructuring
/// assignments. Annex B preserves a CallExpression target so its observable
/// call happens before the web-compat runtime ReferenceError.
fn expr_to_for_head(expr: Expr) -> Result<ForHead, ParseError> {
    if is_valid_ref_target(&expr) {
        return Ok(ForHead::Assignment(AssignmentPattern::Target(Box::new(
            expr,
        ))));
    }
    if is_annex_b_call_assignment_target(&expr) {
        return Ok(ForHead::Expr(expr));
    }
    Err(ParseError {
        message: "invalid for-in/for-of assignment target".to_string(),
        resource: None,
        known_syntax: false,
    })
}

fn known_syntax(mut error: ParseError) -> ParseError {
    error.known_syntax = true;
    error
}

struct Parser {
    edition: SyntaxEdition,
    edition_error: Option<ParseError>,
    tokens: Vec<SpannedToken>,
    positions: Vec<usize>,
    tokenizer: Tokenizer,
    pos: usize,
    capture_debug_identifiers: bool,
    debug_identifier_spans: Vec<(usize, usize, String)>,
    /// Set while parsing a `for`-loop head's init clause, so the
    /// relational-expression tier refuses to consume a bare `in` as a
    /// binary operator there -- see this module's doc comment.
    no_in: bool,
    generator_depth: u32,
    async_depth: u32,
    /// `await` is a keyword at the outermost level of the Module goal, but
    /// remains an IdentifierName in nested ordinary functions.
    module_await: bool,
    /// The Module goal remains in force below nested statements and functions
    /// even where `await` temporarily becomes an IdentifierName. Static
    /// import/export declarations are restricted to the ModuleItem list.
    module: bool,
    /// Parser contexts where IdentifierReference excludes strict-reserved
    /// words. This is activated by a script directive prologue or the Module
    /// goal so parse-only negative tests do not defer a mandated early error
    /// to the compiler.
    strict: bool,
    function_depth: u32,
    static_block_function_depths: Vec<u32>,
    /// The whole text being parsed. Every function and class parsed from it
    /// records its own range of this text (see [`SourceText`]).
    source: std::sync::Arc<str>,
    /// The byte offset of each character of `source` (and of its end), for
    /// mapping the tokenizer's character offsets to `source` byte ranges.
    /// `None` for ASCII text, where the two are the same.
    char_to_byte: Option<Vec<usize>>,
}

impl Parser {
    fn new(source: &str) -> Parser {
        Self::from_tokenizer(Tokenizer::new(source), source)
    }

    /// A parser over complete Script source text, the only place a Hashbang
    /// comment (`#!...`) may begin. Template placeholders and other
    /// substring parses use [`Parser::new`], where `#!` stays an error.
    fn new_script(source: &str) -> Parser {
        let mut tokenizer = Tokenizer::new(source);
        tokenizer.skip_hashbang();
        Self::from_tokenizer(tokenizer, source)
    }

    fn new_module(source: &str) -> Parser {
        let mut tokenizer = Tokenizer::new_module(source);
        tokenizer.skip_hashbang();
        Self::from_tokenizer(tokenizer, source)
    }

    fn from_tokenizer(mut tokenizer: Tokenizer, source: &str) -> Parser {
        let (tokens, positions) = tokenize_all(&mut tokenizer);
        // The tokenizer counts characters; a source range counts bytes.
        let char_to_byte = (!source.is_ascii()).then(|| {
            source
                .char_indices()
                .map(|(offset, _)| offset)
                .chain([source.len()])
                .collect()
        });
        Parser {
            edition: SyntaxEdition::EsNext,
            edition_error: None,
            tokens,
            positions,
            tokenizer,
            pos: 0,
            capture_debug_identifiers: false,
            debug_identifier_spans: Vec::new(),
            no_in: false,
            generator_depth: 0,
            async_depth: 0,
            module_await: false,
            module: false,
            strict: false,
            function_depth: 0,
            static_block_function_depths: Vec::new(),
            source: source.into(),
            char_to_byte,
        }
    }

    /// Where the current token starts, as a character offset into the source.
    fn token_start(&self) -> usize {
        self.tokens[self.pos].start
    }

    /// Where the token before the current one starts. Only meaningful for a
    /// token that was really consumed: a RegExp or tagged template literal
    /// leaves no token of its own behind.
    fn previous_token_start(&self, back: usize) -> usize {
        self.tokens[self.pos - back].start
    }

    /// The source text from the character offset `start` up to the end of the
    /// last token consumed: the text of the function or class just parsed.
    ///
    /// The end is the tokenizer position before the current token's leading
    /// whitespace and comments (`positions[pos]`), which unlike the previous
    /// token's end is right even when the last thing consumed was a RegExp or
    /// tagged template, which the parser scans outside the token stream.
    fn source_text_from(&self, start: usize) -> SourceText {
        let end = self.positions[self.pos];
        let to_byte = |offset: usize| match &self.char_to_byte {
            Some(offsets) => offsets[offset],
            None => offset,
        };
        SourceText::range(&self.source, to_byte(start), to_byte(end))
    }

    fn rescan_suffix(&mut self) {
        let (tokens, positions) = tokenize_all(&mut self.tokenizer);
        self.tokens.truncate(self.pos);
        self.positions.truncate(self.pos);
        self.tokens.extend(tokens);
        self.positions.extend(positions);
    }

    fn peek(&self) -> &Token {
        &self.tokens[self.pos].token
    }

    fn peek_at(&self, offset: usize) -> &Token {
        let idx = (self.pos + offset).min(self.tokens.len() - 1);
        &self.tokens[idx].token
    }

    fn newline_before(&self) -> bool {
        self.tokens[self.pos].newline_before
    }

    fn current_identifier_escaped(&self) -> bool {
        self.tokens[self.pos].identifier_escaped
    }

    /// Contextual `async` is a terminal symbol in the async-function and
    /// async-arrow productions. Its decoded spelling alone is insufficient:
    /// `\\u0061sync` must not select either production.
    fn require_unescaped_async(&self) -> Result<(), ParseError> {
        if self.current_identifier_escaped() {
            return Err(self.syntax_error("the async keyword cannot contain an escape"));
        }
        Ok(())
    }

    /// `AssignmentProperty : IdentifierReference Initializer_opt` is more
    /// restrictive than an object literal's PropertyName. In particular a
    /// keyword is legal as `{ keyword: target }` but cannot be a shorthand
    /// assignment target. The token retains whether its spelling was escaped
    /// so a decoded reserved word is rejected too.
    fn assignment_property_is_identifier_reference(&self) -> bool {
        match self.peek() {
            Token::Identifier(name) => self.identifier_reference_name_is_valid(name),
            // `let` stays a valid IdentifierReference in sloppy code.
            Token::Keyword(Keyword::Let) => self.identifier_reference_name_is_valid("let"),
            _ => false,
        }
    }

    /// Whether `name` may be an IdentifierReference here (§13.1.1). Besides
    /// the ReservedWords, the strict-mode reserved words and the `yield` /
    /// `await` context rules apply. The keywords the tokenizer keeps as
    /// [`Keyword`] tokens can only arrive here as a property-name string
    /// (`({ true })`) or as an escaped spelling, and are reserved too.
    fn identifier_reference_name_is_valid(&self, name: &str) -> bool {
        if Keyword::from_str(name).is_some_and(|keyword| keyword != Keyword::Let) {
            return false;
        }
        if matches!(
            name,
            "class" | "debugger" | "enum" | "export" | "extends" | "import" | "super" | "with"
        ) {
            return false;
        }
        if name == "yield" && (self.generator_depth != 0 || self.strict) {
            return false;
        }
        // Module code reserves `await` at every depth, nested plain functions
        // included (§13.1.1: the goal symbol is Module).
        if name == "await"
            && (self.async_depth != 0
                || self.module_await
                || self.module
                || self.static_block_function_depths.last() == Some(&self.function_depth))
        {
            return false;
        }
        !(self.strict && is_strict_reserved_word(name))
    }

    fn at_eof(&self) -> bool {
        matches!(self.peek(), Token::Eof)
    }

    fn advance(&mut self) -> Token {
        self.check_edition_token();
        let t = self.tokens[self.pos].token.clone();
        if self.pos + 1 < self.tokens.len() {
            self.pos += 1;
        }
        t
    }

    fn check_punct(&self, p: Punct) -> bool {
        matches!(self.peek(), Token::Punct(pp) if *pp == p)
    }

    fn check_punct_at(&self, offset: usize, p: Punct) -> bool {
        matches!(self.peek_at(offset), Token::Punct(pp) if *pp == p)
    }

    fn check_keyword(&self, k: Keyword) -> bool {
        matches!(self.peek(), Token::Keyword(kk) if *kk == k)
    }

    fn check_identifier(&self, expected: &str) -> bool {
        matches!(self.peek(), Token::Identifier(name) if name == expected)
    }

    fn check_identifier_at(&self, offset: usize, expected: &str) -> bool {
        matches!(self.peek_at(offset), Token::Identifier(name) if name == expected)
    }

    /// Consumes a contextual keyword (`as`, `from`, `with`, ...). It is a
    /// terminal symbol of its production, so a spelling containing a Unicode
    /// escape cannot stand in for it: that is a SyntaxError, except when a
    /// preceding line terminator lets ASI end the statement first (the escaped
    /// word then starts the next statement as an ordinary identifier).
    fn eat_contextual_keyword(&mut self, expected: &str) -> Result<bool, ParseError> {
        if !self.check_identifier(expected) {
            return Ok(false);
        }
        if self.current_identifier_escaped() {
            if self.newline_before() {
                return Ok(false);
            }
            return Err(
                self.syntax_error(format!("the {expected} keyword cannot contain an escape"))
            );
        }
        self.advance();
        Ok(true)
    }

    fn eat_punct(&mut self, p: Punct) -> bool {
        if self.check_punct(p) {
            self.advance();
            true
        } else {
            false
        }
    }

    fn eat_keyword(&mut self, k: Keyword) -> bool {
        if self.check_keyword(k) {
            self.advance();
            true
        } else {
            false
        }
    }

    fn expect_punct(&mut self, p: Punct) -> Result<(), ParseError> {
        if self.eat_punct(p) {
            Ok(())
        } else {
            Err(self.error(format!("expected {p:?}")))
        }
    }

    fn expect_keyword(&mut self, k: Keyword) -> Result<(), ParseError> {
        if self.eat_keyword(k) {
            Ok(())
        } else {
            Err(self.error(format!("expected keyword {k:?}")))
        }
    }

    /// A token the grammar cannot accept at this point. The tokenizer now
    /// emits `Token::Invalid` only for malformed lexical input; grammar
    /// productions with an unsupported valid form mark that error explicitly.
    fn error(&self, message: impl Into<String>) -> ParseError {
        ParseError {
            message: format!("{} (found {:?})", message.into(), self.peek()),
            resource: None,
            known_syntax: true,
        }
    }

    /// Legacy octal and non-octal decimal escapes are Annex B extensions.
    /// The tokenizer records their use because the surrounding syntactic goal
    /// determines whether they are permitted.
    fn reject_legacy_octal_escape(&self) -> Result<(), ParseError> {
        if self.strict && self.tokens[self.pos].legacy_octal_escape {
            return Err(self.syntax_error(
                "legacy octal and non-octal decimal literals and escapes are not valid in strict mode",
            ));
        }
        Ok(())
    }

    /// Parses one statement of a body that begins with a Directive
    /// Prologue, turning strict mode on at a Use Strict Directive. Only an
    /// unparenthesized string-literal statement spelled exactly `use strict`
    /// (no escape, no line continuation) is that directive.
    ///
    /// The compiler recognizes a directive by the cooked value of the leading
    /// string statements alone. A `use strict`-valued statement that is not
    /// a directive (`('use strict')`, `'use\u0020strict'`) is therefore kept
    /// in the AST wrapped in an `Expr::Parenthesized`, which evaluates the
    /// same but is no longer a bare string statement.
    fn parse_prologue_statement(
        &mut self,
        prologue: &mut DirectivePrologue,
    ) -> Result<Stmt, ParseError> {
        let start = self.pos;
        let statement = unlabel_function_declaration(self.parse_statement()?);
        if !prologue.open {
            return Ok(statement);
        }
        let token = &self.tokens[start];
        let is_directive = matches!(&statement, Stmt::Expr(Expr::String(_)))
            && matches!(token.token, Token::String(_));
        if !is_directive {
            prologue.open = false;
        } else {
            prologue.legacy_octal |= token.legacy_octal_escape;
        }
        let value = match statement {
            Stmt::Expr(Expr::String(value)) => value,
            other => return Ok(other),
        };
        if value != "use strict" {
            return Ok(Stmt::Expr(Expr::String(value)));
        }
        if !is_directive || token.string_escaped {
            return Ok(Stmt::Expr(Expr::Parenthesized(Box::new(Expr::String(
                value,
            )))));
        }
        if prologue.legacy_octal {
            return Err(ParseError {
                message: "legacy octal and non-octal decimal escapes cannot precede a \
                          Use Strict Directive"
                    .to_string(),
                resource: None,
                known_syntax: true,
            });
        }
        self.strict = true;
        Ok(Stmt::Expr(Expr::String(value)))
    }

    /// `{ FunctionBody }` of a function, method, accessor or arrow: a
    /// statement list with its own Directive Prologue, whose strictness ends
    /// with the body.
    pub(super) fn parse_function_body(&mut self) -> Result<Vec<Stmt>, ParseError> {
        self.with_in_allowed(Self::parse_function_body_in)
    }

    fn parse_function_body_in(&mut self) -> Result<Vec<Stmt>, ParseError> {
        self.expect_punct(Punct::LBrace)?;
        let outer_strict = self.strict;
        let mut prologue = DirectivePrologue::default();
        let mut statements = Vec::new();
        let result = loop {
            if self.check_punct(Punct::RBrace) {
                break self.expect_punct(Punct::RBrace);
            }
            if self.at_eof() {
                break Err(self.error("unterminated block, expected '}'"));
            }
            match self.parse_prologue_statement(&mut prologue) {
                Ok(statement) => statements.push(statement),
                Err(error) => break Err(error),
            }
        };
        self.strict = outer_strict;
        result.map(|()| statements)
    }

    /// Runs `parse` with the `in` operator enabled again. A `for` head parses
    /// its init with `in` disabled only at its own top level (`[~In]`);
    /// parentheses, brackets, argument lists, object literals and function
    /// bodies nested inside it restore `[+In]`.
    fn with_in_allowed<T>(
        &mut self,
        parse: impl FnOnce(&mut Self) -> Result<T, ParseError>,
    ) -> Result<T, ParseError> {
        let saved_no_in = std::mem::replace(&mut self.no_in, false);
        let result = parse(self);
        self.no_in = saved_no_in;
        result
    }

    fn syntax_error(&self, message: impl Into<String>) -> ParseError {
        ParseError {
            message: format!("{} (found {:?})", message.into(), self.peek()),
            resource: None,
            known_syntax: true,
        }
    }

    fn expect_identifier_name(&mut self) -> Result<String, ParseError> {
        match self.peek().clone() {
            Token::Identifier(name) => {
                self.advance();
                Ok(name)
            }
            Token::Keyword(k) => {
                self.advance();
                Ok(keyword_as_str(k).to_string())
            }
            _ => Err(self.error("expected an identifier")),
        }
    }

    fn expect_member_name(&mut self) -> Result<String, ParseError> {
        if let Token::PrivateIdentifier(name) = self.peek().clone() {
            self.advance();
            return Ok(format!("#{name}"));
        }
        self.expect_identifier_name()
    }

    fn expect_binding_identifier(&mut self) -> Result<String, ParseError> {
        match self.peek().clone() {
            Token::Identifier(name) => {
                self.advance();
                Ok(name)
            }
            _ => Err(self.syntax_error("expected a binding identifier")),
        }
    }

    fn expect_module_name(&mut self) -> Result<String, ParseError> {
        self.reject_legacy_octal_escape()?;
        match self.advance() {
            Token::String(name) => name
                .to_utf8()
                .map_err(|_| self.syntax_error("module specifier must be well-formed Unicode")),
            _ => Err(self.syntax_error("expected a module specifier string")),
        }
    }

    fn expect_module_export_name(&mut self) -> Result<String, ParseError> {
        self.reject_legacy_octal_escape()?;
        match self.peek().clone() {
            Token::String(name) => {
                self.advance();
                name.to_utf8().map_err(|_| {
                    self.syntax_error("module export name must be well-formed Unicode")
                })
            }
            _ => self.expect_identifier_name(),
        }
    }

    /// `of` written without an escape: the contextual keyword cannot be spelled
    /// `o\u0066`.
    fn is_contextual_of(&self) -> bool {
        matches!(self.peek(), Token::Identifier(name) if name == "of")
            && !self.current_identifier_escaped()
    }
}

fn class_element_name(key: &PropertyKey) -> String {
    match key {
        PropertyKey::Identifier(name) => name.clone(),
        PropertyKey::String(name) => name.to_utf8().unwrap_or_default(),
        PropertyKey::Number(number) => number.to_string(),
        PropertyKey::Computed(_) => String::new(),
    }
}

impl Parser {
    /// Parses a template placeholder's source text. It is a fresh parser over
    /// just that text, but it inherits the enclosing function's context so
    /// that `yield`, `await` and strict-only restrictions mean inside the
    /// placeholder what they mean around the template.
    fn parse_template_placeholder(&self, source: &str) -> Result<Expr, ParseError> {
        let mut parser = Parser::new(source);
        parser.edition = self.edition;
        parser.generator_depth = self.generator_depth;
        parser.async_depth = self.async_depth;
        parser.module_await = self.module_await;
        parser.strict = self.strict;
        let expr = parser.parse_expression()?;
        if !parser.at_eof() {
            return Err(parser.error("unexpected trailing tokens after expression"));
        }
        parser.validate_edition()?;
        editions::validate_expression(
            &expr,
            self.edition,
            self.function_depth != 0 || self.async_depth != 0 || self.generator_depth != 0,
        )?;
        Ok(expr)
    }

    fn parse_template(
        &self,
        quasis: Vec<crate::JsString>,
        raw_expressions: Vec<String>,
    ) -> Result<Expr, ParseError> {
        let expressions = raw_expressions
            .iter()
            .map(|src| self.parse_template_placeholder(src))
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Expr::Template {
            quasis,
            expressions,
        })
    }
}

#[cfg(test)]
mod unit_tests {
    use super::*;

    #[test]
    fn source_text_ranges_are_limited_to_u32_offsets() {
        let source: std::sync::Arc<str> = "ab".into();
        let build = || SourceText::range(&source, 0, 1);
        let built = build();
        assert_eq!(source_text_within(0, build), built);
        assert_eq!(source_text_within(u32::MAX as usize, build), built);
        // Too long a source keeps no range at all.
        assert_eq!(
            source_text_within(u32::MAX as usize + 1, build),
            SourceText::default()
        );
    }

    #[test]
    fn only_expression_statements_are_parenthesized() {
        assert_eq!(
            parenthesize_expression_statement(Stmt::Expr(Expr::Null)),
            Stmt::Expr(Expr::Parenthesized(Box::new(Expr::Null)))
        );
        assert_eq!(parenthesize_expression_statement(Stmt::Empty), Stmt::Empty);
    }
}
