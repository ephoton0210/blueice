// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! The Immutable ArrayBuffer proposal
//! (tc39/proposal-immutable-arraybuffer, Test262 feature
//! `immutable-arraybuffer`): the `ArrayBuffer.prototype` API that creates and
//! observes an immutable buffer, plus the write-path guards shared by
//! TypedArray, DataView, Atomics and `Uint8Array.prototype.setFrom*`.
//!
//! The `[[ArrayBufferIsImmutable]]` slot itself lives on the heap's ArrayBuffer
//! record (`Heap::alloc_immutable_array_buffer`); everything here is the
//! VM-side observable behaviour keyed off `Heap::buffer_is_immutable`.

use super::*;

impl Vm {
    /// CreateBytesModule's value (import-bytes proposal): `Construct(
    /// %Uint8Array%, « AllocateImmutableArrayBuffer(%ArrayBuffer%, bytes) »)`,
    /// a length-fixed `Uint8Array` viewing the whole immutable buffer.
    pub(in super::super) fn create_bytes_module_value(
        &mut self,
        bytes: Vec<u8>,
    ) -> Result<Value, RuntimeError> {
        if bytes.len() > self.heap.max_array_buffer_byte_length() {
            return Err(RuntimeError::RangeError(
                "immutable ArrayBuffer length is too large".into(),
            ));
        }
        let length = bytes.len();
        let buffer_prototype = self.buffer_prototype("ArrayBuffer")?;
        let view_prototype = self.buffer_prototype("Uint8Array")?;
        let buffer = self
            .with_roots(|heap| heap.alloc_immutable_array_buffer(bytes, Some(buffer_prototype)))?;
        // The buffer is only in this Rust local until the view holds it; the
        // operand stack keeps it alive across the view's allocation.
        let base = self.stack.len();
        self.stack.push(Value::Object(buffer));
        let view = self.with_roots(|heap| {
            heap.alloc_typed_array(
                buffer,
                0,
                length,
                false,
                TypedArrayKind::Uint8,
                Some(view_prototype),
            )
        });
        self.stack.truncate(base);
        Ok(Value::Object(view?))
    }

    /// `get ArrayBuffer.prototype.immutable`.
    pub(super) fn array_buffer_immutable(&self, receiver: &Value) -> Result<Value, RuntimeError> {
        // RequireInternalSlot([[ArrayBufferData]]) plus the SharedArrayBuffer
        // rejection is exactly the ordinary ArrayBuffer receiver check.
        let buffer = self.array_buffer_receiver(receiver)?;
        Ok(Value::Bool(self.heap.buffer_is_immutable(buffer).expect(
            "the receiver was checked to be a live ArrayBuffer",
        )))
    }

    /// Steps 1-7 of ArrayBufferCopyAndDetach, shared by `transfer`,
    /// `transferToFixedLength` and `transferToImmutable`: the receiver check,
    /// then `ToIndex(newLength)` (which may run user code and so detach or
    /// resize the source), and only afterwards the detached/immutable
    /// rejections. Returns the source, its byte length as of *after* the
    /// coercion, and the requested new byte length.
    pub(super) fn array_buffer_copy_and_detach_source(
        &mut self,
        receiver: &Value,
        args: &[Value],
    ) -> Result<(ObjectId, usize, usize), RuntimeError> {
        let source = self.array_buffer_receiver(receiver)?;
        let new_length = if args.is_empty() || args[0] == Value::Undefined {
            None
        } else {
            Some(self.buffer_index(&args[0])?)
        };
        // `source` is a live ArrayBuffer, so the heap queries below cannot fail.
        if self
            .heap
            .buffer_is_detached(source)
            .expect("the receiver was checked to be a live ArrayBuffer")
        {
            return Err(RuntimeError::TypeError("ArrayBuffer is detached".into()));
        }
        if self
            .heap
            .buffer_is_immutable(source)
            .expect("the receiver was checked to be a live ArrayBuffer")
        {
            return Err(RuntimeError::TypeError(
                "ArrayBuffer is immutable and cannot be detached".into(),
            ));
        }
        let source_length = self
            .heap
            .buffer_byte_length(source)
            .expect("the receiver was checked to be a live ArrayBuffer");
        Ok((source, source_length, new_length.unwrap_or(source_length)))
    }

    /// `ArrayBuffer.prototype.transferToImmutable ( [ newLength ] )`.
    /// Like `transfer`, it never observes `constructor` or species: the
    /// result is always an intrinsic %ArrayBuffer%, zero-extended when
    /// `newLength` exceeds the source, and the source is detached only after
    /// every fallible step succeeded.
    pub(super) fn array_buffer_transfer_to_immutable(
        &mut self,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let (source, source_length, length) =
            self.array_buffer_copy_and_detach_source(receiver, args)?;
        if length > self.heap.max_array_buffer_byte_length() {
            return Err(RuntimeError::RangeError(
                "immutable ArrayBuffer length is too large".into(),
            ));
        }
        let mut bytes = self
            .heap
            .array_buffer_copy(source, 0, source_length.min(length))
            .expect("the copied range lies within the source");
        bytes.resize(length, 0);
        // A live ArrayBuffer receiver means %ArrayBuffer.prototype% exists.
        let prototype = self
            .buffer_prototype("ArrayBuffer")
            .expect("the ArrayBuffer intrinsics exist");
        let target =
            self.with_roots(|heap| heap.alloc_immutable_array_buffer(bytes, Some(prototype)))?;
        self.heap
            .detach_array_buffer(source)
            .expect("an attached, mutable ArrayBuffer can be detached");
        Ok(Value::Object(target))
    }

    /// `ArrayBuffer.prototype.sliceToImmutable ( start, end )`. Bounds are
    /// resolved against the length at entry (ResolveBounds may run user code
    /// that resizes the source); the copy is then checked against the length
    /// *after* that code ran.
    pub(super) fn array_buffer_slice_to_immutable(
        &mut self,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let buffer = self.array_buffer_receiver(receiver)?;
        // `buffer` is a live ArrayBuffer, so the heap queries below cannot
        // fail (a detached one is rejected before it is measured).
        if self
            .heap
            .buffer_is_detached(buffer)
            .expect("the receiver was checked to be a live ArrayBuffer")
        {
            return Err(RuntimeError::TypeError("ArrayBuffer is detached".into()));
        }
        let length = self
            .heap
            .array_buffer_byte_length(buffer)
            .expect("an attached ArrayBuffer has a length");
        let first = self.relative_buffer_index(native::argument(args, 0), length)?;
        let last = if args.get(1).is_some_and(|value| *value != Value::Undefined) {
            self.relative_buffer_index(native::argument(args, 1), length)?
        } else {
            length
        };
        let new_length = last.saturating_sub(first);
        // Bounds resolution may have detached or resized the source.
        if self
            .heap
            .buffer_is_detached(buffer)
            .expect("the receiver was checked to be a live ArrayBuffer")
        {
            return Err(RuntimeError::TypeError("ArrayBuffer is detached".into()));
        }
        if self
            .heap
            .array_buffer_byte_length(buffer)
            .expect("an attached ArrayBuffer has a length")
            < last
        {
            return Err(RuntimeError::RangeError(
                "ArrayBuffer shrank below the requested slice".into(),
            ));
        }
        let bytes = self
            .heap
            .array_buffer_copy(buffer, first, new_length)
            .expect("the slice lies within the buffer");
        let prototype = self
            .buffer_prototype("ArrayBuffer")
            .expect("the ArrayBuffer intrinsics exist");
        let result =
            self.with_roots(|heap| heap.alloc_immutable_array_buffer(bytes, Some(prototype)))?;
        Ok(Value::Object(result))
    }

    /// The `~write~` half of ValidateTypedArray's brand check: throws a
    /// TypeError when `receiver` is a TypedArray backed by an immutable
    /// buffer. Anything that is not a TypedArray passes through untouched so
    /// the caller's own receiver validation reports it.
    pub(super) fn reject_immutable_typed_array(
        &self,
        receiver: &Value,
    ) -> Result<(), RuntimeError> {
        let Some(object) = receiver.object_id() else {
            return Ok(());
        };
        if self
            .heap
            .is_typed_array(object)
            .expect("a receiver object is live")
            && self
                .heap
                .typed_array_is_immutable(object)
                .expect("a TypedArray has a buffer")
        {
            return Err(RuntimeError::TypeError(
                "TypedArray is backed by an immutable ArrayBuffer".into(),
            ));
        }
        Ok(())
    }
}
