// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! BlueJS tokenizer: a `&str` -> [`Token`] stream, scoped to exactly
//! `phase-2-mvp-scope/PLAN.md`'s "MVP JS scope (decided)" -- not the
//! full ECMAScript lexical grammar. The edition 17 implementation track
//! now extends that original subset: Number/BigInt radix literals and
//! separators, ECMAScript whitespace/line terminators, string
//! continuations, and Annex B legacy octal escapes are implemented. Regex
//! literals, `**`, and tagged templates remain to be implemented.
//! [`Keyword`] mirrors this: `undefined` is deliberately NOT a keyword
//! here (unlike `null`/`true`/`false`) because it isn't one in real
//! ECMAScript either -- it's an ordinary identifier bound to a global
//! property, so it tokenizes as [`Token::Identifier`] and the parser/
//! interpreter, not the lexer, is where it becomes meaningful.
//!
//! Source characters use Rust `char`; cooked literals use UTF-16 code
//! units so Unicode escapes can preserve lone surrogates losslessly. The
//! input is *lexer text* (see [`crate::source_encoding`]): an unpaired
//! surrogate in the source arrives as one reserved private-use character
//! and is turned back into its code unit wherever the source becomes a
//! JavaScript value (string and template literals, RegExp patterns).

use crate::JsString;
use icu_properties::{props, CodePointSetData};
use num_bigint::BigInt;

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    Number(f64),
    BigInt(BigInt),
    /// A plain (non-template) string literal, already "cooked" --
    /// escape sequences resolved to the characters they represent.
    String(JsString),
    /// A template literal (`` `...` ``). `quasis.len() ==
    /// raw_expressions.len() + 1` always holds, the same invariant
    /// real engines' `TemplateStringsArray` relies on: quasis are the
    /// cooked string pieces between `${`/`}` boundaries, and
    /// `raw_expressions` is each placeholder's *unparsed source text*
    /// (not a token stream) -- see this module's doc comment on
    /// [`Tokenizer::scan_template`] for why re-lexing/re-parsing that
    /// text later, rather than recursively tokenizing it inline here,
    /// is this crate's chosen way to handle template nesting without a
    /// stateful lexer-mode stack.
    Template {
        quasis: Vec<JsString>,
        raw_expressions: Vec<String>,
    },
    Identifier(String),
    /// A `#`-prefixed identifier. It is admitted only by class-element and
    /// private-member parser productions.
    PrivateIdentifier(String),
    Keyword(Keyword),
    Punct(Punct),
    Invalid(String),
    Eof,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Keyword {
    Var,
    Let,
    Const,
    Function,
    Return,
    If,
    Else,
    For,
    While,
    Do,
    Switch,
    Case,
    Default,
    Break,
    Continue,
    Throw,
    Try,
    Catch,
    Finally,
    New,
    Typeof,
    Void,
    Delete,
    Instanceof,
    In,
    True,
    False,
    Null,
    This,
}

impl Keyword {
    pub(crate) fn from_str(s: &str) -> Option<Keyword> {
        Some(match s {
            "var" => Keyword::Var,
            "let" => Keyword::Let,
            "const" => Keyword::Const,
            "function" => Keyword::Function,
            "return" => Keyword::Return,
            "if" => Keyword::If,
            "else" => Keyword::Else,
            "for" => Keyword::For,
            "while" => Keyword::While,
            "do" => Keyword::Do,
            "switch" => Keyword::Switch,
            "case" => Keyword::Case,
            "default" => Keyword::Default,
            "break" => Keyword::Break,
            "continue" => Keyword::Continue,
            "throw" => Keyword::Throw,
            "try" => Keyword::Try,
            "catch" => Keyword::Catch,
            "finally" => Keyword::Finally,
            "new" => Keyword::New,
            "typeof" => Keyword::Typeof,
            "void" => Keyword::Void,
            "delete" => Keyword::Delete,
            "instanceof" => Keyword::Instanceof,
            "in" => Keyword::In,
            "true" => Keyword::True,
            "false" => Keyword::False,
            "null" => Keyword::Null,
            "this" => Keyword::This,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Punct {
    LParen,
    RParen,
    LBrace,
    RBrace,
    LBracket,
    RBracket,
    Semicolon,
    Comma,
    Colon,
    Dot,
    Ellipsis,
    Arrow,
    Plus,
    Minus,
    Star,
    StarStar,
    StarStarAssign,
    Slash,
    Percent,
    PlusPlus,
    MinusMinus,
    Assign,
    PlusAssign,
    MinusAssign,
    StarAssign,
    SlashAssign,
    PercentAssign,
    ShiftLeftAssign,
    ShiftRightAssign,
    UnsignedShiftRightAssign,
    AndAssign,
    XorAssign,
    OrAssign,
    EqEq,
    NotEq,
    EqEqEq,
    NotEqEq,
    Lt,
    Gt,
    LtEq,
    GtEq,
    ShiftLeft,
    ShiftRight,
    UnsignedShiftRight,
    And,
    Xor,
    Or,
    AndAnd,
    AndAndAssign,
    OrOr,
    OrOrAssign,
    Bang,
    Tilde,
    Question,
    QuestionQuestion,
    QuestionQuestionAssign,
    QuestionDot,
    /// `@`, which only ever begins a decorator.
    At,
}

/// One lexical error -- a plain message rather than a structured enum,
/// matching this codebase's precedent of not over-engineering error
/// types for a from-scratch MVP subsystem (see e.g. `blueice-html`'s
/// own error handling, which mostly just recovers instead of erroring
/// at all). Unlike HTML/CSS's "never fail the whole parse" philosophy,
/// JS syntax errors are real spec-mandated failures with no defined
/// recovery, so this crate surfaces them as `Err` rather than silently
/// skipping malformed input.
#[derive(Debug, Clone, PartialEq)]
pub struct LexError {
    pub message: String,
    pub known_syntax: bool,
}

impl LexError {
    fn new(message: impl Into<String>) -> LexError {
        LexError {
            message: message.into(),
            known_syntax: false,
        }
    }

    fn syntax(message: impl Into<String>) -> LexError {
        LexError {
            message: message.into(),
            known_syntax: true,
        }
    }
}

/// One token plus whether a line terminator appeared anywhere in the
/// whitespace/comments immediately before it -- the one piece of
/// lexical information ECMAScript's automatic-semicolon-insertion
/// rules need from the lexer (see `research/js-bytecode-eventloop.md`'s
/// neighboring engines-agree-on-shape precedent; ASI itself isn't
/// covered there, but real engines universally thread this same bit
/// from lexer to parser rather than having the parser re-scan
/// whitespace itself).
#[derive(Debug, Clone, PartialEq)]
pub struct SpannedToken {
    pub token: Token,
    /// Where the token's first character sits, as a character offset from the
    /// start of the source (after the whitespace and comments before it). The
    /// token ends where the tokenizer's [`Tokenizer::position`] is once it has
    /// been scanned; a function's source text (its `[[SourceText]]`) is the
    /// range from the start of its first token to the end of its last.
    pub start: usize,
    pub newline_before: bool,
    /// Whether this IdentifierName used a Unicode escape.  Contextual
    /// keywords such as `await` cannot be escaped when the grammar requires
    /// the keyword spelling, so the parser must retain this lexical fact.
    pub identifier_escaped: bool,
    /// Whether this token's string literal used a legacy decimal or octal
    /// escape. These escapes are accepted only by non-strict script code;
    /// retain the lexical fact so the parser can enforce that early error.
    pub legacy_octal_escape: bool,
    /// Whether this token's string literal contained any escape sequence or
    /// line continuation. A Use Strict Directive must be spelled exactly
    /// `"use strict"` or `'use strict'`, so an escaped spelling never counts.
    pub string_escaped: bool,
}

pub(crate) type TaggedTemplateData = (Vec<JsString>, Vec<Option<JsString>>, Vec<String>);

pub struct Tokenizer {
    input: Vec<char>,
    pos: usize,
    /// Annex B HTML close comments are recognized only at the start of a
    /// physical line (after whitespace).  Keep that lexical state here so
    /// trivia does not need to rescan prior source text.
    line_start: bool,
    identifier_escaped: bool,
    legacy_octal_escape: bool,
    string_escaped: bool,
    html_comments_enabled: bool,
}

pub(crate) fn is_ident_start(c: char) -> bool {
    matches!(c, '_' | '$') || CodePointSetData::new::<props::IdStart>().contains(c)
}

pub(crate) fn is_ident_continue(c: char) -> bool {
    matches!(c, '_' | '$' | '\u{200c}' | '\u{200d}')
        || CodePointSetData::new::<props::IdContinue>().contains(c)
}

fn is_line_terminator(c: char) -> bool {
    matches!(c, '\n' | '\r' | '\u{2028}' | '\u{2029}')
}

impl Tokenizer {
    pub(crate) fn position(&self) -> usize {
        self.pos
    }

    pub(crate) fn at_template(&mut self, position: usize) -> bool {
        self.pos = position;
        self.skip_trivia().is_ok() && self.peek() == Some('`')
    }

    pub(crate) fn regexp_at(&mut self, position: usize) -> Result<(JsString, JsString), LexError> {
        self.pos = position;
        self.skip_trivia()?;
        self.advance();
        let mut pattern = JsString::default();
        let mut class = false;
        loop {
            let c = self
                .advance()
                .ok_or_else(|| LexError::syntax("unterminated RegExp literal"))?;
            if is_line_terminator(c) {
                return Err(LexError::syntax("line terminator in RegExp literal"));
            }
            if c == '/' && !class {
                break;
            }
            pattern.push_code_point(self.source_code_point(c));
            if c == '\\' {
                let escaped = self
                    .advance()
                    .ok_or_else(|| LexError::syntax("unterminated RegExp escape"))?;
                if is_line_terminator(escaped) {
                    return Err(LexError::syntax("line terminator in RegExp escape"));
                }
                pattern.push_code_point(self.source_code_point(escaped));
            } else if c == '[' {
                class = true;
            } else if c == ']' {
                class = false;
            }
        }
        let mut flags = JsString::default();
        while self.peek().is_some_and(is_ident_continue) {
            flags.push_code_point(self.advance().unwrap() as u32);
        }
        Ok((pattern, flags))
    }

    pub(crate) fn tagged_template_at(
        &mut self,
        position: usize,
    ) -> Result<TaggedTemplateData, LexError> {
        self.pos = position;
        self.skip_trivia()?;
        self.advance();
        let mut raw = Vec::new();
        let mut current = String::new();
        let mut expressions = Vec::new();
        loop {
            let c = self
                .advance()
                .ok_or_else(|| LexError::new("unterminated tagged template"))?;
            if c == '`' {
                raw.push(current);
                break;
            }
            if c == '$' && self.peek() == Some('{') {
                self.advance();
                raw.push(std::mem::take(&mut current));
                expressions.push(self.scan_raw_until_matching_brace()?);
            } else if c == '\\' {
                current.push(c);
                let c = self
                    .advance()
                    .ok_or_else(|| LexError::new("unterminated tagged template escape"))?;
                if c == '\r' {
                    // The consumed CR already marked a line start.
                    self.pos += usize::from(self.peek() == Some('\n'));
                    current.push('\n');
                } else {
                    current.push(c);
                }
            } else if c == '\r' {
                self.pos += usize::from(self.peek() == Some('\n'));
                current.push('\n');
            } else {
                current.push(c);
            }
        }
        let cooked = raw
            .iter()
            .map(|raw| {
                let mut lexer = Tokenizer::new(raw);
                let mut result = JsString::default();
                while let Some(c) = lexer.advance() {
                    if c == '\\' {
                        match lexer.scan_escape() {
                            // Legacy octal and `\8`/`\9` escapes are
                            // NotEscapeSequences in a template: the cooked
                            // value of that string is undefined.
                            Ok(Some(_)) if lexer.legacy_octal_escape => return None,
                            Ok(Some(c)) => result.push_code_point(c),
                            Ok(None) => {}
                            Err(_) => return None,
                        }
                    } else {
                        result.push_code_point(lexer.source_code_point(c));
                    }
                }
                Some(result)
            })
            .collect();
        Ok((
            raw.iter()
                .map(|raw| crate::source_encoding::decode(raw))
                .collect(),
            cooked,
            expressions,
        ))
    }

    /// The code point the source character `c` (just consumed) stands for in
    /// a literal's value. Ordinary characters stand for themselves; the
    /// lexer-text encoding of an unpaired surrogate stands for that code
    /// unit, and its escape character makes the character after it literal
    /// (consumed here too).
    #[inline]
    fn source_code_point(&mut self, c: char) -> u32 {
        if (c as u32) < crate::source_encoding::RESERVED_START {
            return c as u32;
        }
        if c == crate::source_encoding::ESCAPE {
            return self.advance().map_or(c as u32, |next| next as u32);
        }
        crate::source_encoding::lone_surrogate(c).map_or(c as u32, u32::from)
    }

    /// `input` is lexer text: see [`crate::source_encoding`].
    pub fn new(input: &str) -> Tokenizer {
        Tokenizer {
            input: input.chars().collect(),
            pos: 0,
            line_start: true,
            identifier_escaped: false,
            legacy_octal_escape: false,
            string_escaped: false,
            html_comments_enabled: true,
        }
    }

    /// Modules exclude Annex B's HTML-like comment extensions.
    pub fn new_module(input: &str) -> Tokenizer {
        Tokenizer {
            html_comments_enabled: false,
            ..Self::new(input)
        }
    }

    /// Consumes a Hashbang comment (`#!` through the end of the line, not
    /// including the line terminator) when it is the first thing in the
    /// source text. Callers apply this only to complete Script or Module
    /// text; the line terminator that ends it is ordinary trivia.
    pub(crate) fn skip_hashbang(&mut self) {
        if self.pos == 0 && self.peek() == Some('#') && self.peek_at(1) == Some('!') {
            while self.peek().is_some_and(|c| !is_line_terminator(c)) {
                self.advance();
            }
        }
    }

    fn peek(&self) -> Option<char> {
        self.input.get(self.pos).copied()
    }

    fn peek_at(&self, offset: usize) -> Option<char> {
        self.input.get(self.pos + offset).copied()
    }

    fn advance(&mut self) -> Option<char> {
        let c = self.peek();
        if let Some(c) = c {
            self.pos += 1;
            if is_line_terminator(c) {
                self.line_start = true;
            } else if !crate::primitive::whitespace(c) {
                self.line_start = false;
            }
        }
        c
    }

    /// Skips whitespace and comments, reporting whether a line
    /// terminator was seen anywhere along the way (for ASI, see
    /// [`SpannedToken`]).
    fn skip_trivia(&mut self) -> Result<bool, LexError> {
        let mut saw_newline = false;
        // Annex B permits a legacy HTML close comment after leading trivia,
        // and directly after a block comment even when a token preceded that
        // comment on the same line.
        let mut html_close_allowed = self.line_start;
        loop {
            match self.peek() {
                Some(c) if is_line_terminator(c) => {
                    saw_newline = true;
                    self.advance();
                    html_close_allowed = true;
                }
                Some(c) if crate::primitive::whitespace(c) => {
                    self.advance();
                }
                // Annex B's legacy HTML comments are lexical comments in
                // Script code. `<!--` has no line-start restriction, while
                // `-->` is recognized only after a line terminator and any
                // following whitespace/comments.
                Some('<')
                    if self.peek_at(1) == Some('!')
                        && self.peek_at(2) == Some('-')
                        && self.peek_at(3) == Some('-') =>
                {
                    if !self.html_comments_enabled {
                        return Err(LexError::syntax(
                            "HTML-like comments are not allowed in module code",
                        ));
                    }
                    for _ in 0..4 {
                        self.advance();
                    }
                    while let Some(c) = self.peek() {
                        if is_line_terminator(c) {
                            break;
                        }
                        self.advance();
                    }
                }
                Some('-')
                    if html_close_allowed
                        && self.peek_at(1) == Some('-')
                        && self.peek_at(2) == Some('>') =>
                {
                    if !self.html_comments_enabled {
                        return Err(LexError::syntax(
                            "HTML-like comments are not allowed in module code",
                        ));
                    }
                    for _ in 0..3 {
                        self.advance();
                    }
                    while let Some(c) = self.peek() {
                        if is_line_terminator(c) {
                            break;
                        }
                        self.advance();
                    }
                }
                Some('/') if self.peek_at(1) == Some('/') => {
                    while let Some(c) = self.peek() {
                        if is_line_terminator(c) {
                            break;
                        }
                        self.advance();
                    }
                    html_close_allowed = true;
                }
                Some('/') if self.peek_at(1) == Some('*') => {
                    self.advance();
                    self.advance();
                    loop {
                        match self.peek() {
                            None => return Err(LexError::new("unterminated block comment")),
                            Some(c) if is_line_terminator(c) => {
                                saw_newline = true;
                                self.advance();
                            }
                            Some('*') if self.peek_at(1) == Some('/') => {
                                self.advance();
                                self.advance();
                                html_close_allowed = true;
                                break;
                            }
                            Some(_) => {
                                self.advance();
                            }
                        }
                    }
                }
                _ => break,
            }
        }
        Ok(saw_newline)
    }

    pub fn next_spanned(&mut self) -> Result<SpannedToken, LexError> {
        let newline_before = self.skip_trivia()?;
        self.identifier_escaped = false;
        self.legacy_octal_escape = false;
        self.string_escaped = false;
        let start = self.pos;
        let token = self.next_token()?;
        Ok(SpannedToken {
            token,
            start,
            newline_before,
            identifier_escaped: self.identifier_escaped,
            legacy_octal_escape: self.legacy_octal_escape,
            string_escaped: self.string_escaped,
        })
    }

    fn next_token(&mut self) -> Result<Token, LexError> {
        let c = match self.peek() {
            None => return Ok(Token::Eof),
            Some(c) => c,
        };
        if c.is_ascii_digit() || (c == '.' && self.peek_at(1).is_some_and(|d| d.is_ascii_digit())) {
            return self.scan_number();
        }
        if c == '"' || c == '\'' {
            return self.scan_string(c);
        }
        if c == '`' {
            self.advance();
            return self.scan_template();
        }
        if c == '#' {
            self.advance();
            return self.scan_private_identifier();
        }
        if is_ident_start(c) || (c == '\\' && self.peek_at(1) == Some('u')) {
            return self.scan_identifier_or_keyword();
        }
        self.scan_punct()
    }

    fn scan_number(&mut self) -> Result<Token, LexError> {
        let leading_zero = self.peek() == Some('0');
        if leading_zero {
            let bits = match self.peek_at(1) {
                Some('b' | 'B') => Some(1),
                Some('o' | 'O') => Some(3),
                Some('x' | 'X') => Some(4),
                _ => None,
            };
            if let Some(bits) = bits {
                self.advance();
                self.advance();
                let digits = self.scan_digits(1 << bits, true)?;
                if digits.is_empty() {
                    return Err(LexError::new("non-decimal literal requires digits"));
                }
                if self.peek() == Some('n') {
                    self.advance();
                    return self.finish_bigint(&digits, 1 << bits);
                }
                return self.finish_number(crate::primitive::radix_number(&digits, bits));
            }
        }
        let mut text = self.scan_digits(10, !leading_zero)?;
        // A LegacyOctalIntegerLiteral (`010`) or NonOctalDecimalIntegerLiteral
        // (`08`, `019`) is an Annex B extension that strict code rejects, so
        // the parser must learn that this token used one.
        if leading_zero && text.len() > 1 {
            self.legacy_octal_escape = true;
        }
        if self.peek() == Some('n') {
            self.advance();
            if leading_zero && text.len() > 1 {
                return Err(LexError::new(
                    "decimal BigInt literal cannot have a leading zero",
                ));
            }
            return self.finish_bigint(&text, 10);
        }
        // Legacy leading-zero octal literals exist in sloppy scripts.
        // Unlike leading-zero decimals containing 8/9, they have no
        // decimal fraction/exponent production (§12.9.3).
        if leading_zero && text.len() > 1 && text.bytes().all(|b| b <= b'7') {
            return self.finish_number(crate::primitive::radix_number(&text, 3));
        }
        if self.peek() == Some('.') {
            self.advance();
            text.push('.');
            text.push_str(&self.scan_digits(10, true)?);
        }
        if matches!(self.peek(), Some('e') | Some('E')) {
            self.advance();
            text.push('e');
            if matches!(self.peek(), Some('+') | Some('-')) {
                text.push(self.advance().unwrap());
            }
            let digits = self.scan_digits(10, true)?;
            if digits.is_empty() {
                return Err(LexError::new("exponent requires digits"));
            }
            text.push_str(&digits);
        }
        // Validated decimal syntax; overflow/underflow become infinity/zero.
        self.finish_number(text.parse().expect("scanner emits valid decimal syntax"))
    }

    fn scan_digits(&mut self, radix: u32, separators: bool) -> Result<String, LexError> {
        let mut digits = String::new();
        loop {
            match self.peek() {
                Some(c) if c.is_digit(radix) => {
                    digits.push(c);
                    self.advance();
                }
                Some('_') => {
                    if !separators
                        || digits.is_empty()
                        || !self.peek_at(1).is_some_and(|c| c.is_digit(radix))
                    {
                        return Err(LexError::new("numeric separator must occur between digits"));
                    }
                    self.advance();
                }
                _ => return Ok(digits),
            }
        }
    }

    fn finish_number(&self, number: f64) -> Result<Token, LexError> {
        if self
            .peek()
            .is_some_and(|c| is_ident_start(c) || c.is_ascii_digit() || c == '\\')
        {
            return Err(LexError::new(
                "identifier or digit immediately after numeric literal",
            ));
        }
        Ok(Token::Number(number))
    }

    fn finish_bigint(&self, digits: &str, radix: u32) -> Result<Token, LexError> {
        if self
            .peek()
            .is_some_and(|c| is_ident_start(c) || c.is_ascii_digit() || c == '\\')
        {
            return Err(LexError::new(
                "identifier or digit immediately after BigInt literal",
            ));
        }
        let value = BigInt::parse_bytes(digits.as_bytes(), radix)
            .expect("scanner validates BigInt literal digits");
        Ok(Token::BigInt(value))
    }

    fn scan_escape(&mut self) -> Result<Option<u32>, LexError> {
        // Caller has already consumed the leading '\\'.
        let c = self
            .advance()
            .ok_or_else(|| LexError::new("unterminated escape sequence"))?;
        Ok(Some(match c {
            'n' => 0x0a,
            't' => 0x09,
            'r' => 0x0d,
            'b' => 0x08,
            'f' => 0x0c,
            'v' => 0x0b,
            // Annex B.1.2's LegacyOctalEscapeSequence. A leading 0 may
            // consume two following octal digits; a leading 1-3 can consume
            // two; and 4-7 can consume one. `\\000`, for example, is one
            // NUL code unit, not `\\0` followed by two literal zeroes.
            '0'..='7' => {
                let first = c.to_digit(8).expect("octal range is valid");
                let mut value = first;
                let mut consumed_extra = 0;
                let limit = if first <= 3 { 2 } else { 1 };
                while consumed_extra < limit {
                    let Some(next) = self.peek().filter(|next| ('0'..='7').contains(next)) else {
                        break;
                    };
                    self.advance();
                    value = value * 8 + next.to_digit(8).expect("octal range is valid");
                    consumed_extra += 1;
                }
                // A bare `\\0` is the ordinary NullEscape. Every other
                // form here is legacy-only and invalid in strict code,
                // including `\\0` directly followed by `8` or `9`.
                self.legacy_octal_escape =
                    first != 0 || consumed_extra != 0 || matches!(self.peek(), Some('8' | '9'));
                value
            }
            // NonOctalDecimalEscapeSequence is likewise prohibited in
            // strict code, while preserving Annex B's sloppy-mode cooking.
            '8' | '9' => {
                self.legacy_octal_escape = true;
                c as u32
            }
            c if is_line_terminator(c) => {
                if c == '\r' && self.peek() == Some('\n') {
                    self.advance();
                }
                return Ok(None); // A whole LineTerminatorSequence contributes nothing.
            }
            '\'' | '"' | '`' | '\\' | '$' => c as u32,
            'x' => {
                let hex: String = (0..2)
                    .map(|_| {
                        self.advance()
                            .ok_or_else(|| LexError::new("unterminated \\x escape"))
                    })
                    .collect::<Result<_, _>>()?;
                Self::hex_escape(&hex, "\\x")?
            }
            'u' => {
                if self.peek() == Some('{') {
                    self.advance();
                    let mut hex = String::new();
                    while self.peek().is_some_and(|c| c != '}') {
                        hex.push(self.advance().unwrap());
                    }
                    self.advance()
                        .ok_or_else(|| LexError::new("unterminated \\u{...} escape"))?;
                    let code = Self::hex_escape(&hex, "\\u{...}")?;
                    if code > 0x10ffff {
                        return Err(LexError::new("invalid \\u{...} escape codepoint"));
                    }
                    code
                } else {
                    let hex: String = (0..4)
                        .map(|_| {
                            self.advance()
                                .ok_or_else(|| LexError::new("unterminated \\u escape"))
                        })
                        .collect::<Result<_, _>>()?;
                    Self::hex_escape(&hex, "\\u")?
                }
            }
            // NonEscapeCharacter, including astral source characters and an
            // unpaired surrogate (one code unit, however it was spelled).
            other => self.source_code_point(other),
        }))
    }

    fn hex_escape(hex: &str, kind: &str) -> Result<u32, LexError> {
        // ECMA-262 (2026) §12.9.4 requires HexDigits, not the optional
        // leading '+' accepted by Rust's from_str_radix.
        let invalid = || {
            LexError::new(format!(
                "invalid {kind} escape '{}'",
                crate::source_encoding::describe(hex)
            ))
        };
        if hex.is_empty() || !hex.bytes().all(|c| c.is_ascii_hexdigit()) {
            return Err(invalid());
        }
        u32::from_str_radix(hex, 16).map_err(|_| invalid())
    }

    fn scan_string(&mut self, quote: char) -> Result<Token, LexError> {
        self.advance(); // opening quote
        let mut out = JsString::default();
        loop {
            match self.peek() {
                None => return Err(LexError::new("unterminated string literal")),
                Some(c) if c == quote => {
                    self.advance();
                    return Ok(Token::String(out));
                }
                Some('\n' | '\r') => {
                    return Err(LexError::new(
                        "unterminated string literal (line terminator)",
                    ))
                }
                Some('\\') => {
                    self.advance();
                    self.string_escaped = true;
                    if let Some(c) = self.scan_escape()? {
                        out.push_code_point(c);
                    }
                }
                Some(c) => {
                    self.advance();
                    out.push_code_point(self.source_code_point(c));
                }
            }
        }
    }

    /// Scans a template literal's body (opening backtick already
    /// consumed). Placeholder expressions (`${...}`) are captured as
    /// raw, unparsed source text rather than recursively tokenized
    /// in-line -- this crate's `Parser` re-tokenizes/re-parses each one
    /// independently as an ordinary expression once template AST
    /// construction needs it (`parser.rs`'s `parse_template`). This
    /// trades a small amount of re-scanning for avoiding a second,
    /// stateful "lexer mode stack" (the technique real engines use to
    /// resume template scanning after a `}` closes a placeholder) --
    /// a deliberate simplicity-over-performance call consistent with
    /// this phase's own "design for later performance, don't build it
    /// now" priority.
    fn scan_template(&mut self) -> Result<Token, LexError> {
        let mut quasis = Vec::new();
        let mut raw_expressions = Vec::new();
        let mut current = JsString::default();
        loop {
            match self.peek() {
                None => return Err(LexError::new("unterminated template literal")),
                Some('`') => {
                    self.advance();
                    quasis.push(current);
                    return Ok(Token::Template {
                        quasis,
                        raw_expressions,
                    });
                }
                Some('$') if self.peek_at(1) == Some('{') => {
                    self.advance();
                    self.advance();
                    quasis.push(std::mem::take(&mut current));
                    raw_expressions.push(self.scan_raw_until_matching_brace()?);
                }
                Some('\\') => {
                    self.advance();
                    if let Some(c) = self.scan_escape()? {
                        current.push_code_point(c);
                    }
                    // A tagged template re-scans its own text and may carry
                    // such an escape (cooked value `undefined`); an untagged
                    // template may not (§13.2.8.1, NotEscapeSequence).
                    if self.legacy_octal_escape {
                        return Err(LexError::syntax(
                            "octal escape sequences are not allowed in template literals",
                        ));
                    }
                }
                Some('\r') => {
                    self.advance();
                    if self.peek() == Some('\n') {
                        self.advance();
                    }
                    current.push_code_point('\n' as u32);
                }
                Some(c) => {
                    self.advance();
                    current.push_code_point(self.source_code_point(c));
                }
            }
        }
    }

    /// Ask the expression parser which closing brace ends this placeholder.
    /// Brace counting cannot distinguish a RegExp body, division, comments,
    /// object literals, or nested templates. Each candidate is a finite prefix
    /// ending in `}`, so recursive template parsing always consumes less source.
    fn scan_raw_until_matching_brace(&mut self) -> Result<String, LexError> {
        let mut out = String::new();
        while let Some(c) = self.advance() {
            out.push(c);
            if c == '}' && crate::parser::closes_template_placeholder(&out) {
                out.pop();
                return Ok(out);
            }
        }
        Err(LexError::new(
            "unterminated or invalid template placeholder",
        ))
    }

    fn scan_identifier_or_keyword(&mut self) -> Result<Token, LexError> {
        let mut text = String::new();
        loop {
            let first = text.is_empty();
            let character = match self.peek() {
                Some('\\') => {
                    self.identifier_escaped = true;
                    self.scan_identifier_escape()?
                }
                Some(character)
                    if if first {
                        is_ident_start(character)
                    } else {
                        is_ident_continue(character)
                    } =>
                {
                    self.advance();
                    character
                }
                _ => break,
            };
            if if first {
                !is_ident_start(character)
            } else {
                !is_ident_continue(character)
            } {
                return Err(LexError::new(
                    "unicode escape does not form a valid identifier character",
                ));
            }
            text.push(character);
        }
        // A keyword spelled with a Unicode escape is never that keyword
        // (§12.7.2): it stays an IdentifierName, valid as a property name,
        // and the parser rejects it wherever a reserved word cannot be an
        // IdentifierReference or BindingIdentifier.
        match Keyword::from_str(&text) {
            Some(kw) if !self.identifier_escaped => Ok(Token::Keyword(kw)),
            _ => Ok(Token::Identifier(text)),
        }
    }

    fn scan_private_identifier(&mut self) -> Result<Token, LexError> {
        let mut text = String::new();
        loop {
            let first = text.is_empty();
            let character = match self.peek() {
                Some('\\') => {
                    self.identifier_escaped = true;
                    self.scan_identifier_escape()?
                }
                Some(character)
                    if if first {
                        is_ident_start(character)
                    } else {
                        is_ident_continue(character)
                    } =>
                {
                    self.advance();
                    character
                }
                _ => break,
            };
            if if first {
                !is_ident_start(character)
            } else {
                !is_ident_continue(character)
            } {
                return Err(LexError::new(
                    "unicode escape does not form a valid private identifier character",
                ));
            }
            text.push(character);
        }
        if text.is_empty() {
            return Err(LexError::new("private identifier requires a name"));
        }
        Ok(Token::PrivateIdentifier(text))
    }

    fn scan_identifier_escape(&mut self) -> Result<char, LexError> {
        debug_assert_eq!(self.peek(), Some('\\'));
        self.advance();
        if self.advance() != Some('u') {
            return Err(LexError::new("identifier escape must use \\u"));
        }
        let code = if self.peek() == Some('{') {
            self.advance();
            let mut hex = String::new();
            while self.peek().is_some_and(|character| character != '}') {
                hex.push(self.advance().unwrap());
            }
            self.advance()
                .ok_or_else(|| LexError::new("unterminated \\u{...} identifier escape"))?;
            let code = Self::hex_escape(&hex, "\\u{...}")?;
            if code > 0x10ffff {
                return Err(LexError::new(
                    "invalid \\u{...} identifier escape codepoint",
                ));
            }
            code
        } else {
            let hex: String = (0..4)
                .map(|_| {
                    self.advance()
                        .ok_or_else(|| LexError::new("unterminated \\u identifier escape"))
                })
                .collect::<Result<_, _>>()?;
            Self::hex_escape(&hex, "\\u")?
        };
        char::from_u32(code)
            .ok_or_else(|| LexError::new("identifier escape is not a Unicode scalar value"))
    }

    fn scan_punct(&mut self) -> Result<Token, LexError> {
        // Note: the leading character is already consumed by `let c =
        // self.advance()` below, so this only needs to check for (and
        // possibly consume) the second character.
        macro_rules! two {
            ($second:expr, $with:expr, $without:expr) => {{
                if self.peek() == Some($second) {
                    self.advance();
                    $with
                } else {
                    $without
                }
            }};
        }
        let c = self.advance().unwrap();
        let punct = match c {
            '(' => Punct::LParen,
            ')' => Punct::RParen,
            '{' => Punct::LBrace,
            '}' => Punct::RBrace,
            '[' => Punct::LBracket,
            ']' => Punct::RBracket,
            ';' => Punct::Semicolon,
            ',' => Punct::Comma,
            ':' => Punct::Colon,
            '.' => {
                if self.peek() == Some('.') && self.peek_at(1) == Some('.') {
                    self.advance();
                    self.advance();
                    Punct::Ellipsis
                } else {
                    Punct::Dot
                }
            }
            '+' => match self.peek() {
                Some('+') => {
                    self.advance();
                    Punct::PlusPlus
                }
                Some('=') => {
                    self.advance();
                    Punct::PlusAssign
                }
                _ => Punct::Plus,
            },
            '-' => match self.peek() {
                Some('-') => {
                    self.advance();
                    Punct::MinusMinus
                }
                Some('=') => {
                    self.advance();
                    Punct::MinusAssign
                }
                _ => Punct::Minus,
            },
            '*' => {
                if self.peek() == Some('*') {
                    self.advance();
                    if self.peek() == Some('=') {
                        self.advance();
                        Punct::StarStarAssign
                    } else {
                        Punct::StarStar
                    }
                } else if self.peek() == Some('=') {
                    self.advance();
                    Punct::StarAssign
                } else {
                    Punct::Star
                }
            }
            '/' => {
                if self.peek() == Some('=') {
                    self.advance();
                    Punct::SlashAssign
                } else {
                    Punct::Slash
                }
            }
            '%' => {
                if self.peek() == Some('=') {
                    self.advance();
                    Punct::PercentAssign
                } else {
                    Punct::Percent
                }
            }
            '=' => {
                if self.peek() == Some('=') && self.peek_at(1) == Some('=') {
                    self.advance();
                    self.advance();
                    Punct::EqEqEq
                } else if self.peek() == Some('=') {
                    self.advance();
                    Punct::EqEq
                } else if self.peek() == Some('>') {
                    self.advance();
                    Punct::Arrow
                } else {
                    Punct::Assign
                }
            }
            '!' => {
                if self.peek() == Some('=') && self.peek_at(1) == Some('=') {
                    self.advance();
                    self.advance();
                    Punct::NotEqEq
                } else if self.peek() == Some('=') {
                    self.advance();
                    Punct::NotEq
                } else {
                    Punct::Bang
                }
            }
            '<' => {
                if self.peek() == Some('<') {
                    self.advance();
                    if self.peek() == Some('=') {
                        self.advance();
                        Punct::ShiftLeftAssign
                    } else {
                        Punct::ShiftLeft
                    }
                } else {
                    two!('=', Punct::LtEq, Punct::Lt)
                }
            }
            '>' => {
                if self.peek() == Some('>') {
                    self.advance();
                    if self.peek() == Some('>') {
                        self.advance();
                        if self.peek() == Some('=') {
                            self.advance();
                            Punct::UnsignedShiftRightAssign
                        } else {
                            Punct::UnsignedShiftRight
                        }
                    } else if self.peek() == Some('=') {
                        self.advance();
                        Punct::ShiftRightAssign
                    } else {
                        Punct::ShiftRight
                    }
                } else {
                    two!('=', Punct::GtEq, Punct::Gt)
                }
            }
            '&' => {
                if self.peek() == Some('&') {
                    self.advance();
                    if self.peek() == Some('=') {
                        self.advance();
                        Punct::AndAndAssign
                    } else {
                        Punct::AndAnd
                    }
                } else if self.peek() == Some('=') {
                    self.advance();
                    Punct::AndAssign
                } else {
                    Punct::And
                }
            }
            '|' => {
                if self.peek() == Some('|') {
                    self.advance();
                    if self.peek() == Some('=') {
                        self.advance();
                        Punct::OrOrAssign
                    } else {
                        Punct::OrOr
                    }
                } else if self.peek() == Some('=') {
                    self.advance();
                    Punct::OrAssign
                } else {
                    Punct::Or
                }
            }
            '^' => two!('=', Punct::XorAssign, Punct::Xor),
            '~' => Punct::Tilde,
            '@' => Punct::At,
            '?' => {
                if self.peek() == Some('?') {
                    self.advance();
                    if self.peek() == Some('=') {
                        self.advance();
                        Punct::QuestionQuestionAssign
                    } else {
                        Punct::QuestionQuestion
                    }
                } else if self.peek() == Some('.')
                    && !self.peek_at(1).is_some_and(|c| c.is_ascii_digit())
                {
                    self.advance();
                    Punct::QuestionDot
                } else {
                    Punct::Question
                }
            }
            other => {
                let code = self.source_code_point(other);
                return Err(LexError::new(format!(
                    "unexpected character '{}'",
                    crate::source_encoding::describe_code_point(code)
                )));
            }
        };
        Ok(Token::Punct(punct))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tokens(src: &str) -> Vec<Token> {
        let mut t = Tokenizer::new(src);
        let mut out = Vec::new();
        loop {
            let spanned = t.next_spanned().unwrap();
            let is_eof = spanned.token == Token::Eof;
            out.push(spanned.token);
            if is_eof {
                return out;
            }
        }
    }

    #[test]
    fn scans_numbers() {
        assert_eq!(tokens("42"), vec![Token::Number(42.0), Token::Eof]);
        assert_eq!(tokens("2.5"), vec![Token::Number(2.5), Token::Eof]);
        assert_eq!(tokens(".5"), vec![Token::Number(0.5), Token::Eof]);
        assert_eq!(tokens("1e3"), vec![Token::Number(1000.0), Token::Eof]);
        assert_eq!(tokens("1.5e-2"), vec![Token::Number(0.015), Token::Eof]);
        assert_eq!(tokens("0"), vec![Token::Number(0.0), Token::Eof]);
        // Assert token boundaries independently of the full parser/VM.
        assert_eq!(
            tokens("0xA_B 0b1_0 0o7_0 07 08 1_0 0.5"),
            vec![
                Token::Number(171.0),
                Token::Number(2.0),
                Token::Number(56.0),
                Token::Number(7.0),
                Token::Number(8.0),
                Token::Number(10.0),
                Token::Number(0.5),
                Token::Eof,
            ]
        );
    }

    #[test]
    fn an_exponent_without_digits_is_a_lexical_error() {
        assert!(Tokenizer::new("1.e").next_spanned().is_err());
        for source in ["0x", "1_", "123abc"] {
            assert!(Tokenizer::new(source).next_spanned().is_err(), "{source}");
        }
    }

    #[test]
    fn template_cooking_normalizes_newlines_but_preserves_placeholder_comments() {
        assert_eq!(
            tokens("`a\r\nb${1/* } */+2}c\rd`"),
            vec![
                Token::Template {
                    quasis: vec!["a\nb".into(), "c\nd".into()],
                    raw_expressions: vec!["1/* } */+2".into()]
                },
                Token::Eof,
            ]
        );
        for newline in ["\n", "\r", "\r\n", "\u{2028}", "\u{2029}"] {
            assert_eq!(
                tokens(&format!("'a\\{newline}b'")),
                vec![Token::String("ab".into()), Token::Eof]
            );
            let mut tokenizer = Tokenizer::new(&format!("/*{newline}*/x"));
            let spanned = tokenizer.next_spanned().unwrap();
            assert!(spanned.newline_before);
            assert_eq!(spanned.token, Token::Identifier("x".into()));
        }
        assert!(Tokenizer::new("`${1/* unterminated }`")
            .next_spanned()
            .is_err());
    }

    #[test]
    fn scans_every_simple_escape_sequence() {
        assert_eq!(
            tokens(r"'\t\r\b\f\v\0'"),
            vec![Token::String("\t\r\u{8}\u{c}\u{b}\0".into()), Token::Eof]
        );
        assert_eq!(tokens(r"'\q'"), vec![Token::String("q".into()), Token::Eof]);
        // unrecognized escape: falls back to the escaped character itself
    }

    #[test]
    fn scans_legacy_octal_escapes_as_one_escape_sequence() {
        assert_eq!(
            tokens(r"'\000\007\010\377\400'"),
            vec![Token::String("\0\u{7}\u{8}\u{ff} 0".into()), Token::Eof,]
        );

        let mut tokenizer = Tokenizer::new(r"'\000'");
        assert!(tokenizer.next_spanned().unwrap().legacy_octal_escape);
        let mut tokenizer = Tokenizer::new(r"'\0'");
        assert!(!tokenizer.next_spanned().unwrap().legacy_octal_escape);
        let mut tokenizer = Tokenizer::new(r"'\8'");
        assert!(tokenizer.next_spanned().unwrap().legacy_octal_escape);
    }

    #[test]
    fn a_backslash_newline_is_a_line_continuation_contributing_no_character() {
        assert_eq!(
            tokens("'a\\\nb'"),
            vec![Token::String("ab".into()), Token::Eof]
        );
    }

    #[test]
    fn scans_a_bare_four_hex_digit_unicode_escape_without_braces() {
        assert_eq!(
            tokens("'\\u0041'"),
            vec![Token::String("A".into()), Token::Eof]
        );
    }

    #[test]
    fn scans_string_literals_with_escapes() {
        assert_eq!(
            tokens(r#""hello""#),
            vec![Token::String("hello".into()), Token::Eof]
        );
        assert_eq!(
            tokens("'hello'"),
            vec![Token::String("hello".into()), Token::Eof]
        );
        assert_eq!(
            tokens(r#""a\nb""#),
            vec![Token::String("a\nb".into()), Token::Eof]
        );
        assert_eq!(
            tokens(r#""a\"b""#),
            vec![Token::String("a\"b".into()), Token::Eof]
        );
        assert_eq!(
            tokens(r"'\u{1F600}'"),
            vec![Token::String("\u{1F600}".into()), Token::Eof]
        );
        assert_eq!(tokens(r"'A'"), vec![Token::String("A".into()), Token::Eof]);
        assert_eq!(
            tokens(r"'\x41'"),
            vec![Token::String("A".into()), Token::Eof]
        );
    }

    #[test]
    fn unterminated_string_is_an_error() {
        assert!(Tokenizer::new("\"abc").next_spanned().is_err());
        assert!(Tokenizer::new("\"abc\n\"").next_spanned().is_err());
    }

    #[test]
    fn scans_identifiers_and_keywords() {
        assert_eq!(
            tokens("foo _bar $baz"),
            vec![
                Token::Identifier("foo".to_string()),
                Token::Identifier("_bar".to_string()),
                Token::Identifier("$baz".to_string()),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens(r"\u0065xtends \u{61}sync"),
            vec![
                Token::Identifier("extends".to_string()),
                Token::Identifier("async".to_string()),
                Token::Eof
            ]
        );
        assert!(Tokenizer::new(r"\u0030").next_spanned().is_err());
        assert_eq!(
            tokens("undefined"),
            vec![Token::Identifier("undefined".to_string()), Token::Eof]
        );
        assert_eq!(
            tokens("let x = true"),
            vec![
                Token::Keyword(Keyword::Let),
                Token::Identifier("x".to_string()),
                Token::Punct(Punct::Assign),
                Token::Keyword(Keyword::True),
                Token::Eof
            ]
        );
        // ECMAScript uses Unicode ID_Start/ID_Continue, rather than Rust's
        // alphabetic/alphanumeric approximation, and additionally permits
        // ZWNJ/ZWJ after the first code point.
        assert_eq!(
            tokens("℘x a\u{200c}b \\u{2118}\\u{200d}c"),
            vec![
                Token::Identifier("℘x".to_string()),
                Token::Identifier("a\u{200c}b".to_string()),
                Token::Identifier("℘\u{200d}c".to_string()),
                Token::Eof,
            ]
        );
        assert!(Tokenizer::new("\u{200c}name").next_spanned().is_err());
    }

    #[test]
    fn scans_a_simple_template_literal_with_no_placeholders() {
        assert_eq!(
            tokens("`hello`"),
            vec![
                Token::Template {
                    quasis: vec!["hello".into()],
                    raw_expressions: vec![]
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn scans_a_template_literal_with_placeholders() {
        assert_eq!(
            tokens("`a${x}b${y + 1}c`"),
            vec![
                Token::Template {
                    quasis: vec!["a".into(), "b".into(), "c".into()],
                    raw_expressions: vec!["x".to_string(), "y + 1".to_string()]
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn template_literal_body_text_resolves_escapes() {
        assert_eq!(
            tokens("`a\\nb`"),
            vec![
                Token::Template {
                    quasis: vec!["a\nb".into()],
                    raw_expressions: vec![]
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn template_placeholder_errors_propagate_for_unterminated_nested_string_or_template() {
        assert!(Tokenizer::new("`${ \"unterminated").next_spanned().is_err());
        assert!(Tokenizer::new("`${ `unterminated").next_spanned().is_err());
    }

    #[test]
    fn unterminated_template_placeholder_itself_is_an_error() {
        // Runs out of input before the `${`'s own closing `}`, as
        // opposed to the surrounding template's closing backtick.
        assert!(Tokenizer::new("`${ 1 + 2").next_spanned().is_err());
    }

    #[test]
    fn template_placeholder_nested_string_and_template_bodies_handle_escapes() {
        // Exercises nested strings and templates with
        // own backslash-escape handling (distinct from `scan_escape`,
        // since this is *raw* copying for brace-balancing, not cooking).
        assert_eq!(
            tokens(r#"`${ "a\"}" }`"#),
            vec![
                Token::Template {
                    quasis: vec![Default::default(), Default::default()],
                    raw_expressions: vec![" \"a\\\"}\" ".to_string()]
                },
                Token::Eof
            ]
        );
        let toks = tokens("`${ `a\\`b${1}` }`");
        assert_eq!(
            toks,
            vec![
                Token::Template {
                    quasis: vec![Default::default(), Default::default()],
                    raw_expressions: vec![" `a\\`b${1}` ".to_string()]
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn template_placeholder_can_contain_braces_strings_and_nested_templates() {
        assert_eq!(
            tokens("`${ {} }`"),
            vec![
                Token::Template {
                    quasis: vec![Default::default(), Default::default()],
                    raw_expressions: vec![" {} ".to_string()]
                },
                Token::Eof
            ]
        );
        assert_eq!(
            tokens(r#"`${ "}" }`"#),
            vec![
                Token::Template {
                    quasis: vec![Default::default(), Default::default()],
                    raw_expressions: vec![r#" "}" "#.to_string()]
                },
                Token::Eof
            ]
        );
        let toks = tokens("`${ `${a}` }`");
        assert_eq!(
            toks,
            vec![
                Token::Template {
                    quasis: vec![Default::default(), Default::default()],
                    raw_expressions: vec![" `${a}` ".to_string()]
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn unterminated_template_is_an_error() {
        assert!(Tokenizer::new("`abc").next_spanned().is_err());
        assert!(Tokenizer::new("`abc${x}").next_spanned().is_err());
    }

    #[test]
    fn scans_punctuators_longest_match_first() {
        assert_eq!(
            tokens("=== == = ! != !=="),
            vec![
                Token::Punct(Punct::EqEqEq),
                Token::Punct(Punct::EqEq),
                Token::Punct(Punct::Assign),
                Token::Punct(Punct::Bang),
                Token::Punct(Punct::NotEq),
                Token::Punct(Punct::NotEqEq),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("=> ..."),
            vec![
                Token::Punct(Punct::Arrow),
                Token::Punct(Punct::Ellipsis),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("++ -- + -"),
            vec![
                Token::Punct(Punct::PlusPlus),
                Token::Punct(Punct::MinusMinus),
                Token::Punct(Punct::Plus),
                Token::Punct(Punct::Minus),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("&& || ??"),
            vec![
                Token::Punct(Punct::AndAnd),
                Token::Punct(Punct::OrOr),
                Token::Punct(Punct::QuestionQuestion),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("<= >= < >"),
            vec![
                Token::Punct(Punct::LtEq),
                Token::Punct(Punct::GtEq),
                Token::Punct(Punct::Lt),
                Token::Punct(Punct::Gt),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("+= -= *= **= /= %="),
            vec![
                Token::Punct(Punct::PlusAssign),
                Token::Punct(Punct::MinusAssign),
                Token::Punct(Punct::StarAssign),
                Token::Punct(Punct::StarStarAssign),
                Token::Punct(Punct::SlashAssign),
                Token::Punct(Punct::PercentAssign),
                Token::Eof
            ]
        );
        assert_eq!(
            tokens("a / b % c"),
            vec![
                Token::Identifier("a".to_string()),
                Token::Punct(Punct::Slash),
                Token::Identifier("b".to_string()),
                Token::Punct(Punct::Percent),
                Token::Identifier("c".to_string()),
                Token::Eof
            ]
        );
    }

    #[test]
    fn scans_bitwise_shift_and_compound_punctuators_longest_first() {
        assert_eq!(
            tokens("& &= | |= ^ ^= ~ << <<= >> >>= >>> >>>="),
            vec![
                Token::Punct(Punct::And),
                Token::Punct(Punct::AndAssign),
                Token::Punct(Punct::Or),
                Token::Punct(Punct::OrAssign),
                Token::Punct(Punct::Xor),
                Token::Punct(Punct::XorAssign),
                Token::Punct(Punct::Tilde),
                Token::Punct(Punct::ShiftLeft),
                Token::Punct(Punct::ShiftLeftAssign),
                Token::Punct(Punct::ShiftRight),
                Token::Punct(Punct::ShiftRightAssign),
                Token::Punct(Punct::UnsignedShiftRight),
                Token::Punct(Punct::UnsignedShiftRightAssign),
                Token::Eof,
            ]
        );
    }

    #[test]
    fn skips_line_and_block_comments() {
        assert_eq!(
            tokens("1 // comment\n2"),
            vec![Token::Number(1.0), Token::Number(2.0), Token::Eof]
        );
        assert_eq!(
            tokens("1 /* block \n comment */ 2"),
            vec![Token::Number(1.0), Token::Number(2.0), Token::Eof]
        );
    }

    #[test]
    fn skips_annex_b_html_comments() {
        assert_eq!(
            tokens("<!-- ignored\n1\n  --> ignored\n2"),
            vec![Token::Number(1.0), Token::Number(2.0), Token::Eof]
        );
        // The close spelling remains ordinary punctuator source away from a
        // line start; accepting it there would change executable code.
        assert_eq!(
            tokens("1 --> 2"),
            vec![
                Token::Number(1.0),
                Token::Punct(Punct::MinusMinus),
                Token::Punct(Punct::Gt),
                Token::Number(2.0),
                Token::Eof,
            ]
        );
    }

    #[test]
    fn unterminated_block_comment_is_an_error() {
        let mut t = Tokenizer::new("1 /* unterminated");
        assert_eq!(t.next_spanned().unwrap().token, Token::Number(1.0));
        assert!(t.next_spanned().is_err());
    }

    #[test]
    fn tracks_newline_before_a_token_for_asi() {
        let mut t = Tokenizer::new("1\n2");
        assert!(!t.next_spanned().unwrap().newline_before);
        assert!(t.next_spanned().unwrap().newline_before);
    }

    #[test]
    fn spanned_tokens_record_where_they_start() {
        // Offsets count characters (not UTF-8 bytes or UTF-16 units) from the
        // start of the source, and skip the whitespace and comments before a
        // token; the tokenizer position after a token is where it ends.
        let source = "  foo /* c */ 'b\u{1F600}r' // x\n\u{3042}\u{3044}";
        let mut t = Tokenizer::new(source);
        let mut spans = Vec::new();
        loop {
            let spanned = t.next_spanned().unwrap();
            if spanned.token == Token::Eof {
                break;
            }
            spans.push((spanned.start, t.position()));
        }
        assert_eq!(spans, vec![(2, 5), (14, 19), (25, 27)]);
        assert_eq!(t.next_spanned().unwrap().start, 27);
    }

    #[test]
    fn unexpected_character_is_an_error_not_a_panic() {
        assert!(Tokenizer::new("\\").next_spanned().is_err());
        assert!(Tokenizer::new("#").next_spanned().is_err());
    }

    #[test]
    fn at_sign_is_the_decorator_punctuator() {
        assert_eq!(
            tokens("@dec"),
            vec![
                Token::Punct(Punct::At),
                Token::Identifier("dec".into()),
                Token::Eof
            ]
        );
    }

    #[test]
    fn empty_input_yields_immediate_eof() {
        assert_eq!(tokens(""), vec![Token::Eof]);
        assert_eq!(tokens("   \n\t  "), vec![Token::Eof]);
    }

    /// Lexer text for `units`, as the entry points of `eval` produce it.
    fn encoded(units: &[u16]) -> String {
        crate::source_encoding::encode(&JsString::from_code_units(units.to_vec()))
    }

    fn js(units: &[u16]) -> JsString {
        JsString::from_code_units(units.to_vec())
    }

    #[test]
    fn a_string_literal_holds_an_unpaired_surrogate_as_that_code_unit() {
        for unit in [0xD800, 0xDBFF, 0xDC00, 0xDFFF] {
            let source = encoded(&[0x27, 0x61, unit, 0x62, 0x27]);
            assert_eq!(
                tokens(&source),
                vec![Token::String(js(&[0x61, unit, 0x62])), Token::Eof]
            );
            // An escaped surrogate is a NonEscapeCharacter: the backslash is dropped.
            let source = encoded(&[0x22, 0x5C, unit, 0x22]);
            assert_eq!(
                tokens(&source),
                vec![Token::String(js(&[unit])), Token::Eof]
            );
        }
    }

    #[test]
    fn a_string_literal_holds_a_genuine_reserved_character_as_itself() {
        for code in [0x10F000, 0x10F7FF, 0x10F800] {
            let genuine = char::from_u32(code).unwrap();
            let source =
                crate::source_encoding::escape(&format!("'{genuine}\\{genuine}'")).into_owned();
            assert_eq!(
                tokens(&source),
                vec![
                    Token::String(JsString::from(format!("{genuine}{genuine}"))),
                    Token::Eof
                ]
            );
        }
    }

    #[test]
    fn a_template_literal_holds_unpaired_surrogates_in_its_cooked_pieces() {
        let source = encoded(&[0x60, 0xD800, 0x24, 0x7B, 0x31, 0x7D, 0xDC00, 0x60]);
        assert_eq!(
            tokens(&source),
            vec![
                Token::Template {
                    quasis: vec![js(&[0xD800]), js(&[0xDC00])],
                    raw_expressions: vec!["1".into()],
                },
                Token::Eof
            ]
        );
    }

    #[test]
    fn a_placeholder_keeps_its_source_in_lexer_text() {
        let source = encoded(&[0x60, 0x24, 0x7B, 0x27, 0xD800, 0x27, 0x7D, 0x60]);
        let expression = encoded(&[0x27, 0xD800, 0x27]);
        assert_eq!(
            tokens(&source),
            vec![
                Token::Template {
                    quasis: vec!["".into(), "".into()],
                    raw_expressions: vec![expression.clone()],
                },
                Token::Eof,
            ]
        );
        assert_eq!(tokens(&expression)[0], Token::String(js(&[0xD800])));
    }

    #[test]
    fn helper_entry_points_preserve_template_errors_and_crlf() {
        assert!(Tokenizer::new("`${").tagged_template_at(0).is_err());
        assert!(Tokenizer::new_module("<!-- /x/").next_spanned().is_err());
        assert!(Tokenizer::new_module("<!-- `x`").next_spanned().is_err());
        for source in ["`\\\r\nx`", "`\r\nx`"] {
            assert!(Tokenizer::new(source).tagged_template_at(0).is_ok());
        }
    }

    #[test]
    fn private_identifier_escapes_validate_each_code_point() {
        assert_eq!(
            Tokenizer::new("#\\u0061\\u0062")
                .next_spanned()
                .unwrap()
                .token,
            Token::PrivateIdentifier("ab".into())
        );
        for source in ["#\\u0030", "#a\\u0020", "#\\u{xyz}", "#\\u00zz"] {
            assert!(Tokenizer::new(source).next_spanned().is_err(), "{source}");
        }
    }

    #[test]
    fn a_tagged_template_reports_cooked_and_raw_strings_with_the_surrogate_intact() {
        let source = encoded(&[0x60, 0xD800, 0x5C, 0xDC00, 0x60]);
        let (raw, cooked, expressions) = Tokenizer::new(&source).tagged_template_at(0).unwrap();
        assert_eq!(raw, vec![js(&[0xD800, 0x5C, 0xDC00])]);
        assert_eq!(cooked, vec![Some(js(&[0xD800, 0xDC00]))]);
        assert!(expressions.is_empty());
    }

    #[test]
    fn a_regexp_literal_keeps_an_unpaired_surrogate_in_its_pattern() {
        let source = encoded(&[0x2F, 0x5B, 0xD800, 0x5D, 0x5C, 0xDC00, 0xDBFF, 0x2F, 0x67]);
        let (pattern, flags) = Tokenizer::new(&source).regexp_at(0).unwrap();
        assert_eq!(pattern, js(&[0x5B, 0xD800, 0x5D, 0x5C, 0xDC00, 0xDBFF]));
        assert_eq!(flags, JsString::from("g"));
    }

    #[test]
    fn a_regexp_literal_keeps_a_genuine_reserved_character_after_a_backslash() {
        let source = crate::source_encoding::escape("/\\\u{10F000}\u{10F800}/u").into_owned();
        let (pattern, _) = Tokenizer::new(&source).regexp_at(0).unwrap();
        assert_eq!(pattern, JsString::from("\\\u{10F000}\u{10F800}"));
    }

    #[test]
    fn comments_skip_unpaired_surrogates_and_only_line_terminators_end_a_line_comment() {
        let source = encoded(&[0x2F, 0x2F, 0xD800, 0x2F, 0x2A, 0xDC00, 0x0A, 0x37]);
        assert_eq!(tokens(&source), vec![Token::Number(7.0), Token::Eof]);
        let source = encoded(&[0x2F, 0x2A, 0xD800, 0x2A, 0x2F, 0x37, 0xDFFF]);
        let mut tokenizer = Tokenizer::new(&source);
        assert_eq!(tokenizer.next_spanned().unwrap().token, Token::Number(7.0));
        assert!(tokenizer.next_spanned().is_err());
    }

    #[test]
    fn an_unpaired_surrogate_is_never_an_identifier_or_punctuator() {
        for source in [
            encoded(&[0xD800]),
            encoded(&[0x61, 0xDFFF]),
            encoded(&[0x31, 0xDC00]),
        ] {
            let mut tokenizer = Tokenizer::new(&source);
            let failed = (0..3).any(|_| tokenizer.next_spanned().is_err());
            assert!(failed, "{source:?}");
        }
        let error = Tokenizer::new(&encoded(&[0xD800]))
            .next_spanned()
            .unwrap_err();
        assert_eq!(error.message, "unexpected character '\\uD800'");
        let error = Tokenizer::new(&crate::source_encoding::escape("\u{10F800}"))
            .next_spanned()
            .unwrap_err();
        assert_eq!(error.message, "unexpected character '\u{10F800}'");
    }

    #[test]
    fn re_scanning_a_template_or_regexp_reports_broken_leading_trivia() {
        // Both re-scans first skip trivia from the position they are given.
        assert!(Tokenizer::new("/* open").regexp_at(0).is_err());
        assert!(Tokenizer::new("/* open").tagged_template_at(0).is_err());
        assert!(!Tokenizer::new("/* open").at_template(0));
        assert!(Tokenizer::new(" /a/").regexp_at(0).is_ok());
        assert!(Tokenizer::new(" `a`").at_template(0));
    }

    #[test]
    fn a_tagged_template_normalizes_lone_carriage_returns() {
        for (source, raw) in [
            ("`a\\\rb`", "a\\\nb"),
            ("`a\\\r\nb`", "a\\\nb"),
            ("`a\rb`", "a\nb"),
            ("`a\r\nb`", "a\nb"),
        ] {
            let (raws, _, expressions) = Tokenizer::new(source).tagged_template_at(0).unwrap();
            assert_eq!(raws, vec![JsString::from(raw)], "{source:?}");
            assert!(expressions.is_empty());
        }
    }

    #[test]
    fn a_tagged_template_placeholder_must_close_and_a_trailing_escape_must_finish() {
        assert!(Tokenizer::new("`a${ b").tagged_template_at(0).is_err());
        assert!(Tokenizer::new("`a\\").tagged_template_at(0).is_err());
        assert!(Tokenizer::new("`a").tagged_template_at(0).is_err());
    }

    #[test]
    fn private_identifiers_accept_valid_unicode_escapes_only() {
        assert_eq!(
            tokens("#\\u0061b"),
            vec![Token::PrivateIdentifier("ab".into()), Token::Eof]
        );
        assert_eq!(
            tokens("#a\\u{62}"),
            vec![Token::PrivateIdentifier("ab".into()), Token::Eof]
        );
        for source in [
            "#\\u0031",  // a digit cannot start a name
            "#a\\u0020", // a space cannot continue one
            "#\\u{110000}",
            "#\\u{zz}",
            "#\\u{}",
            "#\\u00zz",
            "#\\u00",
            "#\\u{61",
            "#\\x0061",
            "#\\ud800",
            "#",
        ] {
            assert!(Tokenizer::new(source).next_spanned().is_err(), "{source}");
        }
    }

    #[test]
    fn a_string_or_template_that_ends_inside_an_escape_is_an_error() {
        for source in [
            "'\\",
            "'\\x",
            "'\\x1",
            "'\\u",
            "'\\u12",
            "'\\u{",
            "'\\u{12",
            "'\\u{110000}'",
            "'\\u{zz}'",
            "'\\u{ffffffffff}'",
            "'\\xzz'",
            "'\\uzzzz'",
            "`\\",
            "`\\x1",
            "`\\u{12",
            "`\\u12",
        ] {
            assert!(Tokenizer::new(source).next_spanned().is_err(), "{source:?}");
        }
    }

    #[test]
    fn html_like_comments_end_at_the_line_terminator() {
        assert_eq!(
            tokens("<!-- comment\n1"),
            vec![Token::Number(1.0), Token::Eof]
        );
        assert_eq!(
            tokens("0\n--> comment\n1"),
            vec![Token::Number(0.0), Token::Number(1.0), Token::Eof]
        );
    }

    #[test]
    fn an_identifier_escape_must_form_an_identifier_character() {
        for source in ["\\u0031", "a\\u0020", "\\u{31}b"] {
            let error = Tokenizer::new(source).next_spanned().unwrap_err();
            assert_eq!(
                error.message, "unicode escape does not form a valid identifier character",
                "{source:?}"
            );
        }
        assert_eq!(
            tokens("\\u0061\\u{62}c"),
            vec![Token::Identifier("abc".into()), Token::Eof]
        );
    }

    #[test]
    fn a_regexp_that_ends_early_is_an_error() {
        for source in ["/abc", "/abc\\", "/a\nb/", "/a\\\nb/", "/[a"] {
            assert!(Tokenizer::new(source).regexp_at(0).is_err(), "{source:?}");
        }
        assert_eq!(
            Tokenizer::new("/a[/]b\\//gi").regexp_at(0).unwrap(),
            (JsString::from("a[/]b\\/"), JsString::from("gi"))
        );
    }

    #[test]
    fn only_a_leading_hashbang_line_is_skipped() {
        let mut tokenizer = Tokenizer::new("#!/bin/node\n1");
        tokenizer.skip_hashbang();
        assert_eq!(tokenizer.next_spanned().unwrap().token, Token::Number(1.0));
        let mut tokenizer = Tokenizer::new("1 #!x");
        tokenizer.skip_hashbang();
        assert_eq!(tokenizer.next_spanned().unwrap().token, Token::Number(1.0));
        assert!(tokenizer.next_spanned().is_err());
        // Without the `!` it is the start of a private name, not a comment.
        let mut tokenizer = Tokenizer::new("#x\n1");
        tokenizer.skip_hashbang();
        assert_eq!(
            tokenizer.next_spanned().unwrap().token,
            Token::PrivateIdentifier("x".into())
        );
        let mut tokenizer = Tokenizer::new("#!");
        tokenizer.skip_hashbang();
        assert_eq!(tokenizer.next_spanned().unwrap().token, Token::Eof);
    }
}
