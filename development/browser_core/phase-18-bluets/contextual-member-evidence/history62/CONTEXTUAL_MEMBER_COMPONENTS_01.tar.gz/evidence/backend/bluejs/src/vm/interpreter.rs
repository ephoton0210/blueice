// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use super::*;

impl Vm {
    /// Both private fields and private methods refer to the captured class
    /// owner through a binding slot. An uninitialized or non-object slot is
    /// the same protocol error for either kind of element.
    pub(super) fn private_element_owner(&mut self, slot: usize) -> Result<ObjectId, RuntimeError> {
        self.binding_value(slot)
            .expect(
                "a private owner uses a retained synthetic class binding, never a deleted eval var",
            )
            .and_then(|value| value.object_id())
            .ok_or_else(|| {
                RuntimeError::TypeError(
                    "private elements are not available in this function".into(),
                )
            })
    }

    pub(super) fn private_element_receiver(value: Value) -> Result<ObjectId, RuntimeError> {
        value.object_id().ok_or_else(|| {
            RuntimeError::TypeError("private fields require an object receiver".into())
        })
    }

    pub(super) fn interpret(
        &mut self,
        code: &Bytecode,
        iterators: &mut Vec<Value>,
        start_pc: usize,
        resume_value: Option<Value>,
        suspend_at: Option<InterpreterSuspensionPoint>,
        restored_handlers: Option<(Vec<HandlerFrame>, usize)>,
    ) -> Result<InterpreterExit, RuntimeError> {
        let iterator_root_base = self.async_frame_roots.len();
        let result = self.interpret_frame(
            code,
            iterators,
            start_pc,
            resume_value,
            suspend_at,
            restored_handlers,
            iterator_root_base,
        );
        // Every exit, including a resource refusal, releases this active
        // frame's records. A suspended frame's caller owns them afterwards.
        self.async_frame_roots.truncate(iterator_root_base);
        result
    }

    #[allow(clippy::too_many_arguments)]
    fn interpret_frame(
        &mut self,
        code: &Bytecode,
        iterators: &mut Vec<Value>,
        start_pc: usize,
        resume_value: Option<Value>,
        suspend_at: Option<InterpreterSuspensionPoint>,
        restored_handlers: Option<(Vec<HandlerFrame>, usize)>,
        iterator_root_base: usize,
    ) -> Result<InterpreterExit, RuntimeError> {
        let stack_base = self.stack.len();
        let pending_base = self.pending_completions.len();
        let save_base = self.completion_saves.len();
        if let Some(value) = resume_value {
            self.stack.push(value);
        }
        let mut pc = start_pc;
        let (mut handlers, handler_stack_base) =
            restored_handlers.unwrap_or_else(|| (Vec::new(), stack_base));
        // Suspended frames store stack offsets relative to their saved stack,
        // while an active interpreter may have an ambient caller frame below
        // it.  Convert at the boundary so catch/finally cleanup always uses
        // the current absolute operand-stack offsets.
        for handler in &mut handlers {
            handler.stack_depth += handler_stack_base;
        }
        let mut suspended_await = None;
        let mut executed_root_instruction = false;
        loop {
            // IteratorStep and IteratorStepReference can remove a record
            // from the operand stack while retaining it for abrupt cleanup.
            // The Rust iterator vector is therefore an active GC owner too.
            // Nested interpreters append their roots after this frame's set.
            self.async_frame_roots.truncate(iterator_root_base);
            self.async_frame_roots
                .extend(iterators.iter().filter_map(Value::object_id));
            if matches!(suspend_at, Some(InterpreterSuspensionPoint::Offset(target)) if target == pc)
                || (executed_root_instruction
                    && suspend_at == Some(InterpreterSuspensionPoint::AfterRootInstruction))
            {
                // The caller owns the returned records while execution is
                // suspended. Handler stack depths are relative to this
                // frame's operand-stack base, exactly like `Yield`, so a
                // later interpreter entry can restore them without exposing
                // an ambient caller frame to the continuation.
                for handler in &mut handlers {
                    handler.stack_depth -= handler_stack_base;
                }
                return Ok(InterpreterExit::Suspend {
                    pc,
                    iterators: std::mem::take(iterators),
                    handlers: std::mem::take(&mut handlers),
                });
            }
            self.charge_step()?;
            let instruction = code
                .instruction(pc)
                .expect("compiler emits valid instruction boundaries");
            let operand = instruction.operand.unwrap_or(0) as usize;
            pc += instruction.opcode.width();
            let throw_epoch_before = self.throw_epoch;
            let outcome: Result<Option<Completion>, RuntimeError> = (|| {
                match instruction.opcode {
                    Opcode::SetFunctionName => {
                        let len = self.stack.len();
                        let (key, function) =
                            (self.stack[len - 2].clone(), self.stack[len - 1].clone());
                        self.set_function_name_from_key(&function, &key, operand as u32)?;
                    }
                    Opcode::DefineData
                    | Opcode::DefineAccessor
                    | Opcode::DefineMethod
                    | Opcode::DefineClassAccessor => {
                        let value = self.pop();
                        let (receiver, key) = self.property_reference().expect(
                            "literal definitions retain their new owner and an already converted property key",
                        );
                        let object = receiver.object_id().unwrap();
                        if matches!(
                            instruction.opcode,
                            Opcode::DefineMethod
                                | Opcode::DefineAccessor
                                | Opcode::DefineClassAccessor
                        ) {
                            if let Some(function) = value.object_id() {
                                self.with_roots(|heap| heap.set_closure_home(function, object))?;
                            }
                        }
                        if instruction.opcode == Opcode::DefineData {
                            self.define_data(object, key, value.clone(), true, true, true)?;
                        } else {
                            let descriptor = if instruction.opcode == Opcode::DefineMethod {
                                PropertyDescriptor::data(value.clone(), true, operand != 0, true)
                            } else {
                                PropertyDescriptor {
                                    get: (operand == 0).then(|| value.clone()),
                                    set: (operand != 0).then(|| value.clone()),
                                    enumerable: Some(instruction.opcode == Opcode::DefineAccessor),
                                    configurable: Some(true),
                                    ..Default::default()
                                }
                            };
                            if !self.with_roots(|heap| {
                                heap.define_own_property(object, key, descriptor)
                            })? {
                                return Err(RuntimeError::TypeError(
                                    "cannot define class property".into(),
                                ));
                            }
                        }
                        self.stack.push(value);
                    }
                    Opcode::DefinePrivateField => {
                        let (receiver, name) = self.property_reference().expect(
                            "the compiler supplies a live class owner and a constant private name",
                        );
                        let owner = receiver
                            .object_id()
                            .expect("private class owner is an object");
                        let name = name
                            .into_string()
                            .expect("compiler emits string private names");
                        self.with_roots(|heap| {
                            if operand != 0 {
                                heap.add_private_brand(owner, owner)?;
                            }
                            heap.define_private_field(owner, name)
                        })?;
                    }
                    Opcode::DefinePrivateMethod | Opcode::DefinePrivateAccessor => {
                        let value = self.pop();
                        let (receiver, name) = self.property_reference().expect(
                            "the compiler supplies a live class owner and a constant private name",
                        );
                        let owner = receiver
                            .object_id()
                            .expect("private class owner is an object");
                        let name = name
                            .into_string()
                            .expect("compiler emits string private names");
                        let function = value
                            .object_id()
                            .expect("private methods and accessors are functions");
                        // Installing the static brand can collect between home
                        // metadata and the private element's first heap edge.
                        // Keep both popped operands live through every step,
                        // and release them on either success or refusal.
                        let base = self.stack.len();
                        self.stack.extend([receiver, value.clone()]);
                        let result = self.with_roots(|heap| {
                            heap.set_closure_home(function, owner)?;
                            if instruction.opcode == Opcode::DefinePrivateMethod {
                                if operand != 0 {
                                    heap.add_private_brand(owner, owner)?;
                                }
                                heap.define_private_method(owner, name, value)
                            } else {
                                if operand & 2 != 0 {
                                    heap.add_private_brand(owner, owner)?;
                                }
                                heap.define_private_accessor(owner, name, value, operand & 1 != 0)
                            }
                        });
                        self.stack.truncate(base);
                        result?;
                    }
                    Opcode::DeleteProperty => {
                        let (receiver, key) = self.property_reference()
                            .expect("DeleteProperty consumes a compiler-prepared object-coercible base and canonical key");
                        let deleted = match receiver {
                            Value::Object(id) => self.object_delete(id, &key)?,
                            Value::String(s) => {
                                !matches!(&key, PropertyName::String(key) if s.own_property(key).is_some())
                            }
                            _ => true,
                        };
                        if !deleted && self.strict {
                            return Err(RuntimeError::TypeError(
                                "cannot delete non-configurable property".into(),
                            ));
                        }
                        self.stack.push(Value::Bool(deleted));
                    }
                    Opcode::Throw => {
                        return Ok(Some(Completion::Throw(RuntimeError::Thrown(self.pop()))))
                    }
                    Opcode::InvalidAssignmentTarget => {
                        // Annex B CallExpression targets evaluate the call,
                        // then throw before an assignment RHS or update
                        // coercion can be observed.
                        self.pop();
                        return Err(RuntimeError::ReferenceError(
                            "invalid assignment target".into(),
                        ));
                    }
                    Opcode::ArrayPush => {
                        let base = self.stack.len() - 2;
                        self.array_push(
                            &self.stack[base].clone(),
                            &self.stack[base + 1].clone(),
                            operand,
                        )?;
                        self.stack.truncate(base + 1);
                    }
                    Opcode::CallSpread | Opcode::DirectEvalSpread => {
                        let base = self.stack.len() - 3;
                        let args = self.array_like_values(&self.stack[base + 2].clone())?;
                        let callee = self.stack[base].clone();
                        let receiver = self.stack[base + 1].clone();
                        let result = if instruction.opcode == Opcode::DirectEvalSpread
                            && self.is_intrinsic_eval(&callee).expect(
                                "intrinsic eval classification only reads the live callee tag",
                            ) {
                            self.direct_eval(native::argument(&args, 0))?
                        } else {
                            self.call_native(callee, receiver, args, operand != 0)?
                        };
                        self.stack.truncate(base);
                        self.stack.push(result);
                    }
                    Opcode::CallClassStaticBlock => {
                        let base = self.stack.len() - 2;
                        let target = self.stack[base]
                            .clone()
                            .object_id()
                            .expect("class constructors are objects");
                        if let Value::Object(function) = self.stack[base + 1] {
                            self.with_roots(|heap| heap.set_closure_home(function, target))?;
                        }
                        let callee = self.stack[base + 1].clone();
                        let direct_debugger_call = self.debugger_nested_pause_request.is_some()
                            && callee.object_id().is_some_and(|id| {
                                self.heap
                                    .closure(id)
                                    .expect("the static-block callee is a live operand")
                                    .is_some()
                            });
                        let previous = std::mem::replace(
                            &mut self.debugger_nested_direct_call,
                            direct_debugger_call,
                        );
                        let caller_generation = self
                            .debugger_nested_pause_request
                            .is_some()
                            .then_some(code.debugger_program_generation)
                            .flatten();
                        let previous_caller_generation = std::mem::replace(
                            &mut self.debugger_nested_direct_caller_generation,
                            caller_generation,
                        );
                        let result =
                            self.call_native(callee, self.stack[base].clone(), Vec::new(), false);
                        self.debugger_nested_direct_call = previous;
                        self.debugger_nested_direct_caller_generation = previous_caller_generation;
                        result?;
                        if self.debugger_nested_continuation.is_none() {
                            self.stack.truncate(base + 1);
                        }
                    }
                    Opcode::DefineInstanceField => {
                        // The receiver and value stay on the operand stack (and
                        // so rooted) until the definition has completed.
                        let base = self.stack.len() - 3;
                        let receiver = self.stack[base].clone();
                        let key = self
                            .coerce_property_key(&self.stack[base + 1].clone())
                            .expect(
                                "class evaluation converted and retained the field's property key",
                            );
                        let value = self.stack[base + 2].clone();
                        // This private initializer is invoked only after
                        // constructor dispatch has obtained its object result.
                        let object = receiver
                            .object_id()
                            .expect("constructor dispatch supplies the class field receiver");
                        if !self.object_define_own_property(
                            object,
                            key,
                            PropertyDescriptor::data(value, true, true, true),
                        )? {
                            return Err(RuntimeError::TypeError(
                                "cannot define class field".into(),
                            ));
                        }
                        self.stack.truncate(base);
                    }
                    Opcode::PrivateFieldAdd => {
                        // The receiver, name and value stay rooted on the
                        // operand stack until the field has been added.
                        let base = self.stack.len() - 3;
                        let receiver = self.stack[base].clone();
                        let name = self.stack[base + 1]
                            .as_string()
                            .expect("compiler emits a string private name")
                            .clone();
                        let value = self.stack[base + 2].clone();
                        let owner = self.private_element_owner(operand).expect("the compiler initializes the synthetic private owner before instance elements");
                        self.private_field_add(&receiver, owner, name, value)?;
                        self.stack.truncate(base);
                    }
                    Opcode::SetClassHome => self.set_class_home()?,
                    Opcode::SetClassHeritage => self.set_class_heritage()?,
                    Opcode::SetClassFields => self.set_class_fields()?,
                    Opcode::InitializeInstanceElements => {
                        // `F, result`: run F's [[Fields]] against the value
                        // super() constructed, then drop F beneath it.
                        let base = self.stack.len() - 2;
                        let (constructor, result) =
                            (self.stack[base].clone(), self.stack[base + 1].clone());
                        self.initialize_instance_elements(&constructor, &result)?;
                        self.stack.remove(base);
                    }
                    Opcode::CreateMetadata => self.create_metadata()?,
                    Opcode::DefineMetadata => self.define_metadata()?,
                    Opcode::PushDecorator => self.push_decorator()?,
                    Opcode::CallDecoratedStaticElement => self.call_decorated_static_element()?,
                    Opcode::DecorateElement => self.decorate_element(operand as u32)?,
                    Opcode::DecorateClass => self.decorate_class()?,
                    Opcode::ReplaceClassElement => self
                        .replace_class_element(operand as u32)
                        .expect("decoration only reinstalls previously validated class elements"),
                    Opcode::RunInitializers => self.run_initializers()?,
                    Opcode::ApplyInitializers => self.apply_initializers()?,
                    Opcode::InitializePrivateBrand => {
                        let owner = self.private_element_owner(operand).expect("the compiler initializes the synthetic private owner before instance elements");
                        let receiver = Self::private_element_receiver(self.pop()).expect(
                            "instance initialization follows a successful object construction",
                        );
                        // PrivateMethodOrAccessorAdd: installing the same
                        // methods twice (a constructor returning an already
                        // initialized object) is a TypeError, and so is adding
                        // one to an object that is no longer extensible
                        // (`nonextensible-applies-to-private`).
                        if self.heap.has_private_brand(receiver, owner).expect(
                            "the private owner and receiver were resolved from live frame values",
                        ) {
                            return Err(RuntimeError::TypeError(
                                "private methods are already installed on this object".into(),
                            ));
                        }
                        if !self.object_is_extensible(receiver)? {
                            return Err(RuntimeError::TypeError(
                                "cannot add a private element to a non-extensible object".into(),
                            ));
                        }
                        self.with_roots(|heap| heap.add_private_brand(receiver, owner))?;
                    }
                    Opcode::PrivateGet | Opcode::PrivateGetMethod => {
                        let (receiver, owner, name) = self.private_reference(operand).expect("the compiler emits a constant private name and a retained synthetic class owner");
                        let value = self.private_get(&receiver, owner, &name)?;
                        self.stack.push(value);
                        if instruction.opcode == Opcode::PrivateGetMethod {
                            self.stack.push(receiver);
                        }
                    }
                    Opcode::PrivateSet => {
                        let value = self.pop();
                        let (receiver, owner, name) = self.private_reference(operand).expect("the compiler emits a constant private name and a retained synthetic class owner");
                        self.private_set(&receiver, owner, name, value.clone())?;
                        self.stack.push(value);
                    }
                    Opcode::PrivateSetLeaf => {
                        let (receiver, owner, name) = self.private_reference(operand).expect("the compiler emits a constant private name and a retained synthetic class owner");
                        let value = self
                            .stack
                            .last()
                            .expect("the destructured value is on the stack")
                            .clone();
                        self.private_set(&receiver, owner, name, value)?;
                    }
                    Opcode::PrivatePostIncrement
                    | Opcode::PrivatePreIncrement
                    | Opcode::PrivatePostDecrement
                    | Opcode::PrivatePreDecrement => {
                        let (receiver, owner, name) = self.private_reference(operand).expect("the compiler emits a constant private name and a retained synthetic class owner");
                        // The private Reference is evaluated once: PrivateGet
                        // then PrivateSet on the same receiver and name.
                        // Keep the receiver rooted across a getter or setter.
                        self.stack.push(receiver.clone());
                        let old_value = self.private_get(&receiver, owner, &name)?;
                        let decrement = matches!(
                            instruction.opcode,
                            Opcode::PrivatePostDecrement | Opcode::PrivatePreDecrement
                        );
                        let (old, new) = self.numeric_step(&old_value, decrement)?;
                        self.stack.push(new.clone());
                        self.private_set(&receiver, owner, name, new.clone())?;
                        self.stack.pop();
                        self.stack.pop();
                        let prefix = matches!(
                            instruction.opcode,
                            Opcode::PrivatePreIncrement | Opcode::PrivatePreDecrement
                        );
                        self.stack.push(if prefix { new } else { old });
                    }
                    Opcode::PrivateIn => {
                        let (receiver, owner, _name) = self.private_reference(operand).expect("the compiler emits a constant private name and a retained synthetic class owner");
                        let object = receiver.object_id().ok_or_else(|| {
                            RuntimeError::TypeError("private brand checks require an object".into())
                        })?;
                        self.stack
                            .push(Value::Bool(self.heap.has_private_brand(object, owner).expect("the private owner and receiver were resolved from live frame values")));
                    }
                    Opcode::SuperBase => {
                        let base = self.super_base()
                            .expect("compiled super references have a retained ordinary class or literal home object; its prototype read cannot allocate");
                        self.stack.push(base);
                    }
                    Opcode::SuperGet | Opcode::SuperGetMethod => {
                        // The Reference operands stay on the stack (rooted)
                        // until the property read, and any getter, is done.
                        let base = self.stack.len() - 3;
                        let (target, key_value, this) = (
                            self.stack[base].clone(),
                            self.stack[base + 1].clone(),
                            self.stack[base + 2].clone(),
                        );
                        let value = self.super_get(&target, &key_value, &this)?;
                        self.check_string(&value)?;
                        self.stack.truncate(base);
                        self.stack.push(value);
                        if instruction.opcode == Opcode::SuperGetMethod {
                            self.stack.push(this);
                        }
                    }
                    Opcode::SuperSet => {
                        // Operand 0: `base, key, value, this`; operand 1 (a
                        // destructuring leaf): `value, base, key, this`.
                        let base = self.stack.len() - 4;
                        let (target, key_value, value) = if operand == 0 {
                            (
                                self.stack[base].clone(),
                                self.stack[base + 1].clone(),
                                self.stack[base + 2].clone(),
                            )
                        } else {
                            (
                                self.stack[base + 1].clone(),
                                self.stack[base + 2].clone(),
                                self.stack[base].clone(),
                            )
                        };
                        let this = self.stack[base + 3].clone();
                        self.super_set(&target, &key_value, &value, &this)?;
                        self.stack.truncate(base);
                        self.stack.push(value);
                    }
                    Opcode::SuperUpdate => {
                        let base = self.stack.len() - 3;
                        let (target, key_value, this) = (
                            self.stack[base].clone(),
                            self.stack[base + 1].clone(),
                            self.stack[base + 2].clone(),
                        );
                        // The compiler converted the key once already.
                        let old_value = self.super_get(&target, &key_value, &this)?;
                        let (old, new) = self.numeric_step(&old_value, operand & 1 != 0)?;
                        self.stack.push(new.clone());
                        self.super_set(&target, &key_value, &new, &this)?;
                        self.stack.truncate(base);
                        self.stack.push(if operand & 2 == 0 { old } else { new });
                    }
                    Opcode::DeleteSuperProperty => {
                        return Err(RuntimeError::ReferenceError(
                            "cannot delete a super property".into(),
                        ));
                    }
                    Opcode::ThisBinding => {
                        let this = self
                            .binding_value(operand)
                            .expect("the synthetic derived-this binding is a retained local cell")
                            .ok_or_else(|| {
                                RuntimeError::ReferenceError(
                                    "this is uninitialized before super()".into(),
                                )
                            })?;
                        self.stack.push(this);
                    }
                    Opcode::SuperConstructor => {
                        let constructor = self.pop();
                        let object = constructor
                            .object_id()
                            .expect("the derived constructor binding holds a function");
                        let parent = self.object_get_prototype(object).expect(
                            "the compiler's derived constructor is a retained ordinary closure",
                        );
                        self.stack.push(parent.map_or(Value::Null, Value::Object));
                    }
                    Opcode::SuperCall | Opcode::SuperCallSpread | Opcode::SuperCallForward => {
                        // `superCtor` sits below any arguments and stays
                        // rooted on the stack through the construction.
                        let (constructor_slot, args) = match instruction.opcode {
                            Opcode::SuperCall => {
                                let constructor_slot = self.stack.len() - operand - 1;
                                (
                                    constructor_slot,
                                    self.stack[constructor_slot + 1..].to_vec(),
                                )
                            }
                            Opcode::SuperCallSpread => {
                                let arguments = self.stack[self.stack.len() - 1].clone();
                                let constructor_slot = self.stack.len() - 2;
                                (constructor_slot, self.array_like_values(&arguments)?)
                            }
                            _ => (self.stack.len() - 1, self.arguments.clone()),
                        };
                        let constructor = self.stack[constructor_slot].clone();
                        let value = self.super_call(constructor, args)?;
                        self.stack.truncate(constructor_slot);
                        self.stack.push(value);
                    }
                    Opcode::BindThisValue => {
                        let value = self
                            .stack
                            .last()
                            .expect("the constructed value is on the stack")
                            .clone();
                        if self
                            .binding_value(operand)
                            .expect("the synthetic derived-this binding is a retained local cell")
                            .is_some()
                        {
                            return Err(RuntimeError::ReferenceError(
                                "super() was already called".into(),
                            ));
                        }
                        self.store_binding(operand, value)?;
                    }
                    Opcode::RegExpLiteral => {
                        let base = self.stack.len() - 2;
                        let regexp = self.regexp_create(
                            &self.stack[base].clone(),
                            &self.stack[base + 1].clone(),
                        )?;
                        self.stack.truncate(base);
                        self.stack.push(regexp);
                    }
                    Opcode::TemplateObject => {
                        let object = self.template_object(&code.templates[operand])?;
                        self.stack.push(object);
                    }
                    Opcode::GetIterator => {
                        let value = self.stack.last().unwrap().clone();
                        let iterator = self.get_iterator(&value)?;
                        self.pop();
                        self.stack.push(iterator.clone());
                        iterators.push(iterator);
                    }
                    Opcode::IteratorNext => {
                        // The synchronous yield* compiler is the only
                        // producer: it always supplies the resumed argument.
                        // AsyncIteratorNext also serves for-await and retains
                        // its separate no-argument form.
                        let base = self.stack.len() - 2;
                        let record = self.stack[base].clone();
                        let argument = Some(self.stack[base + 1].clone());
                        self.stack.truncate(base + 1);
                        let result = self.iterator_next(&record, argument)?;
                        self.stack.push(result);
                    }
                    Opcode::IteratorStepValue => {
                        // Synchronous yield*: a finished delegate's value is
                        // the expression's result. Otherwise the delegate's
                        // own result object is what the generator yields
                        // (GeneratorYield(innerResult)), and its `value` is
                        // not read.
                        let base = self.stack.len() - 2;
                        let record = self.stack[base].clone();
                        let result = self.stack[base + 1].clone();
                        iterators.retain(|active| active != &record);
                        let record_id = record
                            .object_id()
                            .expect("compiler only emits iterator records");
                        if !matches!(result, Value::Object(_)) {
                            return Err(RuntimeError::TypeError(
                                "iterator result must be an object".into(),
                            ));
                        }
                        let done = self.get_property(&result, &"done".into())?;
                        if self.to_boolean(&done).expect(
                            "the interpreter operand is live and ToBoolean does not run user code",
                        ) {
                            let value = self.get_property(&result, &"value".into())?;
                            self.stack.truncate(base);
                            self.heap.set(record_id, "done", Value::Bool(true)).expect(
                                "the private iterator record already owns its boolean done field",
                            );
                            self.stack.push(value);
                            pc = operand;
                        } else {
                            iterators.push(Value::Object(record_id));
                            // The record stays beneath the yielded result.
                        }
                    }
                    Opcode::GetAsyncIterator => {
                        let value = self.stack.last().unwrap().clone();
                        let iterator = self.get_async_iterator(&value)?;
                        self.pop();
                        self.stack.push(iterator.clone());
                        iterators.push(iterator);
                    }
                    Opcode::ForInKeys => {
                        let source = self.stack.last().expect("for-in has a source").clone();
                        let record = self.for_in_iterator(&source)?;
                        self.pop();
                        self.stack.push(record.clone());
                        iterators.push(record);
                    }
                    Opcode::IteratorStep => {
                        let record = self.stack.last().unwrap().clone();
                        iterators.retain(|active| active != &record);
                        let result = self.iterator_step(&record, true)?;
                        self.pop();
                        if let Some(value) = result {
                            iterators.push(record);
                            self.stack.push(value);
                        } else {
                            pc = operand;
                        }
                    }
                    Opcode::AsyncIteratorNext => {
                        let (record, argument) = if operand == 0 {
                            (self.stack.last().unwrap().clone(), None)
                        } else {
                            let base = self.stack.len() - 2;
                            let record = self.stack[base].clone();
                            let argument = self.stack[base + 1].clone();
                            self.stack.truncate(base + 1);
                            (record, Some(argument))
                        };
                        let promise = self.async_iterator_next(&record, argument)?;
                        self.stack.push(promise);
                    }
                    Opcode::AsyncIteratorStep => {
                        let base = self.stack.len() - 2;
                        let record = self.stack[base].clone();
                        let result = self.stack[base + 1].clone();
                        iterators.retain(|active| active != &record);
                        let value = self.async_iterator_step(&record, &result)?;
                        self.stack.truncate(base);
                        if let Some(value) = value {
                            iterators.push(record);
                            self.stack.push(value);
                        } else {
                            pc = operand;
                        }
                    }
                    Opcode::AsyncIteratorStepValue => {
                        // yield* needs the completed iterator result's value
                        // as its own expression result, unlike for-await.
                        let base = self.stack.len() - 2;
                        let record = self.stack[base].clone();
                        let result = self.stack[base + 1].clone();
                        iterators.retain(|active| active != &record);
                        let record_id = record
                            .object_id()
                            .expect("compiler only emits iterator records");
                        if !matches!(result, Value::Object(_)) {
                            return Err(RuntimeError::TypeError(
                                "async iterator result must be an object".into(),
                            ));
                        }
                        let done = self.get_property(&result, &"done".into())?;
                        let value = self.get_property(&result, &"value".into())?;
                        self.stack.truncate(base);
                        if self.to_boolean(&done).expect(
                            "the interpreter operand is live and ToBoolean does not run user code",
                        ) {
                            self.heap.set(record_id, "done", Value::Bool(true)).expect(
                                "the private iterator record already owns its boolean done field",
                            );
                            self.stack.push(value);
                            pc = operand;
                        } else {
                            iterators.push(Value::Object(record_id));
                            self.stack.push(Value::Object(record_id));
                            self.stack.push(value);
                        }
                    }
                    Opcode::IteratorStepReference => {
                        let base = self.stack.len() - 3;
                        let record = self.stack[base].clone();
                        iterators.retain(|active| active != &record);
                        let result = self.iterator_step(&record, true)?;
                        self.stack.remove(base);
                        if let Some(value) = result {
                            iterators.push(record);
                            self.stack.push(value);
                        } else {
                            pc = operand;
                        }
                    }
                    Opcode::IteratorElision => {
                        let record = self.stack.last().unwrap().clone();
                        iterators.retain(|active| active != &record);
                        if self.iterator_step(&record, false)?.is_some() {
                            iterators.push(record);
                        }
                    }
                    Opcode::IteratorClose => {
                        let record = self.stack.last().unwrap().clone();
                        iterators.retain(|active| active != &record);
                        self.iterator_close(&record)?;
                        self.pop();
                    }
                    Opcode::CloseIteratorBinding => {
                        if let Some(record) = self.binding_value(operand).expect(
                            "the compiler's synthetic iterator slot is a retained local binding",
                        ) {
                            // `return()` is user code and can allocate, so
                            // the record must be stack-rooted just as it is
                            // for the ordinary IteratorClose opcode.
                            self.stack.push(record);
                            let record = self
                                .stack
                                .last()
                                .expect("iterator record is rooted")
                                .clone();
                            iterators.retain(|active| active != &record);
                            let result = self.iterator_close(&record);
                            self.stack.pop();
                            result?;
                        }
                        // Otherwise a crossed handler already closed this
                        // iterator before its finalizer and reset the private
                        // loop scope that stored the record.
                    }
                    Opcode::IteratorFinish => {
                        let record = self.stack.last().unwrap().clone();
                        let id = record
                            .object_id()
                            .expect("compiler only emits iterator records");
                        let done = matches!(
                            self.heap.get_own(id, "done").expect(
                                "the active iterator record is rooted by this execution frame"
                            ),
                            Some(Value::Bool(true))
                        );
                        iterators.retain(|candidate| candidate != &record);
                        if !done {
                            self.iterator_close(&record)?;
                        }
                        self.pop();
                    }
                    Opcode::IteratorRest => {
                        let record = self.stack.last().unwrap().clone();
                        let base = self.stack.len() - 1;
                        iterators.retain(|candidate| candidate != &record);
                        iterators.push(record.clone());
                        // Keep accumulated values in a rooted managed array while
                        // subsequent next/done/value callbacks can trigger GC.
                        let array = self.array_from(Vec::new())?;
                        self.stack.push(array.clone());
                        while let Some(value) = self.iterator_step(&record, true)? {
                            self.charge_step()?;
                            self.array_push(&array, &value, 0)?;
                        }
                        iterators.retain(|candidate| candidate != &record);
                        self.stack.truncate(base);
                        self.stack.push(array);
                    }
                    Opcode::IteratorRestReference => {
                        let base = self.stack.len() - 3;
                        let record = self.stack[base].clone();
                        iterators.retain(|active| active != &record);
                        iterators.push(record.clone());
                        let array = self.array_from(Vec::new())?;
                        self.stack.push(array.clone());
                        while let Some(value) = self.iterator_step(&record, true)? {
                            self.charge_step()?;
                            self.array_push(&array, &value, 0)?;
                        }
                        iterators.retain(|active| active != &record);
                        self.stack.remove(base);
                    }
                    Opcode::RequireObject => {
                        let value = self.stack.last().unwrap().clone();
                        self.coerce_object(&value)?;
                    }
                    Opcode::DestructureProperty => {
                        let base = self.stack.len() - 3;
                        let source = self.stack[base].clone();
                        let excluded = self.stack[base + 1].clone();
                        let key = self
                            .coerce_property_key(&self.stack[base + 2].clone())
                            .expect("the compiler converted the destructuring source key before resolving its target");
                        let value = self.get_property(&source, &key)?;
                        self.array_push(&excluded, &key.value(), 0)?;
                        self.stack.truncate(base);
                        self.stack.extend([source, excluded, value]);
                    }
                    Opcode::DestructurePropertyReference => {
                        // [..., source, excluded, source-key, source-key,
                        // target-object, raw-target-key] becomes [...,
                        // source, excluded, target-object, raw-target-key,
                        // value].
                        // The duplicate source key keeps target evaluation
                        // ahead of GetV without changing excluded-key order.
                        let base = self.stack.len() - 6;
                        let source = self.stack[base].clone();
                        let excluded = self.stack[base + 1].clone();
                        let source_key = self
                            .coerce_property_key(&self.stack[base + 2].clone())
                            .expect("the compiler converted and duplicated the destructuring source key before resolving its target");
                        let object = self.stack[base + 4].clone();
                        let raw_target_key = self.stack[base + 5].clone();
                        let value = self.get_property(&source, &source_key)?;
                        self.array_push(&excluded, &source_key.value(), 0)?;
                        self.stack.truncate(base);
                        self.stack
                            .extend([source, excluded, object, raw_target_key, value]);
                    }
                    Opcode::ObjectRest => {
                        let base = self.stack.len() - 2;
                        let source = self.stack[base].clone();
                        let excluded = self.stack[base + 1].clone();
                        let rest = self.destructure_object_rest(&source, &excluded)?;
                        self.stack.truncate(base);
                        self.stack.push(rest);
                    }
                    Opcode::CopyDataProperties => {
                        let base = self.stack.len() - 2;
                        let target = self.stack[base]
                            .clone()
                            .object_id()
                            .expect("compiler creates an object literal target");
                        let source = self.stack[base + 1].clone();
                        self.copy_data_properties(target, &source, &[])?;
                        self.pop();
                    }
                    Opcode::Closure => {
                        let child = code.functions[operand].clone();
                        let function_prototype = if child.generator && !child.async_function {
                            self.generator_function_prototype()?
                        } else if child.generator {
                            self.async_generator_function_prototype()?
                        } else if child.async_function {
                            self.async_function_prototype()?
                        } else {
                            self.function_prototype()?
                        };
                        let mut captures = Vec::new();
                        for &slot in &child.captures {
                            captures.push(self.capture(slot as usize)?);
                        }
                        let this = if child.arrow {
                            if self.this == Value::Undefined
                                && self.call_depth == 0
                                && !self.top_level_module
                            {
                                self.global("globalThis")?
                            } else {
                                self.this.clone()
                            }
                        } else {
                            Value::Undefined
                        };
                        let id = self.with_roots(|heap| {
                            heap.alloc_closure(child.clone(), captures, this, function_prototype)
                        })?;
                        if let Some(module) = &self.active_module_name {
                            self.module_closure_referrers.insert(id, module.clone());
                        }
                        self.stack.push(Value::Object(id));
                        if child.arrow && self.new_target != Value::Undefined {
                            let new_target = self.new_target.clone();
                            self.with_roots(|heap| heap.set_closure_new_target(id, new_target))?;
                        }
                        if child.with_depth != 0 {
                            let with_objects = self.with_objects.clone();
                            self.with_roots(|heap| {
                                heap.set_closure_with_objects(id, with_objects)
                            })?;
                        }
                        // Arrow functions inherit their containing function's
                        // [[HomeObject]] together with lexical `this`.  Keeping
                        // the new closure on the operand stack first makes it a
                        // GC root while installing metadata may allocate.
                        if child.arrow {
                            if let Some(home) = self.home_object {
                                self.with_roots(|heap| heap.set_closure_home(id, home))?;
                            }
                        }
                        // OrdinaryFunctionCreate's SetFunctionLength precedes
                        // SetFunctionName, so `length` is the first own key.
                        self.define_data(
                            id,
                            "length",
                            Value::Number(child.function_length as f64),
                            false,
                            false,
                            true,
                        )?;
                        self.define_data(
                            id,
                            "name",
                            Value::String(child.function_name.clone().into()),
                            false,
                            false,
                            true,
                        )?;
                        if child.constructible
                            && !child.strict
                            && !child.arrow
                            && !child.generator
                            && !child.async_function
                        {
                            self.install_legacy_function_properties(id)?;
                        }
                        if child.generator {
                            // Generator function objects are not constructors,
                            // but each owns the prototype used for iterators it
                            // creates. The own object inherits the shared
                            // generator/async-generator prototype and remains
                            // replaceable by user code.
                            let base_prototype = if child.async_function {
                                self.async_generator_prototype()
                                    .expect("the function-side prototype retained its async generator prototype")
                            } else {
                                self.generator_prototype().expect(
                                    "the function-side prototype retained its generator prototype",
                                )
                            };
                            let prototype =
                                self.with_roots(|heap| heap.alloc_object(Some(base_prototype)))?;
                            self.define_data(
                                id,
                                "prototype",
                                Value::Object(prototype),
                                true,
                                false,
                                false,
                            )?;
                        } else if child.constructible {
                            let object_prototype = self.object_prototype;
                            let prototype =
                                self.with_roots(|heap| heap.alloc_object(Some(object_prototype)))?;
                            self.define_data(
                                id,
                                "prototype",
                                Value::Object(prototype),
                                !child.class_constructor,
                                false,
                                false,
                            )?;
                            self.define_data(
                                prototype,
                                "constructor",
                                Value::Object(id),
                                true,
                                false,
                                true,
                            )?;
                        }
                    }
                    Opcode::This => {
                        if self.this == Value::Undefined
                            && self.call_depth == 0
                            && !self.top_level_module
                        {
                            self.this = self.global("globalThis")?;
                        }
                        self.stack.push(self.this.clone());
                    }
                    Opcode::NewTarget => self.stack.push(self.new_target.clone()),
                    Opcode::Argument => self
                        .stack
                        .push(native::argument(&self.arguments, operand).clone()),
                    Opcode::RestArguments => {
                        let array = self
                            .array_from(self.arguments.iter().skip(operand).cloned().collect())?;
                        self.stack.push(array);
                    }
                    Opcode::ArgumentsObject => self.create_arguments_object(code)?,
                    Opcode::Return => return Ok(Some(Completion::Return(self.pop()))),
                    Opcode::TailRecur => {
                        let base = self.stack.len() - operand;
                        let args = self.stack[base..].to_vec();
                        self.stack.truncate(base);
                        return Ok(Some(Completion::TailRecur(args)));
                    }
                    Opcode::Yield => {
                        if !code.generator {
                            return Err(RuntimeError::TypeError(
                                "yield is not supported in this execution context".into(),
                            ));
                        }
                        return Ok(Some(Completion::Yield(self.pop())));
                    }
                    Opcode::Await => {
                        // Await always applies PromiseResolve before it
                        // observes settlement, so plain thenables use the
                        // same queued resolution path as Promise values.
                        let awaited_value = self.pop();
                        let awaited = self.promise_resolve(awaited_value)?;
                        if code.async_function || (self.top_level_module && self.call_depth == 0) {
                            suspended_await = Some(
                                awaited
                                    .object_id()
                                    .expect("PromiseResolve returns a Promise object"),
                            );
                            return Ok(None);
                        }
                        // Await resumes only after the next queued turn. A
                        // fulfilled Promise still crosses that boundary; a
                        // pending one may need several pre-existing jobs to
                        // settle, but we never collapse later turns into the
                        // current continuation.
                        loop {
                            let pending = awaited
                                .object_id()
                                .and_then(|promise| self.promises.get(&promise))
                                .is_some_and(|record| {
                                    matches!(record.status, PromiseStatus::Pending)
                                });
                            let advanced = self.run_next_job_while_module_suspended()?;
                            if !pending || !advanced {
                                break;
                            }
                        }
                        let value = self.await_value(awaited)?;
                        self.stack.push(value);
                    }
                    Opcode::DynamicImport => {
                        let options = self.pop();
                        let specifier = self.pop();
                        let promise = self.dynamic_import(
                            specifier,
                            options,
                            ImportPhase::from_operand(operand),
                        )?;
                        self.stack.push(promise);
                    }
                    Opcode::ImportMeta => {
                        let meta = self.import_meta()?;
                        self.stack.push(meta);
                    }
                    Opcode::EnterWith => {
                        let object = self.pop();
                        let object = self.coerce_object(&object)?;
                        self.with_objects.push(Value::Object(object));
                    }
                    Opcode::LeaveWith => {
                        self.with_objects
                            .pop()
                            .expect("compiler balances with scopes");
                    }
                    Opcode::WithGet => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let fallback = self.with_binding_fallback(&name)?;
                        let value = self.with_get(&name, fallback)?;
                        self.stack.push(value);
                    }
                    Opcode::WithGetMethod => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let fallback = self.with_binding_fallback(&name)?;
                        let (value, receiver) = self.with_get_method(&name, fallback)?;
                        self.stack.push(value);
                        self.stack.push(receiver);
                    }
                    Opcode::WithGetOrUndefined => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let fallback = self.with_binding_fallback(&name)?;
                        let value = self.with_get_or_undefined(&name, fallback)?;
                        self.stack.push(value);
                    }
                    Opcode::WithSet => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        self.with_set(
                            &name.to_utf8().expect("compiler emits a UTF-8 identifier"),
                            self.stack.last().expect("assignment has a value").clone(),
                        )?;
                    }
                    Opcode::ResolveWithReference => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let mut object_reference = None;
                        for object in self.with_objects.clone().into_iter().rev() {
                            if self.with_has_binding(&object, &name)? {
                                object_reference = Some(object);
                                break;
                            }
                        }
                        if let Some(object) = object_reference {
                            // The pair is a property reference. Keeping it on
                            // the operand stack makes it survive calls, handler
                            // unwinding and generator suspension just like an
                            // ordinary member-reference pair.
                            self.stack.push(object);
                            self.stack.push(Value::String(name.into()));
                        } else if let Some(slot) = self.active_binding_slot(&name) {
                            // `Null` tags an internal binding reference; the
                            // slot is safe because it is compiler-owned and is
                            // consumed only by StoreWithReference.
                            self.stack.push(Value::Number(slot as f64));
                            self.stack.push(Value::Null);
                        } else if self.dynamic_eval_bindings.contains_key(&name)
                            || self
                                .dynamic_eval_outer_bindings
                                .iter()
                                .rev()
                                .any(|bindings| bindings.contains_key(&name))
                        {
                            self.stack.push(Value::Bool(false));
                            self.stack.push(Value::String(name.into()));
                        } else {
                            // Preserve the global Environment Record before
                            // the RHS can create an eval binding of this name.
                            // Declarative globals resolve even while in TDZ;
                            // standard object globals must first materialize.
                            let resolves = if self.global_bindings.contains_key(&name) {
                                true
                            } else {
                                let global = self
                                    .global("globalThis")?
                                    .object_id()
                                    .expect("globalThis is an object");
                                self.materialize_lexical_global(global, &name)?;
                                self.has_property(global, &name.as_str().into())?
                            };
                            self.stack.push(if resolves {
                                Value::Bool(true)
                            } else {
                                Value::Undefined
                            });
                            self.stack.push(Value::String(name.into()));
                        }
                    }
                    Opcode::LoadWithReference => {
                        let marker = self.pop();
                        let target = self.pop();
                        let value = self.load_with_reference(code, &target, &marker)?;
                        // Preserve the original Reference for PutValue after
                        // the RHS has run. `get_property` may invoke a getter,
                        // so stack-resident values are the GC roots here.
                        self.stack.push(target);
                        self.stack.push(marker);
                        self.stack.push(value);
                    }
                    Opcode::StoreWithReference => {
                        let value = self.pop();
                        let marker = self.pop();
                        let target = self.pop();
                        self.store_with_reference(code, target, marker, &value)?;
                        self.stack.push(value);
                    }
                    Opcode::EndParameterEvalScope => self.parameter_eval_env = None,
                    Opcode::StoreResolvedWithReference => {
                        let marker = self.pop();
                        let target = self.pop();
                        let value = self.pop();
                        self.stack.push(value.clone());
                        self.store_with_reference(code, target, marker, &value)?;
                    }
                    Opcode::UpdateWithReference => {
                        // `name++` / `--name` on a Reference resolved before
                        // the read: GetValue, ToNumeric, then PutValue on that
                        // same Reference. Operand bit 0: decrement; bit 1:
                        // prefix (the result is the new value, else the old).
                        let marker = self.pop();
                        let target = self.pop();
                        self.stack.push(target.clone());
                        self.stack.push(marker.clone());
                        let current = self.load_with_reference(code, &target, &marker)?;
                        let (old, new) = self.numeric_step(&current, operand & 1 != 0)?;
                        self.store_with_reference(code, target, marker, &new)?;
                        self.stack.truncate(self.stack.len() - 2);
                        self.stack.push(if operand & 2 == 0 { old } else { new });
                    }
                    Opcode::Global => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        // A direct reference to a standard global resolves
                        // through the global object record.  `Vm::global`
                        // remains the private intrinsic materializer used by
                        // engine algorithms, but source-level `Object`,
                        // `Array`, and friends must observe replacement or
                        // deletion of their configurable global properties.
                        // Establish the realm global first so
                        // `lookup_global_name` can materialize the initial
                        // lazy property before it checks that object record.
                        self.global("globalThis")?;
                        let value = self
                            .lookup_global_name(&name)?
                            .ok_or(RuntimeError::ReferenceError(name))?;
                        self.stack.push(value);
                    }
                    Opcode::ToPropertyKey => {
                        let value = self.stack.last().unwrap().clone();
                        let key = self.coerce_property_key(&value)?;
                        self.pop();
                        self.stack.push(key.value());
                    }
                    Opcode::PreparePropertyReference => {
                        let base = self.stack.len() - 2;
                        if matches!(self.stack[base], Value::Null | Value::Undefined) {
                            return Err(RuntimeError::TypeError(
                                "cannot access a property of null or undefined".into(),
                            ));
                        }
                        let key = self.coerce_property_key(&self.stack[base + 1].clone())?;
                        self.stack[base + 1] = key.value();
                    }
                    Opcode::Constant => {
                        self.check_string(&code.constants[operand])?;
                        self.stack.push(code.constants[operand].clone());
                    }
                    Opcode::GlobalString => {
                        let (constructor, _) = self.string_intrinsics()?;
                        self.stack.push(Value::Object(constructor));
                    }
                    Opcode::GetBinding => {
                        let value = self
                            .eval_aware_binding_value(operand, &code.bindings[operand].name)?
                            .ok_or_else(|| {
                                RuntimeError::ReferenceError(code.bindings[operand].name.clone())
                            })?;
                        self.stack.push(value);
                    }
                    Opcode::TypeofBinding => {
                        let value = self
                            .eval_aware_binding_value(operand, &code.bindings[operand].name)?
                            .unwrap_or(Value::Undefined);
                        self.stack
                            .push(Value::String(self.typeof_value(&value).expect("the interpreter owns this live value and typeof cannot invoke JavaScript").into()));
                    }
                    Opcode::ResolveBindingReference => {
                        let slot = operand;
                        let dynamic = self.cells.get(&slot).and_then(|cell| {
                            self.dynamic_eval_shadowing_cell(&code.bindings[slot].name, *cell)
                        });
                        // `Number(slot), Null` is a static binding reference;
                        // replacing Null with a cell records a dynamic eval
                        // binding that was already visible at resolution.
                        self.stack.push(Value::Number(slot as f64));
                        self.stack
                            .push(dynamic.map(Value::Object).unwrap_or(Value::Null));
                    }
                    Opcode::LoadBindingReference => {
                        let marker = self.pop();
                        let target = self.pop();
                        let slot = target
                            .as_number()
                            .expect("compiler emits a binding reference");
                        let slot = slot as usize;
                        let value = match marker {
                            Value::Null => self.binding_value(slot)?,
                            _ => self
                                .heap
                                .get_own(
                                    marker
                                        .object_id()
                                        .expect("compiler emits a binding reference marker"),
                                    "value",
                                )
                                .expect("the resolved dynamic reference retains its binding cell"),
                        }
                        .ok_or_else(|| {
                            RuntimeError::ReferenceError(code.bindings[slot].name.clone())
                        })?;
                        self.stack.push(Value::Number(slot as f64));
                        self.stack.push(marker);
                        self.stack.push(value);
                    }
                    Opcode::InitializeBinding => {
                        let value = self.pop();
                        self.store_binding(operand, value)?;
                    }
                    Opcode::StoreBinding | Opcode::StoreEvalVar => {
                        let value = self.stack.last().expect("store has a value").clone();
                        self.assign_binding_slot(
                            code,
                            operand,
                            value,
                            instruction.opcode == Opcode::StoreEvalVar,
                        )?;
                    }
                    Opcode::StoreBindingReference => {
                        let (target, marker, value, result) = if operand == 0 {
                            let value = self.pop();
                            let marker = self.pop();
                            let target = self.pop();
                            (target, marker, value.clone(), value)
                        } else {
                            // A postfix update leaves its original value
                            // below the reference's new value.
                            let base = self.stack.len() - 4;
                            let target = self.stack[base].clone();
                            let marker = self.stack[base + 1].clone();
                            let result = self.stack[base + 2].clone();
                            let value = self.stack[base + 3].clone();
                            self.stack.truncate(base);
                            (target, marker, value, result)
                        };
                        let slot = target
                            .as_number()
                            .expect("compiler emits a binding reference");
                        let slot = slot as usize;
                        match marker {
                            Value::Null => {
                                if self.eval_var_deleted(slot) {
                                    let name = &code.bindings[slot].name;
                                    self.assign_unbound_name(name, value.clone(), code.strict)?;
                                } else {
                                    if self.binding_value(slot)?.is_none() {
                                        return Err(RuntimeError::ReferenceError(
                                            code.bindings[slot].name.clone(),
                                        ));
                                    }
                                    if binding_allows_assignment(&code.bindings[slot], code.strict)?
                                    {
                                        self.store_binding(slot, value.clone())?;
                                    }
                                }
                            }
                            _ => self.store_global_cell(
                                marker
                                    .object_id()
                                    .expect("compiler emits a binding reference marker"),
                                value.clone(),
                            )?,
                        }
                        if operand != 0 {
                            // The compiler removes the new value first and
                            // leaves the old value as the postfix result.
                            self.stack.push(result);
                            self.stack.push(value);
                        } else {
                            self.stack.push(result);
                        }
                    }
                    Opcode::UnboundName | Opcode::TypeofName => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        // As for `Global`: the realm global object must exist
                        // before a lazily-materialized standard global can be
                        // found on it.
                        self.global("globalThis")?;
                        let value = self.lookup_global_name(&name)?;
                        if instruction.opcode == Opcode::TypeofName {
                            let value = value.unwrap_or(Value::Undefined);
                            self.stack
                                .push(Value::String(self.typeof_value(&value).expect("the interpreter owns this live value and typeof cannot invoke JavaScript").into()));
                        } else {
                            self.stack
                                .push(value.ok_or(RuntimeError::ReferenceError(name))?);
                        }
                    }
                    Opcode::ResolveUnboundName => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let resolves = self.unbound_name_resolves(&name)?;
                        self.stack.push(Value::Bool(resolves));
                    }
                    Opcode::SetUnboundName | Opcode::SetResolvedUnboundName => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        // Stack: [resolved flag,] value. The flag was computed
                        // before the right-hand side ran.
                        let value = self.stack.pop().expect("assignment has a value");
                        let resolved = (instruction.opcode == Opcode::SetResolvedUnboundName)
                            .then(|| self.stack.pop() == Some(Value::Bool(true)));
                        self.stack.push(value.clone());
                        if !self.set_dynamic_eval_binding(&name, value.clone())?
                            && !self.set_global_binding(&name, value.clone())?
                        {
                            let global = self.global("globalThis")?;
                            let global_id = global.object_id().expect("globalThis is an object");
                            let key: PropertyName = name.as_str().into();
                            // Standard globals (`NaN`, `undefined`, ...) are
                            // created lazily; the name resolves once made.
                            self.materialize_lexical_global(global_id, &name)?;
                            let unresolvable = match resolved {
                                Some(resolved) => !resolved,
                                None => !self.has_property(global_id, &key)?,
                            };
                            if code.strict && unresolvable {
                                return Err(RuntimeError::ReferenceError(name));
                            }
                            // A strict write to a binding that resolved but
                            // has since disappeared is also a ReferenceError
                            // (SetMutableBinding of the object record).
                            if code.strict && !self.has_property(global_id, &key)? {
                                return Err(RuntimeError::ReferenceError(name));
                            }
                            self.set_property(&global, &key, &value)?;
                        }
                    }
                    Opcode::DeleteUnboundName => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let deleted = self.delete_unbound_name(&name)?;
                        self.stack.push(Value::Bool(deleted));
                    }
                    Opcode::DeleteWithBinding => {
                        let name = code.constants[operand]
                            .as_string()
                            .expect("compiler emits a name");
                        let name = name.to_utf8().expect("compiler emits a UTF-8 identifier");
                        let mut outcome = Value::Undefined;
                        for object in self.with_objects.clone().into_iter().rev() {
                            if self.with_has_binding(&object, &name)? {
                                let id = object.object_id().expect("with objects are objects");
                                outcome = Value::Bool(if self.is_parameter_eval_env(id) {
                                    self.delete_eval_env_var(id, &name)
                                        .expect("with resolution just validated its retained ordinary parameter-eval environment; deletion cannot allocate")
                                } else {
                                    self.object_delete(id, &name.as_str().into())?
                                });
                                break;
                            }
                        }
                        self.stack.push(outcome);
                    }
                    Opcode::DeleteDynamicBinding => {
                        let deleted = self.delete_eval_var(operand)?;
                        self.stack.push(Value::Bool(deleted));
                    }
                    Opcode::EnterScope => {
                        for slot in &code.scopes[operand] {
                            if let Some(name) = self.eval_dynamic_slots.get(&(*slot as usize)) {
                                let cell = self
                                    .dynamic_eval_bindings
                                    .get(name)
                                    .expect("prepared dynamic eval binding survives execution")
                                    .cell;
                                self.cells.insert(*slot as usize, cell);
                                continue;
                            }
                            if let Some(name) = self.script_global_slots.get(&(*slot as usize)) {
                                let cell = self
                                    .global_bindings
                                    .get(name)
                                    .expect("prepared global binding survives script execution")
                                    .cell;
                                self.cells.insert(*slot as usize, cell);
                                continue;
                            }
                            if code.module
                                && operand == 0
                                && self.cells.contains_key(&(*slot as usize))
                            {
                                // ModuleDeclarationInstantiation seeded this
                                // slot (or linked it to an exporter cell).
                                continue;
                            }
                            self.cells.remove(&(*slot as usize));
                            self.bindings[*slot as usize] =
                                if !code.bindings[*slot as usize].lexical {
                                    Some(Value::Undefined)
                                } else {
                                    None
                                };
                        }
                        self.active_scopes.push(operand as u32);
                        self.active_scope_slots.push(code.scopes[operand].clone());
                    }
                    Opcode::CloneScope => self.clone_scope(code, operand as u32)?,
                    Opcode::LeaveScope => self.leave_scope(code, operand as u32),
                    Opcode::Pop => {
                        self.pop();
                    }
                    Opcode::Dup => self
                        .stack
                        .push(self.stack.last().expect("dup has a value").clone()),
                    Opcode::Dup2 => {
                        let index = self.stack.len() - 2;
                        self.stack.push(self.stack[index].clone());
                        self.stack.push(self.stack[index + 1].clone());
                    }
                    Opcode::Swap => {
                        let index = self.stack.len() - 2;
                        self.stack.swap(index, index + 1);
                    }
                    Opcode::Add => self.binary(Self::add)?,
                    Opcode::Subtract => self.arithmetic(Opcode::Subtract)?,
                    Opcode::Multiply => self.arithmetic(Opcode::Multiply)?,
                    Opcode::Exponentiate => self.exponentiate()?,
                    Opcode::Divide => self.arithmetic(Opcode::Divide)?,
                    Opcode::Remainder => self.arithmetic(Opcode::Remainder)?,
                    Opcode::ShiftLeft | Opcode::ShiftRight | Opcode::UnsignedShiftRight => {
                        self.shift(instruction.opcode)?
                    }
                    Opcode::BitAnd | Opcode::BitXor | Opcode::BitOr => {
                        self.bitwise(instruction.opcode)?
                    }
                    Opcode::StrictEqual => self
                        .binary(|_, a, b| Ok(Value::Bool(a == b)))
                        .expect("strict equality only compares values and cannot fail"),
                    Opcode::StrictNotEqual => self
                        .binary(|_, a, b| Ok(Value::Bool(a != b)))
                        .expect("strict inequality only compares values and cannot fail"),
                    Opcode::Equal => {
                        self.binary(|vm, a, b| vm.loose_equal(a, b).map(Value::Bool))?
                    }
                    Opcode::NotEqual => self
                        .binary(|vm, a, b| vm.loose_equal(a, b).map(|equal| Value::Bool(!equal)))?,
                    Opcode::Instanceof => self.binary(|vm, value, target| {
                        vm.has_instance(value, target, false).map(Value::Bool)
                    })?,
                    Opcode::In => self
                        .binary(|vm, key, object| vm.property_in(&key, &object).map(Value::Bool))?,
                    Opcode::Less => self.relational(|order| order == Ordering::Less)?,
                    Opcode::Greater => self.relational(|order| order == Ordering::Greater)?,
                    Opcode::LessEqual => self.relational(|order| order != Ordering::Greater)?,
                    Opcode::GreaterEqual => self.relational(|order| order != Ordering::Less)?,
                    Opcode::Negate
                    | Opcode::BitNot
                    | Opcode::ToNumber
                    | Opcode::ToNumeric
                    | Opcode::ToString
                    | Opcode::Not
                    | Opcode::Typeof => {
                        let arg = self.stack.last().unwrap().clone();
                        let value = match instruction.opcode {
                            Opcode::Negate => self.negate(&arg)?,
                            Opcode::BitNot => self.bit_not(&arg)?,
                            Opcode::ToNumber => Value::Number(self.coerce_number(&arg)?),
                            Opcode::ToNumeric => match self.coerce_numeric(&arg)? {
                                primitive::Numeric::Number(number) => Value::Number(number),
                                primitive::Numeric::BigInt(value) => Value::BigInt(value),
                            },
                            Opcode::ToString => Value::String(self.coerce_string(&arg)?),
                            Opcode::Not => Value::Bool(!self.to_boolean(&arg).expect("the interpreter operand is live and ToBoolean does not run user code")),
                            _ => Value::String(self.typeof_value(&arg).expect("the interpreter owns this live value and typeof cannot invoke JavaScript").into()),
                        };
                        self.check_string(&value)?;
                        self.pop();
                        self.stack.push(value);
                    }
                    Opcode::PushOne => {
                        // `++`/`--` on a plain identifier: the value just
                        // pushed by `ToNumeric` (possibly duplicated for a
                        // postfix update) determines which "one" to add.
                        let one = match self.stack.last().unwrap() {
                            Value::BigInt(_) => Value::BigInt(BigInt::one()),
                            _ => Value::Number(1.0),
                        };
                        self.stack.push(one);
                    }
                    Opcode::Jump => pc = operand,
                    Opcode::JumpIfFalse | Opcode::JumpIfTrue | Opcode::JumpIfNotNullish => {
                        let arg = self.pop();
                        let take = match instruction.opcode {
                            Opcode::JumpIfFalse => !self.to_boolean(&arg).expect("the interpreter operand is live and ToBoolean does not run user code"),
                            Opcode::JumpIfTrue => self.to_boolean(&arg).expect("the interpreter operand is live and ToBoolean does not run user code"),
                            _ => !matches!(arg, Value::Null | Value::Undefined),
                        };
                        if take {
                            pc = operand;
                        }
                    }
                    Opcode::NewObject => {
                        let prototype = self.object_prototype;
                        let id = self.with_roots(|heap| heap.alloc_object(Some(prototype)))?;
                        self.stack.push(Value::Object(id));
                    }
                    Opcode::NewArray => {
                        let prototype = self.array_prototype;
                        let id = self
                            .with_roots(|heap| heap.alloc_array(operand as u32, Some(prototype)))?;
                        self.stack.push(Value::Object(id));
                    }
                    Opcode::GetProperty | Opcode::GetMethod => {
                        let (receiver, key) = self.property_reference()
                            .expect("property reads consume a prepared source reference or a retained class metadata object and literal key");
                        let value = self.get_property(&receiver, &key)?;
                        self.check_string(&value)?;
                        self.stack.push(value);
                        if instruction.opcode == Opcode::GetMethod {
                            self.stack.push(receiver);
                        }
                    }
                    Opcode::TailCall => {
                        let eval_candidate = operand & 1 != 0;
                        let argument_count = operand >> 1;
                        let base = self.stack.len() - argument_count - 2;
                        let callee = self.stack[base].clone();
                        if eval_candidate
                            && self.is_intrinsic_eval(&callee).expect(
                                "intrinsic eval classification only reads the live callee tag",
                            )
                        {
                            // A direct eval runs in this frame's scope: not a
                            // call that can replace it.
                            let args = self.stack[base + 2..].to_vec();
                            let result = self.direct_eval(native::argument(&args, 0))?;
                            self.check_string(&result)?;
                            self.stack.truncate(base);
                            self.stack.push(result);
                        } else if self.frame_can_be_replaced(code)
                            && self
                                .is_callable(&callee)
                                .expect("the live callee capability check cannot invoke JavaScript")
                        {
                            let values = self.stack.split_off(base);
                            return Ok(Some(Completion::TailCall(values)));
                        } else {
                            // The frame is a construct call (its result is
                            // adjusted after it returns) or the callee is not
                            // callable (a TypeError raised here, in this
                            // frame): an ordinary call, then the `Return`
                            // the compiler emitted after this instruction.
                            let receiver = self.stack[base + 1].clone();
                            let args = self.stack[base + 2..].to_vec();
                            let result = self.call_native(callee, receiver, args, false)?;
                            self.stack.truncate(base);
                            self.stack.push(result);
                        }
                    }
                    Opcode::Call | Opcode::DirectEval | Opcode::Construct => {
                        // Leave every call input on the stack until dispatch
                        // completes, so native allocations see all GC roots.
                        let base = self.stack.len() - operand - 2;
                        let callee = self.stack[base].clone();
                        let receiver = self.stack[base + 1].clone();
                        let args = self.stack[base + 2..].to_vec();
                        let result = if instruction.opcode == Opcode::DirectEval
                            && self.is_intrinsic_eval(&callee).expect(
                                "intrinsic eval classification only reads the live callee tag",
                            ) {
                            let value = self.direct_eval(native::argument(&args, 0))?;
                            self.check_string(&value)?;
                            value
                        } else {
                            let direct_debugger_call = if instruction.opcode == Opcode::Call
                                && self.debugger_nested_pause_request.is_some()
                            {
                                match callee.object_id() {
                                    Some(id) => self.heap.closure(id).expect("the debugger examines a live operand without invoking JavaScript").is_some(),
                                    None => false,
                                }
                            } else {
                                false
                            };
                            let previous = std::mem::replace(
                                &mut self.debugger_nested_direct_call,
                                direct_debugger_call,
                            );
                            let caller_generation = self
                                .debugger_nested_pause_request
                                .is_some()
                                .then_some(code.debugger_program_generation)
                                .flatten();
                            let previous_caller_generation = std::mem::replace(
                                &mut self.debugger_nested_direct_caller_generation,
                                caller_generation,
                            );
                            let result = self.call_native(
                                callee,
                                receiver,
                                args,
                                instruction.opcode == Opcode::Construct,
                            );
                            self.debugger_nested_direct_call = previous;
                            self.debugger_nested_direct_caller_generation =
                                previous_caller_generation;
                            result?
                        };
                        if self.debugger_nested_continuation.is_none() {
                            self.stack.truncate(base);
                            self.stack.push(result);
                        }
                    }
                    Opcode::DiscardReference => {
                        let value = self.pop();
                        let reference_values = operand;
                        let reference_start = self
                            .stack
                            .len()
                            .checked_sub(reference_values)
                            .expect("compiler retains a complete reference");
                        self.stack.truncate(reference_start);
                        self.stack.push(value);
                    }
                    Opcode::SetProperty => {
                        let value = self.pop();
                        let (object, key) = self.property_reference()?;
                        self.set_property(&object, &key, &value)?;
                        self.stack.push(value);
                    }
                    Opcode::SetDestructureProperty => {
                        // A destructuring leaf has already produced its value;
                        // evaluating a member target appends its object/key after
                        // that value. Preserve the value for the caller to pop.
                        let base = self.stack.len() - 3;
                        let value = self.stack[base].clone();
                        let object = self.stack[base + 1].clone();
                        let key = self.coerce_property_key(&self.stack[base + 2].clone())
                            .expect("assign_pattern_target emitted PreparePropertyReference and retained its canonical key");
                        self.set_property(&object, &key, &value)?;
                        self.stack.truncate(base);
                        self.stack.push(value);
                    }
                    Opcode::SetDestructurePropertyReference => {
                        // IteratorStepReference removed the iterator record,
                        // leaving object, raw key and element value in order.
                        let base = self.stack.len() - 3;
                        let object = self.stack[base].clone();
                        let key = self.coerce_property_key(&self.stack[base + 1].clone())?;
                        let value = self.stack[base + 2].clone();
                        self.set_property(&object, &key, &value)?;
                        self.stack.truncate(base);
                        self.stack.push(value);
                    }
                    Opcode::UpdateProperty => {
                        let (object, key) = self.property_reference()
                            .expect("UpdateProperty consumes a compiler-prepared object-coercible base and canonical key");
                        self.stack.push(object.clone());
                        let old_value = self.get_property(&object, &key)?;
                        let (old, new) = self.numeric_step(&old_value, operand & 1 != 0)?;
                        self.set_property(&object, &key, &new)?;
                        self.stack.pop();
                        self.stack.push(if operand & 2 == 0 { old } else { new });
                    }
                    Opcode::SetLiteralPrototype => {
                        let value = self.pop();
                        let object = self
                            .pop()
                            .object_id()
                            .expect("literal receiver is an object");
                        match value {
                            Value::Object(prototype) => self.heap.set_prototype(object, Some(prototype))
                                .expect("an unpublished extensible object literal cannot occur in its live candidate prototype chain"),
                            Value::Null => self.heap.set_prototype(object, None)
                                .expect("the unpublished object literal is extensible"),
                            _ => {} // Literal __proto__ with a primitive value has no effect.
                        }
                    }
                    Opcode::SetCompletion => {
                        self.completion = self.pop();
                        self.completion_empty = false;
                    }
                    Opcode::SetStrictMode => self.strict = operand != 0,
                    Opcode::ClearCompletion => {
                        self.completion = Value::Undefined;
                        self.completion_empty = true;
                    }
                    Opcode::PushHandler => {
                        debug_assert!(operand < code.handlers.len());
                        handlers.push(HandlerFrame {
                            metadata: operand,
                            stack_depth: self.stack.len(),
                            scope_depth: self.active_scopes.len(),
                            iterator_depth: iterators.len(),
                            with_depth: self.with_objects.len(),
                            state: HandlerState::Try,
                            pending: None,
                        });
                    }
                    Opcode::PopHandler => {
                        handlers
                            .pop()
                            .expect("compiler pops its active try handler");
                    }
                    Opcode::EnterFinalizer => {
                        handlers
                            .last_mut()
                            .expect("compiler enters the finalizer of an active try handler")
                            .state = HandlerState::Finally;
                        self.completion_saves
                            .push((self.completion.clone(), self.completion_empty));
                    }
                    Opcode::ResumeCompletion => return Ok(Some(Completion::Resume(operand))),
                    Opcode::MarkDisposables => {
                        self.dispose_marks.push(self.disposables.len());
                    }
                    Opcode::AddDisposableResource => {
                        let value = self.pop();
                        let hint = if operand == 0 {
                            DisposeHint::Sync
                        } else {
                            DisposeHint::Async
                        };
                        let mut disposables = std::mem::take(&mut self.disposables);
                        let result = self.add_disposable_resource(&mut disposables, value, hint);
                        self.disposables = disposables;
                        result?;
                    }
                    Opcode::DisposeResources => {
                        let mark = self
                            .dispose_marks
                            .pop()
                            .expect("compiler matches every DisposeResources with a mark");
                        let resources = self.disposables.split_off(mark);
                        // The handler's frame stays on the runtime handler
                        // stack (in `Finally` state) until `ResumeCompletion`
                        // runs after this opcode; only an abrupt entry has a
                        // pending completion; see
                        // `Opcode::DisposeResources`'s definition.
                        let frame = handlers
                            .last()
                            .expect("resource disposal is compiled inside its synthetic finalizer");
                        assert_eq!(
                            frame.metadata, operand,
                            "the disposal operand identifies the active synthetic finalizer"
                        );
                        let prior = frame
                            .pending
                            .map(|index| self.pending_completions[index].clone());
                        let prior = match prior {
                            Some(Completion::Throw(error)) => Some(error),
                            _ => None,
                        };
                        self.dispose_resources_sync(resources, prior)?;
                    }
                    Opcode::DrainAsyncDisposables => {
                        let mark = self
                            .dispose_marks
                            .pop()
                            .expect("compiler matches every DrainAsyncDisposables with a mark");
                        let resources = self.disposables.split_off(mark);
                        // See `Opcode::DisposeResources`'s own comment: same
                        // abrupt-vs-normal-entry distinction, same handler
                        // index trick.
                        let frame = handlers
                            .last()
                            .expect("resource disposal is compiled inside its synthetic finalizer");
                        assert_eq!(
                            frame.metadata, operand,
                            "the disposal operand identifies the active synthetic finalizer"
                        );
                        let prior = frame
                            .pending
                            .map(|index| self.pending_completions[index].clone());
                        let prior = match prior {
                            Some(Completion::Throw(error)) => Some(error),
                            _ => None,
                        };
                        let value = self.build_async_dispose_state(resources, prior)?;
                        self.stack.push(value);
                    }
                    Opcode::AbruptJump => {
                        let jump = &code.abrupt_jumps[operand];
                        return Ok(Some(Completion::Jump {
                            cleanup: jump.cleanup as usize,
                            target: jump.target as usize,
                        }));
                    }
                    Opcode::Halt => return Ok(Some(Completion::Halt(self.completion.clone()))),
                }
                Ok(None)
            })();
            let new_throw = match &outcome {
                Ok(Some(Completion::Throw(error))) => error.is_catchable(),
                Err(error) if error.is_catchable() => {
                    self.throw_epoch == throw_epoch_before || self.pending_throw_site.is_none()
                }
                _ => false,
            };
            let completion = match outcome {
                Ok(completion) => completion,
                Err(error) if error.is_catchable() => Some(Completion::Throw(error)),
                Err(error) => return Err(error),
            };
            if new_throw {
                self.throw_epoch = self.throw_epoch.wrapping_add(1);
                self.pending_throw_site = code
                    .debugger_program_generation
                    .zip(code.debugger_code_unit_ordinal)
                    .zip(u32::try_from(instruction.offset).ok())
                    .map(
                        |((program_generation, code_unit_ordinal), bytecode_offset)| {
                            VmDebuggerThrowSite {
                                program_generation,
                                code_unit_ordinal,
                                bytecode_offset,
                            }
                        },
                    );
            }
            if self.debugger_nested_continuation.is_some() {
                debug_assert!(matches!(
                    instruction.opcode,
                    Opcode::Call | Opcode::CallClassStaticBlock
                ));
                for handler in &mut handlers {
                    handler.stack_depth -= handler_stack_base;
                }
                return Ok(InterpreterExit::Suspend {
                    pc: instruction.offset,
                    iterators: std::mem::take(iterators),
                    handlers: std::mem::take(&mut handlers),
                });
            }
            if let Some(promise) = suspended_await.take() {
                for handler in &mut handlers {
                    handler.stack_depth -= handler_stack_base;
                }
                return Ok(InterpreterExit::Await {
                    promise,
                    pc,
                    handlers: std::mem::take(&mut handlers),
                });
            }
            if let Some(completion) = completion {
                if let Completion::Yield(value) = completion {
                    for handler in &mut handlers {
                        handler.stack_depth -= handler_stack_base;
                    }
                    return Ok(InterpreterExit::Yield {
                        value,
                        pc,
                        iterators: std::mem::take(iterators),
                        handlers: std::mem::take(&mut handlers),
                    });
                }
                match self.resolve_completion(code, &mut handlers, iterators, completion)? {
                    CompletionAction::Continue => {}
                    CompletionAction::Jump(target) => pc = target,
                    CompletionAction::Return(value) => return Ok(InterpreterExit::Return(value)),
                    CompletionAction::TailCall(values) => {
                        // The frame ends here; `call_with_target` runs the
                        // callee at this frame's depth once it is torn down.
                        self.pending_tail_call = Some(values);
                        return Ok(InterpreterExit::Return(Value::Undefined));
                    }
                    CompletionAction::TailRecur(args) => {
                        self.stack.truncate(stack_base);
                        self.unwind_scopes(code, 0);
                        self.unwind_with(0);
                        self.close_iterators_to(iterators, 0);
                        handlers.clear();
                        self.pending_completions.truncate(pending_base);
                        self.completion_saves.truncate(save_base);
                        self.completion = Value::Undefined;
                        self.completion_empty = true;
                        self.this = Value::Undefined;
                        self.arguments = args;
                        pc = 0;
                    }
                    CompletionAction::Throw(error) => return Err(error),
                }
            }
            executed_root_instruction = true;
        }
    }
}
