// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

use super::*;

/// Helpers that share the single-source callback loop. Composite helpers
/// retain their own state machines and never enter this dispatch type.
#[derive(PartialEq)]
enum SingleSourceHelperKind {
    Map,
    Filter,
    Take,
    Drop,
    FlatMap,
}

impl Vm {
    pub(in super::super::super) fn iterator_helper_next(
        &mut self,
        receiver: &Value,
    ) -> Result<Value, RuntimeError> {
        let Value::Object(helper) = receiver else {
            return Err(RuntimeError::TypeError(
                "Iterator helper next requires an iterator helper".into(),
            ));
        };
        let Some(state) = self.heap.iterator_helper(*helper)? else {
            return Err(RuntimeError::TypeError(
                "Iterator helper next requires an iterator helper".into(),
            ));
        };
        let kind = match state.kind {
            IteratorHelperKind::Concat => {
                return self.iterator_concat_next(*helper, receiver, &state)
            }
            IteratorHelperKind::Zip | IteratorHelperKind::ZipKeyed => {
                return self.iterator_zip_next(*helper, receiver, &state)
            }
            IteratorHelperKind::Chunks => {
                return self.iterator_chunks_next(*helper, receiver, &state)
            }
            IteratorHelperKind::Windows => {
                return self.iterator_windows_next(*helper, receiver, &state)
            }
            IteratorHelperKind::Map => SingleSourceHelperKind::Map,
            IteratorHelperKind::Filter => SingleSourceHelperKind::Filter,
            IteratorHelperKind::Take => SingleSourceHelperKind::Take,
            IteratorHelperKind::Drop => SingleSourceHelperKind::Drop,
            IteratorHelperKind::FlatMap => SingleSourceHelperKind::FlatMap,
        };
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(Value::Object(state.record));
        self.stack.push(state.callback.clone());
        let record = Value::Object(state.record);
        let result = (|| {
            self.heap
                .begin_iterator_helper(*helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            loop {
                if kind == SingleSourceHelperKind::Take && state.index == 0 {
                    self.heap
                        .finish_iterator_helper(*helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                    self.iterator_close(&record)?;
                    return self.iterator_result(Value::Undefined, true);
                }
                if kind == SingleSourceHelperKind::FlatMap {
                    let inner = self
                        .heap
                        .get_own(state.record, "flatMapInner")
                        .expect("the rooted helper retains its private metadata");
                    if let Some(inner @ Value::Object(_)) = inner {
                        self.stack.push(inner.clone());
                        let next = self.iterator_step(&inner, true);
                        self.stack.pop();
                        if let Some(value) = next? {
                            self.stack.push(value.clone());
                            let result = self.iterator_result(value, false);
                            self.stack.pop();
                            return result;
                        }
                        self.heap
                            .set(state.record, "flatMapInner", Value::Undefined)
                            .expect("clearing private iterator storage requires no heap growth");
                    }
                }
                let Some(value) = self.iterator_step(&record, true)? else {
                    self.heap
                        .finish_iterator_helper(*helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                    return self.iterator_result(Value::Undefined, true);
                };
                match kind {
                    SingleSourceHelperKind::Take => {
                        self.heap
                            .consume_iterator_helper_take(*helper)
                            .expect("the validated, rooted iterator helper keeps its brand");
                        self.stack.push(value.clone());
                        let result = self.iterator_result(value, false);
                        self.stack.pop();
                        return result;
                    }
                    SingleSourceHelperKind::Drop => {
                        let remaining = self
                            .heap
                            .iterator_helper(*helper)
                            .expect("the validated iterator helper remains rooted")
                            .expect("iterator helper state remains live")
                            .index;
                        if remaining > 0 {
                            self.heap
                                .consume_iterator_helper_take(*helper)
                                .expect("the validated, rooted iterator helper keeps its brand");
                            continue;
                        }
                        self.stack.push(value.clone());
                        let result = self.iterator_result(value, false);
                        self.stack.pop();
                        return result;
                    }
                    SingleSourceHelperKind::Map => {
                        let callback_result = self.iterator_helper_callback(*helper, &value)?;
                        self.stack.pop();
                        self.stack.push(callback_result.clone());
                        let result = self.iterator_result(callback_result, false);
                        self.stack.pop();
                        return result;
                    }
                    SingleSourceHelperKind::Filter => {
                        let callback_result = self.iterator_helper_callback(*helper, &value)?;
                        // ToBoolean is a pure read; the callback result is live
                        // and conversion cannot invoke user code.
                        let selected = self.to_boolean(&callback_result).expect(
                            "ToBoolean cannot fail for the freshly returned callback value",
                        );
                        if selected {
                            let result = self.iterator_result(value, false);
                            self.stack.pop();
                            return result;
                        }
                        self.stack.pop();
                    }
                    SingleSourceHelperKind::FlatMap => {
                        let mapped = self.iterator_helper_callback(*helper, &value)?;
                        self.stack.pop();
                        self.stack.push(mapped.clone());
                        let inner = self.iterator_flattenable_record(&mapped);
                        self.stack.pop();
                        let inner = inner?;
                        self.stack.push(inner.clone());
                        self.heap.set(state.record, "flatMapInner", inner).expect(
                            "replacing a private object-or-undefined slot requires no heap growth",
                        );
                        self.stack.pop();
                    }
                }
            }
        })();
        if result.is_err() {
            self.heap
                .finish_iterator_helper(*helper)
                .expect("the validated, rooted iterator helper keeps its brand");
        } else if !self
            .heap
            .iterator_helper(*helper)
            .expect("the validated iterator helper remains rooted")
            .is_some_and(|state| state.done)
        {
            self.heap
                .leave_iterator_helper(*helper)
                .expect("the validated, rooted iterator helper keeps its brand");
        }
        self.stack.truncate(base + 3);
        let result = self.close_iterator_on_error(&record, result);
        self.stack.truncate(base);
        result
    }

    pub(in super::super::super) fn iterator_concat_next(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let metadata = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(metadata.clone());
        let outcome = (|| {
            self.heap
                .begin_iterator_helper(helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            loop {
                if let Some(current @ Value::Object(_)) = self
                    .heap
                    .get_own(state.record, "concatCurrent")
                    .expect("the rooted helper retains its private metadata")
                {
                    self.stack.push(current.clone());
                    let next = self.iterator_step(&current, true);
                    self.stack.pop();
                    if let Some(value) = next? {
                        self.stack.push(value.clone());
                        let result = self.iterator_result(value, false);
                        self.stack.pop();
                        return result;
                    }
                    self.heap
                        .set(state.record, "concatCurrent", Value::Undefined)
                        .expect("clearing private iterator storage requires no heap growth");
                    continue;
                }

                let current_state = self
                    .heap
                    .iterator_helper(helper)
                    .expect("the validated iterator helper remains rooted")
                    .expect("concat helper state remains live");
                let length = self
                    .heap
                    .get_own(state.record, "concatLength")
                    .expect("the rooted helper retains its private metadata")
                    .and_then(|value| value.as_number().map(|value| value as u64))
                    .expect("concat state stores its argument count");
                if current_state.index >= length {
                    self.heap
                        .finish_iterator_helper(helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                    return self.iterator_result(Value::Undefined, true);
                }
                let index = current_state.index;
                let iterable = self
                    .heap
                    .get_own(state.record, format!("concatIterable{index}"))
                    .expect("the rooted helper retains its private metadata")
                    .expect("concat state stores every iterable");
                let open = self
                    .heap
                    .get_own(state.record, format!("concatOpen{index}"))
                    .expect("the rooted helper retains its private metadata")
                    .expect("concat state stores every iterator method");
                self.stack.push(iterable.clone());
                self.stack.push(open.clone());
                let opened = self.call_native(open, iterable, Vec::new(), false)?;
                self.stack.pop();
                self.stack.pop();
                if !matches!(opened, Value::Object(_)) {
                    return Err(RuntimeError::TypeError(
                        "Iterator.concat iterator method must return an object".into(),
                    ));
                }
                self.stack.push(opened.clone());
                let direct = self.direct_iterator_record(&opened)?;
                self.stack.pop();
                self.stack.push(direct.clone());
                self.heap
                    .set(state.record, "concatCurrent", direct)
                    .expect("replacing a private object-or-undefined slot requires no heap growth");
                self.heap
                    .advance_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                self.stack.pop();
            }
        })();
        let outcome = match outcome {
            Ok(value) => {
                if !self
                    .heap
                    .iterator_helper(helper)
                    .expect("the validated iterator helper remains rooted")
                    .is_some_and(|state| state.done)
                {
                    self.heap
                        .leave_iterator_helper(helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                }
                Ok(value)
            }
            Err(error) => {
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                self.close_concat_on_error(&metadata, error)
            }
        };
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super::super) fn iterator_zip_next(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let metadata = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(metadata.clone());
        let outcome = (|| {
            self.heap
                .begin_iterator_helper(helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            let count = self
                .heap
                .get_own(state.record, "zipCount")
                .expect("the rooted helper retains its private metadata")
                .and_then(|value| value.as_number().map(|value| value as u64))
                .expect("zip metadata stores its source count");
            let mode = self
                .heap
                .get_own(state.record, "zipMode")
                .expect("the rooted helper retains its private metadata")
                .expect("zip metadata stores its mode");
            let mode = mode.as_string().expect("zip mode is a string").clone();
            if count == 0 {
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                return self.iterator_result(Value::Undefined, true);
            }
            let values_base = self.stack.len();
            let result = (|| {
                let mut values = Vec::new();
                let mut any_done = false;
                let mut all_done = true;
                for index in 0..count {
                    let record = self
                        .heap
                        .get_own(state.record, format!("zipRecord{index}"))
                        .expect("the rooted helper retains its private metadata")
                        .expect("zip metadata stores every source record");
                    self.stack.push(record.clone());
                    let step = self.iterator_step(&record, true);
                    self.stack.pop();
                    match step? {
                        Some(value) => {
                            all_done = false;
                            self.stack.push(value.clone());
                            values.push(Some(value));
                        }
                        None => {
                            any_done = true;
                            if mode == "strict" {
                                if index != 0 {
                                    self.heap.finish_iterator_helper(helper).expect(
                                        "the validated, rooted iterator helper keeps its brand",
                                    );
                                    let _ = self.iterator_zip_close_records(state.record, count);
                                    return Err(RuntimeError::TypeError(
                                        "Iterator.zip strict sources have different lengths".into(),
                                    ));
                                }
                                for remaining in 1..count {
                                    let record = self
                                        .heap
                                        .get_own(state.record, format!("zipRecord{remaining}"))
                                        .expect("the rooted helper retains its private metadata")
                                        .expect("zip metadata stores every source record");
                                    self.stack.push(record.clone());
                                    let step = self.iterator_step(&record, true);
                                    self.stack.pop();
                                    if step?.is_some() {
                                        self.heap
                                            .finish_iterator_helper(helper)
                                            .expect("the validated iterator helper remains rooted");
                                        let _ =
                                            self.iterator_zip_close_records(state.record, count);
                                        return Err(RuntimeError::TypeError(
                                            "Iterator.zip strict sources have different lengths"
                                                .into(),
                                        ));
                                    }
                                }
                                self.heap.finish_iterator_helper(helper).expect(
                                    "the validated, rooted iterator helper keeps its brand",
                                );
                                return self.iterator_result(Value::Undefined, true);
                            }
                            values.push(None);
                        }
                    }
                    if mode == "shortest" && any_done {
                        self.iterator_zip_close_records(state.record, count)?;
                        self.heap
                            .finish_iterator_helper(helper)
                            .expect("the validated, rooted iterator helper keeps its brand");
                        return self.iterator_result(Value::Undefined, true);
                    }
                }
                if mode == "longest" {
                    if all_done {
                        self.heap
                            .finish_iterator_helper(helper)
                            .expect("the validated, rooted iterator helper keeps its brand");
                        return self.iterator_result(Value::Undefined, true);
                    }
                    for (index, value) in values.iter_mut().enumerate() {
                        if value.is_none() {
                            let padding = self
                                .heap
                                .get_own(state.record, format!("zipPadding{index}"))
                                .expect("the rooted helper retains its private metadata")
                                .expect("zip metadata stores every padding value");
                            self.stack.push(padding.clone());
                            *value = Some(padding);
                        }
                    }
                }
                let values = values
                    .into_iter()
                    .map(|value| value.expect("non-longest modes have no completed source"))
                    .collect();
                let values = if state.kind == IteratorHelperKind::Zip {
                    self.array_from(values)?
                } else {
                    self.iterator_zip_keyed_results(state.record, values)?
                };
                // Adding the marker property grows the helper's state, which
                // can run a major collection: root the result first.
                self.stack.push(values.clone());
                self.with_roots(|heap| heap.set(state.record, "zipStarted", Value::Bool(true)))?;
                let result = self.iterator_result(values, false);
                self.stack.pop();
                result
            })();
            self.stack.truncate(values_base);
            result
        })();
        let outcome = match outcome {
            Ok(value) => {
                if !self
                    .heap
                    .iterator_helper(helper)
                    .expect("the validated iterator helper remains rooted")
                    .is_some_and(|state| state.done)
                {
                    self.heap
                        .leave_iterator_helper(helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                }
                Ok(value)
            }
            Err(error) => {
                // The thrown value is referenced only by this Rust local,
                // while finishing the helper and closing every source run
                // JavaScript and may collect.
                self.root_thrown(&error);
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                let _ = self.iterator_zip_close_records(
                    state.record,
                    self.iterator_zip_count(state.record)
                        .expect("zip factories install a numeric source count"),
                );
                Err(error)
            }
        };
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super::super) fn iterator_zip_keyed_results(
        &mut self,
        metadata: ObjectId,
        values: Vec<Value>,
    ) -> Result<Value, RuntimeError> {
        let result = self.with_roots(|heap| heap.alloc_object(None))?;
        let base = self.stack.len();
        self.stack.push(Value::Object(result));
        let outcome = (|| {
            for (index, value) in values.into_iter().enumerate() {
                let key = self
                    .heap
                    .get_own(metadata, format!("zipKey{index}"))
                    .expect("the rooted zipKeyed helper retains its private metadata")
                    .expect("zipKeyed metadata stores every source key");
                let key = self
                    .coerce_property_key(&key)
                    .expect("a stored own property key is a String or Symbol");
                self.stack.push(value.clone());
                // The unpublished result is a fresh ordinary object. Use the
                // shared data-property installation and its allocation guard.
                self.define_data(result, key, value, true, true, true)?;
                self.stack.pop();
            }
            Ok(Value::Object(result))
        })();
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super::super) fn iterator_zip_count(
        &self,
        metadata: ObjectId,
    ) -> Result<u64, RuntimeError> {
        self.heap
            .get_own(metadata, "zipCount")?
            .and_then(|value| value.as_number().map(|value| value as u64))
            .ok_or_else(|| RuntimeError::TypeError("invalid Iterator.zip state".into()))
    }

    pub(in super::super::super) fn iterator_zip_close_records(
        &mut self,
        metadata: ObjectId,
        count: u64,
    ) -> Result<(), RuntimeError> {
        let mut completion = None;
        let base = self.stack.len();
        for index in (0..count).rev() {
            let record = self
                .heap
                .get_own(metadata, format!("zipRecord{index}"))
                .expect("zip cleanup retains its private metadata")
                .expect("zip metadata stores every source record");
            self.stack.push(record.clone());
            let close = self.iterator_close(&record);
            self.stack.pop();
            if let Err(error) = close {
                // IteratorCloseAll continues after an abrupt `return`. The
                // first such error becomes the completion; later close errors
                // cannot replace it, but their `return` methods still run,
                // so the retained error must stay rooted meanwhile.
                if completion.is_none() {
                    self.root_thrown(&error);
                    completion = Some(error);
                }
            }
        }
        self.stack.truncate(base);
        if let Some(error) = completion {
            return Err(error);
        }
        Ok(())
    }

    /// Like [`Self::iterator_zip_close_records`] for a completion that is
    /// already a throw: the in-flight error stays rooted while every `return`
    /// method runs, and an error from one of them is discarded.
    pub(in super::super::super) fn iterator_zip_close_records_after(
        &mut self,
        metadata: ObjectId,
        count: u64,
        error: &RuntimeError,
    ) {
        let base = self.stack.len();
        self.root_thrown(error);
        let _ = self.iterator_zip_close_records(metadata, count);
        self.stack.truncate(base);
    }

    /// Keeps the value of a throw completion alive on the VM stack. The
    /// caller truncates the stack once the error has been handed onward.
    pub(in super::super::super) fn root_thrown(&mut self, error: &RuntimeError) {
        if let RuntimeError::Thrown(value) = error {
            self.stack.push(value.clone());
        }
    }

    pub(in super::super::super) fn iterator_chunks_next(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let record = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(record.clone());
        let outcome = (|| {
            self.heap
                .begin_iterator_helper(helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            let values_base = self.stack.len();
            let chunk = (|| {
                let mut values = Vec::new();
                for _ in 0..state.index {
                    let Some(value) = self.iterator_step(&record, true)? else {
                        break;
                    };
                    self.stack.push(value.clone());
                    values.push(value);
                }
                if values.is_empty() {
                    return Ok(None);
                }
                self.array_from(values).map(Some)
            })();
            self.stack.truncate(values_base);
            let Some(chunk) = chunk? else {
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                return self.iterator_result(Value::Undefined, true);
            };
            self.stack.push(chunk.clone());
            let result = self.iterator_result(chunk, false);
            self.stack.pop();
            result
        })();
        let outcome = match outcome {
            Ok(value) => {
                if !self
                    .heap
                    .iterator_helper(helper)
                    .expect("the validated iterator helper remains rooted")
                    .is_some_and(|state| state.done)
                {
                    self.heap
                        .leave_iterator_helper(helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                }
                Ok(value)
            }
            Err(error) => {
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                self.close_iterator_on_error(&record, Err(error))
            }
        };
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super::super) fn iterator_windows_next(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let record = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(record.clone());
        let outcome = (|| {
            self.heap
                .begin_iterator_helper(helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            let values_base = self.stack.len();
            let window = (|| {
                let allow_partial = matches!(
                    self.heap
                        .get_own(state.record, "windowsAllowPartial")
                        .expect("the rooted helper retains its private metadata"),
                    Some(Value::Bool(true))
                );
                let prior = self
                    .heap
                    .get_own(state.record, "windowsBuffer")
                    .expect("the rooted helper retains its private metadata");
                let mut values = Vec::new();
                if let Some(Value::Object(buffer)) = prior {
                    // A full prior window slides by one element. Its private
                    // buffer is ordinary traced storage, but every value is
                    // rooted while the next pull can allocate or invoke JS.
                    for index in 1..state.index {
                        let value = self
                            .heap
                            .get_own(buffer, index.to_string())
                            .expect("the private window buffer is retained by the rooted helper")
                            .expect("window buffer has the requested length");
                        self.stack.push(value.clone());
                        values.push(value);
                    }
                    let Some(value) = self.iterator_step(&record, true)? else {
                        self.heap
                            .finish_iterator_helper(helper)
                            .expect("the validated, rooted iterator helper keeps its brand");
                        return Ok(None);
                    };
                    self.stack.push(value.clone());
                    values.push(value);
                } else {
                    for _ in 0..state.index {
                        let Some(value) = self.iterator_step(&record, true)? else {
                            self.heap
                                .finish_iterator_helper(helper)
                                .expect("the validated, rooted iterator helper keeps its brand");
                            if allow_partial && !values.is_empty() {
                                return self.array_from(values).map(Some);
                            }
                            return Ok(None);
                        };
                        self.stack.push(value.clone());
                        values.push(value);
                    }
                }
                // A yielded full window becomes the next private sliding
                // buffer, while the caller receives a distinct Array.
                let buffer = self.array_from(values.clone())?;
                self.stack.push(buffer.clone());
                self.heap
                    .set(state.record, "windowsBuffer", buffer)
                    .expect("replacing a private object-or-undefined slot requires no heap growth");
                self.stack.pop();
                self.array_from(values).map(Some)
            })();
            let Some(window) = window? else {
                self.stack.truncate(values_base);
                return self.iterator_result(Value::Undefined, true);
            };
            self.stack.push(window.clone());
            let result = self.iterator_result(window, false);
            self.stack.pop();
            self.stack.truncate(values_base);
            result
        })();
        let outcome = match outcome {
            Ok(value) => {
                if !self
                    .heap
                    .iterator_helper(helper)
                    .expect("the validated iterator helper remains rooted")
                    .is_some_and(|state| state.done)
                {
                    self.heap
                        .leave_iterator_helper(helper)
                        .expect("the validated, rooted iterator helper keeps its brand");
                }
                Ok(value)
            }
            Err(error) => {
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                self.close_iterator_on_error(&record, Err(error))
            }
        };
        self.stack.truncate(base);
        outcome
    }

    pub(in super::super::super) fn close_concat_on_error<T>(
        &mut self,
        metadata: &Value,
        error: RuntimeError,
    ) -> Result<T, RuntimeError> {
        let metadata = metadata
            .object_id()
            .expect("concat metadata is an ordinary object");
        let current = self
            .heap
            .get_own(metadata, "concatCurrent")
            .expect("concat cleanup retains its private metadata");
        if let Some(current @ Value::Object(_)) = current {
            self.stack.push(current.clone());
            let result = self.close_iterator_on_error(&current, Err(error));
            self.stack.pop();
            result
        } else {
            Err(error)
        }
    }

    pub(in super::super::super) fn iterator_helper_callback(
        &mut self,
        helper: ObjectId,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        let state = self
            .heap
            .iterator_helper(helper)
            .expect("the validated iterator helper remains rooted")
            .expect("iterator helper state remains live");
        if state.index >= 9_007_199_254_740_991 {
            return Err(RuntimeError::RangeError(
                "Iterator helper index exceeds the safe integer range".into(),
            ));
        }
        let base = self.stack.len();
        self.stack.push(Value::Object(helper));
        self.stack.push(value.clone());
        let callback_result = self.call_native(
            state.callback.clone(),
            Value::Undefined,
            vec![value.clone(), Value::Number(state.index as f64)],
            false,
        );
        let callback_result = match callback_result {
            Ok(result) => result,
            Err(error) => {
                self.stack.truncate(base);
                return Err(error);
            }
        };
        self.heap
            .advance_iterator_helper(helper)
            .expect("the validated, rooted iterator helper keeps its brand");
        self.stack.remove(base);
        Ok(callback_result)
    }

    pub(in super::super::super) fn close_direct_iterator_on_error<T>(
        &mut self,
        iterator: &Value,
        error: RuntimeError,
    ) -> Result<T, RuntimeError> {
        let base = self.stack.len();
        if let RuntimeError::Thrown(value) = &error {
            self.stack.push(value.clone());
        }
        let _ = self.iterator_close_direct(iterator);
        self.stack.truncate(base);
        Err(error)
    }

    pub(in super::super::super) fn iterator_includes(
        &mut self,
        receiver: &Value,
        search_element: &Value,
        skipped_elements: &Value,
    ) -> Result<Value, RuntimeError> {
        if !matches!(receiver, Value::Object(_)) {
            return Err(RuntimeError::TypeError(
                "Iterator helper requires an object receiver".into(),
            ));
        }
        self.stack.push(receiver.clone());
        self.stack.push(search_element.clone());
        let result = (|| {
            // `includes` intentionally does not apply ToNumber to its
            // optional skip count. It accepts only integral Numbers and
            // infinities, and validates before reading `next`.
            let to_skip = match skipped_elements {
                Value::Undefined => 0.0,
                Value::Number(number)
                    if !number.is_nan() && (number.is_infinite() || number.fract() == 0.0) =>
                {
                    *number
                }
                _ => {
                    return self.close_direct_iterator_on_error(
                        receiver,
                        RuntimeError::TypeError(
                            "Iterator.includes skippedElements must be an integral Number".into(),
                        ),
                    )
                }
            };
            if to_skip < 0.0 {
                return self.close_direct_iterator_on_error(
                    receiver,
                    RuntimeError::RangeError(
                        "Iterator.includes skippedElements must not be negative".into(),
                    ),
                );
            }
            if to_skip.is_finite() && to_skip > 9_007_199_254_740_991.0 {
                return self.close_direct_iterator_on_error(
                    receiver,
                    RuntimeError::RangeError(
                        "Iterator.includes skippedElements exceeds MAX_SAFE_INTEGER".into(),
                    ),
                );
            }
            let mut skipped = to_skip;
            let record = self.direct_iterator_record(receiver)?;
            self.stack.push(record.clone());
            let result = (|| {
                while let Some(value) = self.iterator_step(&record, true)? {
                    if skipped > 0.0 {
                        skipped -= 1.0;
                        continue;
                    }
                    if Self::same_value_zero(&value, search_element) {
                        self.iterator_close(&record)?;
                        return Ok(Value::Bool(true));
                    }
                }
                Ok(Value::Bool(false))
            })();
            self.stack.pop();
            self.close_iterator_on_error(&record, result)
        })();
        self.stack.pop();
        self.stack.pop();
        result
    }

    pub(in super::super::super) fn same_value_zero(left: &Value, right: &Value) -> bool {
        match (left, right) {
            (Value::Number(left), Value::Number(right)) => {
                left == right || (left.is_nan() && right.is_nan())
            }
            _ => left == right,
        }
    }

    pub(in super::super::super) fn iterator_join(
        &mut self,
        receiver: &Value,
        separator: &Value,
    ) -> Result<Value, RuntimeError> {
        if !matches!(receiver, Value::Object(_)) {
            return Err(RuntimeError::TypeError(
                "Iterator helper requires an object receiver".into(),
            ));
        }
        self.stack.push(receiver.clone());
        let result = (|| {
            // The separator is coerced before `next` is fetched. Its abrupt
            // conversion closes the direct iterator record without observing
            // that property.
            let separator = if *separator == Value::Undefined {
                ",".into()
            } else {
                match self.coerce_string(separator) {
                    Ok(separator) => separator,
                    Err(error) => return self.close_direct_iterator_on_error(receiver, error),
                }
            };
            let record = self.direct_iterator_record(receiver)?;
            self.stack.push(record.clone());
            let result = (|| {
                let mut result = JsString::default();
                let mut first = true;
                while let Some(value) = self.iterator_step(&record, true)? {
                    if !first {
                        native::append(&mut result, &separator, self.config.max_string_bytes)?;
                    }
                    first = false;
                    if !matches!(value, Value::Null | Value::Undefined) {
                        self.stack.push(value.clone());
                        let text = self.coerce_string(&value);
                        self.stack.pop();
                        let text = text?;
                        native::append(&mut result, &text, self.config.max_string_bytes)?;
                    }
                }
                Ok(Value::String(result))
            })();
            self.stack.pop();
            self.close_iterator_on_error(&record, result)
        })();
        self.stack.pop();
        result
    }

    pub(in super::super::super) fn iterator_helper_return(
        &mut self,
        receiver: &Value,
    ) -> Result<Value, RuntimeError> {
        let Value::Object(helper) = receiver else {
            return Err(RuntimeError::TypeError(
                "Iterator helper return requires an iterator helper".into(),
            ));
        };
        let Some(state) = self.heap.iterator_helper(*helper)? else {
            return Err(RuntimeError::TypeError(
                "Iterator helper return requires an iterator helper".into(),
            ));
        };
        if state.kind == IteratorHelperKind::Concat {
            return self.iterator_concat_return(*helper, receiver, &state);
        }
        if matches!(
            state.kind,
            IteratorHelperKind::Zip | IteratorHelperKind::ZipKeyed
        ) {
            return self.iterator_zip_return(*helper, receiver, &state);
        }
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        self.stack.push(receiver.clone());
        self.stack.push(Value::Object(state.record));
        let record = Value::Object(state.record);
        let result = (|| {
            self.heap
                .begin_iterator_helper(*helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            if state.kind == IteratorHelperKind::FlatMap {
                if let Some(inner @ Value::Object(_)) = self
                    .heap
                    .get_own(state.record, "flatMapInner")
                    .expect("the rooted helper retains its private metadata")
                {
                    self.stack.push(inner.clone());
                    let inner_result = self.iterator_close(&inner);
                    self.stack.pop();
                    if let Err(error) = inner_result {
                        return self.close_iterator_on_error(&record, Err(error));
                    }
                }
            }
            self.iterator_close(&record)?;
            self.iterator_result(Value::Undefined, true)
        })();
        self.heap
            .finish_iterator_helper(*helper)
            .expect("the validated, rooted iterator helper keeps its brand");
        self.stack.pop();
        self.stack.pop();
        result
    }

    pub(in super::super::super) fn iterator_concat_return(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let metadata = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(metadata.clone());
        let result = (|| {
            self.heap
                .begin_iterator_helper(helper)
                .expect("the validated, rooted iterator helper keeps its brand");
            if let Some(current @ Value::Object(_)) = self
                .heap
                .get_own(state.record, "concatCurrent")
                .expect("the rooted helper retains its private metadata")
            {
                self.stack.push(current.clone());
                let close = self.iterator_close(&current);
                self.stack.pop();
                close?;
            }
            self.iterator_result(Value::Undefined, true)
        })();
        self.heap
            .finish_iterator_helper(helper)
            .expect("the validated, rooted iterator helper keeps its brand");
        self.stack.truncate(base);
        result
    }

    pub(in super::super::super) fn iterator_zip_return(
        &mut self,
        helper: ObjectId,
        receiver: &Value,
        state: &IteratorHelperState,
    ) -> Result<Value, RuntimeError> {
        if state.done {
            return self.iterator_result(Value::Undefined, true);
        }
        if state.executing {
            return Err(RuntimeError::TypeError(
                "Iterator helper is already executing".into(),
            ));
        }
        let metadata = Value::Object(state.record);
        let base = self.stack.len();
        self.stack.push(receiver.clone());
        self.stack.push(metadata);
        let result = (|| {
            let started = matches!(
                self.heap
                    .get_own(state.record, "zipStarted")
                    .expect("the rooted helper retains its private metadata"),
                Some(Value::Bool(true))
            );
            if started {
                // Resuming a suspended yield runs the close handlers while
                // the helper is executing, so their re-entrant `next`/return
                // calls see the GeneratorValidate TypeError.
                self.heap
                    .begin_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                let close = self.iterator_zip_close_records(
                    state.record,
                    self.iterator_zip_count(state.record)
                        .expect("zip factories install a numeric source count"),
                );
                if let Err(error) = &close {
                    self.root_thrown(error);
                }
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                close?;
            } else {
                // GeneratorClose from suspended-start completes the helper
                // before the close handlers run. Re-entrant `next` therefore
                // returns the completed iterator result.
                self.heap
                    .finish_iterator_helper(helper)
                    .expect("the validated, rooted iterator helper keeps its brand");
                self.iterator_zip_close_records(
                    state.record,
                    self.iterator_zip_count(state.record)
                        .expect("zip factories install a numeric source count"),
                )?;
            }
            self.iterator_result(Value::Undefined, true)
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super::super) fn iterator_callback(
        &mut self,
        callback: &Value,
        value: Value,
        index: u64,
    ) -> Result<Value, RuntimeError> {
        if !self.is_callable(callback)? {
            return Err(RuntimeError::TypeError(
                "Iterator helper callback must be callable".into(),
            ));
        }
        self.call_native(
            callback.clone(),
            Value::Undefined,
            vec![value, Value::Number(index as f64)],
            false,
        )
    }

    pub(in super::super::super) fn close_iterator_on_error<T>(
        &mut self,
        record: &Value,
        result: Result<T, RuntimeError>,
    ) -> Result<T, RuntimeError> {
        match result {
            Ok(value) => Ok(value),
            Err(error) => {
                // IteratorClose preserves an active iterator's observable
                // cleanup side effect. When a completion is already abrupt,
                // a later `return` failure cannot replace it.
                let base = self.stack.len();
                if let RuntimeError::Thrown(value) = &error {
                    self.stack.push(value.clone());
                }
                let _ = self.iterator_close(record);
                self.stack.truncate(base);
                Err(error)
            }
        }
    }

    pub(in super::super::super) fn iterator_to_array(
        &mut self,
        receiver: &Value,
    ) -> Result<Value, RuntimeError> {
        let record = self.direct_iterator_record(receiver)?;
        self.stack.push(record.clone());
        let result = (|| {
            let array = self.array_from(Vec::new())?;
            self.stack.push(array.clone());
            while let Some(value) = self.iterator_step(&record, true)? {
                self.array_push(&array, &value, 0)?;
            }
            self.stack.pop();
            Ok(array)
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_for_each(
        &mut self,
        receiver: &Value,
        callback: &Value,
    ) -> Result<Value, RuntimeError> {
        let record = self.callback_iterator_record(receiver, callback)?;
        self.stack.push(record.clone());
        let result = (|| {
            let mut index = 0_u64;
            while let Some(value) = self.iterator_step(&record, true)? {
                self.iterator_callback(callback, value, index)?;
                index += 1;
            }
            Ok(Value::Undefined)
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_every(
        &mut self,
        receiver: &Value,
        callback: &Value,
    ) -> Result<Value, RuntimeError> {
        let record = self.callback_iterator_record(receiver, callback)?;
        self.stack.push(record.clone());
        let result = (|| {
            let mut index = 0_u64;
            while let Some(value) = self.iterator_step(&record, true)? {
                let predicate = self.iterator_callback(callback, value, index)?;
                if !self
                    .to_boolean(&predicate)
                    .expect("ToBoolean cannot fail for a freshly returned live value")
                {
                    self.iterator_close(&record)?;
                    return Ok(Value::Bool(false));
                }
                index += 1;
            }
            Ok(Value::Bool(true))
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_some(
        &mut self,
        receiver: &Value,
        callback: &Value,
    ) -> Result<Value, RuntimeError> {
        let record = self.callback_iterator_record(receiver, callback)?;
        self.stack.push(record.clone());
        let result = (|| {
            let mut index = 0_u64;
            while let Some(value) = self.iterator_step(&record, true)? {
                let predicate = self.iterator_callback(callback, value, index)?;
                if self
                    .to_boolean(&predicate)
                    .expect("ToBoolean cannot fail for a freshly returned live value")
                {
                    self.iterator_close(&record)?;
                    return Ok(Value::Bool(true));
                }
                index += 1;
            }
            Ok(Value::Bool(false))
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_find(
        &mut self,
        receiver: &Value,
        callback: &Value,
    ) -> Result<Value, RuntimeError> {
        let record = self.callback_iterator_record(receiver, callback)?;
        self.stack.push(record.clone());
        let result = (|| {
            let mut index = 0_u64;
            while let Some(value) = self.iterator_step(&record, true)? {
                let predicate = self.iterator_callback(callback, value.clone(), index)?;
                if self
                    .to_boolean(&predicate)
                    .expect("ToBoolean cannot fail for a freshly returned live value")
                {
                    self.iterator_close(&record)?;
                    return Ok(value);
                }
                index += 1;
            }
            Ok(Value::Undefined)
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_reduce(
        &mut self,
        receiver: &Value,
        args: &[Value],
    ) -> Result<Value, RuntimeError> {
        let callback = native::argument(args, 0);
        let record = self.callback_iterator_record(receiver, callback)?;
        self.stack.push(record.clone());
        let result = (|| {
            // callback_iterator_record already validates the callback before
            // reading the source's next method, as required by Iterator.reduce.
            let mut index = 0_u64;
            let mut accumulator = if args.len() > 1 {
                args[1].clone()
            } else {
                let Some(value) = self.iterator_step(&record, true)? else {
                    return Err(RuntimeError::TypeError(
                        "cannot reduce an empty iterator without an initial value".into(),
                    ));
                };
                index = 1;
                value
            };
            while let Some(value) = self.iterator_step(&record, true)? {
                accumulator = self.call_native(
                    callback.clone(),
                    Value::Undefined,
                    vec![accumulator, value, Value::Number(index as f64)],
                    false,
                )?;
                index += 1;
            }
            Ok(accumulator)
        })();
        self.stack.pop();
        self.close_iterator_on_error(&record, result)
    }

    pub(in super::super::super) fn iterator_to_string_tag_setter(
        &mut self,
        receiver: &Value,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        let Value::Object(receiver) = receiver else {
            return Err(RuntimeError::TypeError(
                "Iterator prototype tag setter requires an object receiver".into(),
            ));
        };
        let base = self.base_iterator_prototype()?;
        if *receiver == base {
            return Err(RuntimeError::TypeError(
                "cannot assign Iterator.prototype Symbol.toStringTag".into(),
            ));
        }
        let key: PropertyName = JsSymbol::well_known("toStringTag").into();
        if self.object_get_own_property(*receiver, &key)?.is_none() {
            if !self.object_define_own_property(
                *receiver,
                key,
                PropertyDescriptor::data(value.clone(), true, true, true),
            )? {
                return Err(RuntimeError::TypeError("cannot define property".into()));
            }
        } else {
            self.object_set_or_throw(*receiver, &key, value)?;
        }
        Ok(Value::Undefined)
    }

    pub(in super::super::super) fn iterator_constructor_setter(
        &mut self,
        receiver: &Value,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        let Value::Object(receiver) = receiver else {
            return Err(RuntimeError::TypeError(
                "Iterator prototype constructor setter requires an object receiver".into(),
            ));
        };
        let base = self.base_iterator_prototype()?;
        if *receiver == base {
            return Err(RuntimeError::TypeError(
                "cannot assign Iterator.prototype constructor".into(),
            ));
        }
        let key: PropertyName = "constructor".into();
        if self.object_get_own_property(*receiver, &key)?.is_none() {
            // SetterThatIgnoresPrototypeProperties creates an own data
            // property instead of recursively invoking the accessor found on
            // %Iterator.prototype%.
            if !self.object_define_own_property(
                *receiver,
                key,
                PropertyDescriptor::data(value.clone(), true, true, true),
            )? {
                return Err(RuntimeError::TypeError("cannot define property".into()));
            }
        } else {
            self.object_set_or_throw(*receiver, &key, value)?;
        }
        Ok(Value::Undefined)
    }

    pub(in super::super::super) fn template_object(
        &mut self,
        site: &crate::bytecode::TemplateSite,
    ) -> Result<Value, RuntimeError> {
        if let Some(&id) = self.templates.get(&site.id) {
            return Ok(Value::Object(id));
        }
        let base = self.stack.len();
        let result = (|| {
            for string in site.raw.iter().chain(site.cooked.iter().flatten()) {
                self.check_string(&Value::String(string.clone()))?;
            }
            let raw = self.array_from(site.raw.iter().cloned().map(Value::String).collect())?;
            self.stack.push(raw.clone());
            let cooked = self.array_from(
                site.cooked
                    .iter()
                    .cloned()
                    .map(|s| s.map_or(Value::Undefined, Value::String))
                    .collect(),
            )?;
            self.stack.push(cooked.clone());
            self.define_data(
                cooked.object_id().unwrap(),
                "raw",
                raw.clone(),
                false,
                false,
                false,
            )?;
            for array in [&raw, &cooked] {
                let id = array.object_id().unwrap();
                for key in self
                    .heap
                    .own_property_keys(id)
                    .expect("the unpublished template array remains rooted")
                {
                    let mut desc = self
                        .heap
                        .get_own_property_descriptor(id, &key)
                        .expect("a fresh ordinary template array has no namespace export cells")
                        .expect("the key came from this template array");
                    desc.writable = Some(false);
                    desc.configurable = Some(false);
                    self.with_roots(|heap| heap.define_own_property(id, key, desc))?;
                }
                self.heap
                    .prevent_extensions(id)
                    .expect("the unpublished template array remains rooted");
            }
            self.heap.root(cooked.object_id().unwrap())?;
            self.templates
                .insert(site.id.clone(), cooked.object_id().unwrap());
            Ok(cooked)
        })();
        self.stack.truncate(base);
        result
    }
    pub(in super::super::super) fn get_iterator(
        &mut self,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        let method = self.get_method(value, &JsSymbol::well_known("iterator").into())?;
        self.get_iterator_from_method(value, method)
    }

    pub(in super::super::super) fn get_iterator_from_method(
        &mut self,
        value: &Value,
        method: Value,
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let result = (|| {
            let iterator = self.call_native(method, value.clone(), Vec::new(), false)?;
            if !matches!(iterator, Value::Object(_)) {
                return Err(RuntimeError::TypeError("iterator must be an object".into()));
            }
            self.stack.push(iterator.clone());
            let next = self.get_property(&iterator, &"next".into())?;
            self.stack.push(next.clone());
            let record = self.with_roots(|heap| heap.alloc_object(None))?;
            self.stack.push(Value::Object(record));
            self.with_roots(|heap| heap.set(record, "iterator", iterator))?;
            self.with_roots(|heap| heap.set(record, "next", next))?;
            self.with_roots(|heap| heap.set(record, "done", Value::Bool(false)))?;
            Ok(Value::Object(record))
        })();
        self.stack.truncate(base);
        result
    }

    /// GetAsyncIterator first observes @@asyncIterator and uses the ordinary
    /// iterator protocol as an AsyncFromSync fallback. The caller awaits the
    /// returned `.next()` result, so both paths share one record shape.
    pub(in super::super::super) fn get_async_iterator(
        &mut self,
        value: &Value,
    ) -> Result<Value, RuntimeError> {
        let method = self.get_method(value, &JsSymbol::well_known("asyncIterator").into())?;
        if method == Value::Undefined {
            let record = self.get_iterator(value)?;
            return self.mark_async_from_sync(record);
        }
        self.async_iterator_record_from_method(value, method)
    }

    /// CreateAsyncFromSyncIterator over an ordinary iterator record: the same
    /// record, flagged so `AsyncIteratorNext` adopts each result's `value`.
    pub(in super::super::super) fn mark_async_from_sync(
        &mut self,
        record: Value,
    ) -> Result<Value, RuntimeError> {
        let record_id = record
            .object_id()
            .expect("GetIterator creates an iterator record");
        self.stack.push(Value::Object(record_id));
        let result =
            self.with_roots(|heap| heap.set(record_id, "asyncFromSync", Value::Bool(true)));
        self.stack.pop();
        result?;
        Ok(Value::Object(record_id))
    }

    /// GetIteratorFromMethod for an already-fetched `@@asyncIterator` method.
    pub(in super::super::super) fn async_iterator_record_from_method(
        &mut self,
        value: &Value,
        method: Value,
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let result = (|| {
            let iterator = self.call_native(method, value.clone(), Vec::new(), false)?;
            if !matches!(iterator, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "async iterator must be an object".into(),
                ));
            }
            self.stack.push(iterator.clone());
            let next = self.get_property(&iterator, &"next".into())?;
            self.stack.push(next.clone());
            let record = self.with_roots(|heap| heap.alloc_object(None))?;
            self.stack.push(Value::Object(record));
            self.with_roots(|heap| heap.set(record, "iterator", iterator))?;
            self.with_roots(|heap| heap.set(record, "next", next))?;
            self.with_roots(|heap| heap.set(record, "done", Value::Bool(false)))?;
            Ok(Value::Object(record))
        })();
        self.stack.truncate(base);
        result
    }

    pub(in super::super::super) fn async_iterator_next(
        &mut self,
        record: &Value,
        argument: Option<Value>,
    ) -> Result<Value, RuntimeError> {
        let record = record
            .object_id()
            .expect("compiler only emits iterator records");
        if matches!(
            self.heap
                .get_own(record, "done")
                .expect("the caller retains this private ordinary iterator record"),
            Some(Value::Bool(true))
        ) {
            return self.iterator_result(Value::Undefined, true);
        }
        let iterator = self
            .heap
            .get_own(record, "iterator")
            .expect("the validated private iterator record remains live")
            .unwrap_or(Value::Undefined);
        let next = self
            .heap
            .get_own(record, "next")
            .expect("the validated private iterator record remains live")
            .unwrap_or(Value::Undefined);
        let result = self.call_native(next, iterator, argument.into_iter().collect(), false);
        if !matches!(
            self.heap
                .get_own(record, "asyncFromSync")
                .expect("the validated private iterator record remains rooted"),
            Some(Value::Bool(true))
        ) {
            return result;
        }
        match result {
            Ok(result) => self.async_from_sync_continue(record, result, true),
            Err(error) => {
                let error = self.error_value(error)?;
                self.promise_reject(error)
            }
        }
    }

    pub(in super::super::super) fn async_from_sync_handler(
        &mut self,
        function: NativeFunction,
    ) -> Result<Value, RuntimeError> {
        let prototype = self
            .function_prototype()
            .expect("the AsyncFromSync continuation already created a native Promise");
        let id = self.with_roots(|heap| heap.alloc_native_function(function, "", prototype))?;
        self.stack.push(Value::Object(id));
        let result = (|| {
            self.define_data(id, "name", Value::String("".into()), false, false, true)?;
            self.define_data(id, "length", Value::Number(1.0), false, false, true)?;
            Ok(Value::Object(id))
        })();
        self.stack.pop();
        result
    }

    /// AsyncFromSyncIteratorContinuation. A synchronous iterator result's
    /// `value` is adopted through PromiseResolve before a for-await loop sees
    /// it. `close_on_rejection` (true for `next` and `throw`, false for
    /// `return`) makes an unfinished iterator get closed when that value
    /// cannot be resolved or its promise rejects; every failure rejects the
    /// returned promise.
    pub(in super::super::super) fn async_from_sync_continue(
        &mut self,
        record: ObjectId,
        result: Value,
        close_on_rejection: bool,
    ) -> Result<Value, RuntimeError> {
        let base = self.stack.len();
        let outcome = (|| {
            if !matches!(result, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "iterator result must be an object".into(),
                ));
            }
            let done = self.get_property(&result, &"done".into())?;
            let done = self
                .to_boolean(&done)
                .expect("ToBoolean cannot fail for a freshly returned live value");
            let value = self.get_property(&result, &"value".into())?;
            let close = close_on_rejection && !done;
            let value_wrapper = match self.promise_resolve(value) {
                Ok(wrapper) => wrapper,
                Err(error) => {
                    if close {
                        // IteratorClose with the throw completion: the
                        // original error wins over anything `return` does.
                        let error_base = self.stack.len();
                        if let RuntimeError::Thrown(thrown) = &error {
                            self.stack.push(thrown.clone());
                        }
                        let _ = self.iterator_close(&Value::Object(record));
                        self.stack.truncate(error_base);
                    }
                    return Err(error);
                }
            };
            let target = self.new_promise()?;
            self.stack
                .extend([value_wrapper.clone(), Value::Object(target)]);
            let fulfilled = self
                .async_from_sync_handler(NativeFunction::AsyncFromSyncFulfill { target, done })?;
            // Each later allocation (the other handler, the derived
            // promise) can collect, so both handlers stay stack-rooted.
            self.stack.push(fulfilled.clone());
            let rejected = if close {
                let rejected =
                    self.async_from_sync_handler(NativeFunction::AsyncFromSyncReject {
                        target,
                        record,
                    })?;
                self.stack.push(rejected.clone());
                rejected
            } else {
                Value::Undefined
            };
            let wrapper = value_wrapper
                .object_id()
                .expect("PromiseResolve returns a promise object");
            self.perform_promise_then(wrapper, fulfilled, rejected, ReactionTarget::Native(target))
                .expect("PromiseResolve returned a registered AsyncFromSync Promise");
            Ok(Value::Object(target))
        })();
        self.stack.truncate(base);
        match outcome {
            Ok(value) => Ok(value),
            Err(error) => {
                let error = self.error_value(error)?;
                self.promise_reject(error)
            }
        }
    }

    /// Invoke an ordinary iterator's `next` method while retaining the raw
    /// iterator result for synchronous `yield*`. The following bytecode
    /// instruction validates `done`/`value`, matching the split async path.
    pub(in super::super::super) fn iterator_next(
        &mut self,
        record: &Value,
        argument: Option<Value>,
    ) -> Result<Value, RuntimeError> {
        let record = record
            .object_id()
            .expect("compiler only emits iterator records");
        if matches!(
            self.heap
                .get_own(record, "done")
                .expect("the caller retains this private ordinary iterator record"),
            Some(Value::Bool(true))
        ) {
            return self.iterator_result(Value::Undefined, true);
        }
        let iterator = self
            .heap
            .get_own(record, "iterator")
            .expect("the validated private iterator record remains live")
            .unwrap_or(Value::Undefined);
        let next = self
            .heap
            .get_own(record, "next")
            .expect("the validated private iterator record remains live")
            .unwrap_or(Value::Undefined);
        self.call_native(next, iterator, argument.into_iter().collect(), false)
    }

    pub(in super::super::super) fn async_iterator_step(
        &mut self,
        record: &Value,
        result: &Value,
    ) -> Result<Option<Value>, RuntimeError> {
        let record = record
            .object_id()
            .expect("compiler only emits iterator records");
        let outcome = (|| {
            if !matches!(result, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "async iterator result must be an object".into(),
                ));
            }
            let done = self.get_property(result, &"done".into())?;
            if self
                .to_boolean(&done)
                .expect("ToBoolean cannot fail for a freshly returned live value")
            {
                Ok(None)
            } else {
                self.get_property(result, &"value".into()).map(Some)
            }
        })();
        if !matches!(&outcome, Ok(Some(_))) {
            let base = self.stack.len();
            if let Err(RuntimeError::Thrown(value)) = &outcome {
                self.stack.push(value.clone());
            }
            self.heap
                .set(record, "done", Value::Bool(true))
                .expect("the private iterator record owns its existing Boolean done field");
            self.stack.truncate(base);
        }
        outcome
    }

    /// IteratorStepValue, or IteratorStep without IteratorValue for elisions.
    /// Iterator-origin errors complete this record before outer unwinding.
    pub(in super::super::super) fn iterator_step(
        &mut self,
        record: &Value,
        read_value: bool,
    ) -> Result<Option<Value>, RuntimeError> {
        let record = record
            .object_id()
            .expect("compiler only emits iterator records");
        if matches!(
            self.heap
                .get_own(record, "done")
                .expect("the caller retains this private ordinary iterator record"),
            Some(Value::Bool(true))
        ) {
            return Ok(None);
        }
        if self
            .is_for_in_record(record)
            .expect("the record was validated by the preceding done-slot read")
        {
            return self.for_in_step(record);
        }
        let base = self.stack.len();
        let outcome = (|| {
            let iterator = self
                .heap
                .get_own(record, "iterator")
                .expect("the validated private iterator record remains live")
                .unwrap_or(Value::Undefined);
            let next = self
                .heap
                .get_own(record, "next")
                .expect("the validated private iterator record remains live")
                .unwrap_or(Value::Undefined);
            let result = self.call_native(next, iterator, Vec::new(), false)?;
            if !matches!(result, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "iterator result must be an object".into(),
                ));
            }
            self.stack.push(result.clone());
            let done = self.get_property(&result, &"done".into())?;
            let value = if self
                .to_boolean(&done)
                .expect("ToBoolean cannot fail for a freshly returned live value")
            {
                None
            } else if read_value {
                Some(self.get_property(&result, &"value".into())?)
            } else {
                Some(Value::Undefined)
            };
            self.stack.pop();
            Ok(value)
        })();
        // Get(done), ToBoolean(done), and Get(value) may throw after the
        // result was placed on the stack. Release it on every completion.
        self.stack.truncate(base);
        if !matches!(&outcome, Ok(Some(_))) {
            let base = self.stack.len();
            if let Err(RuntimeError::Thrown(value)) = &outcome {
                self.stack.push(value.clone());
            }
            self.heap
                .set(record, "done", Value::Bool(true))
                .expect("the private iterator record owns its existing Boolean done field");
            self.stack.truncate(base);
        }
        outcome
    }

    pub(in super::super::super) fn iterator_close(
        &mut self,
        record: &Value,
    ) -> Result<(), RuntimeError> {
        let id = record
            .object_id()
            .expect("compiler only emits iterator records");
        if matches!(
            self.heap
                .get_own(id, "done")
                .expect("the caller retains this private ordinary iterator record"),
            Some(Value::Bool(true))
        ) {
            return Ok(());
        }
        self.heap
            .set(id, "done", Value::Bool(true))
            .expect("the private iterator record owns its existing Boolean done field");
        if self
            .is_for_in_record(id)
            .expect("the record was validated by the preceding done-slot read")
        {
            // A for-in record has no ECMAScript iterator to return.
            return Ok(());
        }
        let iterator = self
            .heap
            .get_own(id, "iterator")
            .expect("the record remains rooted after marking it done")
            .unwrap_or(Value::Undefined);
        let close = self.get_method(&iterator, &"return".into())?;
        if close != Value::Undefined {
            let result = self.call_native(close, iterator, Vec::new(), false)?;
            if !matches!(result, Value::Object(_)) {
                return Err(RuntimeError::TypeError(
                    "iterator return must return an object".into(),
                ));
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{compile, parse};

    /// An iterable whose iterators would throw if `next` were ever called.
    const IMPOSSIBLE: &str = "({ [Symbol.iterator]() { return { next() { throw 'called'; } }; },
        [Symbol.asyncIterator]() { return { next() { throw 'called'; } }; } })";

    #[test]
    fn a_finished_iterator_record_answers_done_without_calling_next() {
        let mut vm = Vm::default();
        let iterable = vm
            .execute(&compile(&parse(IMPOSSIBLE).unwrap()).unwrap())
            .unwrap();
        vm.stack.push(iterable.clone());
        let done = |vm: &mut Vm, result: Value| {
            vm.stack.push(result.clone());
            let done = vm.get_property(&result, &"done".into()).unwrap();
            let value = vm.get_property(&result, &"value".into()).unwrap();
            (done, value)
        };

        let record = vm.get_iterator(&iterable).unwrap();
        vm.stack.push(record.clone());
        vm.iterator_close(&record).unwrap();
        let result = vm.iterator_next(&record, None).unwrap();
        assert_eq!(done(&mut vm, result), (Value::Bool(true), Value::Undefined));

        let record = vm.get_async_iterator(&iterable).unwrap();
        vm.stack.push(record.clone());
        vm.iterator_close(&record).unwrap();
        let result = vm.async_iterator_next(&record, None).unwrap();
        assert_eq!(done(&mut vm, result), (Value::Bool(true), Value::Undefined));
    }

    /// An iterable (sync and async) whose `next` answers with its argument.
    const ECHO: &str =
        "({ [Symbol.iterator]() { return { next(a) { return { value: a, done: false }; } }; },
        [Symbol.asyncIterator]() { return { next(a) { return { value: a, done: false }; } }; } })";

    /// The value of the iterator result `result`, which stays on the stack.
    fn value_of(vm: &mut Vm, result: Value) -> Value {
        vm.stack.push(result.clone());
        vm.get_property(&result, &"value".into()).unwrap()
    }

    fn evaluate(vm: &mut Vm, source: &str) -> Value {
        let value = vm
            .execute(&compile(&parse(source).unwrap()).unwrap())
            .unwrap();
        vm.stack.push(value.clone());
        value
    }

    #[test]
    fn iterator_next_forwards_its_argument_to_the_iterators_next_method() {
        let mut vm = Vm::default();
        let iterable = evaluate(&mut vm, ECHO);
        let record = vm.get_iterator(&iterable).unwrap();
        vm.stack.push(record.clone());
        let result = vm.iterator_next(&record, Some(Value::Number(5.0))).unwrap();
        assert_eq!(value_of(&mut vm, result), Value::Number(5.0));
        let result = vm.iterator_next(&record, None).unwrap();
        assert_eq!(value_of(&mut vm, result), Value::Undefined);
    }

    #[test]
    fn async_iterator_next_returns_what_an_async_iterator_answers() {
        let mut vm = Vm::default();
        let iterable = evaluate(&mut vm, ECHO);
        let record = vm.get_async_iterator(&iterable).unwrap();
        vm.stack.push(record.clone());
        let result = vm
            .async_iterator_next(&record, Some(Value::Number(7.0)))
            .unwrap();
        assert_eq!(value_of(&mut vm, result), Value::Number(7.0));
    }

    #[test]
    fn async_iterator_next_over_a_sync_iterator_answers_with_a_promise() {
        let mut vm = Vm::default();
        let sync_only = evaluate(
            &mut vm,
            "({ [Symbol.iterator]() { return { next(a) { return { value: a, done: false }; } }; } })",
        );
        let record = vm.get_async_iterator(&sync_only).unwrap();
        vm.stack.push(record.clone());
        let promise = vm
            .async_iterator_next(&record, Some(Value::Number(1.0)))
            .unwrap();
        assert!(vm.promises.contains_key(&promise.object_id().unwrap()));
    }

    #[test]
    fn async_iterator_next_over_a_sync_iterator_answers_a_throwing_next_with_a_promise() {
        let mut vm = Vm::default();
        let throwing = evaluate(
            &mut vm,
            "({ [Symbol.iterator]() { return { next() { throw 'boom'; } }; } })",
        );
        let record = vm.get_async_iterator(&throwing).unwrap();
        vm.stack.push(record.clone());
        let promise = vm.async_iterator_next(&record, None).unwrap();
        assert!(vm.promises.contains_key(&promise.object_id().unwrap()));
    }

    #[test]
    fn async_iterator_next_does_not_reject_over_an_uncatchable_error() {
        let mut vm = Vm::default();
        let endless = evaluate(
            &mut vm,
            "({ [Symbol.iterator]() { return { next() { for (;;) {} } }; } })",
        );
        let record = vm.get_async_iterator(&endless).unwrap();
        vm.stack.push(record.clone());
        vm.remaining_instructions = 1_000;
        assert_eq!(
            vm.async_iterator_next(&record, None),
            Err(RuntimeError::InstructionLimit)
        );
    }
}
