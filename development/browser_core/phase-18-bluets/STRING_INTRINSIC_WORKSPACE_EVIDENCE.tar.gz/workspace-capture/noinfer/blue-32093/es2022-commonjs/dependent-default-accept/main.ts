declare function choose<T extends string, U = T>(anchor: T, check: NoInfer<U>): U;
export const value = choose("red", "red");
