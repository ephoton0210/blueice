export declare const value: NoInfer<number[]>;
