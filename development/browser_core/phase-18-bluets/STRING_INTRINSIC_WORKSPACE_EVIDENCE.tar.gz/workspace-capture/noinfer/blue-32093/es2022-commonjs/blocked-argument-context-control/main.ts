declare function choose<T>(check: NoInfer<T>): T;
export const value: number = choose(7);
