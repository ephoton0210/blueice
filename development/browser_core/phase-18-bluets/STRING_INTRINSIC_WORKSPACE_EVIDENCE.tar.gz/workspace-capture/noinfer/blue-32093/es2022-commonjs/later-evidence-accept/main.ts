declare function choose<T extends string>(check: NoInfer<T> | number, anchor: T): T;
export const value = choose(1, "red");
