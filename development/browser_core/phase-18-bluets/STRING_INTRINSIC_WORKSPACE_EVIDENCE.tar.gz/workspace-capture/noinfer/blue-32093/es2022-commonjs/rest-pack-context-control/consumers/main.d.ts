export declare const value: [number, string];
