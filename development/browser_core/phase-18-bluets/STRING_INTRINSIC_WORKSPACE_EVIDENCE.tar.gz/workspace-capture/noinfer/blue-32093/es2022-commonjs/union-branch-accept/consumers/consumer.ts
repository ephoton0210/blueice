import { value } from "./main";
const observed: 2 = value;
