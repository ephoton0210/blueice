export declare const value: {
    red: number;
};
