declare function choose<T extends string>(anchor: T, check: T): T;
export const value = choose("red", "blue");
