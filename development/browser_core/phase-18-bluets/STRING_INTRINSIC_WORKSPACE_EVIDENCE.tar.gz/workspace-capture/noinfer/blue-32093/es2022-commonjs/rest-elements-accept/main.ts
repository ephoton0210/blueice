declare function choose<T extends string>(anchor: T, ...checks: NoInfer<T>[]): T;
export const value = choose("red", "red", "red");
