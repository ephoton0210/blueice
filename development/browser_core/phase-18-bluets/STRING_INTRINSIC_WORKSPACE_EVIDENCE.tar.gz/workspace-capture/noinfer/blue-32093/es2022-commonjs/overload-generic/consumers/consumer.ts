import { value } from "./main";
const observed: "fallback" = value;
