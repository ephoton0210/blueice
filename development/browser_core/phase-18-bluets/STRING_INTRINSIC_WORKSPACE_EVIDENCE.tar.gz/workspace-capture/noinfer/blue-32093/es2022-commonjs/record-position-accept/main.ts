declare function choose<T extends string>(anchor: T, check: {value: NoInfer<T>}): T;
export const value = choose("red", {value: "red"});
