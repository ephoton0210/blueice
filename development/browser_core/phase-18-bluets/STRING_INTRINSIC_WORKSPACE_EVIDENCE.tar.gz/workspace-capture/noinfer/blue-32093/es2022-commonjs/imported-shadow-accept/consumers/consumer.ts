import { value } from "./main";
const observed: "green" = value;
