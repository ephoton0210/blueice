declare const console: {log(value: string): void};
type Block<T> = NoInfer<T>;
function choose<T extends string>(anchor: T, check: Block<T>): T { return anchor; }
export const value = choose("red", "red");
console.log(value);
