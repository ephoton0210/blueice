declare const anchor: number;
declare function choose<T>(anchor: T, check: NoInfer<T>): T;
export const value = choose(anchor, 8);
