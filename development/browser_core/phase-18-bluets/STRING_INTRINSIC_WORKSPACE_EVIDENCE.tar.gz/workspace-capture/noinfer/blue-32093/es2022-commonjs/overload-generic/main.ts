declare function choose<T extends string>(anchor: T, check: NoInfer<T>): "matched";
declare function choose(anchor: string, check: number): "fallback";
export const value = choose("red", "red");
