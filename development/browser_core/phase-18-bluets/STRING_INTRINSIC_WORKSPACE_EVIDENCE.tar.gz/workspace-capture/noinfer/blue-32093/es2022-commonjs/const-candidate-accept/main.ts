declare function choose<const T>(anchor: T, check: NoInfer<T>): T;
export const value = choose(7, 7);
