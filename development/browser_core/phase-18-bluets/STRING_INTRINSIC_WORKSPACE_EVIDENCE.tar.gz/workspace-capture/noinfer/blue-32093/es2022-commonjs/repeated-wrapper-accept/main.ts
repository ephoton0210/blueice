declare function choose<T extends string>(anchor: T, check: NoInfer<NoInfer<T>>): T;
export const value = choose("red", "red");
