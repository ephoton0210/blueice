declare function choose<T>(check: T): NoInfer<T>;
export const value = choose({value: "ok"});
