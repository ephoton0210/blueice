import { value } from "./main";
const observed: {blue: number} = value;
