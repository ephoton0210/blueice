declare function choose<T extends unknown[]>(...check: NoInfer<T>): T;
export const value: [number, string] = choose(1, "ok");
