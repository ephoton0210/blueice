import { value } from "./main";
const observed: "blue" = value;
