import { value } from "./main";
const observed: [number, string] = value;
