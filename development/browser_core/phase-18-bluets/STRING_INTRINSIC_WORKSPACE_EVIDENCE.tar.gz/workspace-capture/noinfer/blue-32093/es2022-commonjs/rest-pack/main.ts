declare function choose<T extends unknown[]>(...check: NoInfer<T>): T;
export const value = choose(1, "ok");
