import { value } from "./main";
const observed: "matched" = value;
