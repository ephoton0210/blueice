export declare function choose<T extends string>(anchor: T, check: NoInfer<T>): T;
export declare const value: "red";
