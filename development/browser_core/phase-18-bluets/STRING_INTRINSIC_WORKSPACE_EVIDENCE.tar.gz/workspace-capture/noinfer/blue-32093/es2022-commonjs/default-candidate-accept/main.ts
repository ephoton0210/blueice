declare function choose<T = number>(check: NoInfer<T>): T;
export const value = choose(7);
