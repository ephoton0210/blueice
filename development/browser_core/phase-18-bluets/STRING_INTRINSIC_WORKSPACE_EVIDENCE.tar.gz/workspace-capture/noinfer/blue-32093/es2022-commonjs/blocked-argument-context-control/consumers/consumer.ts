import { value } from "./main";
const observed: string = value;
