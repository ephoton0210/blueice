declare function choose<T extends string>(check: NoInfer<T>): T;
export const value = choose("red");
