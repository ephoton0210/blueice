export declare const value: NoInfer<{
    value: string;
}>;
