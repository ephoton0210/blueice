declare function choose<T>(): T;
export const value: number = choose();
