export declare const value: "red" | "blue";
