declare function choose<T>(check: NoInfer<T>): T;
export const value = choose(7);
