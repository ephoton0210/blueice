export type NoInfer<T> = {owner: T};
