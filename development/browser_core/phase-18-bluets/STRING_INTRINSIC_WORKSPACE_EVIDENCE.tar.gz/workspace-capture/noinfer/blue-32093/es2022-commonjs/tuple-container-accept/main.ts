declare function choose<T extends string>(anchor: T, check: NoInfer<[T, number]>): T;
export const value = choose("red", ["red", 1]);
