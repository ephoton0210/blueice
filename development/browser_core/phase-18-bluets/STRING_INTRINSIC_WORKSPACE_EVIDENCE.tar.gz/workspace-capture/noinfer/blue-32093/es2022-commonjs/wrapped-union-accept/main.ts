declare function choose<T extends number>(anchor: T, check: NoInfer<T | string>): T;
export const value = choose(1, "ok");
