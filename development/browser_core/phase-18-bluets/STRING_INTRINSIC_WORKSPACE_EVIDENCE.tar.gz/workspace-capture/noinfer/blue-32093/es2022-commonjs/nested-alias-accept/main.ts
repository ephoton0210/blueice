type Block<T> = NoInfer<{value: T}>;
declare function choose<T extends string>(anchor: T, check: Block<T>): T;
export const value = choose("red", {value: "red"});
