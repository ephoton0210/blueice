import { value } from "./main";
const observed: [string, number] = value;
