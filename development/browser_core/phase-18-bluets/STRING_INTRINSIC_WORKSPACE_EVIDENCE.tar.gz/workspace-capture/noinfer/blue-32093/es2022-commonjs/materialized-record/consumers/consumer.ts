import { value } from "./main";
const observed: {value: number} = value;
