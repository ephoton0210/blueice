type Block<T> = NoInfer<T>;
declare function choose<T extends string>(anchor: T, check: Block<T>): T;
export const value = choose("red", "red");
