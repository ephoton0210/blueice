type Extracted<T> = T extends {value: NoInfer<infer U>} ? U : never;
declare function choose<T>(check: T): T;
export const value = choose<Extracted<{value: string}>>("ok");
