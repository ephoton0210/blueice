import { value } from "./main";
const observed: boolean = value;
