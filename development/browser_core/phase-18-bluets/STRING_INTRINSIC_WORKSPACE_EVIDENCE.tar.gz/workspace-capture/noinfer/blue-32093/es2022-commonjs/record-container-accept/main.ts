declare function choose<T extends string>(anchor: T, check: NoInfer<{value: T}>): T;
export const value = choose("red", {value: "red"});
