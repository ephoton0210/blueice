type Extracted<T> = T extends NoInfer<infer U> ? U : never;
declare function choose<T>(check: T): T;
export const value = choose<Extracted<string>>("ok");
