import { value } from "./main";
const observed: 8 = value;
