type NoInfer<T> = {owner: T};
declare function choose<T extends string>(anchor: T, check: NoInfer<T>): T;
export const value = choose("red", {owner: "blue"});
