export declare const value: "fallback";
