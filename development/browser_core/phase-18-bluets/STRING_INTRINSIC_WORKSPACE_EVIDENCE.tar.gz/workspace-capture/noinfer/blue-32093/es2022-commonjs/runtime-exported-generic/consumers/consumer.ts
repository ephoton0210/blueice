import {choose} from "./main";
choose("red", "blue");
