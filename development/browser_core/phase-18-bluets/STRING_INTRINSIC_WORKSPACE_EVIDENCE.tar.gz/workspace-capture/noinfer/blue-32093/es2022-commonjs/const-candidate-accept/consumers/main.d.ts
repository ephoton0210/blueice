export declare const value: 7;
