import { value } from "./main";
const observed: number = value;
