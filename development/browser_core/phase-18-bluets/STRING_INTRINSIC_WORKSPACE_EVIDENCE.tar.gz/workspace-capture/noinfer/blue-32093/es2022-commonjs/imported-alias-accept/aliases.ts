export type Block<T> = NoInfer<T>;
