declare const console: {log(value: string): void};
export function choose<T extends string>(anchor: T, check: NoInfer<T>): T { return anchor; }
export const value = choose("red", "red");
console.log(value);
