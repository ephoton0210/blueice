declare function choose<T>(anchor: T, key: keyof NoInfer<T>): T;
export const value = choose({red: 1}, "red");
