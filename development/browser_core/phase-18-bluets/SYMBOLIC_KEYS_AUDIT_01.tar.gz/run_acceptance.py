# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""One Mac Cargo pipeline plus one separately supervised Windows target."""
from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, sys, time

root = Path(__file__).resolve().parent
repo = root.parent.parent
preflight_path = repo / 'target/symbolic-key-relations-design-20261113/preflight-3/measurement.json'
state_path = root / 'acceptance-driver.json'
assert not state_path.exists(), 'Inspect the existing acceptance process before retry'
state = {'pid': os.getpid(), 'stage': 'verify-existing-preflight', 'conclusion': 'in_progress', 'steps': []}
sidecars = {}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = state_path.with_suffix('.tmp'); temp.write_text(json.dumps(state, indent=2) + '\n'); temp.replace(state_path)


def source_check():
    frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == frozen['parentCommit']
    for name, digest in frozen['files'].items():
        assert sha(repo / name) == digest, name


def run(label, script):
    state['stage'] = label; save()
    log = root / (label + '-driver.log')
    print('START', label, flush=True)
    with log.open('xb') as output:
        child = subprocess.Popen([sys.executable, '-B', str(root / script)], cwd=repo, stdout=output, stderr=subprocess.STDOUT)
        state['childPid'] = child.pid; save(); code = child.wait()
    state['steps'].append({'label': label, 'exit': code, 'log': log.name, 'sha256': sha(log)})
    state.pop('childPid', None); save(); print('END', label, code, flush=True)
    assert code == 0, (label, code)


def sidecar(label, script):
    log = (root / (label + '-driver.log')).open('xb')
    child = subprocess.Popen([sys.executable, '-B', str(root / script)], cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    log.close(); sidecars[label] = child
    state.setdefault('sidecars', {})[label] = {'pid': child.pid, 'script': script}; save()


try:
    save()
    while True:
        measured = json.loads(preflight_path.read_bytes())
        if measured['conclusion'] != 'in_progress':
            break
        command = subprocess.run(['ps', '-p', str(measured['pid']), '-o', 'command='], capture_output=True, text=True)
        if command.returncode:
            measured = json.loads(preflight_path.read_bytes())
            assert measured['conclusion'] != 'in_progress', 'Preflight handle missing without terminal evidence; do not restart'
            break
        args = shlex.split(command.stdout.strip())
        assert Path(args[-1]).name == 'preflight_3.py' and Path(args[0]).name.lower().startswith('python'), command.stdout
        state.update(stage='waiting-existing-preflight', preflightPid=measured['pid'],
            preflightProcessVerifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()); save()
        time.sleep(10)
    assert measured['conclusion'] == 'success', measured.get('error', measured['conclusion'])
    run('freeze', 'freeze_source.py')
    frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
    state['sourceRevision'] = frozen['sourceRevision']; save(); source_check()
    run('preserve-sources', 'preserve_sources.py')
    run('prepare-windows', 'prepare_windows.py')
    sidecar('windows', 'complete_windows.py')
    sidecar('maps', 'watch_maps.py')
    for label, script in [('native', 'run_native_gates.py'), ('projects', 'run_project_gates.py'), ('local', 'run_local_gates.py')]:
        source_check(); run(label, script)
    state['stage'] = 'waiting-sidecars'; save()
    for label, child in sidecars.items():
        code = child.wait(); state['sidecars'][label]['exit'] = code; save()
        assert code == 0, (label, code)
    source_check()
    state.update(stage='all-gates-complete-awaiting-publication-audit', conclusion='success'); save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error)); save()
    if 'maps' in sidecars and sidecars['maps'].poll() is None:
        sidecars['maps'].terminate(); state['sidecars']['maps']['exit'] = sidecars['maps'].wait(); save()
    raise
