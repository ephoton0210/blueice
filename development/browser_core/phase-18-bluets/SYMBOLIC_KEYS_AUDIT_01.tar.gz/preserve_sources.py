# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path, PurePosixPath
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = read(root / 'frozen-source-preflight.json')
expected = {name: digest for name, digest in frozen['files'].items()
            if name.startswith('backend/')}
assert len(expected) == frozen['backendFiles'] == 14088
for name, digest in frozen['files'].items():
    assert sha(repo / name) == digest, name

output = root / 'source-snapshots'
output.mkdir()
destination = output / 'frozen-backend.tar.gz'
child = subprocess.Popen(['git', 'archive', '--format=tar', '--prefix=backend/',
                          frozen['backendTree']], cwd=repo, stdout=subprocess.PIPE)
with destination.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as archive:
        shutil.copyfileobj(child.stdout, archive, length=1024 * 1024)
assert child.wait() == 0
observed = {}
with tarfile.open(destination, 'r|gz') as archive:
    for member in archive:
        relative = PurePosixPath(member.name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert member.isdir() or member.isfile(), member.name
        if member.isdir():
            continue
        assert member.name not in observed and member.name in expected
        observed[member.name] = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
assert observed == expected
receipt = {'sourceRevision': frozen['sourceRevision'], 'backendFiles': len(observed),
           'archive': 'source-snapshots/' + destination.name,
           'archiveBytes': destination.stat().st_size, 'archiveSha256': sha(destination),
           'sourceManifestSha256': sha(root / 'frozen-source-preflight.json'),
           'allArchiveBytesMatchFrozenFiles': True, 'acceptanceCredit': False}
(output / 'frozen-backend-audit.json').write_text(json.dumps(receipt, indent=2) + '\n')
(output / 'manifest.json').write_text(json.dumps({
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sources': [receipt], 'scope': 'Complete immutable final backend source; gate acceptance is separate.'
}, indent=2) + '\n')

sources = []
for name, digest in expected.items():
    if not name.startswith(('backend/bluets/src/', 'backend/bluets-bluejs/src/')):
        continue
    if name.endswith('.rs'):
        kind = 'rust'
    elif name.endswith('.d.ts'):
        kind = 'declaration'
    else:
        continue
    sources.append({'path': name, 'lines': len((repo / name).read_bytes().splitlines()),
                    'sha256': digest, 'kind': kind})
assert len(sources) == 573
over = [row for row in sources if row['lines'] > 1500]
assert not over
module_audit = {'sourceRevision': frozen['sourceRevision'],
                'scope': 'Every production Rust/declaration source in BlueTS and its BlueJS adapter.',
                'files': len(sources),
                'rustFiles': sum(row['kind'] == 'rust' for row in sources),
                'declarationFiles': sum(row['kind'] == 'declaration' for row in sources),
                'maximumLines': max(row['lines'] for row in sources),
                'overLimit': over, 'sources': sources}
(root / 'all-source-module-size-audit.json').write_text(json.dumps(module_audit, indent=2) + '\n')
print(json.dumps({**receipt, 'moduleFiles': len(sources),
                  'maximumModuleLines': module_audit['maximumLines']}), flush=True)
