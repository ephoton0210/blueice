# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Mark only P0-E after independent verification of published evidence."""
import re
from audit_acceptance import ROOT, PHASE, read


def main():
    proof = read(ROOT / 'publication-before-todo-verification.json')
    data = read(PHASE / 'SYMBOLIC_KEYS_MEASUREMENT.json')
    source = data['source']['sourceRevision']
    assert proof['conclusion'] == 'success' and proof['sourceRevision'] == source
    assert proof['todoExpectedOpen'] and data['conclusion'] == 'completed-within-frozen-scope'
    workspace = data['gates']['workspace']
    document = f'''# P0-E — Symbolic key relations and exact presentation

Accepted within the frozen P0-E contract. Compiler/oracle source:
`{source}`.

Symbolic key relations preserve scoped generic identities through constraints,
captures, aliases and key-set operations. Object intersections distribute before
key projection under the configured work limit. Exact declarations retain
source parentheses and deferred-key order; rejected calls carry the complete
constraint or counterexample explanation. Resource exhaustion and ambient/runtime
authority controls retain their separate policies.

The unchanged original 32 programs pass in their original ES2022/57-library
configuration with both actual Mac compiler profiles. The expanded contract
uses 64 forms across four strict ES5/ES2022 × CommonJS/ESNext profiles with an
explicit ES5 library. Every complete diagnostic, UTF-16 position and physical
declaration byte matches pinned TypeScript 5.9.3.

| Acceptance requirement | Verified result |
| --- | --- |
| Primary matrix | 256 comparisons: 172 accepted, 84 rejected |
| Exact declarations | 176 files per actual compiler |
| Isolated declaration consumers | 344 positive/negative programs per actual compiler |
| Selected-edition syntax / execution | 176 parses /24 executions per actual compiler |
| Separate owner/runtime/resource controls | 12; excluded from direct-agreement credit |
| Compound-key supplement | 16 comparisons: 15 accepts, one rejection; 15 parses; zero inventory credit |
| Complete Native catalog | 189 suites /1076 functions; zero failed, ignored or filtered |
| Complete local workspace | {workspace['passed']} passed; {workspace['failed']} failed; {workspace['ignored']} ignored, with the full Native catalog selected separately |
| Declaration/JavaScript maps | 8407 configurations ×2 builds for each actual Mac compiler profile; zero differences |
| Real projects | defu, mitt, reproductions and interchange gates pass |
| Windows x86_64 | Same-source 82 core oracles, 25 paths and 11 complete regression cohorts |
| Tooling | Format, warnings-denied workspace/all-target Clippy, Node/Python and accounting checks pass |
| Module size | 573 production Rust/declaration files; maximum {data['modules']['maximumLines']} lines |

The accepted-D baseline retains all 256 physical observations: 104 complete
agreements and 152 complete differences. Frozen Native inputs were never replaced
with BlueTSC output. All 42052 earlier suite-qualified assertion IDs and their
classes remain unchanged; 256 primary comparisons and 12 separate controls add
268 assertions, producing N=42320. Supplemental cases and the original-profile
replay add no denominator credit.

The first preflight's NonNullable/keyof declaration regression, the Clippy
failure, focused red/green attempts and the terminal supervisor setup failure
are preserved with their actual sources and outcomes. The final fixed-source
12-step preflight and all full acceptance gates pass. Earlier failures receive
no new-source acceptance credit.

[Measurement](SYMBOLIC_KEYS_MEASUREMENT.json),
[artifact index](SYMBOLIC_KEYS_ARTIFACTS.json) and
[contract/history](SYMBOLIC_KEYS_FOLLOWUP.md) retain the raw evidence and source
bindings. Member manifests are separately hashed and split into small files.
Archives preserve the actual compilers, full sources, products, logs and pinned
oracle packages with their original licenses. Rejected inputs publish no output.
The [reproduction guide](SYMBOLIC_KEYS_REPRODUCTION.md) gives the focused replay
commands and explains the separately required full acceptance gates.

Only the finite P0-E item is complete. All 22 broader G-* rows remain open and
full TypeScript parity remains OFF. The user-approved full-local/Windows-82
boundary is unchanged; hosted CI and extra platform combinations remain
supplementary.
'''
    (PHASE / 'SYMBOLIC_KEYS_ACCEPTANCE.md').write_text(document)
    todo_path = PHASE / 'TODO.md'
    todo = todo_path.read_text()
    accepted = '''- [x] **P0-E — Symbolic key relations and exact presentation.** Delivered
  64 forms ×four profiles =256 complete comparisons: 172 accepts /84 rejects,
  176 exact declarations, 344 isolated consumers, 176 parses and 24 executions
  per actual compiler. Twelve policy controls remain separate; the 16-case
  compound-key supplement and original 32-program/57-library replay add zero
  inventory credit. Complete same-source Native/local/Windows, maps, projects
  and tooling pass. All 42052 prior assertion IDs/classes remain unchanged;
  268 additions bring N to 42320. [Acceptance](SYMBOLIC_KEYS_ACCEPTANCE.md) ·
  [measurement](SYMBOLIC_KEYS_MEASUREMENT.json). Broader rows remain open.'''
    todo, changed = re.subn(r'- \[ \] \*\*P0-E —.*?(?=\n\nEach package)', accepted, todo, flags=re.S)
    assert changed == 1, 'Only the exact open P0-E block may be marked complete'
    latest = '''**Latest completed follow-up:** P0-E repairs symbolic key relations and
exact presentation, preserving scoped generic identities, constraint direction,
compound-key ordering and bounded owner/resource policies.
[Acceptance](SYMBOLIC_KEYS_ACCEPTANCE.md) binds complete Native/local/Windows,
maps, project and tooling gates to its source. P0-A/B/C/D retain their dated
evidence. All 22 broader rows remain open; further closure requires a frozen
contract and measurements for the remaining scope.'''
    todo, latest_changed = re.subn(r'\*\*Latest completed follow-up:\*\*.*?(?=\n\n## Open gaps)', latest, todo, flags=re.S)
    assert latest_changed == 1
    todo_path.write_text(todo)
    contract_path = PHASE / 'SYMBOLIC_KEYS_FOLLOWUP.md'
    contract = contract_path.read_text()
    assert contract.startswith('# P0-E') and 'Status: open.' in contract
    contract = contract.replace('Status: open.',
        'Status: accepted within the frozen P0-E scope. [Complete acceptance](SYMBOLIC_KEYS_ACCEPTANCE.md).', 1)
    contract += '\n\n## Final acceptance\n\nThe final 12-step preflight and complete same-source Native/local/Windows, maps,\nprojects and tooling gates pass. The development checkpoints above retain their\noriginal outcomes; the [measurement](SYMBOLIC_KEYS_MEASUREMENT.json) records the\naccepted source and complete results. Only P0-E is checked. All 22 broad rows\nremain open and full TypeScript parity remains OFF.\n'
    contract_path.write_text(contract)
    print('Marked only P0-E after complete published-evidence verification.')


if __name__ == '__main__':
    main()
