# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import hashlib, json


def audit(root, repo):
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    read = lambda path: json.loads(path.read_bytes())
    reports = list((root / 'baseline').glob('*/report.json'))
    assert len(reports) == 1
    path = reports[0]; report = read(path)
    assert report['sourceCommit'] == '5f12dbca05ebc091208fd8f851aec3acb05c6b83'
    assert report['sourceRevision'] == 'backend-tree:bfee3b4ec32820c6c242798b6d2d90fdb6e00600'
    assert report['compilerSha256'] == sha(root / 'baseline-cli') == 'bc8a8fea563ca0410719c79804c89a3aebccb19c6414be19ca1fef2bdf2c72b3'
    fixture = repo / 'backend/bluets/tests/fixtures/symbolic_keys'
    assert report['frozenInputs'] == read(fixture / 'FROZEN.json')['sha256']
    reference = {row['id']: row for row in read(fixture / 'reference.json')['cases']}
    assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 256
    assert {row['id'] for row in report['cases']} == set(reference)
    actual_agreements = actual_published = 0
    hashes = {}
    for row in report['cases']:
        expected = {key: reference[row['id']][key] for key in ['accepts', 'diagnostics', 'declarations']}
        assert row['native'] == expected
        ordinary_path = path.parent / row['id'] / 'observation.json'
        ordinary = read(ordinary_path)
        assert all(ordinary[key] == row[key] for key in ['id', 'observed', 'agrees', 'publishedOnRejectedNativeInput'])
        outputs = {p.relative_to(ordinary_path.parent / 'dist').as_posix(): p.read_bytes()
                   for p in (ordinary_path.parent / 'dist').rglob('*') if p.is_file()}
        declarations = {name: data.decode('utf-8') for name, data in outputs.items() if name.endswith('.d.ts')}
        assert declarations == row['observed']['declarations']
        published = not expected['accepts'] and bool(outputs)
        agrees = row['observed'] == expected and not published
        assert row['agrees'] == agrees and row['publishedOnRejectedNativeInput'] == published
        actual_agreements += agrees; actual_published += published
        hashes[row['id']] = sha(ordinary_path)
    assert report['comparisons'] == 256
    assert report['completeAgreements'] == actual_agreements == 104
    assert report['completeDifferences'] == 256 - actual_agreements == 152
    assert report['rejectedNativeInputsPublished'] == actual_published == 68
    assert report['unchangedDiscovery32'] == {'comparisons': 128, 'agreements': 64, 'differences': 64}
    return {'report': str(path.relative_to(root)), 'sha256': sha(path),
            'sourceCommit': report['sourceCommit'], 'sourceRevision': report['sourceRevision'],
            'compilerSha256': report['compilerSha256'], 'comparisons': 256,
            'completeAgreements': 104, 'completeDifferences': 152,
            'rawObservationSha256': hashes, 'acceptanceCredit': False}


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    result = audit(root, root.parent.parent)
    (root / 'baseline-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rawObservationSha256'}))
