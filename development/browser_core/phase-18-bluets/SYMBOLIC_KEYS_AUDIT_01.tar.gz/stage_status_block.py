# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Stage only the generated CLAUDE status block, preserving unrelated edits."""
import hashlib
import json
import re
import subprocess
from audit_acceptance import ROOT, REPO, read


def main():
    proof = read(ROOT / 'publication-verification.json')
    assert proof['conclusion'] == 'success' and not proof['todoExpectedOpen']
    head = subprocess.check_output(['git', 'show', 'HEAD:CLAUDE.md'], cwd=REPO)
    working = (REPO / 'CLAUDE.md').read_bytes()
    pattern = rb'<!-- BEGIN CURRENT BLUETS STATUS -->.*?<!-- END CURRENT BLUETS STATUS -->'
    old = re.search(pattern, head, re.S)
    current = re.search(pattern, working, re.S)
    assert old is not None and current is not None
    indexed = subprocess.check_output(['git', 'show', ':CLAUDE.md'], cwd=REPO)
    indexed_block = re.search(pattern, indexed, re.S)
    assert indexed_block is not None
    assert indexed[:indexed_block.start()] + indexed[indexed_block.end():] == head[:old.start()] + head[old.end():], \
        'Preserve unrelated staged CLAUDE changes; do not replace their index entry'
    staged = head[:old.start()] + current.group() + head[old.end():]
    assert b'N = 42,320' in current.group()
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'],
        cwd=REPO, input=staged).decode().strip()
    entry = subprocess.check_output(['git', 'ls-files', '-s', '--', 'CLAUDE.md'],
        cwd=REPO, text=True).split()
    assert len(entry) == 4 and entry[0] == '100644' and entry[2] == '0'
    subprocess.run(['git', 'update-index', '--cacheinfo', entry[0], blob, 'CLAUDE.md'], cwd=REPO, check=True)
    assert subprocess.check_output(['git', 'show', ':CLAUDE.md'], cwd=REPO) == staged
    assert (REPO / 'CLAUDE.md').read_bytes() == working
    receipt = {'sourceRevision': proof['sourceRevision'], 'stagedBlob': blob,
        'stagedOnlyGeneratedStatusBlock': True, 'workingFileUntouched': True,
        'outsideBlockMatchesHead': head[:old.start()] + head[old.end():] ==
            working[:current.start()] + working[current.end():],
        'workingFileSha256': hashlib.sha256(working).hexdigest()}
    (ROOT / 'status-block-staging.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
