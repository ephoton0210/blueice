# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Freeze P0-E only after the complete fixed-source authoring preflight."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PREFLIGHT = REPO / 'target/symbolic-key-relations-design-20261113/preflight-3'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = lambda *args: subprocess.check_output(args, cwd=REPO, text=True).strip()
measurement = json.loads((PREFLIGHT / 'measurement.json').read_bytes())
manifest = json.loads((PREFLIGHT / 'source-manifest.json').read_bytes())
assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
expected_steps = ['fmt', 'clippy', 'build', 'library', 'gc1_object_generic_methods',
                  'symbolic_keys', 'noinfer', 'nonnullable_awaited', 'string_intrinsics',
                  'mapped_inference', 'jsx_checker_matrix', 'gt5_compositions']
assert [step['label'] for step in measurement['steps']] == expected_steps
assert all(step['exit'] == 0 for step in measurement['steps'])
assert sha(PREFLIGHT / 'source-manifest.json') == measurement['sourceManifestSha256']
for step in measurement['steps']:
    assert sha(PREFLIGHT / step['log']) == step['sha256'], step['label']
assert sha(PREFLIGHT / 'accepted-cli') == measurement['compilerSha256']
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
    '--exclude-standard', '-z', '--', 'backend',
    'development/browser_core/phase-18-bluets/tools'], cwd=REPO).decode().split('\0')
files = {name: sha(REPO / name) for name in sorted(set(paths)) if name}
assert files == manifest['expectedFiles']
assert not command('git', 'diff', '--name-only', '--', 'backend',
                   'development/browser_core/phase-18-bluets/tools')
tree = command('git', 'write-tree')
backend_tree = command('git', 'rev-parse', tree + ':backend')
parent = command('git', 'rev-parse', 'HEAD')
assert parent == measurement['parentCommit'] == '5f12dbca05ebc091208fd8f851aec3acb05c6b83'
assert 'backend-tree:' + backend_tree == manifest['sourceRevision'] == measurement['sourceRevision']
assert not command('git', 'diff', '--cached', '--name-only', '--', 'CLAUDE.md')
backend = sorted((name for name in files if name.startswith('backend/')), key=lambda name: name.encode())
indexed = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=REPO).decode().split('\0')[:-1]
assert set(backend) == set(indexed)
fixture = REPO / 'backend/bluets/tests/fixtures/symbolic_keys'
contract = json.loads((fixture / 'FROZEN.json').read_bytes())
for name, digest in {**contract['sha256'], **contract['supplementarySha256']}.items():
    assert sha(fixture / name) == digest, name
tools = json.loads(subprocess.check_output(['node', '-e',
    "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"], cwd=REPO))
frozen = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit': parent, 'backendTree': backend_tree,
    'sourceRevision': 'backend-tree:' + backend_tree,
    'backendFiles': len(backend),
    'backendPathSetSha256': hashlib.sha256('\0'.join(backend).encode()).hexdigest(),
    'files': files, 'preflight': str(PREFLIGHT.relative_to(REPO)),
    'preflightMeasurementSha256': sha(PREFLIGHT / 'measurement.json'),
    'preflightManifestSha256': sha(PREFLIGHT / 'source-manifest.json'),
    'originalFrozenInputs': contract['sha256'],
    'supplementaryFixtureSha256': contract['supplementarySha256'],
    'supplementaryInventoryCredit': 0, 'oracleToolFilesExpected': len(tools),
    'expectedNativeSuites': 189, 'expectedNativeFunctions': 1076,
    'previousAssertions': 42052, 'addedAssertions': 268,
    'scope': 'P0-E finite symbolic-key contract; complete same-source acceptance still required. Prior-source passes receive no new-source credit. All 22 broad rows remain open.',
}
with (ROOT / 'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(frozen, indent=2) + '\n')
print(json.dumps({key: value for key, value in frozen.items() if key != 'files'}))
