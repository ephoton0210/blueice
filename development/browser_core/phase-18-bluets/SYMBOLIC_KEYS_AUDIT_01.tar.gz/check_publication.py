# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Verify published archive bytes, member manifests and acceptance bindings."""
import argparse
import json
import re
import subprocess
from artifact_pack import LIMIT, safe_name, verify_archive
from audit_acceptance import ROOT, REPO, PHASE, read, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--before-todo', action='store_true')
    options = parser.parse_args()
    data = read(PHASE / 'SYMBOLIC_KEYS_MEASUREMENT.json')
    assert data['schema'] == 2 and data['conclusion'] == 'completed-within-frozen-scope'
    assert data['broaderFeatureRowsOpen'] == 22 and data['fullTypeScriptParity'] is False
    source = data['source']['sourceRevision']
    assert data['source']['parentCommit'] == subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    tree = subprocess.check_output(['git', 'write-tree'], cwd=REPO, text=True).strip()
    backend = subprocess.check_output(['git', 'rev-parse', tree + ':backend'], cwd=REPO, text=True).strip()
    assert 'backend-tree:' + backend == source
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'backend'], cwd=REPO)
    index_ref = data['artifactIndex']
    index_path = PHASE / safe_name(index_ref['path'])
    assert sha(index_path) == index_ref['sha256'] and index_path.stat().st_size == index_ref['bytes']
    index = read(index_path)
    assert index['schema'] == 2 and index['sourceRevision'] == source
    owners = {}
    for artifact in index['artifacts']:
        path = PHASE / safe_name(artifact['path'])
        assert path.stat().st_size == artifact['bytes'] < LIMIT
        assert sha(path) == artifact['sha256']
        if artifact.get('originalWindowsArchive'):
            assert artifact['sha256'] == data['windows']['archiveSha256']
            continue
        entries = []
        for part in artifact['memberManifests']:
            part_path = PHASE / safe_name(part['path'])
            assert part_path.stat().st_size == part['bytes'] < 16 * 1024 * 1024
            assert sha(part_path) == part['sha256']
            value = read(part_path)
            assert value['sourceRevision'] == source and value['archive'] == artifact['path']
            assert len(value['entries']) == part['members']
            for row in value['entries']:
                safe_name(row['path'])
                assert row['path'] not in owners and re.fullmatch(r'[0-9a-f]{64}', row['sha256'])
                assert (ROOT / row['path']).stat().st_size == row['bytes']
                assert sha(ROOT / row['path']) == row['sha256']
                owners[row['path']] = {'archive': artifact['path'], 'path': row['path'], 'sha256': row['sha256']}
            entries.extend(value['entries'])
        assert len(entries) == artifact['members']
        verify_archive(path, entries)

    def reference(value):
        assert owners[value['path']] == value
        return read(ROOT / value['path'])

    manifest = reference(data['source']['manifest'])
    assert manifest['sourceRevision'] == source
    for name, digest in manifest['files'].items():
        assert sha(REPO / name) == digest, name
    assert data['nativeMeasurement']['suites'] == 189 and data['nativeMeasurement']['functions'] == 1076
    native = read(PHASE / 'COMPATIBILITY_MEASUREMENT.json')
    assert native['source_revision'] == source and native['conclusion'] == 'success'
    assert sha(PHASE / 'COMPATIBILITY_MEASUREMENT.json') == owners['accepted-native/measurement.json']['sha256']
    assert sha(PHASE / 'COMPATIBILITY_MEASUREMENT.json') == data['nativeMeasurement']['sha256']
    assert len(native['suites']) == 189 and sum(row['passed'] for row in native['suites']) == 1076
    for row in native['suites']:
        assert row['failed'] == row['ignored'] == row['filtered'] == 0
        assert owners['accepted-native/' + row['log']]['sha256'] == row['log_sha256']
    for step in data['gates']['steps']:
        assert step['exit'] == 0 and owners[step['log']]['sha256'] == step['sha256']
    assert data['casePreservation'] == {'previous': 42052, 'current': 42320, 'added': 268, 'allOldCasesUnchanged': True}
    assert data['caseInventoryAdditions'] == 268 and data['directObservations'] == 256
    assert (data['accepted'], data['rejected'], data['declarationFiles']) == (172, 84, 176)
    assert (data['isolatedConsumers'], data['selectedEditionParses'], data['executions']) == (344, 176, 24)
    assert data['boundaryControls'] == 12 and data['boundaryControlsExcludedFromDirectDenominator']
    assert data['supplementaryControls'] == 16 and data['supplementaryInventoryCredit'] == 0
    assert data['supplementarySyntax'] == 15
    for kind in ['native', 'workspace']:
        compiler = data['gates'][kind + 'CompilerSha256']
        assert owners['accepted-' + kind + '-cli']['sha256'] == compiler
        symbolic = data['symbolicKeysReports'][kind]
        report = reference(symbolic['primaryReport'])
        assert report['sourceRevision'] == source and report['compilerSha256'] == compiler
        assert report['conclusion'] == 'success' and len(report['cases']) == 256
        for mode, row in symbolic['supplementaryReports'].items():
            supplement = reference(row)
            assert supplement['mode'] == mode and supplement['conclusion'] == 'success'
            assert len(supplement['cases']) == 16 and supplement['inventoryCredit'] == 0
        original = reference(data['originalDiscovery32'][kind]['reference'])
        assert original['conclusion'] == 'success' and original['compilerSha256'] == compiler
        assert len(original['cases']) == 32 and all(row['agrees'] for row in original['cases'])
        for family in ['mappedInferenceReports', 'stringIntrinsicReports', 'nonNullableAwaitedReports']:
            reference(data[family][kind])
        for row in data['noInferReports'][kind].values():
            reference(row)
        binding = data['mapBindings'][kind]
        assert binding['compilerSha256'] == compiler and binding['verified']
        assert owners[kind + '-declaration-map-report.json']['sha256'] == binding['reportSha256']
        maps = read(ROOT / (kind + '-declaration-map-report.json'))
        assert maps['configurations'] == 8407 and maps['buildsPerConfiguration'] == 2 and not maps['differences']
    for value in data['projects'].values():
        reference(value)
    module = reference(data['modules']['audit'])
    assert module['files'] == data['modules']['files'] == 573
    assert module['maximumLines'] == data['modules']['maximumLines'] < 1500
    reference(data['sourceSnapshots'])
    reference(data['oracleDependencies'])
    baseline = reference(data['baseline']['reference'])
    assert baseline['comparisons'] == 256 and baseline['completeDifferences'] == 152
    assert baseline['completeAgreements'] == 104
    assert data['windows'] == read(ROOT / 'windows/windows-acceptance-verification.json')
    assert data['windows']['coreOracles'] == 82 and data['windows']['paths'] == 25
    assert len(data['windows']['regressionCohorts']) == 11
    assert len(data['windows']['symbolicKeysReports']['ordinaryObservationsSha256']) == 256
    if not options.before_todo:
        assert '- [x] **P0-E —' in (PHASE / 'TODO.md').read_text()
        acceptance = (PHASE / 'SYMBOLIC_KEYS_ACCEPTANCE.md').read_text()
        assert source in acceptance and 'SYMBOLIC_KEYS_MEASUREMENT.json' in acceptance
    result = {'sourceRevision': source, 'conclusion': 'success',
        'artifactFiles': len(index['artifacts']), 'independentlyVerifiedMembers': len(owners),
        'todoExpectedOpen': options.before_todo}
    destination = ROOT / ('publication-before-todo-verification.json' if options.before_todo
                          else 'publication-verification.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
