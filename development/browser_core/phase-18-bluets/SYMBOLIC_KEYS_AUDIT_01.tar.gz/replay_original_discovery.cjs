// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Replay the original ES2022-library observations without replacing their gold.
const {spawnSync} = require('node:child_process');
const {isDeepStrictEqual} = require('node:util');
const c = require('../../development/browser_core/phase-18-bluets/tools/symbolic_keys/common.cjs');
const {assert, fs, path, sha} = c;
const label = process.argv[2]; assert(['native', 'workspace'].includes(label));
assert.equal(process.argv.length, 3);
const parent = path.join(__dirname, 'original-discovery32');
const input = c.read(path.join(parent, 'inputs.json')), reference = c.read(path.join(parent, 'native-reference.json'));
assert.equal(sha(fs.readFileSync(path.join(parent, 'inputs.json'))), reference.inputSha256);
const main = c.read(path.join(c.fixture, 'cases.json'));
for (const entry of input.cases) assert.equal(entry.source, main.cases.find(row => row.id === entry.id).source);
assert.equal(input.cases.length, 32); assert.equal(reference.cases.length, 32);
const compiler = path.join(__dirname, 'accepted-' + label + '-cli');
const compilerSha256 = sha(fs.readFileSync(compiler)), ctx = c.context();
const authority = () => {
    assert.equal(sha(fs.readFileSync(ctx.implementation)), reference.implementationSha256);
    assert.equal(sha(fs.readFileSync(compiler)), compilerSha256);
    for (const [name, digest] of Object.entries(reference.libraries))
        assert.equal(sha(fs.readFileSync(path.join(path.dirname(ctx.implementation), name))), digest);
};
authority();
const root = path.join(parent, 'replay-' + label); fs.mkdirSync(root);
const report = {schema: 1, inventoryCredit: 0,
    sourceRevision: c.read(path.join(__dirname, 'frozen-source-preflight.json')).sourceRevision,
    compilerSha256, inputSha256: reference.inputSha256,
    implementationSha256: reference.implementationSha256, libraries: reference.libraries,
    runnerSha256: sha(fs.readFileSync(__filename)), cases: [], conclusion: 'in_progress'};
const save = () => fs.writeFileSync(path.join(root, 'report.json'), JSON.stringify(report, null, 2) + '\n');
const cache = new Map(), loaded = {};
function prepare(role, entry) {
    const cwd = path.join(root, role, entry.id); fs.mkdirSync(cwd, {recursive: true});
    fs.writeFileSync(path.join(cwd, 'main.ts'), entry.source);
    fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify({compilerOptions: input.options, files: ['main.ts']}, null, 2) + '\n');
    return cwd;
}
try {
    save();
    for (const entry of input.cases) {
        const wanted = reference.cases.find(row => row.id === entry.id);
        const expected = Object.fromEntries(['accepts', 'diagnostics', 'declarations'].map(key => [key, wanted[key]]));
        if (label === 'native') {
            const cwd = prepare('native', entry), converted = ctx.ts.convertCompilerOptionsFromJson(input.options, cwd);
            assert.deepEqual(converted.errors, []);
            const host = ctx.ts.createCompilerHost(converted.options), get = host.getSourceFile;
            host.getSourceFile = (file, version, ...rest) => {
                const relative = path.relative(path.dirname(ctx.implementation), file);
                if (relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) return get(file, version, ...rest);
                const key = file + ':' + version;
                if (!cache.has(key)) cache.set(key, get(file, version, ...rest));
                loaded[path.basename(file)] = sha(fs.readFileSync(file)); return cache.get(key);
            };
            const program = ctx.ts.createProgram([path.join(cwd, 'main.ts')], converted.options, host);
            const diagnostics = ctx.ts.sortAndDeduplicateDiagnostics(ctx.ts.getPreEmitDiagnostics(program)).map(row => c.diagnostic(ctx.ts, row, cwd));
            if (!diagnostics.length) { const emitted = program.emit(); assert(!emitted.emitSkipped && !emitted.diagnostics.length); }
            const outputs = c.inventory(path.join(cwd, 'dist'));
            const observed = {accepts: !diagnostics.length, diagnostics,
                declarations: Object.fromEntries(Object.entries(outputs).filter(([name]) => name.endsWith('.d.ts')))};
            fs.writeFileSync(path.join(cwd, 'observation.json'), JSON.stringify(observed, null, 2) + '\n');
            assert.deepEqual(observed, expected, entry.id + ': original Native replay changed');
            if (!observed.accepts) assert.deepEqual(outputs, {});
        }
        const cwd = prepare('blue', entry);
        const built = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'], {cwd, encoding: 'utf8', timeout: 120000});
        if (built.error) throw built.error;
        assert.equal(built.signal, null);
        fs.writeFileSync(path.join(cwd, 'build.stdout'), built.stdout || ''); fs.writeFileSync(path.join(cwd, 'build.stderr'), built.stderr || '');
        const outputs = c.inventory(path.join(cwd, 'dist'));
        const observed = {accepts: built.status === 0,
            diagnostics: built.stderr.split(/\r?\n/).filter(Boolean).map(line => c.blueDiagnostic(JSON.parse(line))),
            declarations: Object.fromEntries(Object.entries(outputs).filter(([name]) => name.endsWith('.d.ts')))};
        const publishedOnRejectedNativeInput = !expected.accepts && Object.keys(outputs).length > 0;
        const row = {id: entry.id, observed, agrees: isDeepStrictEqual(observed, expected) && !publishedOnRejectedNativeInput,
            publishedOnRejectedNativeInput};
        fs.writeFileSync(path.join(cwd, 'observation.json'), JSON.stringify(row, null, 2) + '\n');
        report.cases.push(row); save();
    }
    if (label === 'native') assert.deepEqual(loaded, reference.libraries);
    authority();
    assert.deepEqual(report.cases.filter(row => !row.agrees).map(row => row.id), []);
    report.conclusion = 'success'; save();
    console.log(JSON.stringify({root, compilerSha256, comparisons: 32, libraries: Object.keys(reference.libraries).length, inventoryCredit: 0}));
} catch (error) {report.conclusion = 'failure'; report.error = String(error.stack || error); save(); throw error;}
