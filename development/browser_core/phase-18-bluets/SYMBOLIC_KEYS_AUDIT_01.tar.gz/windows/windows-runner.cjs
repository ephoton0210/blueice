// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const crypto = require('node:crypto'), assert = require('node:assert/strict');
const base = 'B:/BlueIce/gm3-20261109-360d7d921';
const source = path.join(base, 'p0c-authoring-preflight-1/source');
const out = path.join(base, 'results-symbolic-keys-r1'); fs.mkdirSync(out);
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const manifestPath = path.join(base, 'p0e-r1-source-manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath));
const env = {...process.env, CARGO_INCREMENTAL: '0', CARGO_BUILD_JOBS: '2',
    CARGO_PROFILE_DEV_DEBUG: '0', CARGO_PROFILE_TEST_DEBUG: '0', RUST_TEST_THREADS: '4',
    CARGO_HOME: 'B:/BlueIce/cache/cargo', CARGO_TARGET_DIR: path.join(base, 'target'),
    TEMP: path.join(base, 'temp'), TMP: path.join(base, 'temp'), FORCE_COLOR: '0',
    BLUEICE_BLUETSC_ORACLE: path.join(base, 'oracles/node_modules/.bin/tsc.cmd'),
    BLUEICE_ACORN_ORACLE: path.join(base, 'oracles/node_modules/.bin/acorn.cmd'),
    BLUEICE_DEFU_NATIVE_OBSERVATIONS: path.join(out, 'defu-native-raw')};
for (const key of Object.keys(env)) if (key.startsWith('BLUEICE_WRITE_') || key.startsWith('BLUETS_')) delete env[key];
const state = {pid: process.pid, startedAt: new Date().toISOString(), platform: process.platform + '-' + process.arch,
    sourceRevision: manifest.sourceRevision, parentCommit: manifest.parentCommit,
    expectedSourceManifestSha256: hash(manifestPath), sourcePatchSha256: manifest.sourcePatchSha256,
    oraclesArchiveSha256: hash(path.join(base, 'oracles.tar.gz')),
    feature: 'windows-symlink-tests', stage: 'starting', conclusion: 'in_progress', cases: [], followups: []};
const save = () => {
    const temporary = path.join(out, 'measurement.tmp');
    fs.writeFileSync(temporary, JSON.stringify(state, null, 2) + '\n');
    fs.renameSync(temporary, path.join(out, 'measurement.json'));
};
let compiler;
function compilerCheck() {
    if (compiler) {
        assert.equal(hash(compiler.path), compiler.sha256);
        assert.equal(hash(path.join(out, 'accepted-windows-cli.exe')), compiler.sha256);
    }
}
function run(program, args, label) {
    compilerCheck();
    state.stage = label; state.command = [program, ...args]; save();
    const stdout = fs.openSync(path.join(out, label + '.stdout'), 'wx');
    const stderr = fs.openSync(path.join(out, label + '.stderr'), 'wx');
    try {
        const child = cp.spawnSync(program, args, {cwd: source, env, stdio: ['ignore', stdout, stderr]});
        if (child.error) throw child.error;
        compilerCheck(); return child.status;
    } finally {fs.closeSync(stdout); fs.closeSync(stderr);}
}
try {
    save();
    const backend = Object.keys(manifest.files).filter(name => name.startsWith('backend/'))
        .sort((a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b)));
    assert.equal(backend.length, manifest.backendFiles);
    assert.equal(crypto.createHash('sha256').update(backend.join('\0')).digest('hex'), manifest.backendPathSetSha256);
    for (const [name, digest] of Object.entries(manifest.files)) assert.equal(hash(path.join(source, name)), digest, name);
    state.verifiedSourceFiles = Object.keys(manifest.files).length;
    state.verifiedBackendFiles = backend.length; state.backendPathSetSha256 = manifest.backendPathSetSha256;
    state.rustc = cp.execFileSync('rustc', ['--version'], {env, encoding: 'utf8'}).trim();
    state.cargo = cp.execFileSync('cargo', ['--version'], {env, encoding: 'utf8'}).trim();
    state.node = process.version;
    const matrix = JSON.parse(fs.readFileSync(path.join(source, 'development/browser_core/phase-18-bluets/GM3_FROZEN_MATRIX.json')));
    const cohorts = ['symbolic_keys', 'mapped_inference', 'string_intrinsics', 'gc1_object_generic_methods', 'gm2_incremental_options', 'project_config',
        'defu_prerequisites', 'callable_utilities', 'receiver_utilities', 'noinfer', 'nonnullable_awaited'];
    const targets = [...new Set([...matrix.cases.map(row => path.basename(row.source, '.rs')), 'typescript_oracle', ...cohorts])].sort();
    const args = ['test', '-p', 'blueice-bluets', '--features', 'windows-symlink-tests', '--no-run', '--locked', '--offline',
        '--message-format=json', ...targets.flatMap(target => ['--test', target])];
    state.buildExit = run('cargo', args, 'build'); save(); assert.equal(state.buildExit, 0);
    const binaries = {};
    for (const line of fs.readFileSync(path.join(out, 'build.stdout'), 'utf8').split(/\r?\n/)) {
        let message; try {message = JSON.parse(line);} catch {continue;}
        if (message.reason !== 'compiler-artifact' || !message.executable) continue;
        if (message.profile.test) binaries[message.target.name] = message.executable;
        else if (message.target.name === 'bluetsc') compiler = {path: message.executable, sha256: hash(message.executable)};
    }
    assert(compiler); state.compiler = compiler;
    fs.copyFileSync(compiler.path, path.join(out, 'accepted-windows-cli.exe')); compilerCheck();
    env.BLUEICE_GE5_EXPECTED_COMPILER_SHA256 = compiler.sha256;
    for (const [stem, capture] of [['CALLABLE_UTILITIES', 'callable'], ['RECEIVER_UTILITIES', 'receiver'],
        ['NOINFER', 'noinfer'], ['NONNULLABLE_AWAITED', 'nonnullable-awaited'], ['STRING_INTRINSICS', 'string-intrinsics'], ['MAPPED_INFERENCE', 'mapped-inference'], ['SYMBOLIC_KEYS', 'symbolic-keys']]) {
        env['BLUEICE_' + stem + '_OBSERVATIONS'] = path.join(out, capture + '-observations');
        env['BLUEICE_' + stem + '_EXPECTED_COMPILER_SHA256'] = compiler.sha256;
    }
    env.BLUEICE_CALLABLE_SOURCE_REVISION = env.BLUEICE_RECEIVER_SOURCE_REVISION =
        env.BLUEICE_NOINFER_SOURCE_REVISION = env.BLUEICE_NONNULLABLE_AWAITED_SOURCE_REVISION =
        env.BLUEICE_STRING_INTRINSICS_SOURCE_REVISION = env.BLUEICE_MAPPED_INFERENCE_SOURCE_REVISION = env.BLUEICE_SYMBOLIC_KEYS_SOURCE_REVISION = manifest.sourceRevision;
    // The new cohort runs first; all eleven complete cohorts are required.
    for (const target of cohorts) {
        assert(binaries[target]); const exit = run(binaries[target], ['--include-ignored', '--nocapture'], target);
        const text = fs.readFileSync(path.join(out, target + '.stdout'), 'utf8');
        state.followups.push({target, exit, passed: exit === 0 && /0 failed; 0 ignored;.*0 filtered out/.test(text),
            binarySha256: hash(binaries[target])}); save();
        assert(state.followups.at(-1).passed, target + ' failed');
    }
    for (const [index, row] of matrix.cases.entries()) {
        const target = path.basename(row.source, '.rs');
        const name = row.kind === 'oracle-row' ? 'pinned_rebuild_matrix' : row.name.split('::')[1];
        const label = String(index).padStart(2, '0') + '-' + target;
        const exit = run(binaries[target], ['--exact', name, '--include-ignored', '--nocapture'], label);
        const text = fs.readFileSync(path.join(out, label + '.stdout'), 'utf8');
        state.cases.push({id: row.name, function: name, exit, passed: exit === 0 && /1 passed; 0 failed; 0 ignored;/.test(text),
            stdout: label + '.stdout', stderr: label + '.stderr', binarySha256: hash(binaries[target])}); save();
    }
    state.core82Exit = run(binaries.typescript_oracle, ['--ignored', '--nocapture'], 'core82');
    const text = fs.readFileSync(path.join(out, 'core82.stdout'), 'utf8');
    const ignored = cp.execFileSync(binaries.typescript_oracle, ['--list', '--ignored'], {env, encoding: 'utf8'});
    const all = cp.execFileSync(binaries.typescript_oracle, ['--list'], {env, encoding: 'utf8'});
    fs.writeFileSync(path.join(out, 'core82-ignored-catalog.txt'), ignored); fs.writeFileSync(path.join(out, 'core82-all-catalog.txt'), all);
    const selected = [...ignored.matchAll(/^(.+): test\r?$/gm)].map(match => match[1]).sort();
    const passed = [...text.matchAll(/^test (.+) \.\.\. ok\r?$/gm)].map(match => match[1]).sort();
    state.core82Selection = {selected, passed, ordinarySupportFiltered: 6};
    state.core82Passed = state.core82Exit === 0 && /82 passed; 0 failed; 0 ignored;.*6 filtered out/.test(text)
        && selected.length === 82 && JSON.stringify(selected) === JSON.stringify(passed)
        && [...all.matchAll(/^(.+): test\r?$/gm)].length === 88;
    for (const [name, digest] of Object.entries(manifest.files)) assert.equal(hash(path.join(source, name)), digest, name);
    compilerCheck();
    state.conclusion = state.followups.length === 11 && state.followups.every(row => row.passed)
        && state.cases.length === 25 && state.cases.every(row => row.passed) && state.core82Passed ? 'success' : 'failure';
    state.stage = 'complete'; state.finishedAt = new Date().toISOString(); save();
    process.exitCode = state.conclusion === 'success' ? 0 : 1;
} catch (error) {
    state.error = error.stack; state.conclusion = 'failure'; state.finishedAt = new Date().toISOString(); save(); process.exitCode = 1;
}
