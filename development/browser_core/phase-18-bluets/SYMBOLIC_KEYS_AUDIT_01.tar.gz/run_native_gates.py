# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime,hashlib,json,os,subprocess,shutil
repo=Path('/Users/ephoton/git/blueice-bluets')
root=Path(__file__).resolve().parent
phase=repo/'development/browser_core/phase-18-bluets'
frozen=json.loads((root/'frozen-source-preflight.json').read_text())
revision=frozen['sourceRevision']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',BLUEICE_BLUETSC_ORACLE=str(repo/'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'),BLUEICE_ACORN_ORACLE=str(repo/'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn'),FORCE_COLOR='0')
for key in list(env):
 if key.startswith('BLUEICE_WRITE_') or key.startswith('BLUETS_'):del env[key]
state={'sourceRevision':revision,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'bootstrap','conclusion':'in_progress','steps':[]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(root/'native-gates.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label;save();log=root/(label+'.log');assert not log.exists(),label
 print('START',label,flush=True)
 with log.open('wb') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':args,'exit':r.returncode,'log':log.name,'sha256':sha(log)});save();print('END',label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(label+': exit'+str(r.returncode))
 return log
cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
try:
 save();(root/'baseline-cases.json').write_bytes(subprocess.check_output(['git','show','HEAD:development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json'],cwd=repo))
 run('suite-write',cargo+['--write',revision]);run('source-check',cargo+['--check-staged']);run('case-audit',cargo+['--cases-audit',revision])
 catalog=json.loads((phase/'COMPATIBILITY_SUITES.json').read_text());assert len(catalog['suites'])==189
 suite=next(s for s in catalog['suites'] if s['harness']=='backend/bluets/tests/symbolic_keys.rs');assert len(suite['ignored_tests'])==1
 run('native-build',['cargo','test','-p','blueice-bluets','-p','blueice-bluets-bluejs','--no-run','--locked','--offline'])
 cli=repo/'target/debug/bluetsc';state['nativeCompilerSha256']=sha(cli);shutil.copy2(cli,root/'accepted-native-cli');save()
 env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 env['BLUEICE_NONNULLABLE_AWAITED_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 env['BLUEICE_STRING_INTRINSICS_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 env['BLUEICE_MAPPED_INFERENCE_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 env['BLUEICE_SYMBOLIC_KEYS_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json'),('BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS','callables'),('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers'),('BLUEICE_NOINFER_OBSERVATIONS','noinfer'),('BLUEICE_NONNULLABLE_AWAITED_OBSERVATIONS','nonnullable-awaited'),('BLUEICE_STRING_INTRINSICS_OBSERVATIONS','string-intrinsics'),('BLUEICE_MAPPED_INFERENCE_OBSERVATIONS','mapped-inference'),('BLUEICE_SYMBOLIC_KEYS_OBSERVATIONS','symbolic-keys')]:
  dest=root/'native-capture'/suffix;dest.parent.mkdir(parents=True,exist_ok=True)
  if name.endswith('DIRECTORY') or name.endswith('OBSERVATIONS'):dest.mkdir(exist_ok=True)
  env[name]=str(dest)
 for name in ['BLUEICE_CALLABLE_SOURCE_REVISION','BLUEICE_RECEIVER_SOURCE_REVISION','BLUEICE_NOINFER_SOURCE_REVISION','BLUEICE_NONNULLABLE_AWAITED_SOURCE_REVISION','BLUEICE_STRING_INTRINSICS_SOURCE_REVISION','BLUEICE_MAPPED_INFERENCE_SOURCE_REVISION','BLUEICE_SYMBOLIC_KEYS_SOURCE_REVISION']:env[name]=revision
 tools=subprocess.check_output(['node','-e',"process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"],cwd=repo)
 (root/'frozen-final-oracle-tools.json').write_text(json.dumps({'sha256':json.loads(tools)},indent=2)+'\n')
 run('native',[ 'node',str(root/'measure_priority.cjs')])
 report=json.loads((root/'accepted-native/measurement.json').read_text());assert report['conclusion']=='success' and len(report['suites'])==len(catalog['suites'])==189
 assert all(s['failed']==s['ignored']==s['filtered']==0 for s in report['suites'])
 assert sum(s['passed'] for s in report['suites'])==1076
 state['native']={'suites':189,'functions':sum(s['passed'] for s in report['suites']),'failed':0,'ignored':0,'filtered':0};state.update(stage='complete-native-catalog',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as error:
 state.update(conclusion='failure',error=repr(error),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
