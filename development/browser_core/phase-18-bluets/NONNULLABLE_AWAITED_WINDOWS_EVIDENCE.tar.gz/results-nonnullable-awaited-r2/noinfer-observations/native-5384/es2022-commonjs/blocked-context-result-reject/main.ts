declare function choose<T>(): NoInfer<T>;
export const value: number = choose();
