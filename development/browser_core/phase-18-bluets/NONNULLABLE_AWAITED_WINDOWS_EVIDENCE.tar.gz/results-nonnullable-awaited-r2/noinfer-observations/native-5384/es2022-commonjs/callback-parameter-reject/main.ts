declare function choose<T extends string>(anchor: T, check: (value: NoInfer<T>) => void): T;
export const value = choose("red", (value: "blue") => {});
