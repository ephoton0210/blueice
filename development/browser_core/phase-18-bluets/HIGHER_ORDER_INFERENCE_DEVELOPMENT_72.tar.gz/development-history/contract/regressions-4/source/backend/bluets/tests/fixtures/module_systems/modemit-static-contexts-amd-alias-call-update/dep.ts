// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

let value = 20; export {value as live}; export function bump(): number { const old = value++; value += 21; return old; }
