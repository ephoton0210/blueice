# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Record the expected failing public regression before production repairs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent.parent
output = root / 'rust-red-1'
output.mkdir()
environment = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
                   CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                   RUST_TEST_THREADS='1',
                   BLUEICE_CONDITIONAL_INFERENCE_OBSERVATIONS=str(output / 'observations'))
command = ['cargo', 'test', '-p', 'blueice-bluets', '--test',
           'conditional_inference', '--locked', '--offline']
state = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'command': command, 'conclusion': 'in_progress'}
(output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
source = repo / 'backend/bluets/tests/conditional_inference.rs'
(output / 'conditional_inference.rs').write_bytes(source.read_bytes())
with (output / 'cargo.log').open('wb') as log:
    result = subprocess.run(command, cwd=repo, env=environment,
                            stdout=log, stderr=subprocess.STDOUT)
state.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             exit=result.returncode,
             conclusion='red' if result.returncode else 'unexpectedly-green',
             logSha256=hashlib.sha256((output / 'cargo.log').read_bytes()).hexdigest(),
             testSourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
             compilerSha256=hashlib.sha256((repo / 'target/debug/bluetsc').read_bytes()).hexdigest())
(output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(state), flush=True)
sys.exit(result.returncode)
