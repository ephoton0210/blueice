# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile,shutil

repo=Path('/Users/ephoton/git/blueice-bluets')
root=Path('/private/tmp/bluets-next-project-20261110')
phase=repo/'development/browser_core/phase-18-bluets'
folder=repo/'differential-testing/bluets-projects'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=read(root/'defu-audit-v3/report.json')
probes=read(root/'reproductions-v2/report.json')
checks=read(root/'audit-checks.json')
reference=read(folder/'defu-v6.1.4.native.json')
accepted=read(phase/'PROJECT_FOLLOWUP_MEASUREMENT.json')
assert checks['conclusion']=='pass' and all(c['exit']==0 for c in checks['commands'])
assert report['conclusion']=='blocked' and report['nativeBaselineValid'] and report['compatible'] is False
assert report['native']['incremental']['passed'] and report['bluets']['cold']['exit']!=0
assert probes['conclusion']=='observed-differences' and probes['verdictAgreements']==4 and len(probes['cases'])==8
assert report['compilerSha256']==probes['compilerSha256']==accepted['compilerSha256']['native']
assert report['sourceRevision']==probes['sourceRevision']==accepted['source']['sourceRevision']
assert subprocess.check_output(['git','rev-parse','HEAD:backend'],cwd=repo,text=True).strip()==report['sourceRevision'].split(':')[1]
assert not subprocess.check_output(['git','diff','--name-only','--','backend'],cwd=repo,text=True).strip()
diagnostics=[json.loads(line)for line in(root/'defu-audit-v3/bluets-cold.stderr').read_text().splitlines()]
assert len(diagnostics)==13
# Retain the actual current audit sources as well as recoverable earlier Native
# baseline versions. A recovered version must match its original recorded hash.
tools=root/'accepted-audit-tools';tools.mkdir(exist_ok=True)
for path in folder.glob('*.cjs'):shutil.copyfile(path,tools/path.name)
oldtools=root/'native-baseline-tools';oldtools.mkdir(exist_ok=True)
recovery=[]
for name,digest in reference['tools'].items():
 source=(folder/name).read_text()
 if name=='defu-audit.cjs':
  start=source.index('function verifyReference(');end=source.index('function audit(',start)
  source=source[:start]+source[end:]
  start=source.index('    const declarationTexts =');end=source.index('    report.nativeBaselineValid =',start)
  source=source[:start]+source[end:]
  source=source.replace('applyEdit, verifyReference};','applyEdit};')
 if name=='defu-audit.test.cjs':
  source=source.replace('applyEdit, verifyReference}', 'applyEdit}')
  start=source.index("test('Native baseline changes");end=source.index("test('a refused multi-file",start)
  source=source[:start]+source[end:]
 path=oldtools/name;path.write_text(source)
 assert sha(path)==digest,(name,'Native baseline source recovery does not match its recorded hash')
 recovery.append({'path':name,'sha256':digest})
(root/'native-tool-recovery.json').write_text(json.dumps({'scope':'Earlier baseline tools recovered by reversing later validation-only additions; every byte matches its original recorded SHA-256.','files':recovery},indent=2)+'\n')
archive=root/'defu-project-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for path in sorted(root.iterdir()):
  if path.name not in {'defu-upstream',archive.name}:tar.add(path,arcname=path.name,recursive=True)
assert archive.stat().st_size<95*1024*1024
destination=phase/'DEFU_PROJECT_EVIDENCE.tar.gz';shutil.copyfile(archive,destination)
summary={'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'conclusion':'audit-complete-project-blocked','compilerRepairComplete':False,
 'project':report['project'],'sourceRevision':report['sourceRevision'],
 'compilerSha256':report['compilerSha256'],'compilerBuildEvidence':'PROJECT_FOLLOWUP_MEASUREMENT.json',
 'compilerBytes':'PROJECT_FOLLOWUP_COMPILER_EVIDENCE.tar.gz','audit':report,
 'reproductions':probes,'coldDiagnosticCount':len(diagnostics),'coldDiagnostics':diagnostics,
 'independentFamilies':['contextual parameter and function-type names','conditional tuple infer rest','unknown-object guard ordering'],
 'checks':checks,'productionRustChanged':False,
 'freshFullWorkspaceOrWindowsRun':False,
 'globalCompatibilityDenominatorChanged':False,'fullTypeScriptParity':False,
 'limits':['CommonJS/ES2022 strict production profile only; authored scenarios are not the upstream complete suite.',
 'BlueTSC cold compilation is rejected; all dependent declaration/runtime/consumer/incremental acceptance is blocked.',
 'Negative minimal controls compare verdicts and preserve raw diagnostics, without claiming full diagnostic parity.',
 'Native multi-source incremental state interchange is a separate pending extension; safe owner-current fallback is intentional.',
 'The initial runtime calibration and aggregate-tool environment initialization failure are retained and not credited as passing gates.']}
(phase/'DEFU_PROJECT_MEASUREMENT.json').write_text(json.dumps(summary,indent=2)+'\n')
(phase/'DEFU_PROJECT_ARTIFACTS.json').write_text(json.dumps({'schema':1,'sourceRevision':report['sourceRevision'],'artifacts':[{'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination),'scope':'All project/probe observations, original/updated Native controls, invalid initial calibration, tool initialization failure, complete corrected tool logs and actual audit-tool bytes. Original upstream source archive is separately versioned by the project manifest.'}]},indent=2)+'\n')
print(json.dumps({'sourceRevision':report['sourceRevision'],'nativeBaselineValid':True,'blueTscProject':'blocked','diagnostics':13,'minimalControls':8,'falseRefusals':4,'independentFamilies':3,'archiveBytes':destination.stat().st_size,'archiveSha256':sha(destination)},indent=2))
