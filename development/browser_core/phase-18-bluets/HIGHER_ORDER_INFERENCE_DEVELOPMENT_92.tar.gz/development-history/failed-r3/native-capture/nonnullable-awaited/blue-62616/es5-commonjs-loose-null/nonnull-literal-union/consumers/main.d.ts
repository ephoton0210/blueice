export declare const value: NonNullable<"red" | "blue">;
