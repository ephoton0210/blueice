export declare const value: {};
