type Alias<T> = T;
type Infer<T> = T extends Alias<infer U> ? U : never;
declare const value: Infer<Alias<number>>;
export const result = value;
