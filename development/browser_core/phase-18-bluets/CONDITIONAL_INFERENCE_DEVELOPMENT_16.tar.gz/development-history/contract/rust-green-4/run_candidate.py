# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Snapshot each focused candidate and retain its actual compile/test result."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent.parent
output = root / sys.argv[1]
output.mkdir()
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
sources = sorted(file for file in (repo / 'backend/bluets/src').rglob('*') if file.is_file())
manifest = {}
for source in sources:
    name = source.relative_to(repo)
    destination = output / 'source' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    manifest[name.as_posix()] = sha(source)
test = repo / 'backend/bluets/tests/conditional_inference.rs'
shutil.copy2(test, output / 'conditional_inference.rs')
for fixture in (repo / 'backend/bluets/tests/fixtures/conditional_inference').iterdir():
    if fixture.is_file():
        target = output / 'frozen-inputs' / fixture.name
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(fixture, target)
(output / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
shutil.copy2(__file__, output / 'run_candidate.py')
environment = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
                   CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
                   RUST_TEST_THREADS='1',
                   BLUEICE_CONDITIONAL_INFERENCE_OBSERVATIONS=str(output / 'observations'))
command = ['cargo', 'test', '-p', 'blueice-bluets', '--test',
           'conditional_inference', '--locked', '--offline']
state = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'command': command, 'conclusion': 'in_progress',
         'sourceManifestSha256': sha(output / 'source-manifest.json')}
(output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
with (output / 'cargo.log').open('wb') as log:
    result = subprocess.run(command, cwd=repo, env=environment,
                            stdout=log, stderr=subprocess.STDOUT)
text = (output / 'cargo.log').read_text(errors='replace')
tests_started = 'Running tests/conditional_inference.rs' in text
state.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             exit=result.returncode, testsStarted=tests_started,
             conclusion='success' if result.returncode == 0 else 'failure',
             phase='tests' if tests_started else 'compile',
             logSha256=sha(output / 'cargo.log'),
             sourceUnchanged=all(sha(repo / name) == value for name, value in manifest.items()),
             differences=re.findall(r'(\d+) complete differences', text))
if tests_started:
    compiler = repo / 'target/debug/bluetsc'
    state['compilerSha256'] = sha(compiler)
    shutil.copy2(compiler, output / 'actual-bluetsc')
(output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps(state), flush=True)
sys.exit(result.returncode)
