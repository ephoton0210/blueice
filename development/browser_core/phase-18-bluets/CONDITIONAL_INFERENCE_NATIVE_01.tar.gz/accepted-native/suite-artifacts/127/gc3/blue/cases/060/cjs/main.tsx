// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
import {h} from "./factory.js";
function Select(props:{kind:"number";value:number}):JSX.Element;
function Select(props:{kind:"text";text:string}):JSX.Element;
function Select(props:{kind:"number";value:number}|{kind:"text";text:string}):JSX.Element{return {tag:42};}
const element=<Select kind="text" value={42} />;
export const result=[element.tag];
export const inferred=element;
