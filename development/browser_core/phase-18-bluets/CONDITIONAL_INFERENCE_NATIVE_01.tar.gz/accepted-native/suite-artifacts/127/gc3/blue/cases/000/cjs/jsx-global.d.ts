// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
export {};
declare global { namespace JSX {
interface Element { tag: number; }
interface ElementClass { render(): Element; }
interface ElementAttributesProperty { props: {}; }
interface ElementChildrenAttribute { children: {}; }
interface IntrinsicAttributes { key?: string | number; }
interface IntrinsicElements { span: {value: number}; }
type LibraryManagedAttributes<C,P> = C extends {defaultProps: infer D} ? Omit<P,keyof D> & Partial<Pick<P,Extract<keyof P,keyof D>>> : P;
} }
