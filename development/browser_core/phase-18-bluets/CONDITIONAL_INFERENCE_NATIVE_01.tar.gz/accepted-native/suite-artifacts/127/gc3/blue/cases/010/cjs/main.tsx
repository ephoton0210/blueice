// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
import {h} from "./factory.js";
type Props={kind:"number";value:number}|{kind:"text";text:string};
class Select { props:Props;
 constructor(props:{kind:"number";value:number});
 constructor(props:{kind:"text";text:string});
 constructor(props:Props){this.props=props;}
 render():JSX.Element{return {tag:42};}
}
const element=<Select kind="text" text="ok" />;
export const result=[element.tag];
export const inferred=element;
