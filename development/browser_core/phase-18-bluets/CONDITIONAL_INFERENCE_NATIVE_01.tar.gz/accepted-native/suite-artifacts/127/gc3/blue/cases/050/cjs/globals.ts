// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
export {};
declare global {
 interface GC3State {value:number;}
 var gc3State:GC3State;
 namespace JSX {interface IntrinsicElements {globalitem:{count:number};}}
}
globalThis.gc3State={value:42};
