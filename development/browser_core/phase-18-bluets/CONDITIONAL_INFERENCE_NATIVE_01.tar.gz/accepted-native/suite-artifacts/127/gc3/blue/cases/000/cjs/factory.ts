// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
export function h(tag:any,input:any,...children:any[]):JSX.Element {
 const props=Object.assign({},tag.defaultProps||{},input||{},children.length?{children}:{});
 if(typeof tag==='function') return tag.prototype&&tag.prototype.render ? new tag(props).render() : tag(props);
 return {tag:42};
}
