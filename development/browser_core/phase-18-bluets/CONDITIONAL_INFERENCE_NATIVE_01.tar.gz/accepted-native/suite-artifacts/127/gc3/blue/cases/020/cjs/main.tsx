// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
import {h} from "./factory.js";
function Left(props:{value:number;left?:string}):JSX.Element{return {tag:42};}
function Right(props:{value:number;right?:boolean}):JSX.Element{return {tag:42};}
const Tag=Math.random()>-1?Left:Right;
function UnionProps(props:{kind:"number";value:number}|{kind:"text";text:string}):JSX.Element{return {tag:42};}
const first=<Tag value={42} left="ok" right={true}/>;
const second=<UnionProps kind="text" text={"ok"} />;
export const result=[first.tag,second.tag];
export const inferred=second;
