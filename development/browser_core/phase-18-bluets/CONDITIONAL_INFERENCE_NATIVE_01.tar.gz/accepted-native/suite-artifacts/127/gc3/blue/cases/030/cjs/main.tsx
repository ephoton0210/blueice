// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
import {h} from "./factory.js";
interface NodeProps {value:number;next?:NodeProps;}
interface TreeProps {node:NodeProps;children:JSX.Element|JSX.Element[];}
function Tree(props:TreeProps):JSX.Element{return {tag:props.node.value};}
namespace Tree {export const defaultProps={children:[] as JSX.Element[]};}
const element=<Tree node={{value:42,next:{value:1}}}><span value={1}/></Tree>;
const defaulted=<Tree node={{value:42}}/>;
export const result=[element.tag,defaulted.tag];
export const inferred=element;
