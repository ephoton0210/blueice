// G-C3 🧭 UTF-16 source-coordinate witness
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
import {h} from "./factory.js";
import "./globals.js";
const element=<globalitem count={gc3State.value}/>;
export const result=[element.tag,gc3State.value];
export const inferred=element;
