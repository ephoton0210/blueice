# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime,hashlib,json,tarfile
base=Path('B:/BlueIce/gm3-20261109-360d7d921')
results=base/'results-nonnullable-awaited-r2'
manifest_path=base/'p0b-r2-source-manifest.json'
manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
measurement=json.loads((results/'measurement.json').read_text(encoding='utf-8'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert measurement['conclusion']=='success' and measurement['stage']=='complete'
assert measurement['sourceRevision']==manifest['sourceRevision']=='backend-tree:d93ce26e990e61e09dacab7a31fbcec822674030'
assert measurement['verifiedSourceFiles']==len(manifest['files'])==14697
assert measurement['verifiedBackendFiles']==manifest['backendFiles']==14025
assert measurement['expectedSourceManifestSha256']==sha(manifest_path)
assert measurement['core82Exit']==0 and measurement['core82Passed']
assert len(measurement['cases'])==25 and all(row['passed'] and row['exit']==0 for row in measurement['cases'])
assert len(measurement['followups'])==8 and all(row['passed'] and row['exit']==0 for row in measurement['followups'])
compiler=Path(measurement['compiler']['path']);assert sha(compiler)==measurement['compiler']['sha256']
image=compiler.read_bytes();pe=int.from_bytes(image[60:64],'little');assert image[pe:pe+4]==bytes([80,69,0,0]);machine=int.from_bytes(image[pe+4:pe+6],'little');assert machine==0x8664
archive=base/'p0b-r2-windows-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as output:
 for file in sorted(results.rglob('*')):
  if file.is_file():
   assert not file.is_symlink();output.add(file,arcname=file.relative_to(base).as_posix(),recursive=False)
 for file,name in [(compiler,'followup-bluetsc.exe'),(base/'p0b-r2-source-patch.tar.gz','followup-patch.tar.gz'),(manifest_path,'windows-source-manifest.json'),(base/'p0b-r2-windows-runner.cjs','windows-runner.cjs'),(base/'p0b-r2-apply-source.py','apply-source.py')]:output.add(file,arcname=name,recursive=False)
receipt={'sourceRevision':measurement['sourceRevision'],'conclusion':'success','archive':str(archive),'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'compilerSha256':sha(compiler),'compilerMachine':machine,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(base/'p0b-r2-windows-evidence.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
