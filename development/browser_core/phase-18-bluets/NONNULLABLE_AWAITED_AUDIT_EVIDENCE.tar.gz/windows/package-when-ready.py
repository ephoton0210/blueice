# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import ctypes
import json
import runpy
import time

base = Path('B:/BlueIce/gm3-20261109-360d7d921')
measurement = base / 'results-nonnullable-awaited-r2/measurement.json'
print('Waiting for the existing Windows runner11716 to finish.', flush=True)
while True:
    value = json.loads(measurement.read_bytes())
    assert value['pid'] == 11716
    assert value['sourceRevision'] == 'backend-tree:d93ce26e990e61e09dacab7a31fbcec822674030'
    if value.get('conclusion'):
        assert value['conclusion'] == 'success' and value['stage'] == 'complete', value.get('error')
        break
    kernel = ctypes.windll.kernel32
    kernel.OpenProcess.restype = ctypes.c_void_p
    handle = kernel.OpenProcess(4096, False, 11716)
    code = ctypes.c_ulong()
    assert handle and kernel.GetExitCodeProcess(ctypes.c_void_p(handle), ctypes.byref(code))
    kernel.CloseHandle(ctypes.c_void_p(handle))
    assert code.value == 259, 'Runner ended without a terminal measurement'
    time.sleep(5)
runpy.run_path(str(base / 'p0b-r2-package-evidence.py'), run_name='__main__')
