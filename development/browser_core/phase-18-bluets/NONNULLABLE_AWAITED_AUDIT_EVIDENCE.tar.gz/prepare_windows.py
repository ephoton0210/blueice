# This Source Code Form is subject to the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime,hashlib,io,json,tarfile
repo=Path('/Users/ephoton/git/blueice-bluets');root=repo/'target/nonnullable-awaited-20261112-r2';old=root/'retired-test-count-d5/windows';out=root/'windows';out.mkdir();read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=read(root/'frozen-source-preflight.json');previous=read(old/'windows-source-manifest.json');native=read(root/'native-gates.json');assert native['stage'] in ['source-check','case-audit','native-build','native']
files={};archive=out/'source-patch.tar.gz'
with tarfile.open(archive,'w:gz') as output:
 for name in sorted(previous['files']):
  path=repo/name;assert path.is_file() and not path.is_symlink();data=path.read_bytes();files[name]=hashlib.sha256(data).hexdigest();member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;output.addfile(member,io.BytesIO(data))
assert {name for name in files if name.startswith('backend/')}==set(frozen['files']);assert all(files[name]==digest for name,digest in frozen['files'].items())
manifest={**previous,'scope':'Full canonical corrected backend and retained original Windows82/path/project supports; every selected byte replayed and hashed. No old-source pass credit.','sourceRevision':frozen['sourceRevision'],'files':files,'followupPatchSha256':sha(archive),'correctionScope':'Update stale library unit module counts/source list for the added ES5 thenable layer; source bytes are replayed exactly. Declaration newlines remain the authored explicit LF option.','preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'windows-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
header_py='# This Source Code Form is subject to the terms of the Mozilla Public\n# License, v. 2.0. If a copy of the MPL was not distributed with this\n# file, You can obtain one at https://mozilla.org/MPL/2.0/.\n'
for source,destination in [('windows-runner.cjs','windows-runner.cjs'),('apply-source.py','apply-source.py'),('start-windows.ps1','start-windows.ps1'),('upload_windows.py','upload_windows.py'),('package-evidence-2.py','package-evidence.py')]:
 text=(old/source).read_text().replace('p0b-','p0b-r2-').replace('results-nonnullable-awaited-v1','results-nonnullable-awaited-r2').replace('windows-evidence-v1','windows-evidence').replace('backend-tree:d5f5f555ab5968685c4a3fbff1fd0cc797d6c49e',frozen['sourceRevision']).replace(previous['followupPatchSha256'],manifest['followupPatchSha256'])
 if 'This Source Code Form' not in text:text=(header_py.replace('#','//') if destination.endswith('.cjs') else header_py)+'\n'+text
 if destination.endswith('.py'):compile(text,str(out/destination),'exec')
 (out/destination).write_text(text)
package={'sourceRevision':frozen['sourceRevision'],'selectedFiles':len(files),'backendFiles':frozen['backendFiles'],'sourcePatchBytes':archive.stat().st_size,'sourcePatchSha256':sha(archive),'manifestSha256':sha(out/'windows-source-manifest.json'),'runnerSha256':sha(out/'windows-runner.cjs'),'applySourceSha256':sha(out/'apply-source.py'),'startScriptSha256':sha(out/'start-windows.ps1'),'preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Prepared only; existing Windows VM will run original82 core,25 paths and8 full regression cohorts on corrected source.'}
(out/'package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps(package,indent=2))
