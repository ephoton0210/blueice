# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
repo=Path('/Users/ephoton/git/blueice-bluets');old=repo/'target/nonnullable-awaited-20261112';root=repo/'target/nonnullable-awaited-20261112-r2';assert not root.exists();read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();original=read(old/'STATE.json')
assert read(old/'repair-preflight/measurement.json')['conclusion']=='success'
assert read(old/'local-gates.json')['conclusion']=='failure'
assert read(old/'native-gates.json')['conclusion']=='success'
assert read(old/'post-native-supervisor.json')['conclusion']=='failure'
subprocess.run(['git','add','--','backend/bluets/src/standard_library.rs'],cwd=repo,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip();backend=subprocess.check_output(['git','rev-parse',tree+':backend'],cwd=repo,text=True).strip();assert backend!='d5f5f555ab5968685c4a3fbff1fd0cc797d6c49e'
assert not subprocess.check_output(['git','diff','--numstat','--','backend'],cwd=repo)
root.mkdir();shutil.copytree(old/'repair-preflight',root/'repair-preflight');shutil.copytree(old/'support',root/'support')
for name in ['baseline-cli','baseline-replay.json','baseline-test-source.rs','baseline-cargo.log','baseline-native-durations.json']:
 shutil.copy2(old/name,root/name)
shutil.copytree(old/'cli-baseline-1',root/'cli-baseline-1')
header='# This Source Code Form is subject to the terms of the Mozilla Public\n# License, v. 2.0. If a copy of the MPL was not distributed with this\n# file, You can obtain one at https://mozilla.org/MPL/2.0/.\n'
for name in ['run_native_gates.py','run_local_gates.py','run_project_gates.py','watch_maps.py','measure_priority.cjs','presence_corrected.cjs','audit_acceptance.py','publish_acceptance.py','render_acceptance.py','check_publication.py','verify_windows.py']:
 text=(old/name).read_text().replace(str(old),str(root))
 if 'This Source Code Form' not in text:
  text=(header if name.endswith('.py') else header.replace('#','//'))+'\n'+text
 if name=='verify_windows.py':text=text.replace('results-nonnullable-awaited-v1/','results-nonnullable-awaited-r2/')
 if name=='audit_acceptance.py':
  text=text.replace("ROOT / 'retired-native-4ae/RETIREMENT.json'","ROOT / 'retired-test-count-d5/retired-native-4ae/RETIREMENT.json'")
  text=text.replace("'path': 'retired-native-4ae'","'path': 'retired-test-count-d5/retired-native-4ae'")
  text=text.replace("'retiredNativeEvidence': retired,", "'retiredNativeEvidence': retired, 'retiredTestCountEvidence': {'path':'retired-test-count-d5', 'receiptSha256':sha(ROOT/'retired-test-count-d5/RETIREMENT.json'), 'passCredit':False},")
 if name.endswith('.py'):compile(text,str(root/name),'exec')
 (root/name).write_text(text)
# Preserve the independent baseline and original frozen inputs, without carrying
# a retired source's pass status into this corrected candidate.
state={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'repaired-preflight-passed-source-frozen-awaiting-full-acceptance','sourceRevision':'backend-tree:'+backend,'backendTree':backend,'acceptedBaselineCommit':original['acceptedBaselineCommit'],'acceptedBaselineBackend':original['acceptedBaselineBackend'],'frozenSha256':original['frozenSha256'],'supplementaryFixtureSha256':original['supplementaryFixtureSha256'],'scope':original['scope'],'p0bComplete':False,'retiredTestCountCandidate':'retired-test-count-d5/RETIREMENT.json','preflight':'repair-preflight/measurement.json','nextAction':'Run complete new-source Native/projects/local/maps/Windows acceptance. No old-source pass credit and no checkbox/commit until full gates pass.'}
(root/'STATE.json').write_text(json.dumps(state,indent=2)+'\n')
paths=subprocess.check_output(['git','ls-files','-z','--','backend'],cwd=repo).decode().split(chr(0))[:-1];assert len(paths)==14025
frozen={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':state['sourceRevision'],'backendTree':backend,'parentCommit':original['acceptedBaselineCommit'],'backendFiles':len(paths),'files':{name:sha(repo/name) for name in paths},'scope':'Corrected source frozen after full BlueTS library/fmt/workspace-Clippy preflight; stale library module-count/list assertions repaired. Complete new-source acceptance still required.'}
(root/'frozen-source-preflight.json').write_text(json.dumps(frozen,indent=2)+'\n')
audit=read(old/'all-source-module-size-audit.json');audit['sourceRevision']=state['sourceRevision']
for row in audit['sources']:
 row['sha256']=sha(repo/row['path']);row['lines']=len((repo/row['path']).read_bytes().splitlines())
audit['maximumLines']=max(x['lines'] for x in audit['sources']);audit['overLimit']=[x for x in audit['sources'] if x['lines']>1500];assert not audit['overLimit'];(root/'all-source-module-size-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
# Retain the exact old D5 implementation patch and test-only repair delta.
shutil.copy2(repo/'target/string-intrinsic-design-20261112/p0b-source-prerequisite.patch',old/'candidate-source.patch')
(old/'test-count-repair.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','backend/bluets/src/standard_library.rs'],cwd=repo))
retirement={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':'backend-tree:d5f5f555ab5968685c4a3fbff1fd0cc797d6c49e','conclusion':'retired-failed-workspace-candidate','reason':'New ES5 thenable layer was not reflected in existing library unit assertions: ES2020 count12->13, ES2022 count15->16 and source list. Full Native186/1059 and Windows82+25+8 passed this OLD source, but workspace failed. Known failed workspace was deliberately terminated; no old-source pass credit is transferred.','nativeSession':61231,'nativeExit':0,'localSupervisorSession':17872,'localExit':1,'mapWatcherSession':4356,'mapWatcherExit':143,'stopReceipt':'stop-test-count-candidate.json','sourcePatchSha256':sha(old/'candidate-source.patch'),'testOnlyRepairPatchSha256':sha(old/'test-count-repair.patch'),'correctedSourceRevision':state['sourceRevision'],'originalDirectory':str(old)}
(old/'RETIREMENT.json').write_text(json.dumps(retirement,indent=2)+'\n')
shutil.move(old,root/'retired-test-count-d5')
(root/'RUN_STATE.md').write_text('P0-B corrected candidate R2: '+state['sourceRevision']+'\n\nOld D5 is fully retained in retired-test-count-d5, including Native186/1059, Windows82+25+8 and the actual failing/terminated workspace. All old handles are terminal. Main implementation source is frozen after corrected259 library tests, fmt and workspace/all-targets Clippy pass. New full acceptance is required. P0-C authoring worktree exists at /private/tmp/blueice-bluets-p0c-20261112; its237-form/four-profile candidate inputs are not calibrated/frozen yet, and no C production source or Cargo build exists. Single local Cargo pipeline must be preserved.\n')
print(json.dumps({'root':str(root),'sourceRevision':state['sourceRevision'],'backendFiles':len(paths),'moduleFiles':len(audit['sources']),'maximumModuleLines':audit['maximumLines'],'preflight':'success','retiredCandidate':str(root/'retired-test-count-d5')},indent=2))
