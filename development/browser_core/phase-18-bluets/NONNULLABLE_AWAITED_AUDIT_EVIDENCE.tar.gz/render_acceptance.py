# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
from audit_acceptance import ROOT, PHASE, read, sha

PREFIX = 'NONNULLABLE_AWAITED_'


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


def main():
    data = read(PHASE / (PREFIX + 'MEASUREMENT.json'))
    audit = read(ROOT / 'acceptance-audit.json')
    assert data['conclusion'] == 'completed-within-frozen-scope'
    assert audit['conclusion'] == 'success' and audit['sourceRevision'] == data['source']['sourceRevision']
    for row in data['artifacts']:
        assert sha(PHASE / row['path']) == row['sha256']
    source = data['source']['sourceRevision']
    native = data['nativeMeasurement']
    workspace = data['gates']['workspace']
    acceptance = f'''# P0-B — NonNullable and ES5 Awaited acceptance

Accepted 2026-11-12, source `{source}`, against TypeScript 5.9.3.
The [measurement]({PREFIX}MEASUREMENT.json), [artifact manifest]({PREFIX}ARTIFACTS.json)
and [frozen follow-up]({PREFIX}FOLLOWUP.md) bind this finite package.
Full TypeScript parity remains **OFF**; all 22 broader open feature rows remain open.

NonNullable uses ordinary intersection semantics for `T & {{}}`, including loose-null
options, unknown/any/never, unions and generic inference. Static ES5 thenable
foundations provide PromiseLike, Promise, PromiseConstructorLike and Awaited;
the runtime Promise constructor remains in the ES2015 layer. Owner/local/imported
declarations retain precedence. Structural conditional/infer matching projects
fixed-prefix/rest callbacks and keeps intersection bindings atomic. Copied callable
values preserve their declared diagnostic owner until actual call/relation demand.

Demand frames follow complete type identities through annotations, copied/inferred
values and call results. Semantic nontermination reports Native TS2589 at the
complete demanded use-site; guarded identities and decreasing instantiations remain
valid. Configured zero/one-work or depth refusal remains ResourceLimit, publishes
nothing and does not acquire a Native counterpart. The default work limit is unchanged.

| Frozen acceptance | Actual result |
| --- | --- |
| Primary programs | 91 forms × 4 profiles = 364 comparisons |
| Ordinary operators | Eight independently authored Present/Unwrap forms × 4 profiles = 32 comparisons |
| Complete direct scope | 396/396 complete verdict, primary/related diagnostic and UTF-16-position agreements |
| Additional Native controls | Six independent demand/guard/decreasing/adjacent-error cases, separate from the 396 primary scope |
| Accepted declarations, per actual compiler | 315 byte-exact inventories / 331 files |
| Isolated declaration consumers | 630 positive/negative consumers per compiler |
| Syntax and execution | 331 selected-edition parses and 12 executions per compiler |
| Separate boundaries | Six owner/runtime, nine original and six supplementary resource controls; excluded from direct agreement |
| Complete Native catalog | {native['suites']} suites / {native['functions']:,} functions; zero failed, ignored or filtered |
| Complete local workspace | {workspace['passed']:,} passed, zero failed; Native-only functions are selected in the complete catalog above |
| Complete maps | Fresh process-bound 8,407 configurations × two builds for both actual local compiler profiles; zero differences |
| Windows x86_64 | Same-source 82/82 core oracles, 25/25 paths and eight complete regression cohorts |
| Real projects and tooling | Complete defu/mitt, eight prerequisite reproductions and interchange; formatting, warnings-denied workspace/all-targets Clippy, Node/Python and accounting gates pass |
| Module size | 543 production source files audited; maximum 1,477 lines, none over 1,500 |

The unchanged accepted P0-A source has 29 complete agreements and 82 accepted
builds across the same 396 inputs. This retained baseline executable is a
single-crate development build, recorded separately from the final Native/workspace
compiler profiles. Its complete raw observations, source/compiler hashes and
independent replay are retained. Name witnesses now lack only Uppercase, Lowercase,
Capitalize and Uncapitalize in both selected profiles. These 44 presence witnesses
carry no semantic-denominator credit. Separate frozen ES5 cases isolate Awaited
visibility from PromiseLike visibility and reject static names as runtime values.

All previous 40,213 suite-qualified case IDs and comparison/status/scope/reason
classifications remain unchanged. The 396 direct, six additional Native and
21 separate boundary controls add 423 assertions, making **N = 40,636**.
These assertions are not unique programs or a TypeScript language percentage.
The earlier failed Native candidate is retained with its G-C1 diagnostic failure
and receives no pass credit. A later workspace run caught stale library unit
module-count/source-list assertions after adding the ES5 thenable layer. Its
failed run is retained separately; corrected library, formatting and Clippy
preflight passed before this source was frozen and fully remeasured.
Windows packaging in the retired candidate first failed on CP950 decoding;
its original helper/error and corrected UTF-8 packaging receipt remain alongside
the unchanged successful test results. No test was rerun to hide that packaging error.

Both actual local compilers and the Windows PE x86_64 compiler, full source
snapshots, raw logs, per-case observations, consumer outputs and map bindings are
retained in the archives. Every archive and member is hashed. Reproduction uses
pinned TypeScript 5.9.3 and Acorn 8.15.0; full commands, selected names and versions
are in the measurement. The Windows gate uses the accepted 82-core/local-workspace
boundary; hosted CI, extra OS profiles and coverage are supplementary.

P0-B is complete within this frozen scope. P0-C remains unchecked; broader
feature closure requires its own explicit contract.
'''
    (PHASE / (PREFIX + 'ACCEPTANCE.md')).write_text(acceptance)
    frozen = data['frozenInputs']
    followup = '''# P0-B — NonNullable and ES5 Awaited

Status: completed within the frozen scope. See [acceptance](NONNULLABLE_AWAITED_ACCEPTANCE.md),
[measurements](NONNULLABLE_AWAITED_MEASUREMENT.json) and the
[artifact manifest](NONNULLABLE_AWAITED_ARTIFACTS.json).

The package connects G-T2/G-T3/G-T5/G-T6/G-T7/G-T8 and preserves G-T1 diagnostic
regressions. Its fixtures are `backend/bluets/tests/fixtures/nonnullable_awaited/`.

| Frozen scope | Required and verified result |
| --- | --- |
| Primary | 91 forms × four profiles = 364 comparisons |
| Ordinary operators | Eight Present/Unwrap forms × four profiles = 32 comparisons |
| Complete direct scope | 396 full comparisons; 315 exact declaration inventories / 331 files |
| Declaration consumers | 630 isolated positive/negative Native consumers |
| Syntax/runtime | 331 selected-edition parses and twelve executions |
| Additional Native demand | Six independent recursive/guarded/decreasing/adjacent-error controls |
| Separate boundaries | Six owner/runtime, nine original resource and six supplementary zero/one-work controls |

All authored inputs and Native expectations were frozen before production changes.
Original frozen SHA-256 values remain unchanged:

'''
    for name, digest in frozen.items():
        followup += f'- `{name}`: `{digest}`.\n'
    followup += '''
Supplementary demand references and zero/one-work controls are separately hashed
in the measurement. Native semantic errors and configured policy refusals retain
distinct boundaries. The ordinary Present/Unwrap controls share the same
intersection and conditional machinery; matching a utility name does not supply
its behavior. Each profile requires exact primary/related diagnostics, UTF-16
positions and declaration bytes, including the explicit LF contract on Windows.

The baseline has 29/396 complete agreements and 82 accepts. Complete accepted
measurements reach 396/396 and 315 accepts. Intermediate checkpoints and the
retired G-C1 failure remain in the raw development/audit archives. Acceptance
requires complete same-source Native, local workspace, both map profiles,
projects/tooling and Windows 82-core/path/regression gates. Those gates have now
passed; implementation and measurements are committed together. P0-C and all
22 broader rows retain their open scope.
'''
    (PHASE / (PREFIX + 'FOLLOWUP.md')).write_text(followup)
    path = PHASE / 'TODO.md'
    todo = path.read_text()
    start = todo.index('**Latest completed follow-up:**')
    end = todo.index('\n## Open gaps', start)
    todo = todo[:start] + '''**Latest completed follow-up:** P0-B supplies NonNullable through ordinary
intersection semantics and ES5 Awaited through shared structural conditional/infer
paths, preserving runtime/owner and semantic/resource boundaries.
[Acceptance](NONNULLABLE_AWAITED_ACCEPTANCE.md) binds complete Native/local/Windows
gates, exact declarations, isolated consumers, maps and project regressions to
its source. P0-A and earlier packages retain their dated evidence.
All 22 broader rows remain open; continue with P0-C.
''' + todo[end:]
    todo = replace_once(todo, 'Standard library: five remaining utility names in the current ES2022 probe, ES5 Awaited and its supporting declarations, wider catalogs and compositions.', 'Standard library: four string-intrinsic names in both selected presence profiles, wider catalogs and compositions.')
    todo = replace_once(todo, 'Continue with P0-B, then P0-C.', 'Continue with P0-C.')
    start = todo.index('- [Library selection]')
    end = todo.index('- [Resolution fingerprints]', start)
    todo = todo[:start] + '''- [Library selection](../../../backend/bluets/src/standard_library/manifest.rs)
  admits [static thenable foundations](../../../backend/bluets/src/standard_library/ecma-thenable.v3.d.ts)
  from ES5, including PromiseLike and Awaited. The
  [runtime Promise constructor](../../../backend/bluets/src/standard_library/ecma-promise.v3.d.ts)
  remains ES2015. Frozen visibility, owner/runtime and structural controls verify
  those separate boundaries; wider thenable compositions remain open.
''' + todo[end:]
    start = todo.index('The [current presence witnesses]')
    end = todo.index('- [x] **P0-A', start)
    todo = todo[:start] + '''The [current presence witnesses](NONNULLABLE_AWAITED_MEASUREMENT.json#/presenceInventory/corrected)
retain Uppercase, Lowercase, Capitalize and Uncapitalize as missing in both
selected profiles. NoInfer, NonNullable and the Awaited/PromiseLike witness now
pass; P0-B separately isolates ES5 Awaited and PromiseLike visibility. The
22-name/two-profile probe carries no semantic-denominator credit; broader
catalogs remain open.

''' + todo[end:]
    start = todo.index('- [ ] **P0-B')
    end = todo.index('- [ ] **P0-C', start)
    todo = todo[:start] + '''- [x] **P0-B — NonNullable and ES5 Awaited foundations.** Delivered 396 complete
  direct comparisons plus six independent Native demand controls. Each actual
  compiler passes 315 exact declaration inventories / 331 files, 630 consumers,
  331 parses and twelve executions. Six owner/runtime and fifteen resource
  controls remain separate. Complete same-source Native/local/Windows, maps,
  project and tooling gates pass. All previous cases remain unchanged; 423 new
  assertions bring N to 40,636. [Acceptance](NONNULLABLE_AWAITED_ACCEPTANCE.md) ·
  [measurement](NONNULLABLE_AWAITED_MEASUREMENT.json). Broader rows remain open.
''' + todo[end:]
    todo = replace_once(todo, 'The separate 22-name/two-profile probe measures presence only: after these two\nnames,', 'At the receiver package\'s accepted source, the separate 22-name/two-profile\nprobe measured presence only: after those two names,')
    todo = replace_once(todo, '`NoInfer`, and ES5 `Awaited` remain to be implemented and semantically measured.', '`NoInfer`, and ES5 `Awaited` still required implementation and semantic measurement.\nThe newer P0-A/P0-B acceptance above records their subsequent delivery.')
    path.write_text(todo)
    path = PHASE / 'STANDARD_LIBRARY.md'
    text = path.read_text()
    text = replace_once(text, 'NonNullable, Uppercase, Lowercase, Capitalize, Uncapitalize, ES5 Awaited\nand unmeasured receiver compositions remain open.', 'Unmeasured receiver compositions retain their open scope.')
    before = 'Broader generic inference, structural protocols, overloads, index signatures'
    addition = '''The [NonNullable/Awaited follow-up](NONNULLABLE_AWAITED_ACCEPTANCE.md) supplies
NonNullable through ordinary `T & {}` semantics and places static PromiseLike,
Promise, PromiseConstructorLike and structural Awaited declarations in a separate
ES5 layer. Runtime Promise authority stays in the ES2015 layer. Complete
396-comparison/four-profile acceptance includes exact declarations, 630 isolated
consumers and semantic recursive-demand controls. Six owner/runtime and fifteen
resource controls remain separate. Uppercase, Lowercase, Capitalize,
Uncapitalize and broader library compositions remain open.

'''
    assert text.count(before) == 1
    path.write_text(text.replace(before, addition + before, 1))
    print('Rendered accepted documentation only after complete same-source gate and artifact checks.', flush=True)


if __name__ == '__main__':
    main()
