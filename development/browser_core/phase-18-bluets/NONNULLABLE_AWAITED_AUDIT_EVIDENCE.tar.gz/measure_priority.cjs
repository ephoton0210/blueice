// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

'use strict';
// Acceptance orchestration only: reuse the versioned runner and complete catalog.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const root='/Users/ephoton/git/blueice-bluets',task='/Users/ephoton/git/blueice-bluets/target/nonnullable-awaited-20261112-r2';
const phase=path.join(root,'development/browser_core/phase-18-bluets');
const api=require(path.join(phase,'tools/measure_compatibility_cases.cjs'));
const command=(program,args)=>{const r=cp.spawnSync(program,args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(r.error)throw r.error;if(r.status!==0)throw Error(`${program} exit${r.status}\n${r.stdout}\n${r.stderr}`);return r.stdout;};
async function main(){
 const output=path.join(task,'accepted-native'),jobs=4;api.suiteJobs(jobs);
 if(!['darwin','linux'].includes(process.platform))throw Error('Complete Native catalog requires macOS/Linux');
 const forbidden=Object.keys(process.env).filter(k=>(k.startsWith('BLUEICE_WRITE_')&&process.env[k]==='1')||k.startsWith('BLUETS_'));if(forbidden.length)throw Error('Forbidden recording/filter environment: '+forbidden);
 const load=require(path.join(root,'backend/bluets/tests/fixtures/oracle_support/load_typescript.cjs'));
 if(load(process.env.BLUEICE_BLUETSC_ORACLE).version!=='5.9.3')throw Error('Unpinned oracle');
 fs.mkdirSync(output,{recursive:true});if(fs.readdirSync(output).length)throw Error('Output must be empty');
 const checkSource=()=>command('cargo',['run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--','--check-staged']);checkSource();
 const inventoryPath=path.join(phase,'COMPATIBILITY_SUITES.json'),inventoryBytes=fs.readFileSync(inventoryPath,'utf8'),inventory=JSON.parse(inventoryBytes),tools=api.toolHashes();
 const frozen=JSON.parse(fs.readFileSync(path.join(task,'frozen-source-preflight.json')));if(inventory.source_revision!==frozen.sourceRevision)throw Error('Source mismatch');
 if(JSON.stringify(tools)!==JSON.stringify(JSON.parse(fs.readFileSync(path.join(task,'frozen-final-oracle-tools.json'))).sha256))throw Error('Tool freeze mismatch');
 const artifacts=command('cargo',['test','-p','blueice-bluets','-p','blueice-bluets-bluejs','--no-run','--locked','--offline','--message-format=json']);fs.writeFileSync(path.join(output,'cargo-artifacts.jsonl'),artifacts);
 const messages=artifacts.split(/\r?\n/).filter(Boolean).map(JSON.parse),compiler=api.compilerGuard(messages,process.env.BLUEICE_GE5_EXPECTED_COMPILER_SHA256);if(!compiler)throw Error('Expected immutable compiler required');
 const canonical=api.executables(messages,inventory),indices=new Map(inventory.suites.map((s,i)=>[s.harness,i]));
 const priority=h=>{const base=path.basename(h);return ['nonnullable_awaited.rs','gc1_object_generic_methods.rs','gt10_import_types.rs','noinfer.rs','callable_utilities.rs','receiver_utilities.rs','diagnostics_matrix.rs'].includes(base)?['nonnullable_awaited.rs','gc1_object_generic_methods.rs','gt10_import_types.rs','noinfer.rs','callable_utilities.rs','receiver_utilities.rs','diagnostics_matrix.rs'].indexOf(base)-8:h.startsWith('backend/bluets/tests/')&&base>='gm1_'?0:base.startsWith('ge5_')?2:1;};
 const durations=JSON.parse(fs.readFileSync(path.join(task,'baseline-native-durations.json')));
 const ordered=[...canonical].sort((a,b)=>priority(a.harness)-priority(b.harness)||(priority(a.harness)===2?(durations[b.harness]||0)-(durations[a.harness]||0):0)||indices.get(a.harness)-indices.get(b.harness));
 const executionInventory={...inventory,suites:ordered.map(b=>inventory.suites[indices.get(b.harness)])};
 const report={schema:1,typescript:'5.9.3',suite_jobs:jobs,source_revision:inventory.source_revision,compilerSha256:compiler.sha256,compilerExecutable:compiler.executable,source_graph_sha256:inventory.source_graph_sha256,runner_base_revision:command('git',['rev-parse','HEAD']).trim(),oracle_tools_sha256:tools,source_mode:'immutable-staged-backend-tree',platform:process.platform+'-'+process.arch,rustc:command('rustc',['--version']).trim(),started_at:new Date().toISOString(),finished_at:null,conclusion:'in_progress',collection_mode:'complete-catalog-priority-order',runner_script_sha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),execution_order:ordered.map(s=>s.harness),suites:[]};
 const save=()=>fs.writeFileSync(path.join(output,'measurement.json'),JSON.stringify(report,null,2)+'\n');save();
 try{
  await api.runSuites({binaries:ordered,inventory:executionInventory,output,root,report,save,checkCompiler:()=>compiler.check(),jobs,environment:process.env});
  checkSource();if(fs.readFileSync(inventoryPath,'utf8')!==inventoryBytes)throw Error('Catalog changed during measurement');
  if(JSON.stringify(api.toolHashes())!==JSON.stringify(tools))throw Error('Oracle tooling changed during measurement');compiler.check();
  if(report.suites.length!==inventory.suites.length||new Set(report.suites.map(s=>s.harness)).size!==inventory.suites.length||report.suites.some(s=>s.conclusion!=='success'||s.failed||s.ignored||s.filtered))throw Error('Incomplete catalog');
  report.suites.sort((a,b)=>indices.get(a.harness)-indices.get(b.harness));report.finished_at=new Date().toISOString();report.conclusion='success';save();
  console.log(`COMPLETE ${report.suites.length}/${inventory.suites.length} suites, all selected tests; raw execution order retained`);
 }catch(error){report.finished_at=new Date().toISOString();report.conclusion='failure';report.error=error.message;save();throw error;}
}
main().catch(e=>{console.error(e.stack||e);process.exitCode=1;});
