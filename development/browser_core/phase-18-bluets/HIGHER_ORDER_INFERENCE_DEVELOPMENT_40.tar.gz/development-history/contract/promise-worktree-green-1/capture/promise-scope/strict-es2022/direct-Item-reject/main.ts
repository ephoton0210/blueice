declare function adopt<Item>(value: Item | PromiseLike<Item>): Item;
export const result = adopt(Promise.resolve("value"));
const witness: number = result;
