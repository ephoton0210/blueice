declare function adopt<T>(value: T | PromiseLike<T>): T;
export const result = adopt(Promise.resolve("value"));
const witness: string = result;
