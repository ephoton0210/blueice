declare function adopt<TResult2>(value: TResult2 | PromiseLike<TResult2>): TResult2;
export const result = adopt(Promise.resolve("value"));
const witness: number = result;
