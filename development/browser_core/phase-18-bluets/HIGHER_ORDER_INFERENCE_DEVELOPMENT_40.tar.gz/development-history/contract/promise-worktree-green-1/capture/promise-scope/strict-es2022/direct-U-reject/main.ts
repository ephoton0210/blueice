declare function adopt<U>(value: U | PromiseLike<U>): U;
export const result = adopt(Promise.resolve("value"));
const witness: number = result;
