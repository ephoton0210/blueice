// UTF-16 control: 😀
declare const promise: Promise<number>;
export const result = promise.then(value => Promise.resolve(value.toString())); const witness: Promise<number> = result;
