declare function adopt<TResult1>(value: TResult1 | PromiseLike<TResult1>): TResult1;
export const result = adopt(Promise.resolve("value"));
const witness: string = result;
