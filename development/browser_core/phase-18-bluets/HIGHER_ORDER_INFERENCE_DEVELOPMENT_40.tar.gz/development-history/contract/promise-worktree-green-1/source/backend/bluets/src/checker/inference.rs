// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Bounded structural candidates for one generic call instantiation.

use super::*;
mod barriers;
mod candidates;
pub(super) use barriers::{checking_type, diagnostic_type};
mod collect;
mod contextual_signatures;
pub(super) use contextual_signatures::infer_signature_context;
mod dependencies;
mod higher_order;
pub(super) use higher_order::{bind_result, parameter_scope};
mod indexed;
mod mapped;
mod result_parameters;
mod results;
mod surfaces;

pub(crate) const VERSION: &str = "bluets-generic-inference/16";

pub(in crate::checker) fn depends_on_parameter(
    value: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> bool {
    let parameters = aliases
        .iter()
        .filter(|(_, definition)| definition.kind == TypeDefinitionKind::Parameter)
        .map(|(name, _)| name.clone())
        .collect();
    dependencies::contains(value, &parameters, aliases, &mut HashSet::new(), budget)
}

pub(in crate::checker) fn reverse_mapped_object(
    mapped: &crate::parser::MappedType,
    actual: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> Option<Type> {
    let Type::KeyOf(object) = mapped.parameter.constraint.as_ref()? else {
        return None;
    };
    let Type::Named { name, arguments } = object.as_ref() else {
        return None;
    };
    if !arguments.is_empty() {
        return None;
    }
    let parameters = BTreeSet::from([name.clone()]);
    mapped::infer(mapped, actual, &parameters, aliases, budget).map(|(_, value)| value)
}

/// A signature owns both the lexical spelling and its scoped declaration ID.
pub(in crate::checker) fn declared_parameter<'a>(
    value: &Type,
    parameters: &'a [TypeParameter],
) -> Option<&'a TypeParameter> {
    let Type::Named { name, arguments } = value else {
        return None;
    };
    if !arguments.is_empty() {
        return None;
    }
    parameters.iter().find(|parameter| {
        parameter.name == *name || crate::parser::type_parameter_identity(parameter) == *name
    })
}

pub(in crate::checker) fn direct_result_parameter(
    signature: &FunctionSignature,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> Option<String> {
    result_parameters::naked(
        &signature.return_type,
        &signature.type_parameters,
        aliases,
        &mut HashSet::new(),
        budget,
    )
}

pub(super) fn symbolic_indexed_access(
    value: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
) -> bool {
    let Type::IndexedAccess { object, .. } = value else {
        return false;
    };
    let object = canonical_parameter_references(object, aliases);
    matches!(&object, Type::Named { name, .. } if aliases.get(name).is_some_and(|definition| definition.kind == TypeDefinitionKind::Parameter))
}

pub(super) fn result_type(
    value: &Type,
    substitutions: &BTreeMap<String, Type>,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> Type {
    let value = substitute_type(value, substitutions).runtime_result();
    if symbolic_indexed_access(&value, aliases) {
        return value;
    }
    results::finish(value, aliases, budget)
}

pub(super) fn infer_call_substitutions(
    signature: &FunctionSignature,
    actuals: &[Type],
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> BTreeMap<String, Type> {
    infer_contextual_substitutions(signature, actuals, aliases, budget, None)
}

pub(super) fn infer_contextual_substitutions(
    signature: &FunctionSignature,
    actuals: &[Type],
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
    context: Option<&Type>,
) -> BTreeMap<String, Type> {
    infer_contextual_result(signature, actuals, aliases, budget, context).substitutions
}

pub(super) struct InferenceResult {
    pub(super) substitutions: BTreeMap<String, Type>,
    pub(super) rejected_constraint: Option<(String, Type, Type)>,
    pub(super) inferred_parameters: BTreeSet<String>,
    pub(super) propagated_parameters: Vec<TypeParameter>,
}

fn candidate_parameters(
    signature: &FunctionSignature,
) -> (BTreeSet<String>, BTreeMap<String, String>) {
    let mut parameters = BTreeSet::new();
    let mut identities = BTreeMap::new();
    for parameter in &signature.type_parameters {
        let identity = crate::parser::type_parameter_identity(parameter);
        parameters.insert(parameter.name.clone());
        parameters.insert(identity.clone());
        identities.insert(identity, parameter.name.clone());
    }
    (parameters, identities)
}

pub(super) fn infer_contextual_result(
    signature: &FunctionSignature,
    actuals: &[Type],
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
    context: Option<&Type>,
) -> InferenceResult {
    if signature.type_parameters.is_empty() {
        return InferenceResult {
            substitutions: BTreeMap::new(),
            rejected_constraint: None,
            inferred_parameters: BTreeSet::new(),
            propagated_parameters: Vec::new(),
        };
    }
    if let Some(inferred) = higher_order::infer(signature, actuals, aliases, budget, context) {
        return inferred;
    }
    let (parameters, identities) = candidate_parameters(signature);
    let mut collector = collect::Collector {
        parameters: &parameters,
        identities: &identities,
        candidates: BTreeMap::new(),
        aliases,
        budget,
        active: HashSet::new(),
        dependencies: BTreeMap::new(),
        evidence: 0,
    };
    for (index, actual) in actuals.iter().enumerate() {
        let Some(parameter) = function_parameter_for_argument(signature, index) else {
            break;
        };
        let annotation = if parameter.rest {
            if let Some(annotation @ Type::Named { name, arguments }) = &parameter.annotation {
                if arguments.is_empty() && signature.type_parameters.iter().any(|p| p.name == *name)
                {
                    let mut value = Type::Tuple(
                        actuals[index..]
                            .iter()
                            .cloned()
                            .map(crate::parser::TupleTypeElement::required)
                            .collect(),
                    );
                    if signature.type_parameters.iter().any(|p| {
                        p.name == *name
                            && p.is_const
                            && matches!(p.constraint, Some(Type::Readonly(_)))
                    }) {
                        value = Type::Readonly(Box::new(value));
                    }
                    collector.collect(annotation, &value, false);
                    break;
                }
            }
            rest_parameter_element_annotation(parameter)
        } else {
            parameter.annotation.as_ref()
        };
        if let Some(annotation) = annotation {
            collector.collect(annotation, actual, false);
        }
    }
    let candidates = std::mem::take(&mut collector.candidates);
    drop(collector);
    finish_candidates(signature, candidates, aliases, budget, context)
}

fn finish_candidates(
    signature: &FunctionSignature,
    candidates: BTreeMap<String, candidates::Candidates>,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
    context: Option<&Type>,
) -> InferenceResult {
    let mut substitutions = BTreeMap::new();
    let mut rejected_constraint = None;
    let mut inferred_parameters = BTreeSet::new();
    let naked = result_parameters::naked(
        &signature.return_type,
        &signature.type_parameters,
        aliases,
        &mut HashSet::new(),
        budget,
    );
    for parameter in &signature.type_parameters {
        let literal_constraint = parameter.constraint.as_ref().is_some_and(|constraint| {
            if matches!(constraint, Type::KeyOf(_) | Type::Literal(_)) {
                return true;
            }
            let constraint =
                super::type_operators::expanded(constraint, aliases, &mut HashSet::new(), budget);
            let primitive = |value: &Type| {
                matches!(
                    value,
                    Type::String
                        | Type::Number
                        | Type::BigInt
                        | Type::Boolean
                        | Type::Symbol
                        | Type::UniqueSymbol(_)
                        | Type::Literal(_)
                )
            };
            primitive(&constraint)
                || matches!(&constraint, Type::Union(parts) if parts.iter().all(primitive))
        });
        let preserve = parameter.is_const
            || literal_constraint
            || (naked.as_deref() == Some(parameter.name.as_str())
                && context.is_none_or(|value| matches!(value, Type::Literal(_))));
        if let Some(value) = candidates
            .get(&parameter.name)
            .and_then(|candidates| candidates.solve(preserve, aliases, budget))
        {
            substitutions.insert(parameter.name.clone(), value);
            inferred_parameters.insert(parameter.name.clone());
        }
    }
    if let Some(context) = context {
        let (parameters, identities) = candidate_parameters(signature);
        let mut collector = collect::Collector {
            parameters: &parameters,
            identities: &identities,
            candidates: BTreeMap::new(),
            aliases,
            budget,
            active: HashSet::new(),
            dependencies: BTreeMap::new(),
            evidence: 0,
        };
        collector.collect(&signature.return_type, context, false);
        for (name, candidates) in &collector.candidates {
            if let Some(value) = candidates.solve(true, aliases, budget) {
                substitutions.entry(name.clone()).or_insert(value);
                inferred_parameters.insert(name.clone());
            }
        }
    }
    for parameter in &signature.type_parameters {
        let default = parameter
            .default
            .as_ref()
            .map(|value| substitute_type(value, &substitutions))
            .unwrap_or(Type::StrictUnknown);
        substitutions
            .entry(parameter.name.clone())
            .or_insert(default);
    }
    // Constraints may refer to a later parameter. Populate all arguments
    // before validating any of them, rather than replacing valid earlier
    // evidence with an unresolved forward constraint.
    for parameter in &signature.type_parameters {
        let value = substitutions[&parameter.name].clone();
        if let Some(constraint) = &parameter.constraint {
            let mut constraint = substitute_type(constraint, &substitutions);
            if let Some(resolved) =
                super::type_operators::resolve(&constraint, aliases, &mut HashSet::new(), budget)
            {
                constraint = resolved;
            }
            if matches!(value, Type::Unknown | Type::StrictUnknown)
                || !is_assignable(&value, &constraint, aliases, &mut HashSet::new(), budget)
            {
                if !matches!(value, Type::Unknown | Type::StrictUnknown)
                    && rejected_constraint.is_none()
                {
                    // A primitive constraint preserves successful literal inference,
                    // but a rejected ordinary candidate retains the widened type
                    // reported by the public checker before that inference support.
                    let candidate = if parameter.is_const {
                        value
                    } else {
                        widen(&value)
                    };
                    rejected_constraint =
                        Some((parameter.name.clone(), candidate, constraint.clone()));
                }
                substitutions.insert(parameter.name.clone(), constraint);
            }
        }
    }
    for parameter in &signature.type_parameters {
        if let Some(value) = substitutions.get(&parameter.name).cloned() {
            substitutions.insert(crate::parser::type_parameter_identity(parameter), value);
        }
    }
    InferenceResult {
        substitutions,
        rejected_constraint,
        inferred_parameters,
        propagated_parameters: Vec::new(),
    }
}

fn widen(value: &Type) -> Type {
    match value {
        Type::StringLiteral(_) => Type::String,
        Type::Literal(text) if text.starts_with(['\'', '"', '`']) => Type::String,
        Type::Literal(text) if text.parse::<f64>().is_ok() => Type::Number,
        Type::Literal(text) if matches!(text.as_str(), "true" | "false") => Type::Boolean,
        value => value.clone(),
    }
}
