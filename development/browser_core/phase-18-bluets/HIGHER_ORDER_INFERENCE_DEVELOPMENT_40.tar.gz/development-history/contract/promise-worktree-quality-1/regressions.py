# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/private/tmp/blueice-bluets-p0g-promise-20261114-r1')
phase = repo / 'development/browser_core/phase-18-bluets'
output = root / sys.argv[1]
assert not output.exists(), 'Retain earlier runs'
output.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others',
    '--exclude-standard', '-z', '--', 'backend', str(phase.relative_to(repo) / 'tools')], cwd=repo).decode().split('\0')
files = {name: sha(repo / name) for name in sorted(set(paths)) if name}
(output / 'source-manifest.json').write_text(json.dumps(files, indent=2) + '\n')
for name in files:
    target = output / 'source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)
shutil.copy2(__file__, output / 'regressions.py')
state = {'conclusion': 'in_progress', 'stage': 'preflight', 'steps': [],
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceManifestSha256': sha(output / 'source-manifest.json')}
save = lambda: (output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
environment = dict(os.environ, CARGO_TARGET_DIR='/Users/ephoton/git/blueice-bluets/target', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_TEST_THREADS='1', FORCE_COLOR='0',
    BLUEICE_BLUETSC_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'),
    BLUEICE_ACORN_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn'))
for key, suffix in [('BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS','callables'),
    ('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers'),('BLUEICE_GC3_REPORT_DIRECTORY','gc3')]:
    environment[key] = str(output / 'capture' / suffix)

def run(label, args):
    state['stage'] = label
    save()
    print('START', label, flush=True)
    log = output / (label + '.log')
    with log.open('xb') as stream:
        result = subprocess.run(args, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    state['steps'].append({'label': label, 'command': args, 'exit': result.returncode,
        'log': log.name, 'logSha256': sha(log)})
    save()
    print('END', label, result.returncode, flush=True)
    assert result.returncode == 0, label

try:
    save()
    cargo = ['cargo','test','-p','blueice-bluets','--locked','--offline']
    run('library', cargo + ['--lib'])
    affected = ['gt2_inference','gt3_operators','gt5_compositions','gc1_object_generic_methods',
        'callable_utilities','receiver_utilities','gt10_import_types','nonnullable_awaited','gt4_overload_chains']
    run('affected-callers', cargo + [argument for name in affected for argument in ['--test', name]]
        + ['--','--include-ignored'])
    run('call-chain-regressions',cargo+['--test','diagnostics_matrix',
        '--test','standard_library_checker_matrix','--test','inferred_return_checker_matrix'])
    run('fmt', ['cargo','fmt','--all','--','--check'])
    run('clippy', ['cargo','clippy','--workspace','--all-targets','--features',
        'blueice-bluets/windows-symlink-tests','--locked','--offline','--','-D','warnings'])
    tests = sorted((phase / 'tools').glob('*.test.cjs'))
    tests += sorted((repo / 'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))
    tests += sorted((repo / 'differential-testing/bluets-projects').glob('*.test.cjs'))
    run('node-tools', ['node','--test',*[str(path) for path in tests]])
    run('python-tools', ['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
    assert all(sha(repo / name) == digest for name, digest in files.items())
    sizes = {name:len((repo/name).read_text().splitlines()) for name in files
        if name.startswith('backend/bluets/src/') and (name.endswith('.rs') or name.endswith('.d.ts'))}
    assert all(count < 1500 for count in sizes.values())
    state.update(moduleSizeAudit={'files':len(sizes),'maximumLines':max(sizes.values())},
        conclusion='success',stage='complete')
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
