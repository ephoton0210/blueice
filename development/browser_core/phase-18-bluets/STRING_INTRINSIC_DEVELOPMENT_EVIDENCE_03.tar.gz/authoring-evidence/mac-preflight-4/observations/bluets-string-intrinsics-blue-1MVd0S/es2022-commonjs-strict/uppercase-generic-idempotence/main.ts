export function value<T extends string>(input: Uppercase<Uppercase<T>>): Uppercase<T> { return input; }
