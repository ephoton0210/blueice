declare const input: Capitalize<"\uD800a">;
export const value: Capitalize<"\uDC00a"> = input;
