declare const input: Capitalize<"\uDC00a">;
export const value: Capitalize<"\uFFFDa"> = input;
