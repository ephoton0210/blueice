type Uncapitalize<T> = intrinsic;
export declare const value: Uncapitalize<unknown>;
export {};
