export declare const value: Uncapitalize<"word">;
export declare const runtime: number;
