type Uncapitalize<T> = intrinsic;
export declare const value: Uncapitalize<{
    key: number;
}>;
export {};
