export const value: Uppercase<`${number}`> = "1E+21";
