export const value: Lowercase<`${string}-post`> = "abc-post";
