export const value = Lowercase("word");
