import { value } from "./main";
const proof: typeof value = "not-number";
