export type Uppercase<T, U> = intrinsic;
