export type Lowercase<T extends string> = intrinsic;
export const value: Lowercase<"word"> = "word";
