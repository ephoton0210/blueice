export const value = Uncapitalize("word");
