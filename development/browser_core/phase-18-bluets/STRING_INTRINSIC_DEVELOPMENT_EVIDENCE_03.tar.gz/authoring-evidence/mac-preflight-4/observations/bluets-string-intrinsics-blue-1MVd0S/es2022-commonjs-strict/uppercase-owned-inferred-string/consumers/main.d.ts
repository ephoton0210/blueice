type Uppercase<T> = intrinsic;
export declare const value: Uppercase<string>;
export {};
