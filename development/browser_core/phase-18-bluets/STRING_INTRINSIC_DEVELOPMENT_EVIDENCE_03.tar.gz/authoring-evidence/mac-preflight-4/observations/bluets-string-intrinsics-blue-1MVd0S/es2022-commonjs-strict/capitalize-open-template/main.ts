export const value: Capitalize<`pre-${string}`> = "Pre-mixed";
