type Lowercase<T> = intrinsic;
declare function map<T>(input: T): Lowercase<T>;
declare const input: number;
export const value = map(input);
