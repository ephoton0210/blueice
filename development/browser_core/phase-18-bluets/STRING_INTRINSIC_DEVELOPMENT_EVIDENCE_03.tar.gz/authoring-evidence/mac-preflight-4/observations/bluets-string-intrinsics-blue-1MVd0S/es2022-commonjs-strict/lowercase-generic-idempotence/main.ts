export function value<T extends string>(input: Lowercase<Lowercase<T>>): Lowercase<T> { return input; }
