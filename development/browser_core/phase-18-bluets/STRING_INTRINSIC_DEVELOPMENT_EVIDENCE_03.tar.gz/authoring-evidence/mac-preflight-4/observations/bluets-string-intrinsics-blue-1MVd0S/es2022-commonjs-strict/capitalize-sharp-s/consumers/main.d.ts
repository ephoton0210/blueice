export declare const value: "SSeta";
