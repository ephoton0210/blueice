export const value: Uncapitalize<string> = "word";
