export declare const value: "ΟΣ";
