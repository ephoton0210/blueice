export declare const value: "A�𐐨z";
