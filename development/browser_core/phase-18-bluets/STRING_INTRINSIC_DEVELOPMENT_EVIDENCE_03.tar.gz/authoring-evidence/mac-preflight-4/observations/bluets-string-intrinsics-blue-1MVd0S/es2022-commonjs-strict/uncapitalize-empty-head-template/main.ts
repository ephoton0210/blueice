export const value: Uncapitalize<`${string}-post`> = "word-post";
