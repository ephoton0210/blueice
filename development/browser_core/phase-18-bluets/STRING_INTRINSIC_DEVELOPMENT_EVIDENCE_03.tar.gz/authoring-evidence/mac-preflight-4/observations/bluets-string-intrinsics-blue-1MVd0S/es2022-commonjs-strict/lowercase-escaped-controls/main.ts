declare function map<T extends string>(input: T): Lowercase<T>;
export const value = map("a\u0000\n\u000b\"\\z");
