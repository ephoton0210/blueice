export declare const value: "i̇stanbul";
