type IsMapped<T extends string> = T extends Uppercase<T> ? true : false;
export const value: [IsMapped<"ABC">, IsMapped<"aBc">] = [true, false];
