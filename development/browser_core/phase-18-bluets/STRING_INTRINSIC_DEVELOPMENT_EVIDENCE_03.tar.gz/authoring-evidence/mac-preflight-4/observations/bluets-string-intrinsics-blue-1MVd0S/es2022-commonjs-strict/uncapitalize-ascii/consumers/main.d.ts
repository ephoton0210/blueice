export declare const value: "wOrD";
