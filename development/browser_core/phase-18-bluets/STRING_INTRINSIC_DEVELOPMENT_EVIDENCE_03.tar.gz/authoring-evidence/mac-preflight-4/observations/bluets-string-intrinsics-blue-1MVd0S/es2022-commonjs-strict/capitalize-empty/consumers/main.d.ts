export declare const value: "";
