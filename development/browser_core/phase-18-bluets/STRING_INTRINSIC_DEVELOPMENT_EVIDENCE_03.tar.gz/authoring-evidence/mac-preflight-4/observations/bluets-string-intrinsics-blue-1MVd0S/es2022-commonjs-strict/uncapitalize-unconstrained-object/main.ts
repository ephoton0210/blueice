type Uncapitalize<T> = intrinsic;
export const value: Uncapitalize<{ key: number }> = { key: 1 };
