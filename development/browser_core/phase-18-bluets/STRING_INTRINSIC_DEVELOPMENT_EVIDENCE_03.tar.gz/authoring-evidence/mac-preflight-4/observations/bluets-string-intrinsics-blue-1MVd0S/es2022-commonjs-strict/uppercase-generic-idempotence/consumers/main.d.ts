export declare function value<T extends string>(input: Uppercase<Uppercase<T>>): Uppercase<T>;
