type Lowercase<T> = {
    owner: T;
};
export declare const value: Lowercase<number>;
export {};
