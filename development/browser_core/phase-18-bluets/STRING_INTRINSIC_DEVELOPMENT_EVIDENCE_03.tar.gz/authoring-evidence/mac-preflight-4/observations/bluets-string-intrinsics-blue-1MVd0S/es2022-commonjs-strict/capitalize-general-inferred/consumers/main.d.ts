export declare const value: Capitalize<string>;
