declare const input: Uncapitalize<"\uD800a">;
export const value: Uncapitalize<"\uFFFDa"> = input;
