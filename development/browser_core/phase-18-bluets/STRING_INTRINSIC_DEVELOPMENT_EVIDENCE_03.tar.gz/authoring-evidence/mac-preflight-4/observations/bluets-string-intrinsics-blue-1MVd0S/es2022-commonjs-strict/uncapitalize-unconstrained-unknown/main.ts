type Uncapitalize<T> = intrinsic;
export const value: Uncapitalize<unknown> = "anything";
