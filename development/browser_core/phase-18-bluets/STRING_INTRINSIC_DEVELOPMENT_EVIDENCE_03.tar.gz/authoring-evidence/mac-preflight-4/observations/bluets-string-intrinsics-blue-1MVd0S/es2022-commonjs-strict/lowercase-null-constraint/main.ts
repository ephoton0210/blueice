export declare const value: Lowercase<null>;
