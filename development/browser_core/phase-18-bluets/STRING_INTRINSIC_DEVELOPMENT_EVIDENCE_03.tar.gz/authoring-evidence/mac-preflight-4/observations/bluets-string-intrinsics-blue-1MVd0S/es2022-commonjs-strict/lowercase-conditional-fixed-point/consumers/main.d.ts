type IsMapped<T extends string> = T extends Lowercase<T> ? true : false;
export declare const value: [IsMapped<"abc">, IsMapped<"aBc">];
export {};
