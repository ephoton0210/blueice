export type Uncapitalize<T extends string> = intrinsic;
export const value: Uncapitalize<"word"> = "word";
