export declare const value: "ος";
