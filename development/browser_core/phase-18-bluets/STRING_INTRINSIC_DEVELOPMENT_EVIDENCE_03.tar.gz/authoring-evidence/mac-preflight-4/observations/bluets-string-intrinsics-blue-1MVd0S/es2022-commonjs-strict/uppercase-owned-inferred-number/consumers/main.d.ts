type Uppercase<T> = intrinsic;
export declare const value: Uppercase<`${number}`>;
export {};
