export declare const value: "𐐀WORD";
