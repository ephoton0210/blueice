type Uppercase<T> = intrinsic;
declare function map<T>(input: T): Uppercase<T>;
declare const input: string;
export const value = map(input);
