type Lowercase<T> = intrinsic;
export const value: Lowercase<number> = "1e+21";
