export type Uncapitalize<T extends string> = intrinsic;
export declare const value: Uncapitalize<"word">;
