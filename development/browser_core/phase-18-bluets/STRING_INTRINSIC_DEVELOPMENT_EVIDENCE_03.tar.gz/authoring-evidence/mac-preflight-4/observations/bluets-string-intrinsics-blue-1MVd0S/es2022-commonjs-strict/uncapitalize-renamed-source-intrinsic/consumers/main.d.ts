import type { Uncapitalize as Mapping } from "./types";
export declare const value: Mapping<"word">;
