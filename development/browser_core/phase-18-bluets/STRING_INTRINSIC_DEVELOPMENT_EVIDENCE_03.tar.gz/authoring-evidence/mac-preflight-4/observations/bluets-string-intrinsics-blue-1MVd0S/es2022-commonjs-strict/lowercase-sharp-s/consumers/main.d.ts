export declare const value: "ßeta";
