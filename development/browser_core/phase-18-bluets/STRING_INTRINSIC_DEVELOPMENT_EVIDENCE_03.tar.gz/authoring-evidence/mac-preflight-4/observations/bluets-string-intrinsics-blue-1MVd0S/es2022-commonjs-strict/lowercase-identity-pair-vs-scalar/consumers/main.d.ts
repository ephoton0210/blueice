export declare const value: Lowercase<"𐐨a">;
