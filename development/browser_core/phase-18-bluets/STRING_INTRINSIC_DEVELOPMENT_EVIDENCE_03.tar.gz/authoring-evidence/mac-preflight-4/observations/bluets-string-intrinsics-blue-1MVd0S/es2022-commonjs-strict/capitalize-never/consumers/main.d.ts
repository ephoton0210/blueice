export declare const value: never;
