declare function map<T extends string>(input: Lowercase<T>): T;
export const value = map("abc");
