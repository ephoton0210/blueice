declare const input: Uppercase<"\uD800a">;
export const value: Uppercase<"\uFFFDa"> = input;
