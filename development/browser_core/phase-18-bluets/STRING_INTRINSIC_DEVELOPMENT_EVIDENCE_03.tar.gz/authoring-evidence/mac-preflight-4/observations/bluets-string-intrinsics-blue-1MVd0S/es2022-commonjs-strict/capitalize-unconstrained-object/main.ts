type Capitalize<T> = intrinsic;
export const value: Capitalize<{ key: number }> = { key: 1 };
