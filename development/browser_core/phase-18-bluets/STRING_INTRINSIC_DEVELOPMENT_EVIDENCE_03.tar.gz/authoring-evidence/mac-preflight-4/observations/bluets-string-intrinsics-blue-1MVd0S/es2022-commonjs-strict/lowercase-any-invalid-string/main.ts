export const value: Lowercase<any> = "aBc";
