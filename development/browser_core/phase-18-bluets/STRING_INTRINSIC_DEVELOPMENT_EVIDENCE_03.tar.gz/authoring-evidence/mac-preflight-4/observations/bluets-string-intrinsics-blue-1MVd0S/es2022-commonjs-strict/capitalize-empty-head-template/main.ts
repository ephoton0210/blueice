export const value: Capitalize<`${string}-post`> = "Word-post";
