export declare const value: "other" | "word";
