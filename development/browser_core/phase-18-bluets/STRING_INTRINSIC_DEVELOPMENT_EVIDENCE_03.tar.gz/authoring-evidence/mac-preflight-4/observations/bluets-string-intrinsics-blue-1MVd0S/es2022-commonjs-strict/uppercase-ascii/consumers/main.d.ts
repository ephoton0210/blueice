export declare const value: "WORD";
