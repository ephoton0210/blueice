export const value: Capitalize<string> = "word";
