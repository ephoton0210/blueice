export const value: Lowercase<any> = 123;
