export declare const value: Uncapitalize<number>;
