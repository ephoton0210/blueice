import type { Uncapitalize as Owned } from "./types";
export declare const value: Owned<number>;
