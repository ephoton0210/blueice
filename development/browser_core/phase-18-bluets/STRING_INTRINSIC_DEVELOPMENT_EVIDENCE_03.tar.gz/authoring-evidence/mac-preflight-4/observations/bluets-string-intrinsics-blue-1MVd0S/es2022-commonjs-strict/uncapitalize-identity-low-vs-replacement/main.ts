declare const input: Uncapitalize<"\uDC00a">;
export const value: Uncapitalize<"\uFFFDa"> = input;
