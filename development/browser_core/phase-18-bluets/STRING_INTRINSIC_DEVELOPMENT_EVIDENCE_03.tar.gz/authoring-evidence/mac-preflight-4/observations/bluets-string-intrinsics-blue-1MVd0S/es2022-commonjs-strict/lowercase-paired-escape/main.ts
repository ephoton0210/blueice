declare function map<T extends string>(input: T): Lowercase<T>;
export const value = map("\uD801\uDC28word");
