type IsMapped<T extends string> = T extends Uncapitalize<T> ? true : false;
export declare const value: [IsMapped<"word">, IsMapped<"Word">];
export {};
