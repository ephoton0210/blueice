import type { Lowercase as Mapping } from "./types";
export declare const value: Mapping<"word">;
