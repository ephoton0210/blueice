import type { Lowercase as Owned } from "./types";
export declare const value: Owned<number>;
