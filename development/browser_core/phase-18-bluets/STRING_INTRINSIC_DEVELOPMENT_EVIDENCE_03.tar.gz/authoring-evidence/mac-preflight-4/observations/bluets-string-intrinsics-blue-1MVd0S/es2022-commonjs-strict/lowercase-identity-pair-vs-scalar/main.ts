declare const input: Lowercase<"\uD801\uDC28a">;
export const value: Lowercase<"𐐨a"> = input;
