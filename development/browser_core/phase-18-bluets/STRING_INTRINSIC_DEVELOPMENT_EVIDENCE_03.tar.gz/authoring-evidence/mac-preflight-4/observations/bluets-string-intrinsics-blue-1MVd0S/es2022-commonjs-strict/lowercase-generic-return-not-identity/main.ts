export function value<T extends string>(input: T): Lowercase<T> { return input; }
