export type NoInfer<T> = intrinsic;
export const value: NoInfer<number> = 1;
