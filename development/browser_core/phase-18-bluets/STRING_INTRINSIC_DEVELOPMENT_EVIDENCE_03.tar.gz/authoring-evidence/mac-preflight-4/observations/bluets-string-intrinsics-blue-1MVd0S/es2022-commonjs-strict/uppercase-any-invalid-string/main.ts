export const value: Uppercase<any> = "aBc";
