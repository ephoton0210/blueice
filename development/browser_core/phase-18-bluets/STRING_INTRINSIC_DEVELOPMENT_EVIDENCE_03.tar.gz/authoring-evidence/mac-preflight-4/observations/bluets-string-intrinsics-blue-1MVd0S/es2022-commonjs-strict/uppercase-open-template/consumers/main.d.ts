export declare const value: Uppercase<`pre-${string}`>;
