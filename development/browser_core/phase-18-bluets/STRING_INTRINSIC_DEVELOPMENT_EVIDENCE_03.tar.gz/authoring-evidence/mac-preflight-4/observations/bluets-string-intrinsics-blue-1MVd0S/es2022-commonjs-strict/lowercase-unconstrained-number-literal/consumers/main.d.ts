type Lowercase<T> = intrinsic;
export declare const value: Lowercase<123>;
export {};
