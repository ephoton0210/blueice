declare function map<T extends string>(input: Capitalize<T>): T;
export const value = map("Word");
