export declare const value: Uncapitalize<`pre-${string}`>;
