type Capitalize<T> = intrinsic;
export const value: Capitalize<123> = 123;
