declare function map<T extends string>(input: T): Uppercase<T>;
export const value = map("a\u0001z");
