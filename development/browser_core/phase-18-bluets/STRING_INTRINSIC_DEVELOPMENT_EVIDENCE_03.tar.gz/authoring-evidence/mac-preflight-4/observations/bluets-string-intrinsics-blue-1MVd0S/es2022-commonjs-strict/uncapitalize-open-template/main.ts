export const value: Uncapitalize<`pre-${string}`> = "pre-Mixed";
