export type Uncapitalize<T extends string> = intrinsic;
