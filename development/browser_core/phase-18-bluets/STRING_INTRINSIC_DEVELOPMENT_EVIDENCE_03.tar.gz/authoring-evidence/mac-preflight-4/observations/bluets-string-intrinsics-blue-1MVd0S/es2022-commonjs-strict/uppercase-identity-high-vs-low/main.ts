declare const input: Uppercase<"\uD800a">;
export const value: Uppercase<"\uDC00a"> = input;
