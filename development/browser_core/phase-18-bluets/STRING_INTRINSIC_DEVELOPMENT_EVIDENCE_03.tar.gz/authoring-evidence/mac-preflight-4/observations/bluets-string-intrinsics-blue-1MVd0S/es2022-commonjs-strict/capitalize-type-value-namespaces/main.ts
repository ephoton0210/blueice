const Capitalize = (input: number) => input + 1;
export const value: Capitalize<"word"> = "Word";
export const runtime = Capitalize(1);
