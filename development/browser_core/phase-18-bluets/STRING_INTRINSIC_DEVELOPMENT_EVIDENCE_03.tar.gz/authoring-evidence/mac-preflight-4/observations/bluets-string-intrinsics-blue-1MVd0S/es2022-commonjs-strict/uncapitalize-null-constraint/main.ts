export declare const value: Uncapitalize<null>;
