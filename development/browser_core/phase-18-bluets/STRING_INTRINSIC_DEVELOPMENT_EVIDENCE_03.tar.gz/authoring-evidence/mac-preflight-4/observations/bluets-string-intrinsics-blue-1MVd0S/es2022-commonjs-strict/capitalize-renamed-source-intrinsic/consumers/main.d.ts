import type { Capitalize as Mapping } from "./types";
export declare const value: Mapping<"word">;
