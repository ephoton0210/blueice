type Uncapitalize<T> = intrinsic;
export declare const value: Uncapitalize<string>;
export {};
