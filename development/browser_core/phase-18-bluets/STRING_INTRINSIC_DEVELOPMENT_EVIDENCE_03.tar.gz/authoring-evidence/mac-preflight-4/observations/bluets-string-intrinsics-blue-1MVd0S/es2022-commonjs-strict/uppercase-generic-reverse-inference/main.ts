declare function map<T extends string>(input: Uppercase<T>): T;
export const value = map("ABC");
