export function value<T extends string>(input: Lowercase<T>): T { return input; }
