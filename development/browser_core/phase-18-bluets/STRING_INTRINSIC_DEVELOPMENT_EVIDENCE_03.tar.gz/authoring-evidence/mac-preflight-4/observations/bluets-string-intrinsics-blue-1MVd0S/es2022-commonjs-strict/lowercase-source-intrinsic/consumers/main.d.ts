export type Lowercase<T extends string> = intrinsic;
export declare const value: Lowercase<"word">;
