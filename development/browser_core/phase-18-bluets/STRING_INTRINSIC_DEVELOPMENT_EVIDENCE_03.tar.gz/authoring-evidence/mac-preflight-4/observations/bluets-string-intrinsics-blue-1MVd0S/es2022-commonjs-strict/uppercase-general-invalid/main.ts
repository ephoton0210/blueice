export const value: Uppercase<string> = "aBc";
