export type Uppercase<T> = { owner: T };
