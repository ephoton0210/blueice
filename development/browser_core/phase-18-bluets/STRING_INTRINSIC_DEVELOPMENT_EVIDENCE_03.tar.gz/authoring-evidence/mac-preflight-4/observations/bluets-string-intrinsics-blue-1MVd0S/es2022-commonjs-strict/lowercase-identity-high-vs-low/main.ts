declare const input: Lowercase<"\uD800a">;
export const value: Lowercase<"\uDC00a"> = input;
