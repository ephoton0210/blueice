export const value: Capitalize<any> = 123;
