type Lowercase<T> = intrinsic;
export declare const value: Lowercase<`${number}`>;
export {};
