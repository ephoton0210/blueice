export declare const value: "a�𐐨z";
