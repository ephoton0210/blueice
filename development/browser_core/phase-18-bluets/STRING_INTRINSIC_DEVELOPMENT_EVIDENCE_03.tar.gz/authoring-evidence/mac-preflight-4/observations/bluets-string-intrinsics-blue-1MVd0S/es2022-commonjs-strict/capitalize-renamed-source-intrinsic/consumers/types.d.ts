export type Capitalize<T extends string> = intrinsic;
