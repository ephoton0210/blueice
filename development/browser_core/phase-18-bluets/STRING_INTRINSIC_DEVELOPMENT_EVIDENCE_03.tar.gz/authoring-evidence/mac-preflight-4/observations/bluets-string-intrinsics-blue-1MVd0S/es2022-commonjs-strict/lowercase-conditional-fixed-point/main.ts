type IsMapped<T extends string> = T extends Lowercase<T> ? true : false;
export const value: [IsMapped<"abc">, IsMapped<"aBc">] = [true, false];
