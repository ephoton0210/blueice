declare const input: "word" | "other";
declare function map<T extends string>(input: T): Lowercase<T>;
export const value = map(input);
