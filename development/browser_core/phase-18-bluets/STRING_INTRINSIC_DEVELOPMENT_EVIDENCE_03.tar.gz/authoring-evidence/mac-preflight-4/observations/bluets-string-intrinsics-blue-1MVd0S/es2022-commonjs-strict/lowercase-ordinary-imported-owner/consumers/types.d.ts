export type Lowercase<T> = {
    owner: T;
};
