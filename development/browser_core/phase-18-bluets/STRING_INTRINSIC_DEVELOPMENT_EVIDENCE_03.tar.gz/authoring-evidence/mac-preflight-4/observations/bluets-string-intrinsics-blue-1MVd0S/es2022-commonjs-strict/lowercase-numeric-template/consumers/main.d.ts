export declare const value: Lowercase<`${number}`>;
