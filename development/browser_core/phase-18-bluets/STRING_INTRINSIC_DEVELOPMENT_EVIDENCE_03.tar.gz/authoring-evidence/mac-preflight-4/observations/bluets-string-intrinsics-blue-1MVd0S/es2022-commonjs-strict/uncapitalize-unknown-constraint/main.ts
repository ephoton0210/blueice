export declare const value: Uncapitalize<unknown>;
