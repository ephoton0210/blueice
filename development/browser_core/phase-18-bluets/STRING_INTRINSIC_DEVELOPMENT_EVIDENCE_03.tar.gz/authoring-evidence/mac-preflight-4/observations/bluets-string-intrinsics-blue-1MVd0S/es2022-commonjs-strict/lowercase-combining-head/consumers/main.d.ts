export declare const value: "́word";
