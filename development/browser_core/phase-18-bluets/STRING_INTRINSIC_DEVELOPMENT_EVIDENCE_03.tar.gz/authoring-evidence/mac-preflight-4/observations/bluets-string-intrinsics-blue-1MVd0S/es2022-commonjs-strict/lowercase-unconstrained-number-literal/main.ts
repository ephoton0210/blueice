type Lowercase<T> = intrinsic;
export const value: Lowercase<123> = 123;
