export const value: Lowercase<string> = "aBc";
