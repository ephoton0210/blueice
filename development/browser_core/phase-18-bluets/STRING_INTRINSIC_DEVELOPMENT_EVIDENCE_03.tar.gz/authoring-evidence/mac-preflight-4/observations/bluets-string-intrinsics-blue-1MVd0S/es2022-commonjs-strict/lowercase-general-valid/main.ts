export const value: Lowercase<string> = "abc";
