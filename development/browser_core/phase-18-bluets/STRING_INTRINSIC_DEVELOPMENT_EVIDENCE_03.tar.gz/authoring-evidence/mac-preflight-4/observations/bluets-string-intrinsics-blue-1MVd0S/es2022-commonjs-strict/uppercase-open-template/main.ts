export const value: Uppercase<`pre-${string}`> = "PRE-ABC";
