export const value: Uncapitalize<string> = "Word";
