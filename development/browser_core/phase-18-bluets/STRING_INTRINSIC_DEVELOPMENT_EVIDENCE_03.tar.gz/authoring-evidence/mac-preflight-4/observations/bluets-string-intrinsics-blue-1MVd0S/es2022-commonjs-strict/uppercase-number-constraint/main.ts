export declare const value: Uppercase<number>;
