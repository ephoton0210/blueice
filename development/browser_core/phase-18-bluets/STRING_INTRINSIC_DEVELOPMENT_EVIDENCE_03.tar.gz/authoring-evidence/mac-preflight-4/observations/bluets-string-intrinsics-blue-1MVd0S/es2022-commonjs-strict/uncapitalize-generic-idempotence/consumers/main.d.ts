export declare function value<T extends string>(input: Uncapitalize<Uncapitalize<T>>): Uncapitalize<T>;
