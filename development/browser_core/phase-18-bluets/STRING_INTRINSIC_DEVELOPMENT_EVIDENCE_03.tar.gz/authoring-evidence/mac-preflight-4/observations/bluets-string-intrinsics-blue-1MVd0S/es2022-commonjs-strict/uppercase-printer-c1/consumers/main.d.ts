export declare const value: "A\u0085Z";
