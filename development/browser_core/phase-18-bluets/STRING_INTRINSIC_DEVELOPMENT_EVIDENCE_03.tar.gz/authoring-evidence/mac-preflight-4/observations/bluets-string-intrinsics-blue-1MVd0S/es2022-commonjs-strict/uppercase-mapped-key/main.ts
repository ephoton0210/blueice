type MapKeys<T> = { [K in keyof T as Uppercase<string & K>]: T[K] };
declare function map<T>(input: T): MapKeys<T>;
const mapped = map({ word: 1 });
export const value = mapped["WORD"];
