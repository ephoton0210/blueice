export const value: Capitalize<string> = "Word";
