declare const input: Uncapitalize<"\uD801\uDC28a">;
export const value: Uncapitalize<"𐐨a"> = input;
