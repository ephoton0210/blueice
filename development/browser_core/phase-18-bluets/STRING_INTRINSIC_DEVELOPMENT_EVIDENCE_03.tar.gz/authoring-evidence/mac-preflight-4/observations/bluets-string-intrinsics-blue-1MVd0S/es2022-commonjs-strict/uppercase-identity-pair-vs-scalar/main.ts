declare const input: Uppercase<"\uD801\uDC28a">;
export const value: Uppercase<"𐐨a"> = input;
