export declare const value: "οΣ";
