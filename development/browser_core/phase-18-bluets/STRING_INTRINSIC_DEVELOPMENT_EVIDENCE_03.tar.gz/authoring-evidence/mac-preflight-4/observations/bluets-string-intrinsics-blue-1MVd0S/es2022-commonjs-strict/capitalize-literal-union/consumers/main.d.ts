export declare const value: "Other" | "Word";
