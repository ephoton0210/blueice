type Capitalize<T> = intrinsic;
declare function map<T>(input: T): Capitalize<T>;
declare const input: number;
export const value = map(input);
