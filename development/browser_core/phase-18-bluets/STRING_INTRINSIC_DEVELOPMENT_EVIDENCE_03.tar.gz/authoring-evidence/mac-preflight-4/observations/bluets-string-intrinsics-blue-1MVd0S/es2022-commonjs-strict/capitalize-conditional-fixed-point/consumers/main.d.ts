type IsMapped<T extends string> = T extends Capitalize<T> ? true : false;
export declare const value: [IsMapped<"Word">, IsMapped<"word">];
export {};
