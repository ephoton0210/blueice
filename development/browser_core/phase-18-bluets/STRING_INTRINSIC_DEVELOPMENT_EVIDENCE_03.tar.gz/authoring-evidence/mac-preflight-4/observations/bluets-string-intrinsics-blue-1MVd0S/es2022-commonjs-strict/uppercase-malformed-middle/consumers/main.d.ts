export declare const value: "A�𐐀Z";
