const Lowercase = (input: number) => input + 1;
export const value: Lowercase<"word"> = "word";
export const runtime = Lowercase(1);
