declare const input: Capitalize<"\uD800a">;
export const value: Capitalize<"\uFFFDa"> = input;
