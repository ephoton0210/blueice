export declare const value: "𐐨word";
