declare const input: never;
declare function map<T extends string>(input: T): Lowercase<T>;
export const value = map(input);
