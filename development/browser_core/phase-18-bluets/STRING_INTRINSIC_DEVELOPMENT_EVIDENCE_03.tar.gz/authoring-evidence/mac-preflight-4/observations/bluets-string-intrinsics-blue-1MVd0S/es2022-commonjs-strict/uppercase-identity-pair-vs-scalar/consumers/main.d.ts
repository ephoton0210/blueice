export declare const value: Uppercase<"𐐨a">;
