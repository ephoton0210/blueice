export declare const value: Lowercase<string>;
