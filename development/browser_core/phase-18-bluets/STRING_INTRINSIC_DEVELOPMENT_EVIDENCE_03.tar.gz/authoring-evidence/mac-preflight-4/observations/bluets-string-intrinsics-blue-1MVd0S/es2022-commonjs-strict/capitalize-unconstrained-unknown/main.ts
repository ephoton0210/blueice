type Capitalize<T> = intrinsic;
export const value: Capitalize<unknown> = "anything";
