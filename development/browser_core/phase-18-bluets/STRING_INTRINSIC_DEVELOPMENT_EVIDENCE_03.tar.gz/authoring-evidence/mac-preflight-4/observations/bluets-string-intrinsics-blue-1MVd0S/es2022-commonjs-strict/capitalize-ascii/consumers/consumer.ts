import { value } from "./main";
const proof: number = value;
