import type { Capitalize as Owned } from "./types";
export declare const value: Owned<number>;
