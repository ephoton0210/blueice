type Uppercase<T> = { owner: T };
export const value: Uppercase<number> = { owner: 1 };
