export function value<T extends string>(input: T): Capitalize<T> { return input; }
