export declare const value: "A﻿Z";
