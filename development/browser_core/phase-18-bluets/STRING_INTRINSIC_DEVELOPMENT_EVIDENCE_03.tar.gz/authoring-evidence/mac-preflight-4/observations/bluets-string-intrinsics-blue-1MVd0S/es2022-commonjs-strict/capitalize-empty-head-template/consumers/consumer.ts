import { value } from "./main";
const proof: typeof value = "word-post";
