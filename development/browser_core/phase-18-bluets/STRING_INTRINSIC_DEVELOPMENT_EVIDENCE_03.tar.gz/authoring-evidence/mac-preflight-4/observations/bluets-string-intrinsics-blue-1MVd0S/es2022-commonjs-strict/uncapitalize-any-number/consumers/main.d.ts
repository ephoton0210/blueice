export declare const value: Uncapitalize<any>;
