export declare const value: "i̇STANBUL";
