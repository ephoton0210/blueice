type Lowercase<T> = intrinsic;
export const value: Lowercase<{ key: number }> = { key: 1 };
