export declare const value: "OTHER" | "WORD";
