export type Capitalize<T extends string> = intrinsic;
export const value: Capitalize<"word"> = "Word";
