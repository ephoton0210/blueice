export declare const value: Capitalize<unknown>;
