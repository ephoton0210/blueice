type Capitalize<T> = intrinsic;
export const value: Capitalize<number> = "1e+21";
