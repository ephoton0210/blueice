export function value<T extends string>(input: Uppercase<Lowercase<T>>): Lowercase<Uppercase<T>> { return input; }
