declare function map<T extends string>(input: Uncapitalize<T>): T;
export const value = map("word");
