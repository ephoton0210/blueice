export const value: Capitalize<any> = "word";
