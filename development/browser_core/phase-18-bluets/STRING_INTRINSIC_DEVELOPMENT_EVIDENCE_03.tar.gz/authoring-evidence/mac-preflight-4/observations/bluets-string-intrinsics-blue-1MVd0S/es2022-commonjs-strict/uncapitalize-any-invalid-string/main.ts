export const value: Uncapitalize<any> = "Word";
