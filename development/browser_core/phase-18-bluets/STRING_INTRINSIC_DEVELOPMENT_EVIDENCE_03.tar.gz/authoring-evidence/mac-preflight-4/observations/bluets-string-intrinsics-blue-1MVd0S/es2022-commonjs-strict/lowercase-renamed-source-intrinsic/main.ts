import type { Lowercase as Mapping } from "./types";
export const value: Mapping<"word"> = "word";
