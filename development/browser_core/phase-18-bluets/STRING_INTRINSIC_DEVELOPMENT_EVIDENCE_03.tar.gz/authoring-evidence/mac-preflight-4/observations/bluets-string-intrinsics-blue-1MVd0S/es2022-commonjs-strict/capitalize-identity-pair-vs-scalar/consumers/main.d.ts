export declare const value: Capitalize<"𐐨a">;
