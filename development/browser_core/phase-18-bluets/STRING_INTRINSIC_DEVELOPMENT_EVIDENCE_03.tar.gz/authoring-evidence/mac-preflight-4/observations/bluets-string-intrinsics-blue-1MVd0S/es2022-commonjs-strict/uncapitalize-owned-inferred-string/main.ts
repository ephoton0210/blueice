type Uncapitalize<T> = intrinsic;
declare function map<T>(input: T): Uncapitalize<T>;
declare const input: string;
export const value = map(input);
