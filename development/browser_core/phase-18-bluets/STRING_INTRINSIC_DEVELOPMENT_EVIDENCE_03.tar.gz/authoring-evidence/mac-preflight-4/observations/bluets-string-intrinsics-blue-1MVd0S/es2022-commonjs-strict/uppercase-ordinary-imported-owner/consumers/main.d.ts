import type { Uppercase as Owned } from "./types";
export declare const value: Owned<number>;
