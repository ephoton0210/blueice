export declare const value: "a\0\n\v\"\\z";
