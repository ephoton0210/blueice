type Uncapitalize<T> = intrinsic;
export const value: Uncapitalize<123> = 123;
