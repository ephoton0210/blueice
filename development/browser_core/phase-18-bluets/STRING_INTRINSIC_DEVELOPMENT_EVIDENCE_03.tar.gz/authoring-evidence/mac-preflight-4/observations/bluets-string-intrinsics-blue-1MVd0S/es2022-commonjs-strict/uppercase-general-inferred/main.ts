declare const input: string;
declare function map<T extends string>(input: T): Uppercase<T>;
export const value = map(input);
