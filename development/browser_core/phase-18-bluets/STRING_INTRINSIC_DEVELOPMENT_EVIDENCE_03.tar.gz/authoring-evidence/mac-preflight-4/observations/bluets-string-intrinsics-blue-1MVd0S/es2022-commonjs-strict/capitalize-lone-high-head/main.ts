declare function map<T extends string>(input: T): Capitalize<T>;
export const value = map("\ud800word");
