declare function map<T extends string>(input: T): Uncapitalize<T>;
export const value = map("𐐨word");
