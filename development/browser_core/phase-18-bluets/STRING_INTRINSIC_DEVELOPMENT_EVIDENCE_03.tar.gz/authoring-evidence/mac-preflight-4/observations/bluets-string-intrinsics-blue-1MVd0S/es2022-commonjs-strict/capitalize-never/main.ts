declare const input: never;
declare function map<T extends string>(input: T): Capitalize<T>;
export const value = map(input);
