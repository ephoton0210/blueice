export declare const value: Uppercase<any>;
