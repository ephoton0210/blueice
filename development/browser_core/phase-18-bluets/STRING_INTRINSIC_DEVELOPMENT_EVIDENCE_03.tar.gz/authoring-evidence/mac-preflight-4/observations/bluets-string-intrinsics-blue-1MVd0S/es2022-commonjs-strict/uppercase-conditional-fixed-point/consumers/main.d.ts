type IsMapped<T extends string> = T extends Uppercase<T> ? true : false;
export declare const value: [IsMapped<"ABC">, IsMapped<"aBc">];
export {};
