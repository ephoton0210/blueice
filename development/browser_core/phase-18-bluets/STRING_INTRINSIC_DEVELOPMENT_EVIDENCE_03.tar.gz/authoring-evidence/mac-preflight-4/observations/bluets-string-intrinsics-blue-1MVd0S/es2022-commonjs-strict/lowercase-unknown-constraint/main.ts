export declare const value: Lowercase<unknown>;
