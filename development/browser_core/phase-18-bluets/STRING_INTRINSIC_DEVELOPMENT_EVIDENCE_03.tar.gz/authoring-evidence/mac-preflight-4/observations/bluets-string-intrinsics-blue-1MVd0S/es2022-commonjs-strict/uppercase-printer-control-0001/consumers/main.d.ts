export declare const value: "A\u0001Z";
