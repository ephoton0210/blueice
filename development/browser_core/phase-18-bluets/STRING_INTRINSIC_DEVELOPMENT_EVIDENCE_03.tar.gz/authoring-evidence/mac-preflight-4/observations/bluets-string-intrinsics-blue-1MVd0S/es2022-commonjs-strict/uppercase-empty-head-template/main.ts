export const value: Uppercase<`${string}-post`> = "ABC-POST";
