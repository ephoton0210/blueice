export declare const value: Capitalize<`pre-${string}`>;
