export type Fake<T> = intrinsic;
