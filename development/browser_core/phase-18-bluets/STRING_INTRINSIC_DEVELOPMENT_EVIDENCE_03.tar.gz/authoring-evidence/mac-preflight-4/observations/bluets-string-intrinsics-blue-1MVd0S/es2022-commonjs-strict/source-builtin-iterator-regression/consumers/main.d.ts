export type BuiltinIteratorReturn = intrinsic;
export declare const value: BuiltinIteratorReturn;
