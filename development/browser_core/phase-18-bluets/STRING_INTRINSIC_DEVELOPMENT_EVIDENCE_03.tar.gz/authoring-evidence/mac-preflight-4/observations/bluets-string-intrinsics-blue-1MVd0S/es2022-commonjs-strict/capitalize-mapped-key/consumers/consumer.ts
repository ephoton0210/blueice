import { value } from "./main";
const proof: string = value;
