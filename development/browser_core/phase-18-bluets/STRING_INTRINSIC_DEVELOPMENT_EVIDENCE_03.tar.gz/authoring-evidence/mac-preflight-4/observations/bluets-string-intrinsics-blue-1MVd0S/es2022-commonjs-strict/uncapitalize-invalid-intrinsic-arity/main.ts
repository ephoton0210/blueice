export type Uncapitalize<T, U> = intrinsic;
