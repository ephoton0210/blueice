type Lowercase<T> = intrinsic;
export declare const value: Lowercase<string>;
export {};
