export declare const value: Uncapitalize<string>;
