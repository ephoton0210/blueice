export const value: Uncapitalize<any> = 123;
