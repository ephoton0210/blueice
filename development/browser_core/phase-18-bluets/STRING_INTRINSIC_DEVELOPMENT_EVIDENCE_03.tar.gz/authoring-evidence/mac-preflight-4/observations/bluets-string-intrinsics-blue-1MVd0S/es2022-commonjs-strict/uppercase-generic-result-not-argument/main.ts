export function value<T extends string>(input: Uppercase<T>): T { return input; }
