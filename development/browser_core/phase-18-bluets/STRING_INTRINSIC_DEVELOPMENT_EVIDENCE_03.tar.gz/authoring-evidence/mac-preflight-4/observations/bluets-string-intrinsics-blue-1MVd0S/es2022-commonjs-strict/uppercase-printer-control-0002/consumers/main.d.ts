export declare const value: "A\u0002Z";
