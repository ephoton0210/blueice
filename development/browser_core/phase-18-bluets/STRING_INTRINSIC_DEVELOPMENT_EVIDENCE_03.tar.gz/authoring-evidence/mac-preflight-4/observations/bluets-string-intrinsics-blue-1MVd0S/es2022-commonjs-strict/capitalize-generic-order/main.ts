export function value<T extends string>(input: Capitalize<Uncapitalize<T>>): Uncapitalize<Capitalize<T>> { return input; }
