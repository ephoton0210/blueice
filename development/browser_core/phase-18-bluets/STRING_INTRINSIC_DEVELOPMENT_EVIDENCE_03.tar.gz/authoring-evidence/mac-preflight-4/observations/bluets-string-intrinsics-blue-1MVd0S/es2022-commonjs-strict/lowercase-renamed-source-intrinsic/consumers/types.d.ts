export type Lowercase<T extends string> = intrinsic;
