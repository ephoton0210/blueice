export function value<T extends string>(input: T): Uncapitalize<T> { return input; }
