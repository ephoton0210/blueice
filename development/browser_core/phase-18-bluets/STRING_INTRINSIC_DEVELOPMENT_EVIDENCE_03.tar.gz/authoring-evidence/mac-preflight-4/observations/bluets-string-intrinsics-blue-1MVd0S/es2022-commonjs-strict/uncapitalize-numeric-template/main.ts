export const value: Uncapitalize<`${number}`> = "1e+21";
