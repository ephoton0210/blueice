export declare const value: Lowercase<`pre-${string}`>;
