export declare const value: Uppercase<null>;
