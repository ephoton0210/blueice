export function value<T extends string>(input: T): Uppercase<T> { return input; }
