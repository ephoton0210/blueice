type Uncapitalize<T> = {
    owner: T;
};
export declare const value: Uncapitalize<number>;
export {};
