type Capitalize<T> = intrinsic;
export declare const value: Capitalize<{
    key: number;
}>;
export {};
