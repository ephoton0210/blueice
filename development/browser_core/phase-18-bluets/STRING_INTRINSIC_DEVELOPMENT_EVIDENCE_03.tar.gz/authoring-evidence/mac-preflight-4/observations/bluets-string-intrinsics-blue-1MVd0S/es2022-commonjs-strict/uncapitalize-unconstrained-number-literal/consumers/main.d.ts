type Uncapitalize<T> = intrinsic;
export declare const value: Uncapitalize<123>;
export {};
