export declare const value: Uncapitalize<"𐐨a">;
