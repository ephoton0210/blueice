export function value<T extends string>(input: Capitalize<T>): T { return input; }
