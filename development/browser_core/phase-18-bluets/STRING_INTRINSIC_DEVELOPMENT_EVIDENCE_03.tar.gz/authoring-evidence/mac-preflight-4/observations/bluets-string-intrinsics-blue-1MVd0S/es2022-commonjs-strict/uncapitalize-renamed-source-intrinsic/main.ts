import type { Uncapitalize as Mapping } from "./types";
export const value: Mapping<"word"> = "word";
