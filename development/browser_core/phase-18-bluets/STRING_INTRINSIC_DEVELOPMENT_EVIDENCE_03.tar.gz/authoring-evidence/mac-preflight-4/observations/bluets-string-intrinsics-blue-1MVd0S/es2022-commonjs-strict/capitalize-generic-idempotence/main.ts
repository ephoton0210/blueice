export function value<T extends string>(input: Capitalize<Capitalize<T>>): Capitalize<T> { return input; }
