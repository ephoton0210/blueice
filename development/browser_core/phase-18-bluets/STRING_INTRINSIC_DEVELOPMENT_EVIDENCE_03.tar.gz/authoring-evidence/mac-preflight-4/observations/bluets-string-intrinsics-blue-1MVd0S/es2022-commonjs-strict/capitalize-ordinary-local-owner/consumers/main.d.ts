type Capitalize<T> = {
    owner: T;
};
export declare const value: Capitalize<number>;
export {};
