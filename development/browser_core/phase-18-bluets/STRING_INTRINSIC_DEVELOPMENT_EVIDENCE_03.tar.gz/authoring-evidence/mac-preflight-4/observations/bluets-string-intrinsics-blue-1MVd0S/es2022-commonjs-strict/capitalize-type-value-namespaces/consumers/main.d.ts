export declare const value: Capitalize<"word">;
export declare const runtime: number;
