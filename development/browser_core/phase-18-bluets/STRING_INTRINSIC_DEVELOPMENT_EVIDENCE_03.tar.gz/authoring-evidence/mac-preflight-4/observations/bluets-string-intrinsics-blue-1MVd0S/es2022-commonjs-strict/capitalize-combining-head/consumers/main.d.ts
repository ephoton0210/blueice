export declare const value: "́Word";
