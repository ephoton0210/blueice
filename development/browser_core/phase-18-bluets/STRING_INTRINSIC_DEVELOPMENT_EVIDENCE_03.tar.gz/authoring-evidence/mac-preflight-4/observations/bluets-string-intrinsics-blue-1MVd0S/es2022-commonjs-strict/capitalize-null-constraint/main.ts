export declare const value: Capitalize<null>;
