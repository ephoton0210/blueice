type Uncapitalize<T> = { owner: T };
export const value: Uncapitalize<number> = { owner: 1 };
