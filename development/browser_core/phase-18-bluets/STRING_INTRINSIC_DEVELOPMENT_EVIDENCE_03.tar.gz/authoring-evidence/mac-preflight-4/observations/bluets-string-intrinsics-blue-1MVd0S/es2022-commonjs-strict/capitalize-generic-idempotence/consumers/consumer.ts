import { value } from "./main";
value<"word">("invalid");
