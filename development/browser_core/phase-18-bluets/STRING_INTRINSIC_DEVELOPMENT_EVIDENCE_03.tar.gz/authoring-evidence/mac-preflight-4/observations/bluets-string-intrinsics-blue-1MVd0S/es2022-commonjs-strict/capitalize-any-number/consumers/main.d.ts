export declare const value: Capitalize<any>;
