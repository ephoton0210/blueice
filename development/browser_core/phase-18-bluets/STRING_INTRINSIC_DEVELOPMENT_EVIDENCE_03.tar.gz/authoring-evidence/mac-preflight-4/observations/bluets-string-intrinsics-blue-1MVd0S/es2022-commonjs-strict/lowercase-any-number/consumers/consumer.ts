import { value } from "./main";
const proof: typeof value = "aBc";
