type Capitalize<T> = intrinsic;
export declare const value: Capitalize<string>;
export {};
