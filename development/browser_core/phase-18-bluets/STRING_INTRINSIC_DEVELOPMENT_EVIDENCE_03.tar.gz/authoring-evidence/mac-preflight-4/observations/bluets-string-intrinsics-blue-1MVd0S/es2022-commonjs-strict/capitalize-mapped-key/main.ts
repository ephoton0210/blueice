type MapKeys<T> = { [K in keyof T as Capitalize<string & K>]: T[K] };
declare function map<T>(input: T): MapKeys<T>;
const mapped = map({ word: 1 });
export const value = mapped["Word"];
