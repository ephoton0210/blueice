declare const input: Uppercase<"\uDC00a">;
export const value: Uppercase<"\uFFFDa"> = input;
