declare const input: Capitalize<"\uD801\uDC28a">;
export const value: Capitalize<"𐐨a"> = input;
