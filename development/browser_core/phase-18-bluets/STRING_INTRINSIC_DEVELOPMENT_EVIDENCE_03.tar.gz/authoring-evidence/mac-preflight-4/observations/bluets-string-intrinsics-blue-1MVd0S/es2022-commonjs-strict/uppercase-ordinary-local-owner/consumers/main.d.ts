type Uppercase<T> = {
    owner: T;
};
export declare const value: Uppercase<number>;
export {};
