type IsMapped<T extends string> = T extends Capitalize<T> ? true : false;
export const value: [IsMapped<"Word">, IsMapped<"word">] = [true, false];
