declare const input: Lowercase<"\uD800a">;
export const value: Lowercase<"\uFFFDa"> = input;
