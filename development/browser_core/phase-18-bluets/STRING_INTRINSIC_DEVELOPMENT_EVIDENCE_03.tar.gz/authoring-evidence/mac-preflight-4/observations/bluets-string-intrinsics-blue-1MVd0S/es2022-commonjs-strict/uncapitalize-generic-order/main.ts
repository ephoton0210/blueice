export function value<T extends string>(input: Uncapitalize<Capitalize<T>>): Capitalize<Uncapitalize<T>> { return input; }
