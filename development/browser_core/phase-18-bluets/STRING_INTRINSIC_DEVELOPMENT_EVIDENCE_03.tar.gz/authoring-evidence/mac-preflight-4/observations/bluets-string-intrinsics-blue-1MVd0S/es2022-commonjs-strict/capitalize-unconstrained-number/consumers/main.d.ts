type Capitalize<T> = intrinsic;
export declare const value: Capitalize<number>;
export {};
