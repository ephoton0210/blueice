import type { Capitalize as Owned } from "./types";
export const value: Owned<number> = { owner: 1 };
