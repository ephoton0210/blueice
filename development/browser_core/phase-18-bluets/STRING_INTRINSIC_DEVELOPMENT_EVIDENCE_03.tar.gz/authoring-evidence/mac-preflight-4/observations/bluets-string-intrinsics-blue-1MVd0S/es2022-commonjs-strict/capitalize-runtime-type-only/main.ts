export const value = Capitalize("word");
