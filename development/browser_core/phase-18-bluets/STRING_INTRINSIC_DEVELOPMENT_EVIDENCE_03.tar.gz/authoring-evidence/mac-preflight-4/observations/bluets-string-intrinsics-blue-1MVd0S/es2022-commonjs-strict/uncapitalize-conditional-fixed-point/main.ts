type IsMapped<T extends string> = T extends Uncapitalize<T> ? true : false;
export const value: [IsMapped<"word">, IsMapped<"Word">] = [true, false];
