declare const input: Lowercase<"\uDC00a">;
export const value: Lowercase<"\uFFFDa"> = input;
