export declare const value: "A\u0003Z";
