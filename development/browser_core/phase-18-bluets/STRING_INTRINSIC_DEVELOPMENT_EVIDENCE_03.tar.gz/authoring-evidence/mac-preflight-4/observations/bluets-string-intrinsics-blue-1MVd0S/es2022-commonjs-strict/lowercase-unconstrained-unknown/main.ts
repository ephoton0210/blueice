type Lowercase<T> = intrinsic;
export const value: Lowercase<unknown> = "anything";
