export declare const value: "İSTANBUL";
