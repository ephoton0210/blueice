type Lowercase<T> = intrinsic;
export declare const value: Lowercase<{
    key: number;
}>;
export {};
