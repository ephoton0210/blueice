export declare const value: Lowercase<"word">;
export declare const runtime: number;
