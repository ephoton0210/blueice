type Capitalize<T> = { owner: T };
export const value: Capitalize<number> = { owner: 1 };
