type Capitalize<T> = intrinsic;
export declare const value: Capitalize<123>;
export {};
