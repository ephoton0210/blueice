export declare const value: Lowercase<any>;
