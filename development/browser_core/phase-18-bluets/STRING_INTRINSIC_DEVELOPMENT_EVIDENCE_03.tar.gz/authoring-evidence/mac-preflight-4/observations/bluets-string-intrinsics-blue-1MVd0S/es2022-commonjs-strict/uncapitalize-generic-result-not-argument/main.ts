export function value<T extends string>(input: Uncapitalize<T>): T { return input; }
