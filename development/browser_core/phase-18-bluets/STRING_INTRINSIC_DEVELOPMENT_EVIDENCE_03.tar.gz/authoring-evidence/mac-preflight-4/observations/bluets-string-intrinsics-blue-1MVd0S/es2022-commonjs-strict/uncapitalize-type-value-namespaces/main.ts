const Uncapitalize = (input: number) => input + 1;
export const value: Uncapitalize<"word"> = "word";
export const runtime = Uncapitalize(1);
