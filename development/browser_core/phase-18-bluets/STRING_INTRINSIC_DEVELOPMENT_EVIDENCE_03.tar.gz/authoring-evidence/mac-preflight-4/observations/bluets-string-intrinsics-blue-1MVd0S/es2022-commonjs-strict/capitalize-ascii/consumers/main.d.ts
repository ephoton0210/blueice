export declare const value: "WOrD";
