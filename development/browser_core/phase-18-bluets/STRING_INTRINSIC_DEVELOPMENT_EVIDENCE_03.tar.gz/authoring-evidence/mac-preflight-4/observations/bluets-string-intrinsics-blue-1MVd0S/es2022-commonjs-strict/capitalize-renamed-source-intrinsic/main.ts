import type { Capitalize as Mapping } from "./types";
export const value: Mapping<"word"> = "Word";
