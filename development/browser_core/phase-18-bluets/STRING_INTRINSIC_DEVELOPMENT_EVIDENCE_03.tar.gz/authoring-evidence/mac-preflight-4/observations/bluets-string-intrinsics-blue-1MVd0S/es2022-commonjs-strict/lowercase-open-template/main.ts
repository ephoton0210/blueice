export const value: Lowercase<`pre-${string}`> = "pre-abc";
