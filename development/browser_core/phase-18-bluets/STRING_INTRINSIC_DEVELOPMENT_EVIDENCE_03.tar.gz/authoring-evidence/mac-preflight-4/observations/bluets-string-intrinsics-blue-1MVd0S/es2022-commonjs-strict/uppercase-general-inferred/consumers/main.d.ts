export declare const value: Uppercase<string>;
