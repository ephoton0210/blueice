type Lowercase<T> = { owner: T };
export const value: Lowercase<number> = { owner: 1 };
