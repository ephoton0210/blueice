export declare function value<T extends string>(input: Lowercase<Lowercase<T>>): Lowercase<T>;
