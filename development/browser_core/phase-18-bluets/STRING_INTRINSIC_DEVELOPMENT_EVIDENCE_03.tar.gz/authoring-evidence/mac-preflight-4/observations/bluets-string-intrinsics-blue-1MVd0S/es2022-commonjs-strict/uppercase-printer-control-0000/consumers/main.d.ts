export declare const value: "A\0Z";
