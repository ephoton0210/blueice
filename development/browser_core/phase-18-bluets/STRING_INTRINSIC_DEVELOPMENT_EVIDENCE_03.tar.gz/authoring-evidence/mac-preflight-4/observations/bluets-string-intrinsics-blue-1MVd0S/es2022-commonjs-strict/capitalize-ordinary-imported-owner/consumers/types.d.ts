export type Capitalize<T> = {
    owner: T;
};
