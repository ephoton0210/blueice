export type Capitalize<T, U> = intrinsic;
