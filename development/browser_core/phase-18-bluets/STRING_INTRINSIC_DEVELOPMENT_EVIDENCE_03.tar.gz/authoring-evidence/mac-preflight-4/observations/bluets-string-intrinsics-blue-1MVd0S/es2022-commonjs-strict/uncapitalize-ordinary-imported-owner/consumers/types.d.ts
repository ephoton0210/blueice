export type Uncapitalize<T> = {
    owner: T;
};
