export const value: Uppercase<any> = 123;
