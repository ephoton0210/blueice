type Lowercase<T> = intrinsic;
export declare const value: Lowercase<unknown>;
export {};
