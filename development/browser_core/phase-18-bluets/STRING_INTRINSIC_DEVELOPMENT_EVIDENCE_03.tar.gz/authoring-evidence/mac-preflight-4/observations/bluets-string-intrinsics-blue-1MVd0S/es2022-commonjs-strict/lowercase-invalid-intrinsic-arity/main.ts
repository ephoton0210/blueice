export type Lowercase<T, U> = intrinsic;
