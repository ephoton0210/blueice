export type Capitalize<T extends string> = intrinsic;
export declare const value: Capitalize<"word">;
