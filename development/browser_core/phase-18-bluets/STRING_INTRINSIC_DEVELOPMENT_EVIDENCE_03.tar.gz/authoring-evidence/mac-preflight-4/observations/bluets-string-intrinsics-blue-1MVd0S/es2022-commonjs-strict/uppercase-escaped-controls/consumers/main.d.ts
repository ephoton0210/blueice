export declare const value: "A\0\n\v\"\\Z";
