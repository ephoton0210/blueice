import { value } from "./main";
const proof: typeof value = [false, true];
