export function value<T extends string>(input: Lowercase<Uppercase<T>>): Uppercase<Lowercase<T>> { return input; }
