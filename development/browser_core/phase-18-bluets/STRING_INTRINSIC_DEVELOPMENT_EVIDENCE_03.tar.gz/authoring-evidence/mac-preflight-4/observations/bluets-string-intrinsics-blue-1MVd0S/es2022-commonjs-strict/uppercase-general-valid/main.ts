export const value: Uppercase<string> = "ABC";
