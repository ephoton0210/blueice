export type NoInfer<T> = intrinsic;
export declare const value: NoInfer<number>;
