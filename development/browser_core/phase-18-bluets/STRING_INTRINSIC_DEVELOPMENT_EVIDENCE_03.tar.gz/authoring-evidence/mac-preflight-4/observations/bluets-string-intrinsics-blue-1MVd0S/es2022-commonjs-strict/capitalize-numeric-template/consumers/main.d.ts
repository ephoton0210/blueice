export declare const value: Capitalize<`${number}`>;
