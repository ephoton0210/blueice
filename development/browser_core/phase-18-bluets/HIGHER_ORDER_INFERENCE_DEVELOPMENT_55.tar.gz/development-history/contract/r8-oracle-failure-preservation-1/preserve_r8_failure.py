# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Retain the original r8 source and failed Windows products before any repair."""
from pathlib import Path
import base64
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import tarfile
import time

repo = Path.cwd()
root = repo/'target/higher-order-inference-acceptance-20261114-r8'
contract = Path(__file__).resolve().parent
local = contract/'r8-oracle-failure-preservation-1'
local.mkdir()
remote_output = root/'windows/failed-evidence-preservation-1'
remote_output.mkdir()
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = read(root/'frozen-source-preflight.json')
failed = read(root/'windows/live-observation-2.json')
assert failed['conclusion'] == 'failure' and failed['stage'] == 'gt7_library_manifest'
files = dict(frozen['files'])
for name in ['Cargo.toml','Cargo.lock','LICENSE']:
    files[name] = sha(repo/name)
assert len(files) == 14738
for name,digest in files.items():
    assert sha(repo/name) == digest, name
archive = local/'frozen-source.tar.gz'
with tarfile.open(archive,'w:gz') as package:
    for name in sorted(files):
        package.add(repo/name,arcname=name,recursive=False)
with tarfile.open(archive,'r|gz') as package:
    verified = {item.name:hashlib.sha256(package.extractfile(item).read()).hexdigest()
                for item in package if item.isfile()}
assert verified == files
native = read(root/'native-gates.json')
compiler = root/'accepted-native-cli'
assert sha(compiler) == native['nativeCompilerSha256']
shutil.copy2(compiler,local/'actual-native-cli')
for name in ['launch-state.json','mac-driver.json','native-gates.json',
             'accepted-native/measurement.json','accepted-native/current.json',
             'windows/complete-state.json','windows/live-observation-2.json']:
    target = local/'observed'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,target)
receipt = {'conclusion':'source-preserved-before-oracle-repair',
    'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision':frozen['sourceRevision'],'sourceFiles':len(files),'files':files,
    'archiveSha256':sha(archive),'actualNativeCompilerSha256':sha(compiler),
    'originalWindowsConclusion':'failure','originalWindowsStage':failed['stage'],
    'wholeAcceptanceCredit':0}
(local/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copy2(__file__,local/Path(__file__).name)

old = repo/'target/higher-order-inference-acceptance-20261114-r2/windows/failure-observation-1/archive-failure.py'
code = old.read_text().replace('p0g-r2','p0g-r8').replace('results-higher-order-inference-r2','results-higher-order-inference-r8')
code = code.replace('backend-tree:14d3fff9226074576f7ab1e05277e7abbe4d8649',frozen['sourceRevision'])
code = code.replace('[14244,14788]',"[bootstrap['pid'],bootstrap['nodePid']]")
code = code.replace("measurement['stage']=='gt10_import_types'","measurement['stage']=='gt7_library_manifest'")
code = code.replace('Unchanged G-T10 Native virtual-host cannot resolve normalized Windows filenames; G higher-order cohort itself passed all4tests.',
    'G-T7 Native virtual host cannot resolve normalized Windows filenames; higher-order passes all seven, G-T7 passes five and fails two external-oracle tests.')
marker = "with tarfile.open(archive,'w:gz') as package:\n"
assert code.count(marker) == 1
code = code.replace(marker, "gt7=next(row for row in measurement['followups'] if row['target']=='gt7_library_manifest')\n"
    "test_binary=Path(measurement['command'][0]);assert sha(test_binary)==gt7['binarySha256']\n"+marker+
    " package.add(test_binary,arcname='actual-failed-gt7-test.exe',recursive=False)\n")
code = '\n'.join(Path(__file__).read_text().splitlines()[:3])+'\n'+code
(remote_output/'archive-failure.py').write_text(code)
spec = importlib.util.spec_from_file_location('r8_failure_qga',repo/'target/noinfer-acceptance-20261112/recovery/qga_transfer.py')
qga = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qga)
guest_script = 'B:/BlueIce/gm3-20261109-360d7d921/p0g-r8-archive-failure-1.py'
wrapper = "from pathlib import Path; p=Path("+repr(guest_script)+"); assert not p.exists(); payload="+repr(code)+"; p.write_text(payload,encoding='utf-8'); exec(compile(payload,str(p),'exec'))"
process = qga.call({'execute':'guest-exec','arguments':{
    'path':'C:\\Program Files\\Python312\\python.exe','arg':['-B','-c',wrapper],'capture-output':True}})
state = {'pid':os.getpid(),'conclusion':'in_progress','stage':'observing-owned-failure-archive',
    'guestProcess':process,'sourceRevision':frozen['sourceRevision'],'acceptanceCredit':0}
def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (remote_output/'state.json').write_text(json.dumps(state,indent=2)+'\n')
try:
    save()
    while True:
        result = qga.call({'execute':'guest-exec-status','arguments':{'pid':process['pid']}})
        if result.get('exited'):
            for key in ['out-data','err-data']:
                if key in result:
                    result[key] = base64.b64decode(result[key]).decode('utf-8-sig',errors='replace')
            (remote_output/'guest-terminal.json').write_text(json.dumps(result,indent=2)+'\n')
            assert result['exitcode'] == 0, result
            break
        state['lastGuestStatus'] = result
        save()
        time.sleep(10)
    state['stage'] = 'receiving-failed-source-and-products'
    save()
    qga.download('B:/BlueIce/gm3-20261109-360d7d921/p0g-r8-failed-evidence.json',remote_output/'guest-receipt.json')
    guest = read(remote_output/'guest-receipt.json')
    qga.download(guest['archive'],remote_output/'failed-evidence.tar.gz')
    assert sha(remote_output/'failed-evidence.tar.gz') == guest['archiveSha256']
    assert (remote_output/'failed-evidence.tar.gz').stat().st_size == guest['archiveBytes']
    manifest = read(root/'windows/windows-source-manifest.json')
    preserved = {}
    with tarfile.open(remote_output/'failed-evidence.tar.gz','r|gz') as package:
        for member in package:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            digest = hashlib.sha256(package.extractfile(member).read()).hexdigest()
            if member.name.startswith('source/'):
                name = member.name[len('source/'):]
                assert name not in preserved
                preserved[name] = digest
            if member.name == 'actual-failed-gt7-test.exe':
                gt7 = next(row for row in failed['followups'] if row['target']=='gt7_library_manifest')
                assert digest == gt7['binarySha256']
            if member.name.endswith('/accepted-windows-cli.exe'):
                assert digest == failed['compiler']['sha256']
    assert preserved == manifest['files'] and len(preserved) == 14822
    state.update(conclusion='success',stage='failed-evidence-independently-verified',
        verifiedSourceFiles=len(preserved),archiveSha256=guest['archiveSha256'],
        actualCompilerSha256=failed['compiler']['sha256'],originalFailureUnchanged=True)
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    save()
    print(json.dumps(state))
