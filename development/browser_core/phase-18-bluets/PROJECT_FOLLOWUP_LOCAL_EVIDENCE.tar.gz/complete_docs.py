from pathlib import Path
import json,re
phase=Path('/Users/ephoton/git/blueice-bluets/development/browser_core/phase-18-bluets')
m=json.loads((phase/'PROJECT_FOLLOWUP_MEASUREMENT.json').read_text())
assert m['conclusion']=='complete-within-frozen-scope'
completion_date=m['recordedAt'][:10]
revision=m['source']['sourceRevision'];n=m['native'];w=m['localWorkspace'];counts=m['caseCounts'];functions=sum(s['passed'] for s in n['suites'])
p=phase/'PROJECT_FOLLOWUP_ACCEPTANCE.md';s=p.read_text();s=s.replace('Fresh complete acceptance is in progress. This file does not credit the earlier\nblocked audit or an incomplete validation attempt as a completed repair.',f'''Completed within the frozen project and control matrices on {completion_date} UTC.
Accepted source: `{revision}`. The earlier blocked audit and superseded
attempts retain their original results and are not credited as current passes.

[Measurement](PROJECT_FOLLOWUP_MEASUREMENT.json) ·
[raw evidence and hashes](PROJECT_FOLLOWUP_ARTIFACTS.json)

| Fresh acceptance gate | Result |
| --- | --- |
| Original G-T1 stages and complete Native cohort | {len(n['suites'])} suites / {functions:,} tests, all selected pinned functions included; zero failed, ignored or filtered |
| Complete local workspace | {w['passed']:,} passed / {w['ignored']} existing ignored / {w['groups']} result groups; zero failed or filtered |
| Native and ordinary declaration/JavaScript map checks | Each covers 8,407 configurations × two builds, zero differences; actual compiler/process bindings retained |
| Windows x86_64 VM | 25 path/symlink checks + 82/82 selected core oracles + both added regression cohorts and existing project configuration; all {m['windows']['verifiedSourceFiles']:,} source-manifest files and canonical backend path selection verified |
| Original unchanged mitt project | Cold build, byte-exact declaration, positive/negative consumers, eight runtime scenarios and incremental initial/warm/edit/clean pass |
| Format, workspace all-target Clippy and evidence tools | Pass; warnings denied, source/case/account/status checks retained |
| Module size | All 75 changed production files below 1,200 lines; maximum 1,160 |

All 39,426 prior suite-qualified case identities/classifications remain.
The additions contain 71 Native observations and 15 separate owner-control
families: {counts['listed']:,} total assertions, {counts['agreements']:,}
agreements / {counts['comparison_cases']:,} direct comparisons, three open and
three refused observations, {counts['reference_only']} Native-reference and
{counts['boundary_controls']} owner controls. Expected differences remain
separate from agreement.''')
s=s.replace('Completion requires the fresh complete Native cohort, local workspace, format\nand Clippy checks, source-map measurements and Windows x86_64 82-oracle gate\nbound to the actual immutable source and compiler bytes.', 'The complete Native cohort, local workspace, format and Clippy checks,\nsource-map measurements and Windows x86_64 82-oracle gate above are bound to\nthe actual immutable source and compiler bytes. Broader platform combinations\nremain unmeasured.')
p.write_text(s)
p=phase/'TODO.md';s=p.read_text();s=s.replace('flow, generic-method/diagnostic and explicit incremental repairs are implemented;\ncompletion awaits the fresh complete gates below.', 'flow, generic-method/diagnostic and explicit incremental repairs pass the fresh\ncomplete gates. [Current acceptance](PROJECT_FOLLOWUP_ACCEPTANCE.md) records\nthe immutable source, measurements and remaining scope limits.')
s=s.replace('Investigation complete;\n  **mitt remains incompatible with BlueTSC**: two independent blockers are\n  reproduced below. Native passes all eight runtime scenarios, declaration\n  consumers and warm/edit/clean builds. BlueTSC\'s dependent project checks are\n  explicitly blocked; the constrained-method diagnostic cascade is not a third\n  independent missing feature. The global case denominator is unchanged.', 'The original investigation\n  recorded **two independent blockers** and blocked downstream BlueTSC results.\n  Both are repaired in the current follow-up below; the historical results and\n  frozen project/reproduction bytes remain unchanged.')
s=s.replace('- [ ] **Object-literal generic methods', '- [x] **Object-literal generic methods')
s=s.replace('- [ ] **Explicit incremental configuration', '- [x] **Explicit incremental configuration')
s=s.replace('`incremental: true` alone currently causes BlueTSC\'s unsupported-option error.', '`incremental: true` alone reproduced BlueTSC\'s former unsupported-option error.')
s=s.replace('Both repairs include the existing complete Native, local-workspace and Windows\n82-oracle gates. Freeze additional negative controls before implementation.', f'''Both repairs pass the fresh complete gates on `{revision}`:
**{len(n['suites'])} Native suites / {functions:,} tests**, **{w['passed']:,} local workspace
passes**, both complete **8,407 × two** map checks, Windows **25 path checks +
82 core oracles + the two new cohorts and project-configuration tests**, formatting and warnings-denied Clippy.
Native expectations were frozen before their corresponding implementations;
all old case identities remain. [Acceptance and retained evidence](PROJECT_FOLLOWUP_ACCEPTANCE.md).''')
s=s.replace('**Current platform regression (2026-11-09):**', '**Earlier modularization platform regression (2026-11-09):**')
p.write_text(s)
p=phase/'REAL_PROJECT_AUDIT.md';s=p.read_text();title='# Fixed real-project audit — mitt 3.0.1\n';assert s.startswith(title);s=s.replace(title,title+f'''\n**Current follow-up:** the original project and all frozen repair gates now pass
on `{revision}`. See [completed repair acceptance](PROJECT_FOLLOWUP_ACCEPTANCE.md)
and [source-bound measurement](PROJECT_FOLLOWUP_MEASUREMENT.json). The audit
below retains the earlier blocked source and its original evidence.\n''',1);p.write_text(s)
print('Updated TODO, repair acceptance and historical-audit pointer from completed measurements.')
