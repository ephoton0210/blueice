from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile,time
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-publication-gates-20261110');previous=Path('/private/tmp/bluets-config-gates-20261109');baseline=Path('/private/tmp/bluets-maintenance-20261109');helper='/private/tmp/gm3_qga.py';guest=r'B:\BlueIce\gm3-20261109-360d7d921';state={'stage':'waiting-for-previous-windows-archive'}
def save():
 state['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(root/'windows-launch.json').write_text(json.dumps(state,indent=2)+'\n')
def call(*args):return subprocess.check_output([sys.executable,helper,*args])
def git_paths(args):return [p for p in subprocess.check_output(['git',*args],cwd=repo).decode().split(chr(0)) if p]
try:
 save()
 while True:
  p=previous/'windows-watch.json'
  if p.exists():
   old=json.loads(p.read_bytes())
   if old.get('stage')=='windows-complete' and (previous/'windows-evidence.tar.gz').exists():break
   if old.get('conclusion')=='failure':raise RuntimeError('Previous Windows evidence was not archived: '+str(old))
  time.sleep(15)
 frozen=json.loads((root/'frozen-source.json').read_bytes())
 selection=['backend','development/browser_core/phase-18-bluets/tools/record_gc1_object_generic_methods.cjs','development/browser_core/phase-18-bluets/tools/record_gm2_incremental_options.cjs','differential-testing/bluets-projects']
 tracked=set(git_paths(['ls-files','-z','--',*selection]));manifest=json.loads((baseline/'windows-source-manifest.json').read_bytes());changes=set(git_paths(['diff','--name-only','-z','HEAD','--',*selection]))|(tracked-set(manifest['files']))
 with tarfile.open(previous/'source-patch.tar.gz') as old_patch:changes.update(old_patch.getnames())
 changes=sorted(changes,key=lambda p:p.encode('utf8'));patch=root/'source-patch.tar.gz'
 with tarfile.open(patch,'w:gz') as archive:
  for name in changes:archive.add(repo/name,arcname=name,recursive=False)
 patchhash=hashlib.sha256(patch.read_bytes()).hexdigest();manifest['files'].update({name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changes})
 backend=sorted(git_paths(['ls-files','-z','--','backend']),key=lambda p:p.encode('utf8'));assert {p for p in manifest['files'] if p.startswith('backend/')}==set(backend)
 pathhash=hashlib.sha256(chr(0).join(backend).encode()).hexdigest();manifest.update(sourceRevision=frozen['sourceRevision'],followupPatchSha256=patchhash,backendFiles=len(backend),backendPathSetSha256=pathhash,scope='All frozen backend files, including Unicode names selected with NUL-delimited Git paths, plus recorded build/oracle/project-audit support files. Unrelated repository artifacts are outside this Windows source selection.');(root/'windows-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 prior=json.loads((previous/'windows-source-manifest.json').read_bytes());s=(previous/'windows-runner.cjs').read_text().replace('results-followups-v8','results-followups-v9').replace(prior['sourceRevision'],frozen['sourceRevision']).replace(prior['followupPatchSha256'],patchhash)
 s=s.replace("const expected=manifest.files;", "const expected=manifest.files;const backend=Object.keys(expected).filter(p=>p.startsWith('backend/')).sort((a,b)=>Buffer.compare(Buffer.from(a),Buffer.from(b)));const pathHash=crypto.createHash('sha256').update(backend.join(String.fromCharCode(0))).digest('hex');if(backend.length!==manifest.backendFiles||pathHash!==manifest.backendPathSetSha256)throw Error('Incomplete backend source selection');state.verifiedBackendFiles=backend.length;state.backendPathSetSha256=pathHash;")
 (root/'windows-runner.cjs').write_text(s);s=(previous/'start-windows.ps1').read_text().replace(prior['followupPatchSha256'],patchhash);(root/'start-windows.ps1').write_text(s)
 s=(previous/'watch_windows.py').read_text().replace(str(previous),str(root)).replace('results-followups-v8','results-followups-v9').replace('followup-evidence-v8.tar.gz','followup-evidence-v9.tar.gz')
 s=s.replace("assert r['verifiedSourceFiles']==14619 and r['expectedSourceManifestSha256']==hashlib.sha256((root/'windows-source-manifest.json').read_bytes()).hexdigest()", "manifest=json.loads((root/'windows-source-manifest.json').read_text())\n assert r['verifiedSourceFiles']==len(manifest['files']) and r['verifiedBackendFiles']==manifest['backendFiles'] and r['backendPathSetSha256']==manifest['backendPathSetSha256']\n assert r['expectedSourceManifestSha256']==hashlib.sha256((root/'windows-source-manifest.json').read_bytes()).hexdigest()")
 s=s.replace('verifiedSourceFiles=14619','verifiedSourceFiles=r[\'verifiedSourceFiles\']').replace('Windows25+82 and14619 source hashes verified; raw archive retained','Windows25+82 and all canonical backend source paths verified; raw archive retained');(root/'watch_windows.py').write_text(s)
 state.update(stage='uploading-source',sourceRevision=frozen['sourceRevision'],patchSha256=patchhash,verifiedFiles=len(manifest['files']),backendFiles=len(backend));save()
 for local,remote in [('source-patch.tar.gz','followup-patch.tar.gz'),('windows-source-manifest.json','followup-source-manifest.json'),('windows-runner.cjs','followup-runner.cjs')]:call('write',str(root/local),guest+chr(92)+remote)
 (root/'windows-process.json').write_bytes(call('start',str(root/'start-windows.ps1')));state.update(stage='windows-started');save();subprocess.run([sys.executable,str(root/'watch_windows.py')],check=True);state.update(stage='complete',conclusion='success');save()
except BaseException as error:state.update(conclusion='failure',error=repr(error));save();raise
