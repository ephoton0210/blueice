from pathlib import Path
import datetime,hashlib,json,os,subprocess

repo=Path('/Users/ephoton/git/blueice-bluets')
phase=repo/'development/browser_core/phase-18-bluets'
root=Path('/private/tmp/bluets-publication-gates-20261110')
state=json.loads((root/'acceptance.json').read_text())
assert state['stage']=='node-tools' and state['conclusion']=='failure'
assert state['steps'][-1]['label']=='node-tools' and state['steps'][-1]['exit']==1
assert all(step['exit']==0 for step in state['steps'][:-1])
assert state['workspace']['passed']==7838 and state['workspace']['failed']==0
history=root/'tool-inventory-before-fix'
history.mkdir(exist_ok=False)
for name in ['acceptance.json','node-tools.log','symlink-inventory-before-fix.log']:
 (history/name).write_bytes((root/name).read_bytes())
(history/'correction.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','development/browser_core/phase-18-bluets/tools/report_windows_symlink_tests.cjs','development/browser_core/phase-18-bluets/tools/report_windows_symlink_tests.test.cjs'],cwd=repo))
state.setdefault('automationCorrections',[]).append({
 'kind':'source-inventory-reporter-only',
 'reason':'The new Unix-only incremental-state symlink test increases the source inventory from 25 to 26. Preserve all 25 frozen Windows cases and separately report the new Unix-only case; no new Windows pass is claimed.',
 'rawEvidence':'tool-inventory-before-fix',
 'failedStep':state['steps'].pop(),
 'backendUnchanged':True,
})
state['conclusion']='in_progress'
state.pop('error',None)
state.pop('finishedAt',None)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0')
def save():
 (root/'acceptance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label
 save()
 log=root/(label+'.log')
 with log.open('wb')as out:
  result=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':args,'exit':result.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 save()
 if result.returncode:raise RuntimeError(f'{label}: exit {result.returncode}')
try:
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))+sorted((repo/'differential-testing/bluets-projects').glob('*.test.cjs'))
 run('node-tools',['node','--test',*[str(p)for p in tests]])
 run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:
  run(label,args)
 state['stage']='local-complete-awaiting-windows-and-publication'
 state['conclusion']='success'
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save()
except BaseException as error:
 state['conclusion']='failure'
 state['error']=repr(error)
 state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save()
 raise
