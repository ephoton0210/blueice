from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,shutil
repo=Path('/Users/ephoton/git/blueice-bluets')
phase=repo/'development/browser_core/phase-18-bluets'
root=Path('/Users/ephoton/git/blueice-bluets/target/noinfer-acceptance-20261112')
frozen=json.loads((root/'frozen-source-preflight.json').read_text())
revision=frozen['sourceRevision']
cli=repo/'target/debug/bluetsc'
cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',BLUEICE_BLUETSC_ORACLE='/Users/ephoton/git/blueice-bluets/target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/Users/ephoton/git/blueice-bluets/target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0')
for key in list(env):
 if key.startswith('BLUEICE_WRITE_') or key.startswith('BLUETS_'): del env[key]
state={'sourceRevision':revision,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'starting','conclusion':'in_progress','steps':[]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(root/'acceptance-gates.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label;save();log=root/(label+'.log');print('START',label,flush=True)
 with log.open('wb') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True);state['steps'].append({'label':label,'command':args,'exit':r.returncode,'log':log.name,'sha256':sha(log)});save()
 if r.returncode:raise RuntimeError(f'{label}: exit {r.returncode}')
 return log

def captures(kind):
 base=root/(kind+'-capture')
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json'),('BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS','callables'),('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers'),('BLUEICE_NOINFER_OBSERVATIONS','noinfer')]:
  dest=base/suffix;dest.parent.mkdir(parents=True,exist_ok=True)
  if name.endswith('DIRECTORY') or name.endswith('OBSERVATIONS'):dest.mkdir(exist_ok=True)
  env[name]=str(dest)
 env['BLUEICE_CALLABLE_SOURCE_REVISION']=env['BLUEICE_RECEIVER_SOURCE_REVISION']=env['BLUEICE_NOINFER_SOURCE_REVISION']=revision
try:
 save();(root/'baseline-cases.json').write_bytes(subprocess.check_output(['git','show','HEAD:development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json'],cwd=repo))
 run('suite-write',cargo+['--write',revision]);run('source-check',cargo+['--check-staged'])
 run('native-build',['cargo','test','-p','blueice-bluets','-p','blueice-bluets-bluejs','--no-run','--locked','--offline'])
 state['nativeCompilerSha256']=sha(cli);shutil.copy2(cli,root/'accepted-native-cli');save();env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256'];captures('native')
 run('presence-corrected',['node',str(root/'presence_corrected.cjs')])
 for name,script in [('defu','defu-audit.cjs'),('mitt','audit.cjs'),('reproductions','defu-reproduce.cjs'),('interchange','defu-interchange.cjs')]:
  run('project-'+name,['node',str(repo/'differential-testing/bluets-projects'/script),'--compiler',str(root/'accepted-native-cli'),'--typescript',env['BLUEICE_BLUETSC_ORACLE'],'--output',str(root/('project-'+name)),'--source-tree',frozen['backendTree']])
 run('native',['node',str(root/'measure_priority.cjs')])
 m=json.loads((root/'accepted-native/measurement.json').read_text());catalog=json.loads((phase/'COMPATIBILITY_SUITES.json').read_text());assert m['oracle_tools_sha256']==json.loads((root/'frozen-final-oracle-tools.json').read_text())['sha256'];assert m['conclusion']=='success' and len(m['suites'])==len(catalog['suites'])==185;assert all(s['failed']==s['ignored']==s['filtered']==0 for s in m['suites']);state['native']={'suites':len(m['suites']),'functions':sum(s['passed'] for s in m['suites']),'failed':0,'ignored':0,'filtered':0};save()
 run('cases-write',cargo+['--write-cases',revision,str(root/'accepted-native/measurement.json')]);previous=json.loads((root/'baseline-cases.json').read_text());current=json.loads((phase/'COMPATIBILITY_CASES.json').read_text())
 def cases(d):return {(s['harness'],c['id']):{k:c.get(k) for k in ['comparison','status','scope','reason']} for s in d['suites'] for c in s['cases']}
 before=cases(previous);after=cases(current);assert all(after.get(k)==v for k,v in before.items());assert len(after)-len(before)==286;assert all(h=='backend/bluets/tests/noinfer.rs' for h,i in set(after)-set(before));state['casePreservation']={'previous':len(before),'current':len(after),'added':286,'allOldCasesUnchanged':True};save()
 run('suite-labels',cargo+['--write',revision]);run('account-write',['python3',str(phase/'tools/account_inventory_rows.py'),'--write']);run('status-write',['python3',str(phase/'tools/check_compatibility_status.py'),'--write'])
 del env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256'];env['RUST_TEST_THREADS']='4';captures('workspace');run('workspace-build',['cargo','test','--workspace','--no-run','--locked','--offline']);state['workspaceCompilerSha256']=sha(cli);shutil.copy2(cli,root/'accepted-workspace-cli');save();env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256']
 log=run('workspace',['cargo','test','--workspace','--no-fail-fast','--locked','--offline']);rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',log.read_text(errors='replace'));assert rows and all(r[0]=='ok' and r[2]==r[4]=='0' for r in rows);state['workspace']={'passed':sum(int(r[1]) for r in rows),'failed':0,'ignored':sum(int(r[3]) for r in rows),'filtered':0,'groups':len(rows)};save()
 for family,script,variable in [('callable','verify_callable_utilities.cjs','BLUEICE_CALLABLE_UTILITIES_COMPILER'),('receiver','verify_receiver_utilities.cjs','BLUEICE_RECEIVER_UTILITIES_COMPILER'),('noinfer','verify_noinfer.cjs','BLUEICE_NOINFER_COMPILER')]:
  env[variable]=str(root/'accepted-workspace-cli')
  run('workspace-'+family+'-oracles',['node',str(phase/'tools'/script)])
 run('workspace-noinfer-regressions',['node',str(phase/'tools/verify_noinfer_regressions.cjs')])
 run('fmt-check',['cargo','fmt','--all','--','--check']);run('clippy',['cargo','clippy','--workspace','--all-targets','--features','blueice-bluets/windows-symlink-tests','--','-D','warnings'])
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))+sorted((repo/'differential-testing/bluets-projects').glob('*.test.cjs'));run('node-tools',['node','--test',*[str(p) for p in tests]]);run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,args)
 state.update(stage='local-complete-awaiting-windows-and-publication',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(conclusion='failure',error=repr(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
