# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PHASE = REPO / 'development/browser_core/phase-18-bluets'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(*args):
    return subprocess.check_output(args, cwd=REPO).decode().strip()


def summaries(text):
    return [(status, *map(int, counts)) for status, *counts in re.findall(
        r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', text)]


def audit():
    frozen = read(ROOT / 'frozen-source-preflight.json')
    source = frozen['sourceRevision']
    gates = read(ROOT / 'acceptance-gates.json')
    assert gates['conclusion'] == 'success', 'complete local gate is still required'
    assert gates['sourceRevision'] == source
    labels = [step['label'] for step in gates['steps']]
    required = {'suite-write', 'source-check', 'native-build', 'presence-corrected',
        'project-defu', 'project-mitt', 'project-reproductions', 'project-interchange',
        'native', 'cases-write', 'suite-labels', 'account-write', 'status-write',
        'workspace-build', 'workspace', 'workspace-callable-oracles',
        'workspace-receiver-oracles', 'workspace-noinfer-oracles',
        'workspace-noinfer-regressions', 'fmt-check', 'clippy', 'node-tools',
        'python-tools', 'source-final', 'cases-final', 'account-final', 'status-final'}
    assert set(labels) == required and len(labels) == len(set(labels))
    for step in gates['steps']:
        assert step['exit'] == 0 and sha(ROOT / step['log']) == step['sha256']
    assert command('git', 'rev-parse', 'HEAD') == frozen['head']
    tree = command('git', 'write-tree')
    assert command('git', 'rev-parse', tree + ':backend') == frozen['backendTree']
    assert not command('git', 'diff', '--numstat', '--', 'backend')
    for name, digest in read(ROOT / 'driver-hashes.json').items():
        assert sha(ROOT / name) == digest
    tools = {path.name: sha(path) for path in sorted((PHASE / 'tools').iterdir())
             if path.suffix in ['.cjs', '.py']}
    assert tools == read(ROOT / 'frozen-final-oracle-tools.json')['sha256']
    assert len(tools) == 588
    fixture = REPO / 'backend/bluets/tests/fixtures/noinfer'
    assert sha(fixture / 'cases.json') == frozen['inputSha256'] == 'f93542b0ad33c9ca5fbc3122e732548427bff77108eec7cc3f74046e0f8734e6'
    assert sha(fixture / 'reference.json') == frozen['referenceSha256'] == '5af732d9e989b8dbaa687615ac4837e51f7994220b3bd43637ca260a20d18c65'
    reference = read(fixture / 'reference.json')
    assert len(reference['cases']) == 282 and sum(row['accepts'] for row in reference['cases']) == 153
    assert sum(len(row['declarations']) for row in reference['cases']) == 159
    module_audit = read(ROOT / 'all-source-module-size-audit.json')
    assert module_audit['sourceRevision'] == source and module_audit['files'] == len(module_audit['sources']) == 538
    assert module_audit['maximumLines'] == max(row['lines'] for row in module_audit['sources']) < 1500
    assert not module_audit['overLimit']
    for row in module_audit['sources']:
        assert sha(REPO / row['path']) == row['sha256']
        assert len((REPO / row['path']).read_bytes().splitlines()) == row['lines']

    native = read(ROOT / 'accepted-native/measurement.json')
    catalog = read(PHASE / 'COMPATIBILITY_SUITES.json')
    assert native['conclusion'] == 'success' and native['source_revision'] == catalog['source_revision'] == source
    assert native['oracle_tools_sha256'] == tools and native['suite_jobs'] == 4
    assert native['runner_script_sha256'] == sha(ROOT / 'measure_priority.cjs')
    rows = native['suites']
    assert len(rows) == len(catalog['suites']) == 185
    assert {row['harness'] for row in rows} == {row['harness'] for row in catalog['suites']}
    assert len(set(native['execution_order'])) == 185 and set(native['execution_order']) == {row['harness'] for row in rows}
    for row in rows:
        assert row['conclusion'] == 'success' and row['exit_code'] == 0
        assert row['failed'] == row['ignored'] == row['filtered'] == 0
        assert len(row['test_names']) == len(set(row['test_names'])) == row['passed']
        suite = next(suite for suite in catalog['suites'] if suite['harness'] == row['harness'])
        assert sorted(suite['ignored_tests']) == sorted(row['pinned_tests'])
        log = ROOT / 'accepted-native' / row['log']
        assert sha(log) == row['log_sha256']
        assert summaries(log.read_text())[-1] == ('ok', row['passed'], 0, 0, 0)
    assert sum(row['passed'] for row in rows) == gates['native']['functions'] == 1053
    role_paths = set()
    for row in rows:
        for key, raw_path in row.get('artifact_paths', {}).items():
            path = Path(raw_path)
            if key == 'BLUEICE_GE5_ROLE_REPORT_DIRECTORY' and path.exists():
                role_paths.update(path.rglob('*.json'))
            elif key.startswith('BLUEICE_GE5_') and key.endswith('_REPORT') and path.exists():
                role_paths.add(path)
    interop = next(row for row in rows if row['harness'] == 'backend/bluets/tests/ge5_interop_module_maps.rs')
    expression = next(row for row in rows if row['harness'] == 'backend/bluets/tests/ge5_interop_expression_maps.rs')
    interop_directory = Path(interop['artifact_paths']['BLUEICE_GE5_ROLE_REPORT_DIRECTORY'])
    full_interop_path = interop_directory / 'interop-complete-module-acceptance.json'
    full_interop = read(full_interop_path)
    expected_interop = {index for index, row in enumerate(read(REPO / 'backend/bluets/tests/fixtures/ge5_source_maps/cases.json')['cases'])
                        if row['form'] == 'ge2_module_helpers/interop-exportstar-cycle'}
    assert len(expected_interop) == full_interop['configurations'] == 363
    assert full_interop['completeFamily'] is True and not full_interop['failures']
    assert full_interop['maps'] == len(full_interop['products']) == 1452
    assert len(full_interop['executions']) == 363 and full_interop['selectedEditionSyntaxPrograms'] == 2904
    assert {row['index'] for row in full_interop['products']} == expected_interop
    assert {row['index'] for row in full_interop['executions']} == expected_interop
    assert full_interop['compilerSha256'] == gates['nativeCompilerSha256']
    scoped_reports = {
        interop_directory / 'interop-complete-module-acceptance-partial.json': (3, 12),
        Path(expression['artifact_paths']['BLUEICE_GE5_ROLE_REPORT_DIRECTORY']) / 'interop-expression-maps.json': (1, 4),
    }
    complete_families, partial_reports = [], []
    for path in sorted(role_paths):
        report = read(path)
        if not isinstance(report, dict):
            continue
        assert not report.get('positiveOnly', False), path
        if 'completeFamily' in report:
            if report['completeFamily'] is True:
                complete_families.append(str(path.relative_to(ROOT)))
            else:
                # The frozen harnesses also retain bounded ordinary observations.
                # They are not complete-family evidence. Require their exact
                # known scope and the independently complete 363-row counterpart.
                assert report['completeFamily'] is False and path in scoped_reports, path
                assert (report['configurations'], report['maps']) == scoped_reports[path]
                assert report['failures'] == []
                if path.name.endswith('-partial.json'):
                    assert len(report['products']) == 12 and len(report['executions']) == 3
                    assert {row['index'] for row in report['products']} == {4892, 4933, 5013}
                    assert {row['index'] for row in report['executions']} == {4892, 4933, 5013}
                else:
                    assert report['scope'] == 'Complete original declaration syntax, expression interiors and logical endpoints; module closure pending'
                partial_reports.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                    'configurations': report['configurations'], 'maps': report['maps'],
                    'completeFamily': False, 'completeFamilyCredit': False,
                    'completeCounterpart': str(full_interop_path.relative_to(ROOT)),
                    'scope': report.get('scope', 'Three frozen ordinary module-boundary observations, outside complete-family credit.')})
        if 'compilerSha256' in report:
            assert report['compilerSha256'] == gates['nativeCompilerSha256'], path
    assert complete_families, 'complete role-family reports are required'
    assert {ROOT / row['path'] for row in partial_reports} == set(scoped_reports)
    assert (PHASE / 'COMPATIBILITY_MEASUREMENT.json').read_bytes() == (ROOT / 'accepted-native/measurement.json').read_bytes()
    workspace = summaries((ROOT / 'workspace.log').read_text())
    assert workspace and all(status == 'ok' and failed == filtered == 0 for status, passed, failed, ignored, filtered in workspace)
    assert sum(row[1] for row in workspace) == gates['workspace']['passed']
    assert sum(row[3] for row in workspace) == gates['workspace']['ignored']
    assert len(workspace) == gates['workspace']['groups']

    def case_map(value):
        return {(suite['harness'], row['id']): {key: row.get(key) for key in ['comparison', 'status', 'scope', 'reason']}
            for suite in value['suites'] for row in suite['cases']}
    before, after = case_map(read(ROOT / 'baseline-cases.json')), case_map(read(PHASE / 'COMPATIBILITY_CASES.json'))
    assert len(before) == 39927 and len(after) == 40213
    assert all(after.get(key) == value for key, value in before.items())
    assert len(set(after) - set(before)) == 286
    assert all(harness == 'backend/bluets/tests/noinfer.rs' for harness, _ in set(after) - set(before))
    assert gates['casePreservation'] == {'previous': 39927, 'current': 40213, 'added': 286, 'allOldCasesUnchanged': True}

    report_bindings, maps = {}, {}
    for kind in ['native', 'workspace']:
        compiler_sha = gates[kind + 'CompilerSha256']
        assert sha(ROOT / ('accepted-' + kind + '-cli')) == compiler_sha
        base = ROOT / (kind + '-capture/noinfer')
        report_bindings[kind] = {}
        for label, pattern in [('primary', 'blue-*/report.json'), ('supplement', 'regressions-*/report.json')]:
            found = list(base.glob(pattern))
            assert len(found) == 1
            path = found[0]
            report = read(path)
            assert report['conclusion'] == 'pass' and report['sourceRevision'] == source and report['compilerSha256'] == compiler_sha
            if label == 'primary':
                assert report['inputSha256'] == frozen['inputSha256']
                assert len(report['cases']) == 153 and report['declarationFiles'] == 159
                assert report['consumers'] == 306 and report['syntax'] == 159 and report['runtime'] == 6
                for row in report['cases']:
                    expected = next(row2 for row2 in reference['cases'] if row2['id'] == row['id'])
                    assert row['declarations'] == expected['declarations'] and row.get('consumers') == expected.get('consumers')
            else:
                assert report['inputSha256'] == sha(fixture / 'keyof-diagnostics.json')
                assert len(report['cases']) == 4 and all(row['agrees'] for row in report['cases'])
            report_bindings[kind][label] = {'path': str(path.relative_to(ROOT)), 'sha256': sha(path)}
        binding = read(ROOT / (kind + '-map-binding.json'))
        map_path = ROOT / (kind + '-declaration-map-report.json')
        map_report = read(map_path)
        assert binding['sourceRevision'] == source and binding['compilerSha256'] == compiler_sha
        assert binding['verified'] and binding['reportFreshSinceBinding']
        assert sha(Path(binding['compilerSnapshot'])) == compiler_sha
        assert sha(Path(binding['testExecutable'])) == binding['testExecutableSha256']
        assert binding['reportModifiedEpoch'] >= binding['reportNotBeforeEpoch']
        assert datetime.datetime.fromisoformat(binding['observedAt']).timestamp() <= binding['reportModifiedEpoch']
        assert binding['reportSha256'] == sha(map_path)
        assert map_report['configurations'] == 8407 and map_report['buildsPerConfiguration'] == 2 and not map_report['differences']
        maps[kind] = binding

    projects = {name: read(ROOT / ('project-' + name + '/report.json'))
        for name in ['defu', 'mitt', 'reproductions', 'interchange']}
    assert projects['defu']['compatible'] and projects['mitt']['compatible']
    assert projects['reproductions']['verdictAgreements'] == 8
    assert projects['interchange']['conclusion'] == 'current-policy-verified'
    assert all(report['sourceRevision'] == source and report['compilerSha256'] == gates['nativeCompilerSha256'] for report in projects.values())
    windows = read(ROOT / 'windows/windows-acceptance-verification.json')
    assert windows['conclusion'] == 'success' and windows['sourceRevision'] == source
    assert windows['paths'] == 25 and windows['coreOracles'] == 82 and len(windows['regressionCohorts']) == 7
    assert windows['allSelectedNamesPassedExactly'] and windows['allCanonicalBackendPathsVerified']
    assert windows['actualCompilerArchiveHashMatches'] and windows['archiveSha256'] == sha(ROOT / 'windows-evidence.tar.gz')
    assert all(sha(REPO / name) == digest for name, digest in read(ROOT / 'windows/windows-source-manifest.json')['files'].items() if name.startswith('backend/'))
    baseline = read(ROOT / 'baseline-replay.json')
    assert baseline['conclusion'] == 'completed-baseline' and baseline['comparisons'] == 282
    assert baseline['agreements'] == 6 and baseline['accepted'] == 12
    assert baseline['inputSha256'] == frozen['inputSha256'] and baseline['compilerSha256'] == sha(ROOT / 'baseline-accepted-cli')
    baseline_presence = read(ROOT / 'baseline-presence/presence-corrected.json')
    corrected_presence = read(ROOT / 'presence-corrected.json')
    for value in [baseline_presence, corrected_presence]:
        assert len(value['observations']) == 44 and all(row['nativeAccepts'] for row in value['observations'])
    assert baseline_presence['compilerSha256'] == baseline['compilerSha256'] and baseline_presence['sourceRevision'] == baseline['sourceRevision']
    assert corrected_presence['compilerSha256'] == gates['nativeCompilerSha256'] and corrected_presence['sourceRevision'] == source
    assert {profile: sum(not row['blueAccepts'] for row in corrected_presence['observations'] if row['profile'] == profile)
            for profile in ['es5', 'es2022']} == {'es5': 6, 'es2022': 5}
    retired = {}
    for label, size, expected in [
        ('f98c', 7253023, '0ee1cd99c5fa425eccef4a46bf6c59d5ac3047a2239dbaff8a9ae5c74a2db59e'),
        ('62b', 7450461, '8db7072c0badebb46a31bd74df435d25ced64e411e8d5cf37c087933727037d9')]:
        path = ROOT / ('retired-windows-' + label + '.tar.gz')
        assert path.stat().st_size == size and sha(path) == expected
        retired[label] = {'path': path.name, 'bytes': size, 'sha256': expected, 'passCredit': False}
    return {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceRevision': source, 'conclusion': 'success', 'nativeSuites': 185,
        'nativeFunctions': 1053, 'workspace': gates['workspace'], 'casePreservation': gates['casePreservation'],
        'noInferReports': report_bindings, 'mapBindings': maps, 'windows': windows,
        'completeNativeRoleFamilies': complete_families,
        'partialNativeRoleReports': partial_reports,
        'moduleFiles': 538, 'maximumModuleLines': module_audit['maximumLines'],
        'retiredWindowsEvidence': retired, 'fullTypeScriptParity': False, 'broaderOpenRows': 22}


if __name__ == '__main__':
    receipt = audit()
    (ROOT / 'acceptance-audit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ['sourceRevision', 'conclusion', 'nativeSuites', 'nativeFunctions', 'workspace']}))
