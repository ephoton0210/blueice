python3 - <<'PY'
from pathlib import Path
import ast,shutil
old=Path('/private/tmp/bluets-receiver-followup-20261111'); root=Path('/private/tmp/bluets-noinfer-20261111')
s=(old/'run_gates.py').read_text().replace(str(old),str(root))
s=s.replace("('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers')", "('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers'),('BLUEICE_NOINFER_OBSERVATIONS','noinfer')")
s=s.replace("env['BLUEICE_CALLABLE_SOURCE_REVISION']=env['BLUEICE_RECEIVER_SOURCE_REVISION']=revision", "env['BLUEICE_CALLABLE_SOURCE_REVISION']=env['BLUEICE_RECEIVER_SOURCE_REVISION']=env['BLUEICE_NOINFER_SOURCE_REVISION']=revision")
s=s.replace("==184", "==185").replace("==210", "==282").replace("'added':210", "'added':282").replace("h=='backend/bluets/tests/receiver_utilities.rs'", "h=='backend/bluets/tests/noinfer.rs'")
s=s.replace("for family in ['callable','receiver']:", "for family,script,variable in [('callable','verify_callable_utilities.cjs','BLUEICE_CALLABLE_UTILITIES_COMPILER'),('receiver','verify_receiver_utilities.cjs','BLUEICE_RECEIVER_UTILITIES_COMPILER'),('noinfer','verify_noinfer.cjs','BLUEICE_NOINFER_COMPILER')]:")
s=s.replace("env['BLUEICE_'+family.upper()+'_UTILITIES_COMPILER']", "env[variable]").replace("('verify_'+family+'_utilities.cjs')", "script")
ast.parse(s); (root/'run_gates.py').write_text(s)
s=(old/'measure_priority.cjs').read_text().replace(str(old),str(root)).replace("['diagnostics_matrix.rs','receiver_utilities.rs']", "['diagnostics_matrix.rs','noinfer.rs','receiver_utilities.rs']"); (root/'measure_priority.cjs').write_text(s)
shutil.copy2(old/'baseline-native-durations.json',root/'baseline-native-durations.json')
s=(old/'presence_corrected.cjs').read_text().replace(str(old),str(root)).replace(",'NoInfer',...(p.id", ",...(p.id"); (root/'presence_corrected.cjs').write_text(s)
s=(old/'watch_maps.py').read_text().replace(str(old),str(root));ast.parse(s);(root/'watch_maps.py').write_text(s)
s=(old/'launch_windows.py').read_text().replace(str(old),str(root))
s=s.replace("prior=Path('/private/tmp/bluets-next-project-20261110/windows-corrected')",f"prior=Path('{old}/windows')")
s=s.replace("'verify_receiver_utilities.cjs']", "'verify_receiver_utilities.cjs','record_noinfer.cjs','verify_noinfer.cjs']")
a=s.index(' runner='); b=s.index(" (root/'windows-runner.cjs').write_text",a)
s=s[:a]+''' runner=(prior/'windows-runner.cjs').read_text().replace('results-receivers-v17','results-noinfer-v18').replace(old['sourceRevision'],frozen['sourceRevision']).replace(old['followupPatchSha256'],patchhash)
 previous="'gc1_object_generic_methods','gm2_incremental_options','project_config','defu_prerequisites','callable_utilities','receiver_utilities'";assert runner.count(previous)==2;runner=runner.replace(previous,previous+",'noinfer'")
 point="state.stage='named-cases';save();";assert point in runner
 runner=runner.replace(point,"env.BLUEICE_NOINFER_SOURCE_REVISION=state.sourceRevision;env.BLUEICE_NOINFER_OBSERVATIONS=path.join(out,'noinfer-observations');"+point)
'''+s[b:]
a=s.index(' watch=');b=s.index('\n ast.parse(watch)',a)
s=s[:a]+''' watch=(prior/'watch_windows.py').read_text().replace(str(prior),str(root)).replace('results-receivers-v17','results-noinfer-v18').replace('receiver-evidence-v17','noinfer-evidence-v18').replace("len(r['followups'])==6","len(r['followups'])==7")'''+s[b:]
ast.parse(s);(root/'launch_windows.py').write_text(s)
print('Prepared local acceptance, complete catalog, map binding and Windows v18 drivers; none started.')
PY
node --check /private/tmp/bluets-noinfer-20261111/measure_priority.cjs
node --check /private/tmp/bluets-noinfer-20261111/presence_corrected.cjs