python3 - <<'PY'
from pathlib import Path
r=Path('/private/tmp/bluets-p0b-design-20261111')
s=Path('development/browser_core/phase-18-bluets/tools/record_noinfer.cjs').read_text()
s=s.replace("const repo = path.resolve(__dirname, '../../../..');","const repo = '/Users/ephoton/git/blueice-bluets';")
s=s.replace("const directory = path.join(repo, 'backend/bluets/tests/fixtures/noinfer');","const directory = __dirname;")
s=s.replace("'cases.json'","'cases.draft.json'")
s=s.replace("process.env.BLUEICE_BLUETSC_ORACLE, 'typescript'","'/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc', 'typescript'")
a=s.index('const capture = ');b=s.index('\nfunction diagnostic',a)
s=s[:a]+"const capture = path.join(__dirname, 'matrix-native-draft');"+s[b:]
s=s.replace("if (native.accepts !== entry.accepts) authoringErrors.push({id, kind: 'source', expected: entry.accepts, actual: native});","const intended = entry.acceptsByProfile ? entry.acceptsByProfile[profile.id] : entry.accepts;\n    if (native.accepts !== intended) authoringErrors.push({id, kind: 'source', expected: intended, actual: native});")
s=s.replace("  assert.deepEqual(authoringErrors, [], 'authored NoInfer sources and consumers must match their intended Native verdicts');\n  assert.equal(cases.length, 282);","  fs.writeFileSync(path.join(__dirname, 'matrix-authoring-errors.json'), JSON.stringify(authoringErrors, null, 2) + '\\n');\n  assert.equal(cases.length, 340);")
a=s.index("  const text = JSON.stringify(value");b=s.index('\n} finally',a)
s=s[:a]+"  fs.writeFileSync(path.join(__dirname, 'reference.draft.json'), JSON.stringify(value, null, 2) + '\\n');\n  console.log(JSON.stringify({observations:cases.length, accepts:cases.filter(x=>x.accepts).length, declarations:cases.reduce((n,x)=>n+Object.keys(x.declarations).length,0), authoringErrors:authoringErrors.map(x=>({id:x.id,kind:x.kind,expected:x.expected,actual:x.actual.accepts,diagnostics:x.actual.diagnostics}))},null,2));\n  if (authoringErrors.length) process.exitCode = 2;"+s[b:]
(r/'calibrate_matrix.cjs').write_text(s)
print('Prepared independent Native calibration; production source untouched.')
PY