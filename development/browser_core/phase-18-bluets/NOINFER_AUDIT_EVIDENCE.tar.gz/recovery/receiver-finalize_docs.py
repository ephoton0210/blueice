from pathlib import Path
import json
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';m=json.loads((phase/'RECEIVER_UTILITY_MEASUREMENT.json').read_text());g=m['gates'];assert m['conclusion']=='completed-within-frozen-scope' and g['conclusion']=='success'
source=m['source']['sourceRevision'];native=m['nativeMeasurement'];workspace=g['workspace'];windows=m['windows']
p=phase/'TODO.md';s=p.read_text();a=s.index('**Latest completed follow-up:**');b=s.index('## Maintenance and real-project follow-up',a)
s=s[:a]+'''**Latest completed follow-up:** G-T7/G-T2 supplies the frozen receiver utilities
`ThisParameterType` and `OmitThisParameter`, with full diagnostics, byte-exact
`.d.ts`, isolated consumers and execution. [Current acceptance](RECEIVER_UTILITY_ACCEPTANCE.md)
binds complete Native/local/Windows gates and current project regressions to
this source. Callable utilities and prior mitt/defu evaluations retain their
original dated evidence. All 22 broader rows remain open.

'''+s[b:]
a=s.index('### G-T7 / G-T2 — receiver utility follow-up');b=s.index('## Completed baseline (condensed)',a);section=s[a:b];assert section.count('- [ ]')==3;section=section.replace('- [ ]','- [x]')
section+=f'''Accepted on `{source}`: **{native['suites']} Native suites / {native['functions']:,}
tests**, **{workspace['passed']:,} local workspace passes**, both complete **8,407 ×
two** map reports, and Windows **82 core oracles + 25 paths + six complete
regression cohorts**. All previous 39,717 case identities/classifications remain;
210 new direct observations bring the inventory to 39,927. Six owner checks and
44 name-presence witnesses stay outside direct agreement.
[Measurements and remaining scope](RECEIVER_UTILITY_ACCEPTANCE.md).

''';s=s[:a]+section+s[b:];p.write_text(s)
p=phase/'RECEIVER_UTILITY_FOLLOWUP.md';s=p.read_text().replace('Status: frozen acceptance; implementation and complete gates pending.','''Status: completed within the frozen scope. The [acceptance](RECEIVER_UTILITY_ACCEPTANCE.md)
and [measurements](RECEIVER_UTILITY_MEASUREMENT.json) retain the current-source gates,
actual executable bindings, independent Native fixtures and original failures.''');p.write_text(s)
p=phase/'COMPATIBILITY_INVENTORY.md';lines=p.read_text().splitlines();additions={
 'G-T7':' The [receiver utility follow-up](RECEIVER_UTILITY_ACCEPTANCE.md) adds ThisParameterType and OmitThisParameter through original static declarations and general conditional/infer matching: 210 complete diagnostic observations, 105 byte-exact declaration inventories, 210 isolated consumers, 105 syntax checks and six executions per actual compiler. Six owner checks and the 44 name-presence witnesses are separate. NonNullable, four string intrinsics, NoInfer, ES5 Awaited and unmeasured compositions remain open.',
 'G-T2':' The [receiver follow-up](RECEIVER_UTILITY_ACCEPTANCE.md) additionally measures explicit/absent receivers, final signatures, bounded generic erasure and preservation of generic signatures with unknown/any receivers, labelled parameter-pack substitution and named constructor results. Mixed/recursive/higher-rank receiver compositions remain open.',
 'G-C1':' The [receiver follow-up](RECEIVER_UTILITY_ACCEPTANCE.md) additionally measures primary/related generic signature causes, callable-union reasons, function-expression locations and boolean/null presentation across its 210 frozen observations. Unmeasured CLI/recovery forms remain open.',
 'G-M3':f' The [receiver follow-up](RECEIVER_UTILITY_ACCEPTANCE.md) repeats all 25 Windows paths, 82 core oracles and six complete regression cohorts against {windows["verifiedSourceFiles"]:,} verified files, including all {windows["verifiedBackendFiles"]:,} canonical backend files.'}
for index,line in enumerate(lines):
 for id,addition in additions.items():
  if line.startswith('| '+id+' |'):
   split=line.rfind(' | [evidence]');assert split!=-1;line=line[:split]+addition+line[split:]
 if line.startswith('| G-E5 |'):line=line.replace('[current source-bound follow-up](CALLABLE_UTILITY_ACCEPTANCE.md)','[current source-bound follow-up](RECEIVER_UTILITY_ACCEPTANCE.md)')
 lines[index]=line
p.write_text('\n'.join(lines)+'\n')
p=phase/'PLAN.md';s=p.read_text()+'''
## Receiver utility follow-up — G-T7 / G-T2 (2026-11-11)

The [frozen package](RECEIVER_UTILITY_FOLLOWUP.md) supplies ThisParameterType and
OmitThisParameter with general conditional/infer receiver matching, retained
generic signatures and query identities, and instantiated labelled parameter
packs. All 210 complete Native diagnostic observations and 105 declaration
inventories agree; isolated consumers, syntax, execution and separate owner
controls pass. [Current acceptance](RECEIVER_UTILITY_ACCEPTANCE.md) binds fresh
complete Native/local/Windows gates, both full map reports, actual compilers,
current project regressions and original failures to the implementation source.
The separate presence inventory leaves six ES2022 utility names and seven ES5
names open; it is not a semantic-completeness claim or a case denominator.
All 22 broader rows remain open and full TypeScript parity stays OFF.
''';p.write_text(s)
p=phase/'STANDARD_LIBRARY.md';s=p.read_text();mark='Broader generic inference, structural protocols, overloads, index signatures';addition='''The [receiver utility follow-up](RECEIVER_UTILITY_ACCEPTANCE.md) adds original
ThisParameterType and OmitThisParameter declarations in the same content-hashed
core layer. Conditional signature inference distinguishes `this` from positional
parameters, retains generic signatures for unknown/any receivers, and preserves
named constructor queries. Its 70-form/three-profile matrix requires 210 complete
diagnostics and 105 byte-exact declarations with isolated consumers, syntax and
execution. Six owner controls are separate; no runtime binding is installed.
NonNullable, Uppercase, Lowercase, Capitalize, Uncapitalize, NoInfer, ES5 Awaited
and unmeasured receiver compositions remain open.

''';assert mark in s;s=s.replace(mark,addition+mark);p.write_text(s)
print('Updated completed receiver package and explicit remaining utility gaps; broader22 rows remain open.')
