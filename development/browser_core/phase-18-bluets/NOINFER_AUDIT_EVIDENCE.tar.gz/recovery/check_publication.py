from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-noinfer-20261111');phase=repo/'development/browser_core/phase-18-bluets'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=read(phase/'NOINFER_MEASUREMENT.json');assert m['conclusion']=='completed-within-frozen-scope'
source=m['source']['sourceRevision'];assert source==read(root/'frozen-source-preflight.json')['sourceRevision']
g=m['gates'];assert g['conclusion']=='success' and all(x['exit']==0 for x in g['steps'])
assert {'workspace-noinfer-oracles','workspace-noinfer-regressions'} <= {x['label'] for x in g['steps']}
native=read(phase/'COMPATIBILITY_MEASUREMENT.json');assert native['conclusion']=='success' and native['source_revision']==source and len(native['suites'])==185
assert all(x['conclusion']=='success' and x['failed']==x['ignored']==x['filtered']==0 for x in native['suites'])
index=subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip();backend=subprocess.check_output(['git','rev-parse',index+':backend'],cwd=repo,text=True).strip();assert source=='backend-tree:'+backend
old=json.loads(subprocess.check_output(['git','show','HEAD:development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json'],cwd=repo));new=read(phase/'COMPATIBILITY_CASES.json')
def cases(d):return {(s['harness'],c['id']):{k:c.get(k) for k in ['comparison','status','scope','reason']} for s in d['suites'] for c in s['cases']}
a=cases(old);b=cases(new);assert len(a)==39927 and len(b)==40213 and all(b.get(k)==v for k,v in a.items())
added=set(b)-set(a);assert len(added)==286 and {x[0] for x in added}=={'backend/bluets/tests/noinfer.rs'}
manifest=read(phase/'NOINFER_ARTIFACTS.json');assert manifest['sourceRevision']==source and len(manifest['artifacts'])==3
for artifact in manifest['artifacts']:
 p=phase/artifact['path'];assert p.stat().st_size==artifact['bytes'] and sha(p)==artifact['sha256'] and p.stat().st_size<95*1024*1024
 with tarfile.open(p,'r:gz') as archive:
  members=archive.getmembers();assert members
  for member in members:
   assert not member.name.startswith('/') and '..' not in Path(member.name).parts
   if member.issym() or member.islnk():assert not Path(member.linkname).is_absolute() and '..' not in Path(member.linkname).parts
  names={x.name for x in members}
  if p.name=='NOINFER_EVIDENCE.tar.gz':assert {'retired-f98c/retirement.json','retired-f98c/accepted-native-cli','retired-f98c/windows/retired-windows-evidence.tar.gz','retired-62b/retirement.json','retired-62b/accepted-native-cli','retired-62b/windows/retired-windows-evidence.tar.gz'}<=names
fixture=repo/'backend/bluets/tests/fixtures/noinfer'
for name,key in [('cases.json','nativeInputSha256'),('reference.json','nativeReferenceSha256')]:assert sha(fixture/name)==m['source'][key]
for name,report in m['noInferReports'].items():
 r=report['report'];assert r['conclusion']=='pass' and r['sourceRevision']==source
 assert len(r['cases'])==153 and r['declarationFiles']==159 and r['consumers']==306 and r['syntax']==159 and r['runtime']==6
 expected=m['windows']['compiler']['sha256'] if name=='windows' else g[name+'CompilerSha256'];assert r['compilerSha256']==expected
for name,row in m['diagnosticRegressionReports'].items():
 report=row['report'];assert report['inputSha256']==sha(fixture/'keyof-diagnostics.json');assert report['conclusion']=='pass' and report['sourceRevision']==source and len(report['cases'])==4 and all(x['agrees'] for x in report['cases'])
assert m['directObservations']==286 and m['primaryObservations']==282 and m['diagnosticRegressionObservations']==4
assert m['windows']['core82Passed'] and len(m['windows']['cases'])==25 and all(x['passed'] for x in m['windows']['cases'])
assert len(m['windows']['followups'])==7 and all(x['passed'] for x in m['windows']['followups'])
assert m['ownerChecks']==3 and m['budgetControls']==9 and m['ownerAndBudgetControlsExcludedFromDirectDenominator']
for binding in m['mapBindings'].values():assert binding['verified'] and binding['sourceRevision']==source and binding['reportFreshSinceBinding']
for p in [phase/'NOINFER_ACCEPTANCE.md',phase/'NOINFER_FOLLOWUP.md',fixture/'README.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if ':' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).exists(),(p,target)
todo=(phase/'TODO.md').read_text();assert '- [x] **P0-A — NoInfer' in todo and '- [ ] **P0-B' in todo and '- [ ] **P0-C' in todo
oldtodo=subprocess.check_output(['git','show','HEAD:development/browser_core/phase-18-bluets/TODO.md'],cwd=repo,text=True)
assert todo.count('- [x]')==oldtodo.count('- [x]')+1 and todo.count('- [ ]')==oldtodo.count('- [ ]')-1
assert m['broaderFeatureRowsOpen']==22 and m['fullTypeScriptParity'] is False
assert m['retiredSourceFailure']['nativePartialPassesNotCreditedToNextSource'] and m['retiredSourceFailure']['windowsAbortedNotCreditedToNextSource']
receipt={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':source,'indexTree':index,'oldCaseCount':len(a),'currentCaseCount':len(b),'addedCases':len(added),'allOldCaseIdentitiesAndClassificationsPreserved':True,'frozenNativeBytesUnchanged':True,'artifactsVerified':manifest['artifacts'],'onlyP0AChecked':True,'P0BandP0CRemainOpen':True,'noRetiredPassCredit':True,'broaderFeatureRowsRemainOpen':22,'conclusion':'success'}
(root/'publication-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
