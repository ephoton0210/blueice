# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
$ErrorActionPreference = 'Stop'
$taskRoot = 'B:\BlueIce\gm3-20261109-360d7d921'
Get-ChildItem -LiteralPath $taskRoot -Filter '*noinfer*' |
    Select-Object Name, Length, LastWriteTimeUtc |
    ConvertTo-Json -Depth 5
