from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,tarfile

repo=Path('/Users/ephoton/git/blueice-bluets')
root=Path('/private/tmp/bluets-noinfer-20261111')
phase=repo/'development/browser_core/phase-18-bluets'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
gates=read(root/'acceptance-gates.json');frozen=read(root/'frozen-source-preflight.json');source=frozen['sourceRevision']
assert gates['conclusion']=='success' and gates['sourceRevision']==source and all(x['exit']==0 for x in gates['steps'])
assert {'workspace-callable-oracles','workspace-receiver-oracles','workspace-noinfer-oracles','workspace-noinfer-regressions','workspace','clippy','source-final','cases-final','account-final','status-final'} <= {x['label'] for x in gates['steps']}
for step in gates['steps']:assert sha(root/step['log'])==step['sha256']
native=read(root/'accepted-native/measurement.json')
assert native['conclusion']=='success' and native['source_revision']==source and native['suite_jobs']==4
assert len(native['suites'])==len(set(native['execution_order']))==185
assert set(native['execution_order'])=={x['harness'] for x in native['suites']}
assert native['oracle_tools_sha256']==read(root/'frozen-final-oracle-tools.json')['sha256']
assert native['runner_script_sha256']==sha(root/'measure_priority.cjs')
assert all(x['conclusion']=='success' and x['failed']==x['ignored']==x['filtered']==0 for x in native['suites'])
for x in native['suites']:assert sha(root/'accepted-native'/x['log'])==x['log_sha256']
for name,digest in read(root/'frozen-driver-hashes.json')['sha256'].items():assert sha(root/name)==digest
assert gates['casePreservation']=={'previous':39927,'current':40213,'added':286,'allOldCasesUnchanged':True}
assert (phase/'COMPATIBILITY_MEASUREMENT.json').read_bytes()==(root/'accepted-native/measurement.json').read_bytes()
fixture=repo/'backend/bluets/tests/fixtures/noinfer';refs=read(fixture/'reference.json')
assert sha(fixture/'keyof-diagnostics.json')==frozen['supplementalNativeReferenceSha256']
assert sha(fixture/'cases.json')==frozen['nativeInputSha256']=='f93542b0ad33c9ca5fbc3122e732548427bff77108eec7cc3f74046e0f8734e6'
assert sha(fixture/'reference.json')==frozen['nativeReferenceSha256']=='5af732d9e989b8dbaa687615ac4837e51f7994220b3bd43637ca260a20d18c65'
assert len(refs['cases'])==282 and sum(x['accepts'] for x in refs['cases'])==153
assert sum(len(x['declarations']) for x in refs['cases'])==159
reports={}
for kind in ['native','workspace']:
 assert sha(root/f'accepted-{kind}-cli')==gates[kind+'CompilerSha256']
 found=[(p,read(p)) for p in (root/f'{kind}-capture/noinfer').glob('blue-*/report.json')];assert len(found)==1
 path,report=found[0]
 assert report['sourceRevision']==source and report['compilerSha256']==gates[kind+'CompilerSha256'] and report['conclusion']=='pass'
 assert len(report['cases'])==153 and report['declarationFiles']==159 and report['consumers']==306 and report['syntax']==159 and report['runtime']==6
 reports[kind]={'path':str(path.relative_to(root)),'sha256':sha(path),'report':report}
regressions={}
for kind in ['native','workspace']:
 found=[(p,read(p)) for p in (root/f'{kind}-capture/noinfer').glob('regressions-*/report.json')];assert len(found)==1
 path,report=found[0];assert report['conclusion']=='pass' and report['sourceRevision']==source and report['compilerSha256']==gates[kind+'CompilerSha256']
 assert report['inputSha256']==sha(fixture/'keyof-diagnostics.json') and len(report['cases'])==4 and all(x['agrees'] for x in report['cases'])
 regressions[kind]={'path':str(path.relative_to(root)),'sha256':sha(path),'report':report}
maps={kind:read(root/f'{kind}-map-binding.json') for kind in ['native','workspace']}
for kind,binding in maps.items():
 assert binding['verified'] and binding['reportFreshSinceBinding'] and binding['sourceRevision']==source and binding['compilerSha256']==gates[kind+'CompilerSha256']
 report=read(root/f'{kind}-declaration-map-report.json');assert report['configurations']==8407 and report['buildsPerConfiguration']==2 and not report['differences']
 assert binding['reportSha256']==sha(root/f'{kind}-declaration-map-report.json')
projects={name:read(root/f'project-{name}/report.json') for name in ['defu','mitt','reproductions','interchange']}
assert projects['defu']['compatible'] and projects['mitt']['compatible'] and projects['reproductions']['verdictAgreements']==8 and projects['interchange']['conclusion']=='current-policy-verified'
for report in projects.values():assert report['sourceRevision']==source and report['compilerSha256']==gates['nativeCompilerSha256']
windows=root/'windows';win=read(windows/'windows-measurement.json')
assert win['conclusion']=='success' and win['sourceRevision']==source and win['core82Passed'] and win['core82Exit']==0
assert len(win['cases'])==25 and all(x['passed'] for x in win['cases'])
assert len(win['followups'])==7 and {x['target'] for x in win['followups']}=={'gc1_object_generic_methods','gm2_incremental_options','project_config','defu_prerequisites','callable_utilities','receiver_utilities','noinfer'} and all(x['passed'] for x in win['followups'])
assert read(windows/'windows-watch.json')['conclusion']=='success'
manifest=read(windows/'windows-source-manifest.json')
assert win['verifiedSourceFiles']==len(manifest['files']) and win['verifiedBackendFiles']==manifest['backendFiles'] and win['backendPathSetSha256']==manifest['backendPathSetSha256']
assert win['expectedSourceManifestSha256']==sha(windows/'windows-source-manifest.json')
selection=win['core82Selection'];assert len(selection['selected'])==len(selection['passed'])==82 and sorted(selection['selected'])==sorted(selection['passed']) and selection['ordinarySupportFiltered']==6
with tarfile.open(windows/'windows-evidence.tar.gz','r:gz') as archive:
 found=[x for x in archive.getmembers() if '/noinfer-observations/blue-' in x.name and x.name.endswith('/report.json')];assert len(found)==1
 member=found[0];raw=archive.extractfile(member).read();report=json.loads(raw)
 assert report['sourceRevision']==source and report['compilerSha256']==win['compiler']['sha256'] and report['conclusion']=='pass'
 assert len(report['cases'])==153 and report['declarationFiles']==159 and report['consumers']==306 and report['syntax']==159 and report['runtime']==6
 reports['windows']={'path':member.name,'archive':'NOINFER_WINDOWS_EVIDENCE.tar.gz','sha256':hashlib.sha256(raw).hexdigest(),'report':report}
with tarfile.open(windows/'windows-evidence.tar.gz','r:gz') as archive:
 found=[x for x in archive.getmembers() if '/noinfer-observations/regressions-' in x.name and x.name.endswith('/report.json')];assert len(found)==1
 member=found[0];raw=archive.extractfile(member).read();report=json.loads(raw)
 assert report['inputSha256']==sha(fixture/'keyof-diagnostics.json') and report['conclusion']=='pass' and report['sourceRevision']==source and report['compilerSha256']==win['compiler']['sha256'] and len(report['cases'])==4 and all(x['agrees'] for x in report['cases'])
 regressions['windows']={'path':member.name,'archive':'NOINFER_WINDOWS_EVIDENCE.tar.gz','sha256':hashlib.sha256(raw).hexdigest(),'report':report}
baseline=read(root/'baseline-replay.json')
assert baseline['conclusion']=='completed-baseline' and baseline['comparisons']==282 and baseline['agreements']==6 and baseline['accepted']==12 and baseline['inputSha256']==refs['inputSha256']
assert sha(root/'baseline-accepted-cli')==baseline['compilerSha256']
presence={kind:read(root/f'presence-{kind}.json') for kind in ['baseline','corrected']}
for report in presence.values():assert len(report['observations'])==44 and all(x['nativeAccepts'] for x in report['observations'])
assert presence['baseline']['sourceRevision']==baseline['sourceRevision'] and presence['baseline']['compilerSha256']==baseline['compilerSha256']
assert presence['corrected']['sourceRevision']==source and presence['corrected']['compilerSha256']==gates['nativeCompilerSha256']
assert {p:sum(not x['blueAccepts'] for x in presence['corrected']['observations'] if x['profile']==p) for p in ['es5','es2022']}=={'es5':6,'es2022':5}
assert frozen['maximumProductionLines']<1500
support=root/'accepted-tools';support.mkdir(exist_ok=True)
for p in (phase/'tools').glob('*noinfer*.cjs'):shutil.copy2(p,support/p.name)
(root/'accepted-backend.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD','--','backend'],cwd=repo))
def archive(name,paths):
 paths=sorted(set(paths),key=lambda p:(len(p.parts),str(p)))
 selected=[]
 for p in paths:
  assert p.exists(),p
  if not any(parent in p.parents for parent in selected if parent.is_dir()):selected.append(p)
 dest=phase/name
 with tarfile.open(dest,'w:gz') as tar:
  for p in selected:tar.add(p,arcname=str(p.relative_to(root)),recursive=True)
 assert dest.stat().st_size<95*1024*1024
 return {'path':name,'bytes':dest.stat().st_size,'sha256':sha(dest)}
compilers=archive('NOINFER_COMPILERS.tar.gz',[root/x for x in ['accepted-native-cli','accepted-workspace-cli','baseline-accepted-cli','native-build.log','workspace-build.log','frozen-source-preflight.json']])
paths=[root/x for x in ['accepted-native','native-capture','workspace-capture','acceptance-gates.json','frozen-native.json','frozen-source-preflight.json','frozen-final-oracle-tools.json','frozen-driver-hashes.json','baseline-native-durations.json','baseline-replay','baseline-replay.json','baseline-replay.cjs','accepted-tools','accepted-backend.patch','native-declaration-map-report.json','workspace-declaration-map-report.json','native-map-binding.json','workspace-map-binding.json','native-reference-final','native-recheck-5','focused-native-4','native-design-probes.json','normalization-replay-1','diagnostic-replay-2','diagnostic-replay-4','presence-corrected']]
paths+=[p for p in root.iterdir() if p.suffix in ['.json','.log','.cjs','.py','.rs'] and p.is_file()]
paths+=[root/f'project-{x}' for x in projects]
paths+=[root/'retired-f98c',root/'retired-62b']
paths+=[p for p in windows.iterdir() if p.suffix in ['.json','.py','.cjs','.ps1']]
evidence=archive('NOINFER_EVIDENCE.tar.gz',paths)
meta=read(windows/'windows-archive-receipt.json');p=windows/'windows-evidence.tar.gz'
assert sha(p)==meta['sha256'] and p.stat().st_size==meta['bytes']
dest=phase/'NOINFER_WINDOWS_EVIDENCE.tar.gz';shutil.copy2(p,dest);assert dest.stat().st_size<95*1024*1024
artifacts=[compilers,evidence,{'path':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest)}]
write(phase/'NOINFER_ARTIFACTS.json',{'schema':1,'sourceRevision':source,'artifacts':artifacts})
summary={'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'conclusion':'completed-within-frozen-scope','source':frozen,'gates':gates,'nativeMeasurement':{'path':'COMPATIBILITY_MEASUREMENT.json','sha256':sha(root/'accepted-native/measurement.json'),'suites':185,'functions':sum(x['passed'] for x in native['suites'])},'baseline':{'sourceRevision':baseline['sourceRevision'],'compilerSha256':baseline['compilerSha256'],'comparisons':282,'completeAgreements':6,'accepted':12,'compilerArchive':compilers['path']},'inputSha256':sha(fixture/'cases.json'),'referenceSha256':sha(fixture/'reference.json'),'directObservations':286,'primaryObservations':282,'diagnosticRegressionObservations':4,'acceptedDeclarations':153,'declarationFiles':159,'ownerChecks':3,'budgetControls':9,'ownerAndBudgetControlsExcludedFromDirectDenominator':True,'noInferReports':reports,'mapBindings':maps,'projects':projects,'windows':win,'casePreservation':gates['casePreservation'],'presenceInventory':presence,'presenceInventoryExcludedFromDirectDenominator':True,'broaderFeatureRowsOpen':22,'fullTypeScriptParity':False,'artifacts':artifacts}
retired=read(root/'retired-f98c/retirement.json')
assert retired['nativePartialPassesNotCreditedToNextSource'] and retired['windowsAbortedNotCreditedToNextSource'] and not retired['windowsEvidencePendingDownload']
summary['retiredSourceFailure']=retired
retired2=read(root/'retired-62b/retirement.json')
assert retired2['nativePartialPassesNotCreditedToNextSource'] and retired2['windowsAbortedNotCreditedToNextSource'] and not retired2['windowsEvidencePendingDownload']
summary['retiredDiagnosticFailure']=retired2
summary['diagnosticRegressionReports']=regressions
write(phase/'NOINFER_MEASUREMENT.json',summary)
print('Published fixed-scope NoInfer evidence only after every complete same-source gate passed.')
