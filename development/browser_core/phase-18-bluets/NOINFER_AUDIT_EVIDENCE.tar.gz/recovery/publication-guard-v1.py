# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile
from audit_acceptance import ROOT, REPO, PHASE, read, sha, command


def main():
    measurement = read(PHASE / 'NOINFER_MEASUREMENT.json')
    assert measurement['conclusion'] == 'completed-within-frozen-scope'
    assert measurement['fullTypeScriptParity'] is False and measurement['broaderFeatureRowsOpen'] == 22
    source = measurement['source']['sourceRevision']
    assert source == read(ROOT / 'acceptance-audit.json')['sourceRevision']
    tree = command('git', 'write-tree')
    assert command('git', 'rev-parse', tree + ':backend') == source.split(':', 1)[1]
    assert not command('git', 'diff', '--numstat', '--', 'backend')
    artifacts = read(PHASE / 'NOINFER_ARTIFACTS.json')
    assert artifacts['sourceRevision'] == source and artifacts['artifacts'] == measurement['artifacts']
    assert len({row['path'] for row in artifacts['artifacts']}) == len(artifacts['artifacts']) == 5
    for row in artifacts['artifacts']:
        path = PHASE / row['path']
        assert path.stat().st_size == row['bytes'] < 95 * 1024 * 1024 and sha(path) == row['sha256']
        with tarfile.open(path) as archive:
            members = archive.getmembers()
            assert len({member.name for member in members}) == len(members)
            assert all(member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts for member in members)
    with tarfile.open(PHASE / 'NOINFER_COMPILERS.tar.gz') as archive:
        for kind in ['native', 'workspace']:
            data = archive.extractfile('accepted-' + kind + '-cli').read()
            assert hashlib.sha256(data).hexdigest() == measurement['gates'][kind + 'CompilerSha256']
        data = archive.extractfile('baseline-accepted-cli').read()
        assert hashlib.sha256(data).hexdigest() == measurement['baseline']['compilerSha256']
    for kind in ['native', 'workspace']:
        with tarfile.open(PHASE / ('NOINFER_' + kind.upper() + '_EVIDENCE.tar.gz')) as archive:
            for reference in measurement['noInferReports'][kind].values():
                data = archive.extractfile(reference['path']).read()
                assert hashlib.sha256(data).hexdigest() == reference['sha256']
            data = archive.extractfile(kind + '-declaration-map-report.json').read()
            assert hashlib.sha256(data).hexdigest() == measurement['mapBindings'][kind]['reportSha256']
            if kind == 'native':
                raw = archive.extractfile('accepted-native/measurement.json').read()
                assert hashlib.sha256(raw).hexdigest() == measurement['nativeMeasurement']['sha256']
                assert raw == (PHASE / 'COMPATIBILITY_MEASUREMENT.json').read_bytes()
                for suite in json.loads(raw)['suites']:
                    data = archive.extractfile('accepted-native/' + suite['log']).read()
                    assert hashlib.sha256(data).hexdigest() == suite['log_sha256']
    old = command('git', 'show', 'HEAD:development/browser_core/phase-18-bluets/TODO.md')
    todo = (PHASE / 'TODO.md').read_text()
    before, after = re.findall(r'^\s*- \[([ x])\]', old, re.MULTILINE), re.findall(r'^\s*- \[([ x])\]', todo, re.MULTILINE)
    assert len(before) == len(after)
    changed = [(a, b) for a, b in zip(before, after) if a != b]
    assert changed == [(' ', 'x')]
    assert '- [x] **P0-A —' in todo and '- [ ] **P0-B —' in todo and '- [ ] **P0-C —' in todo
    rows = re.findall(r'^\| (G-[A-Z]\d+) \| ([^|]+) \|', (PHASE / 'COMPATIBILITY_INVENTORY.md').read_text(), re.MULTILINE)
    assert len(rows) == len({identifier for identifier, _ in rows}) == 23
    assert sum(status.strip() == 'open' for _, status in rows) == 22
    assert all(status.strip() == 'open' for identifier, status in rows if identifier != 'G-C2')
    for name in ['NOINFER_ACCEPTANCE.md', 'NOINFER_FOLLOWUP.md', 'TODO.md', 'STANDARD_LIBRARY.md']:
        path = PHASE / name
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', path.read_text()):
            if target.startswith(('https://', 'http://', '#')):
                continue
            filename = target.split('#', 1)[0].strip('<>')
            assert (path.parent / filename).exists(), (name, target)
    subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
    result = {'conclusion': 'success', 'sourceRevision': source, 'artifacts': len(artifacts['artifacts']),
        'exactlyOneTodoPackageChecked': True, 'broaderRowsOpen': 22, 'fullTypeScriptParity': False}
    (ROOT / 'publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
