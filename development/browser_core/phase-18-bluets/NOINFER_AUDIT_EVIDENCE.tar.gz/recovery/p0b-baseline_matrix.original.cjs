'use strict';
const fs = require('node:fs'), path = require('node:path');
const cp = require('node:child_process'), crypto = require('node:crypto');
const assert = require('node:assert/strict'), {isDeepStrictEqual: equal} = require('node:util');
const fixture = path.join(__dirname, 'frozen-matrix');
const read = p => JSON.parse(fs.readFileSync(p));
const sha = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const frozen = read(path.join(fixture, 'freeze-receipt.json'));
const input = read(path.join(fixture, 'cases.json'));
const reference = read(path.join(fixture, 'reference.json'));
const compiler = '/private/tmp/bluets-noinfer-20261111/accepted-native-cli';
const output = path.join(__dirname, 'frozen-baseline');
assert(!fs.existsSync(output)); fs.mkdirSync(output);
const guard = () => {
  assert.equal(sha(path.join(fixture, 'cases.json')), frozen.inputSha256);
  assert.equal(sha(path.join(fixture, 'reference.json')), frozen.referenceSha256);
  assert.equal(sha(compiler), frozen.baselineCompilerSha256);
};
function diagnostic(value) {
  value = Object.hasOwn(value, 'typescript') ? value.typescript : value;
  if (!value) return {missingNativeCounterpart: true};
  return {code: value.code, message: value.message, file: value.span?.module ?? null,
    position: value.position ?? null, relatedInformation: (value.relatedInformation || []).map(diagnostic)};
}
function artifacts(directory) {
  if (!fs.existsSync(directory)) return {};
  const result = {};
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, {withFileTypes: true})) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(file);
      else result[path.relative(directory, file).replaceAll('\\', '/')] = fs.readFileSync(file, 'utf8');
    }
  }
  walk(directory); return result;
}
guard();
const report = {schema: 1, sourceRevision: frozen.baselineSourceRevision,
  compilerSha256: frozen.baselineCompilerSha256, inputSha256: frozen.inputSha256,
  referenceSha256: frozen.referenceSha256, observations: [], conclusion: 'in_progress',
  scope: 'Before P0-B production changes: primary build verdicts, full diagnostics, byte-exact declaration inventories and rejected-project atomicity. Downstream consumers/syntax/execution are separately frozen for complete final acceptance.'};
const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
save();
try {
  for (const expected of reference.cases) {
    const entry = input.cases.find(x => x.id === expected.form);
    const profile = input.profiles.find(x => x.id === expected.profile);
    const cwd = path.join(output, expected.id); fs.mkdirSync(cwd, {recursive: true});
    const sources = {'main.ts': entry.source, ...(entry.files || {})};
    for (const [name, text] of Object.entries(sources)) {
      assert(!path.isAbsolute(name) && !name.split(/[\\/]/).includes('..'));
      fs.mkdirSync(path.dirname(path.join(cwd, name)), {recursive: true});
      fs.writeFileSync(path.join(cwd, name), text);
    }
    fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify({compilerOptions: {...input.options, ...profile.compilerOptions, outDir: 'dist'}, files: Object.keys(sources)}, null, 2) + '\n');
    const built = cp.spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'], {cwd, encoding: 'utf8', timeout: 120000});
    if (built.error) throw built.error;
    fs.writeFileSync(path.join(cwd, 'build.stdout'), built.stdout);
    fs.writeFileSync(path.join(cwd, 'build.stderr'), built.stderr);
    const diagnostics = built.stderr.trim() ? built.stderr.trim().split(/\r?\n/).map(line => {
      try {return diagnostic(JSON.parse(line));}
      catch {return {missingNativeCounterpart: true, rawCliDiagnostic: line};}
    }) : [];
    const emitted = artifacts(path.join(cwd, 'dist'));
    const declarations = Object.fromEntries(Object.entries(emitted).filter(([name]) => name.endsWith('.d.ts')));
    const observed = {accepts: built.status === 0, diagnostics, declarations};
    const agreement = observed.accepts === expected.accepts && equal(diagnostics, expected.diagnostics) && equal(declarations, expected.declarations) && (expected.accepts || !Object.keys(emitted).length);
    report.observations.push({id: expected.id, exit: built.status, ...observed, agreement, artifactSha256: Object.fromEntries(Object.keys(emitted).map(name => [name, sha(path.join(cwd, 'dist', name))]))});
    save();
  }
  guard(); assert.equal(report.observations.length, 364);
  report.conclusion = 'completed-baseline';
  report.agreements = report.observations.filter(x => x.agreement).length;
  report.accepted = report.observations.filter(x => x.accepts).length;
  report.byProfile = Object.fromEntries(input.profiles.map(p => [p.id, {observations: report.observations.filter(x => x.id.startsWith(p.id + '/')).length, agreements: report.observations.filter(x => x.id.startsWith(p.id + '/') && x.agreement).length}]));
  save(); console.log(JSON.stringify({conclusion: report.conclusion, observations: report.observations.length, agreements: report.agreements, accepted: report.accepted, byProfile: report.byProfile}, null, 2));
} catch (error) {report.conclusion = 'error'; report.error = error.stack; save(); throw error;}
