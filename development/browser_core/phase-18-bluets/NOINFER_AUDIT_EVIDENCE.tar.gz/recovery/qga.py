from pathlib import Path
import base64,json,shlex,subprocess,sys,time
host='pb60g.bravotekcorp.cc';vm='omnisolve-winui-automation'
def call(request):
 command=shlex.join(['virsh','qemu-agent-command',vm,'--timeout','20',json.dumps(request)])
 result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,command],capture_output=True,text=True,check=True)
 value=json.loads(result.stdout)
 if 'error' in value:raise RuntimeError(value['error'])
 return value['return']
if sys.argv[1]=='start':
 code=Path(sys.argv[2]).read_text();encoded=base64.b64encode(code.encode('utf-16le')).decode()
 value=call({'execute':'guest-exec','arguments':{'path':'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','arg':['-NoLogo','-NonInteractive','-EncodedCommand',encoded],'capture-output':True}});print(json.dumps(value))
elif sys.argv[1]=='poll':
 value=call({'execute':'guest-exec-status','arguments':{'pid':int(sys.argv[2])}})
 for key in ['out-data','err-data']:
  if key in value:value[key]=base64.b64decode(value[key]).decode('utf-8-sig',errors='replace')
 print(json.dumps(value,ensure_ascii=False))
