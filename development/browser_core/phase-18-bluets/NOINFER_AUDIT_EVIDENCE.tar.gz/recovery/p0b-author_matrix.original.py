from pathlib import Path
import json

root = Path('/private/tmp/bluets-p0b-design-20261111')
cases = []

def add(name, source, accepts=True, positive=None, negative=None, **extra):
    value = {'id': name, 'source': source if source.endswith('\n') else source + '\n', 'accepts': accepts, **extra}
    if positive is not None:
        value['consumer'] = {'positive': 'import { value } from "./main";\n' + positive + '\n',
                             'negative': 'import { value } from "./main";\n' + negative + '\n'}
    cases.append(value)

def observe(name, operand, expected, negative, prelude='', utility='NonNullable'):
    add(name, prelude + f'declare const input: {utility}<{operand}>;\nexport const value = input;',
        positive=f'const observed: {expected} = value;', negative=f'const observed: {negative} = value;')

observe('nonnull-primitive-union', 'string | number | null | undefined', 'string | number', 'boolean')
observe('nonnull-literal-union', '"red" | "blue" | null | undefined', '"red" | "blue"', '"green"')
observe('nonnull-object-union', '{code: number} | null | undefined', '{code: number}', 'string')
observe('nonnull-unknown', 'unknown', '{}', 'number')
observe('nonnull-any', 'any', 'any', 'never')
observe('nonnull-never', 'never', 'never', 'never')
# Never is assignable to every target; a rejecting consumer must assign into it.
cases[-1]['consumer']['negative'] = 'import { value } from "./main";\nconst observed: typeof value = 1;\n'
for operand, slug in [('null', 'null'), ('undefined', 'undefined'), ('null | undefined', 'nullish')]:
    observe('nonnull-' + slug, operand, 'never', 'never')
    cases[-1]['consumer']['negative'] = 'import { value } from "./main";\nconst observed: typeof value = 1;\n'
observe('nonnull-intersection', '({x: number} & {y: string}) | null', '{x: number; y: string}', 'number')
observe('nonnull-array', 'number[] | undefined', 'number[]', 'string[]')
observe('nonnull-tuple', '[number, string] | null', '[number, string]', '[string, number]')
observe('nonnull-function', '((x: number) => string) | undefined', '(x: number) => string', '(x: number) => number')
for label, operand, expression, accepted in [
    ('unknown-number', 'unknown', '7', True), ('unknown-null', 'unknown', 'null', 'strict-only-reject'),
    ('any-null', 'any', 'null', True), ('never-number', 'never', '7', False),
    ('string-number', 'string | null', '7', False), ('string-null', 'string | null', 'null', 'strict-only-reject'),
    ('object-undefined', '{x: number} | undefined', 'undefined', 'strict-only-reject'),
]:
    add('nonnull-assignment-' + label, f'export const value: NonNullable<{operand}> = {expression};', accepted)
add('nonnull-generic-return', 'export declare function requireValue<T>(value: T): NonNullable<T>;\nexport const value = requireValue("ok");', positive='const observed: "ok" = value;', negative='const observed: "bad" = value;')
add('nonnull-generic-guard', 'export function requireValue<T>(input: T): NonNullable<T> {\n if (input == null) throw 0;\n return input;\n}\nexport const value = requireValue("ok");', positive='const observed: "ok" = value;', negative='const observed: number = value;')
add('nonnull-generic-null-reject', 'function requireValue<T>(input: T): NonNullable<T> { return null; }\nexport const value = requireValue(1);', 'strict-only-reject')
add('nonnull-explicit-argument-reject', 'declare function requireValue<T>(input: NonNullable<T>): T;\nexport const value = requireValue<string | null>(7);', False)
observe('nonnull-imported-alias', 'Payload | null', 'Payload', 'string', 'import type { Payload } from "./types";\n')
cases[-1]['files'] = {'types.ts': 'export interface Payload { code: number; }\n'}
cases[-1]['consumer']['positive'] = 'import { value } from "./main";\nconst observed: {code: number} = value;\n'
add('nonnull-mapped-composition', 'type RequiredValues<T> = {[K in keyof T]: NonNullable<T[K]>};\ndeclare const input: RequiredValues<{x: string | null; y: number | undefined}>;\nexport const value = input;', positive='const observed: {x: string; y: number} = value;', negative='const observed: {x: number; y: string} = value;')
add('nonnull-conditional-composition', 'type Present<T> = T extends unknown ? NonNullable<T> : never;\ndeclare const input: Present<string | number | null>;\nexport const value = input;', positive='const observed: string | number = value;', negative='const observed: boolean = value;')
add('nonnull-keyof-composition', 'type Fields = NonNullable<{a: number; b: string} | undefined>;\ndeclare const input: keyof Fields;\nexport const value = input;', positive='const observed: "a" | "b" = value;', negative='const observed: "c" = value;')
add('nonnull-readonly-preserved', 'declare const value: NonNullable<{readonly x: number} | null>;\nvalue.x = 2;\nexport { value };', False)

then_number = 'type Thenable = {then(onfulfilled: (value: number) => void): void};\n'
observe('awaited-number', 'number', 'number', 'string', utility='Awaited')
observe('awaited-literal', '"ok"', '"ok"', '"bad"', utility='Awaited')
observe('awaited-unknown', 'unknown', 'unknown', 'number', utility='Awaited')
observe('awaited-any', 'any', 'any', 'never', utility='Awaited')
observe('awaited-never', 'never', 'never', 'never', utility='Awaited')
cases[-1]['consumer']['negative'] = 'import { value } from "./main";\nconst observed: typeof value = 1;\n'
for operand, name in [('null', 'null'), ('undefined', 'undefined'), ('null | undefined', 'nullish')]:
    observe('awaited-' + name, operand, operand, 'never', utility='Awaited')
observe('awaited-array-not-unwrapped', 'PromiseLike<number>[]', 'PromiseLike<number>[]', 'number[]', utility='Awaited')
observe('awaited-tuple-not-unwrapped', '[PromiseLike<number>, string]', '[PromiseLike<number>, string]', '[number, string]', utility='Awaited')
observe('awaited-promise-like', 'PromiseLike<number>', 'number', 'string', utility='Awaited')
observe('awaited-promise', 'Promise<number>', 'number', 'string', utility='Awaited')
observe('awaited-nested-promise', 'Promise<PromiseLike<number>>', 'number', 'string', utility='Awaited')
observe('awaited-standard-union', 'PromiseLike<number> | string | null', 'number | string | null', 'boolean', utility='Awaited')
observe('awaited-custom', 'Thenable', 'number', 'string', then_number, 'Awaited')
observe('awaited-custom-union', 'Thenable | string', 'number | string', 'boolean', then_number, 'Awaited')
observe('awaited-custom-nested', 'Thenable', 'number', 'string', 'type Thenable = {then(onfulfilled: (value: {then(cb: (value: number) => void): void}) => void): void};\n', 'Awaited')
observe('awaited-primitive-intersection', 'string & Thenable', 'number', 'string', then_number, 'Awaited')
observe('awaited-number-intersection', 'number & Thenable', 'number', 'string', then_number, 'Awaited')
observe('awaited-noncallable-then', 'Thenable', 'Thenable', 'number', 'type Thenable = {then: number};\n', 'Awaited')
cases[-1]['consumer']['positive'] = 'import { value } from "./main";\nconst observed: {then: number} = value;\n'
observe('awaited-optional-then', 'Thenable', 'Thenable', 'number', 'type Thenable = {then?: (onfulfilled: (value: number) => void) => void};\n', 'Awaited')
cases[-1]['consumer']['positive'] = 'import { value } from "./main";\nconst observed: {then?: (onfulfilled: (value: number) => void) => void} = value;\n'
observe('awaited-bad-fulfillment', 'Thenable', 'never', 'never', 'type Thenable = {then(onfulfilled: number): void};\n', 'Awaited')
cases[-1]['consumer']['negative'] = 'import { value } from "./main";\nconst observed: typeof value = 1;\n'
observe('awaited-zero-argument-callback', 'Thenable', 'unknown', 'number', 'type Thenable = {then(onfulfilled: () => void): void};\n', 'Awaited')
observe('awaited-extra-callback-arguments', 'Thenable', 'number', 'string', 'type Thenable = {then(onfulfilled: (value: number, second: string) => void, extra: boolean): void};\n', 'Awaited')
observe('awaited-callback-rest', 'Thenable', 'number', 'string', 'type Thenable = {then(onfulfilled: (...args: [number, string]) => void): void};\n', 'Awaited')
observe('awaited-overloaded-then-last-signature', 'Thenable', 'string', 'number', 'interface Thenable {then(onfulfilled: (value: number) => void): void; then(onfulfilled: (value: string) => void): void;}\n', 'Awaited')
observe('awaited-overloaded-callback-last-signature', 'Thenable', 'string', 'number', 'interface Callback {(value: number): void; (value: string): void;}\ntype Thenable = {then(onfulfilled: Callback): void};\n', 'Awaited')
observe('awaited-alias-chain', 'Outer', 'number', 'string', then_number + 'type Inner = Thenable; type Outer = Inner;\n', 'Awaited')
observe('awaited-imported-thenable', 'Thenable', 'number', 'string', 'import type { Thenable } from "./types";\n', 'Awaited')
cases[-1]['files'] = {'types.ts': then_number.replace('type Thenable', 'export type Thenable')}
observe('awaited-generic-container', 'Box<number>', 'number', 'string', 'interface Box<T> {then(onfulfilled: (value: T) => void): void;}\n', 'Awaited')
add('awaited-generic-return', 'export declare function unwrap<T>(value: T): Awaited<T>;\ndeclare const input: PromiseLike<number>;\nexport const value = unwrap(input);', positive='const observed: number = value;', negative='const observed: string = value;')
add('awaited-contextual-argument-reject', then_number + 'declare function accept(value: Awaited<Thenable>): void;\naccept("bad");\nexport {};', False)
add('awaited-recursive-self-reject', 'interface Recursive {then(onfulfilled: (value: Recursive) => void): void;}\ndeclare const input: Awaited<Recursive>;\nexport const value = input;', False)
add('awaited-recursive-mutual-reject', 'interface First {then(cb: (value: Second) => void): void;}\ninterface Second {then(cb: (value: First) => void): void;}\ndeclare const input: Awaited<First>;\nexport const value = input;', False)
add('awaited-crlf-nonbmp-diagnostic', '// 😀\r\ntype Thenable = {then(cb: (value: number) => void): void};\r\nexport const value: Awaited<Thenable> = "bad";\r\n', False)
add('nonnull-crlf-nonbmp-diagnostic', '// 😀\r\nexport const value: NonNullable<string | null> = 7;\r\n', False)
for name in ['PromiseLike<number>', 'Promise<number>', 'PromiseConstructorLike']:
    add('es5-static-' + name.split('<')[0].lower(), f'export declare const value: {name};',
        positive=f'const observed: {name} = value;', negative='const observed: number = value;')
add('promise-runtime-constructor-authority', 'export const value = Promise;', 'promise-runtime')
add('promise-runtime-resolve', 'export const value = Promise.resolve(7);', 'promise-runtime')
add('promise-runtime-new', 'export const value = new Promise<number>((resolve) => resolve(7));', 'promise-runtime')
add('nonnull-runtime-name-reject', 'export const value = NonNullable;', False)
add('awaited-runtime-name-reject', 'export const value = Awaited;', False)
add('promiselike-runtime-name-reject', 'export const value = PromiseLike;', False)
add('promiseconstructorlike-runtime-name-reject', 'export const value = PromiseConstructorLike;', False)
add('owner-local-nonnullable', 'type NonNullable<T> = {owned: T};\nexport const value: NonNullable<number> = {owned: 7};', positive='const observed: {owned: number} = value;', negative='const observed: number = value;')
add('owner-local-awaited', 'type Awaited<T> = {owned: T};\nexport const value: Awaited<number> = {owned: 7};', positive='const observed: {owned: number} = value;', negative='const observed: number = value;')
add('owner-imported-awaited', 'import type { Awaited } from "./types";\nexport const value: Awaited<number> = {owned: 7};', positive='const observed: {owned: number} = value;', negative='const observed: number = value;', files={'types.ts': 'export type Awaited<T> = {owned: T};\n'})
add('owner-imported-nonnullable', 'import type { NonNullable } from "./types";\nexport const value: NonNullable<number> = {owned: 7};', positive='const observed: {owned: number} = value;', negative='const observed: number = value;', files={'types.ts': 'export type NonNullable<T> = {owned: T};\n'})
add('noinfer-nonnullable-anchor', 'declare function choose<T extends string>(anchor: T, check: NoInfer<NonNullable<T | null>>): T;\nexport const value = choose("red", "red");', positive='const observed: "red" = value;', negative='const observed: "blue" = value;')
add('noinfer-nonnullable-blocked-reject', 'declare function choose<T extends string>(anchor: T, check: NoInfer<NonNullable<T | null>>): T;\nexport const value = choose("red", "blue");', False)
add('noinfer-awaited-anchor', 'declare function choose<T extends string>(anchor: T, check: NoInfer<Awaited<PromiseLike<T>>>): T;\nexport const value = choose("red", "red");', positive='const observed: "red" = value;', negative='const observed: "blue" = value;')
add('noinfer-awaited-blocked-reject', 'declare function choose<T extends string>(anchor: T, check: NoInfer<Awaited<PromiseLike<T>>>): T;\nexport const value = choose("red", "blue");', False)
add('nonnull-runtime-guard', 'export function requireValue<T>(input: T): NonNullable<T> {if(input == null) throw 0; return input;}\nexport const value = requireValue(7);\nif (value !== 7) throw 1;', runtime=True, positive='const observed: 7 = value;', negative='const observed: string = value;')
add('awaited-runtime-erasure', 'export function identity(value: number): Awaited<number> {return value;}\nexport const value = identity(7);\nif (value !== 7) throw 1;', runtime=True, positive='const observed: number = value;', negative='const observed: string = value;')
observe('awaited-callable-object', 'Thenable', 'number', 'string', 'type Thenable = ((input: boolean) => void) & {then(onfulfilled: (value: number) => void): void};\n', 'Awaited')
observe('awaited-generic-then', 'Thenable', 'unknown', 'number', 'type Thenable = {then<T>(onfulfilled: (value: T) => void): void};\n', 'Awaited')
observe('awaited-union-fulfillment-handler', 'Thenable', 'number', 'string', 'type Thenable = {then(onfulfilled: ((value: number) => void) | number): void};\n', 'Awaited')
observe('nonnull-after-awaited', 'Awaited<PromiseLike<number | null>>', 'number', 'string')
observe('awaited-after-nonnull', 'NonNullable<PromiseLike<number> | null>', 'number', 'string', utility='Awaited')
add('owner-runtime-promise-binding', 'const Promise = {resolve(value: number) {return value;}};\nexport const value = Promise.resolve(7);\nif (value !== 7) throw 1;', runtime=True, positive='const observed: number = value;', negative='const observed: string = value;')

# Every accepted declaration inventory gets isolated positive and negative
# consumers, including cases whose source verdict changes with nullability.
for case in cases:
    if 'consumer' in case or case['accepts'] is False:
        continue
    if case['id'] == 'promise-runtime-constructor-authority':
        expected, wrong = 'typeof Promise', 'number'
    elif case['id'].startswith('promise-runtime-'):
        expected, wrong = 'Promise<number>', 'Promise<string>'
    elif case['id'] == 'nonnull-generic-null-reject':
        expected, wrong = 'number', 'string'
    else:
        expected, wrong = 'unknown', 'never'
    case['consumer'] = {'positive': f'import {{ value }} from "./main";\nconst observed: {expected} = value;\n',
                        'negative': f'import {{ value }} from "./main";\nconst observed: {wrong} = value;\n'}

profiles = [
    {'id': 'es5-commonjs-strict', 'compilerOptions': {'target': 'ES5', 'module': 'CommonJS', 'lib': ['ES5']}},
    {'id': 'es5-commonjs-loose-null', 'compilerOptions': {'target': 'ES5', 'module': 'CommonJS', 'lib': ['ES5'], 'strictNullChecks': False}},
    {'id': 'es2022-commonjs-strict', 'compilerOptions': {'target': 'ES2022', 'module': 'CommonJS', 'lib': ['ES2022']}},
    {'id': 'es2022-esnext-es5lib-strict', 'compilerOptions': {'target': 'ES2022', 'module': 'ESNext', 'lib': ['ES5']}},
]
for case in cases:
    if isinstance(case['accepts'], str):
        condition = case.pop('accepts')
        case['acceptsByProfile'] = {p['id']: (p['compilerOptions'].get('strictNullChecks', True) is False if condition == 'strict-only-reject' else p['compilerOptions']['lib'] == ['ES2022']) for p in profiles}
assert len({case['id'] for case in cases}) == len(cases)
value = {'schema': 1, 'typescript': '5.9.3', 'scope': 'P0-B finite NonNullable, ES5 static Promise foundations and structural recursive Awaited matrix. Covers strict-null options, owner aliases, type/runtime authority, custom thenables and shared inference/operator/declaration paths; broader unmeasured library and language compositions remain open.', 'options': {'strict': True, 'declaration': True, 'noEmitOnError': True, 'newLine': 'lf'}, 'profiles': profiles, 'cases': cases}
(root / 'cases.draft.json').write_text(json.dumps(value, indent=2) + '\n')
print(len(cases), 'forms /', len(cases) * len(profiles), 'observations, authored independently of BlueTS')
