python3 - <<'PY'
from pathlib import Path
import json
r=Path('/private/tmp/bluets-p0b-design-20261111');base=json.loads((r/'frozen-matrix/cases.json').read_bytes());p=r/'shared-operator-probes';p.mkdir()
ids=['nonnull-primitive-union','nonnull-unknown','nonnull-nullish','nonnull-object-union','awaited-custom','awaited-custom-nested','awaited-bad-fulfillment','awaited-zero-argument-callback'];rows=[]
for name in ids:
 c=dict(next(x for x in base['cases'] if x['id']==name));c['id']='ordinary-'+name
 utility='NonNullable' if name.startswith('nonnull') else 'Awaited';alias='Present' if utility=='NonNullable' else 'Unwrap'
 definition='type Present<T> = T & {};\n' if utility=='NonNullable' else 'type Unwrap<T> = T extends null | undefined ? T : T extends object & {then(onfulfilled: infer F, ...args: infer Rest): any} ? F extends ((value: infer V, ...args: infer Remaining) => any) ? Unwrap<V> : never : T;\n'
 c['source']=definition+c['source'].replace(utility+'<',alias+'<');rows.append(c)
data={**base,'scope':'P0-B shared-operator controls, independently authored before production. Ordinary aliases use the same intersection and conditional semantics without builtin utility names. Separate from the original frozen364 observations.','cases':rows}
(p/'cases.draft.json').write_text(json.dumps(data,indent=2)+'\n')
s=(r/'calibrate_matrix.cjs').read_text().replace('assert.equal(cases.length, 364)','assert.equal(cases.length, 32)');(p/'calibrate_matrix.cjs').write_text(s)
print('Authored 8 ordinary-alias forms /32Native observations; existing frozen364 bytes untouched.')
PY