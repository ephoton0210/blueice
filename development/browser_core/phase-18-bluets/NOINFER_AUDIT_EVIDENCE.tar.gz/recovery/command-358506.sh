python3 - <<'PY'
from pathlib import Path
import json,hashlib,shutil,datetime
r=Path('/private/tmp/bluets-p0b-design-20261111');p=r/'shared-operator-probes';ref=json.loads((p/'reference.draft.json').read_bytes());assert not json.loads((p/'matrix-authoring-errors.json').read_bytes());assert len(ref['cases'])==32
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
f=p/'frozen-matrix';f.mkdir();shutil.copy2(p/'cases.draft.json',f/'cases.json');shutil.copy2(p/'reference.draft.json',f/'reference.json');primary=json.loads((r/'frozen-matrix/freeze-receipt.json').read_bytes())
receipt={'schema':1,'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'32 additional independently frozen ordinary intersection/conditional alias comparisons; original364 matrix unchanged.','inputSha256':sha(f/'cases.json'),'referenceSha256':sha(f/'reference.json'),'baselineSourceRevision':primary['baselineSourceRevision'],'baselineCompilerSha256':primary['baselineCompilerSha256'],'counts':{'forms':8,'observations':32,'accepted':32,'declarationFiles':32,'consumers':64,'runtime':0},'nativeOnlyExpectations':True,'nativeImplementationSha256':ref['implementationSha256'],'libraries':ref['libraries']};assert ref['inputSha256']==receipt['inputSha256'];(f/'freeze-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
s=(r/'baseline_matrix.cjs').read_text().replace('assert.equal(report.observations.length, 364)','assert.equal(report.observations.length, 32)');(p/'baseline_matrix.cjs').write_text(s)
print(receipt)
PY