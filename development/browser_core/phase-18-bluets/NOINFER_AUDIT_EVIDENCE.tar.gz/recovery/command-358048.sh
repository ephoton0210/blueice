python3 - <<'PY'
from pathlib import Path
import json,hashlib
r=Path('/private/tmp/bluets-p0b-design-20261111');f=r/'frozen-matrix'
controls=[]
for name in ['NonNullable','Awaited']:
 for kind in ['ambient-owner','local-owner']:
  controls.append({'id':kind+'/'+name,'kind':kind,'name':name,'declaration':f'type {name}<T> = {{owned: T}};','source':f'export const value: {name}<number> = {{owned: 7}};','expected':{'diagnostics':[],'projectModules':['memory:///main.ts','memory:///owner.d.ts'] if kind=='ambient-owner' else ['memory:///main.ts'],'artifacts':1}})
 controls.append({'id':'type-only-runtime-deny/'+name,'kind':'runtime-authority','source':name+'();','options':{'require_declared_global_calls':True},'expected':{'hasErrors':True,'runtimeAuthorityGranted':False}})
programs={
 'nonnull-union':'declare const input: NonNullable<number | null | undefined>; export const value = input;',
 'awaited-custom':'type Box<T> = {then(cb: (value: T) => void): void}; declare const input: Awaited<Box<number>>; export const value = input;',
 'awaited-nested':'type Box<T> = {then(cb: (value: T) => void): void}; declare const input: Awaited<Box<Box<number>>>; export const value = input;',
 'composed-operators':'type Box<T> = {then(cb: (value: T) => void): void}; declare const input: NonNullable<Awaited<Box<number | null>>>; export const value = input;',
}
for name,source in programs.items():
 for limit in [0,1]:controls.append({'id':f'work/{name}/{limit}','kind':'resource-limit','source':source,'normal':{'diagnostics':[],'output':True},'limited':{'max_type_expansions':limit},'expected':{'output':False,'resourceDiagnostic':True,'nativeCounterpart':False}})
controls.append({'id':'depth/awaited-nonnullable','kind':'resource-limit','source':'type Deep = Awaited<NonNullable<Awaited<NonNullable<number>>>>; export const value: Deep = 7;','normal':{'diagnostics':[],'output':True},'limited':{'parser.max_type_depth':2},'expected':{'output':False,'resourceDiagnostic':True,'nativeCounterpart':False}})
p=f/'boundary-controls.json';assert not p.exists();p.write_text(json.dumps({'schema':1,'scope':'Separately authored BlueTS public-API owner/runtime/resource controls. Excluded from direct Native comparisons. Normal and constrained compilations must run against the final P0-B source before acceptance.','controls':controls},indent=2)+'\n')
print('Frozen controls',len(controls),'owner/runtime',sum(c['kind']!='resource-limit' for c in controls),'resource',sum(c['kind']=='resource-limit' for c in controls),'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
p=f/'freeze-receipt.json';d=json.loads(p.read_bytes());d['boundaryControlsSha256']=hashlib.sha256((f/'boundary-controls.json').read_bytes()).hexdigest();d['boundaryControlCounts']={'ownerAndRuntime':6,'resource':9};p.write_text(json.dumps(d,indent=2)+'\n')
PY