// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
'use strict';
const fs = require('node:fs'), path = require('node:path');
const {spawnSync} = require('node:child_process');
const {createHash} = require('node:crypto');
const {isDeepStrictEqual} = require('node:util');
const assert = require('node:assert/strict');
const root = __dirname, repo = path.resolve(root, '../..');
const fixture = path.join(repo, 'backend/bluets/tests/fixtures/noinfer');
const bytes = fs.readFileSync(path.join(fixture, 'cases.json'));
const input = JSON.parse(bytes), reference = JSON.parse(fs.readFileSync(path.join(fixture, 'reference.json')));
const sha = value => createHash('sha256').update(value).digest('hex');
const compiler = path.join(root, 'baseline-accepted-cli'), compilerSha256 = sha(fs.readFileSync(compiler));
assert.equal(compilerSha256, 'a2e85a3c66972996537b979b762e38d02787c70c15681b730a81994ec514aa2a');
assert.equal(sha(bytes), reference.inputSha256);
const out = path.join(root, 'baseline-replay');
fs.mkdirSync(out);
const report = {schema: 1, sourceRevision: 'backend-tree:4687d8d818e1d6b08bb437b41b19c9d84813356f',
  inputSha256: sha(bytes), compilerSha256, comparisons: 0, agreements: 0, accepted: 0,
  conclusion: 'in_progress', cases: []};
const save = () => fs.writeFileSync(path.join(root, 'baseline-replay.json'), JSON.stringify(report, null, 2) + '\n');
function diagnostic(value) {
  value = value.typescript === undefined ? value : value.typescript;
  if (value === null) return {missingNativeCounterpart: true};
  return {code: value.code, message: value.message, file: value.span?.module ?? null,
    position: value.position, relatedInformation: (value.relatedInformation || []).map(diagnostic)};
}
try {
  save();
  for (const expected of reference.cases) {
    const entry = input.cases.find(row => row.id === expected.form);
    const profile = input.profiles.find(row => row.id === expected.profile);
    const cwd = path.join(out, expected.profile, expected.form);
    fs.mkdirSync(cwd, {recursive: true});
    fs.writeFileSync(path.join(cwd, 'main.ts'), entry.source);
    for (const [name, text] of Object.entries(entry.files || {})) {
      assert(!path.isAbsolute(name) && !name.split(/[\\/]/).includes('..'));
      fs.mkdirSync(path.dirname(path.join(cwd, name)), {recursive: true});
      fs.writeFileSync(path.join(cwd, name), text);
    }
    fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify({
      compilerOptions: {...input.options, ...profile.compilerOptions, outDir: 'dist'},
      files: ['main.ts', ...Object.keys(entry.files || {})],
    }, null, 2) + '\n');
    const built = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'],
      {cwd, encoding: 'utf8', timeout: 120000});
    fs.writeFileSync(path.join(cwd, 'build.stdout'), built.stdout || '');
    fs.writeFileSync(path.join(cwd, 'build.stderr'), built.stderr || '');
    if (built.error) throw built.error;
    assert.equal(built.signal, null);
    const diagnostics = (built.stderr || '').trim().split(/\r?\n/).filter(Boolean).map(line => diagnostic(JSON.parse(line)));
    const dist = path.join(cwd, 'dist');
    const artifacts = fs.existsSync(dist) ? fs.readdirSync(dist).sort() : [];
    const declarations = Object.fromEntries(artifacts.filter(name => name.endsWith('.d.ts'))
      .map(name => [name, fs.readFileSync(path.join(dist, name), 'utf8')]));
    const accepts = built.status === 0;
    const agrees = accepts === expected.accepts && isDeepStrictEqual(diagnostics, expected.diagnostics)
      && isDeepStrictEqual(declarations, expected.declarations) && (expected.accepts || artifacts.length === 0);
    const row = {id: expected.id, exit: built.status, accepts, diagnostics, declarations, artifacts, agrees};
    fs.writeFileSync(path.join(cwd, 'observation.json'), JSON.stringify(row, null, 2) + '\n');
    report.cases.push(row); report.comparisons++; report.accepted += Number(accepts); report.agreements += Number(agrees); save();
  }
  assert.equal(sha(fs.readFileSync(compiler)), compilerSha256);
  assert.equal(sha(fs.readFileSync(path.join(fixture, 'cases.json'))), reference.inputSha256);
  assert.equal(report.comparisons, 282); assert.equal(report.accepted, 12); assert.equal(report.agreements, 6);
  report.conclusion = 'completed-baseline'; save();
  console.log('Reproduced all 282 baseline observations: six complete agreements, twelve accepted builds.');
} catch (error) { report.conclusion = 'failure'; report.error = error.stack; save(); throw error; }
