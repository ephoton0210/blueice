# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
"""Independently bind the complete workspace map result and libtest excerpt."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    frozen = read(ROOT / 'frozen-source-preflight.json')
    gates = read(ROOT / 'acceptance-gates.json')
    binding = read(ROOT / 'workspace-map-binding.json')
    report_path = ROOT / 'workspace-declaration-map-report.json'
    report = read(report_path)
    source = frozen['sourceRevision']
    assert binding['sourceRevision'] == gates['sourceRevision'] == source
    assert binding['verified'] and binding['reportFreshSinceBinding']
    compiler = gates['workspaceCompilerSha256']
    assert binding['compilerSha256'] == sha(Path(binding['compilerSnapshot'])) == compiler
    assert sha(ROOT / 'accepted-workspace-cli') == compiler
    assert sha(Path(binding['testExecutable'])) == binding['testExecutableSha256']
    assert binding['reportModifiedEpoch'] >= binding['reportNotBeforeEpoch']
    assert datetime.datetime.fromisoformat(binding['observedAt']).timestamp() <= binding['reportModifiedEpoch']
    assert sha(report_path) == binding['reportSha256']
    assert report['configurations'] == 8407 and report['buildsPerConfiguration'] == 2
    assert report['differences'] == []
    assert not subprocess.check_output(['git', 'diff', '--numstat', '--', 'backend'], cwd=REPO)
    recorded_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write('workspace-map-verification.json', {
        'recordedAt': recorded_at, 'sourceRevision': source,
        'conclusion': 'success-within-matrix', 'configurations': 8407,
        'buildsPerConfiguration': 2, 'differences': 0,
        'actualCompilerSha256': compiler,
        'testExecutableSha256': binding['testExecutableSha256'],
        'reportSha256': sha(report_path), 'processBound': True, 'freshReport': True,
        'scope': 'Complete declarations and JavaScript metadata/order/tables/bounds matrix only; overall workspace and subsequent gates remain pending.'})
    text = (ROOT / 'workspace.log').read_text(errors='strict')
    start = re.search(r'^\s*Running tests/ge5_source_maps\.rs[^\n]*', text, re.MULTILINE)
    assert start
    following = re.search(r'^\s*Running ', text[start.end():], re.MULTILINE)
    assert following, 'Wait for the next harness before retaining an immutable excerpt'
    excerpt = text[start.start():start.end() + following.start()]
    assert Path(binding['testExecutable']).name in excerpt
    results = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', excerpt)
    assert results == [('ok', '43', '0', '21', '0')]
    native = read(ROOT / 'accepted-native/measurement.json')
    suite = next(row for row in native['suites'] if row['harness'] == 'backend/bluets/tests/ge5_source_maps.rs')
    expected_ignored = set(suite['pinned_tests'])
    expected_passed = set(suite['test_names']) - expected_ignored
    passed = re.findall(r'^test ([^\s]+) \.\.\. ok$', excerpt, re.MULTILINE)
    ignored = re.findall(r'^test ([^\s]+) \.\.\. ignored(?:,|$)', excerpt, re.MULTILINE)
    assert len(passed) == len(set(passed)) == len(expected_passed) == 43
    assert len(ignored) == len(set(ignored)) == len(expected_ignored) == 21
    assert set(passed) == expected_passed and set(ignored) == expected_ignored
    excerpt_path = ROOT / 'workspace-map-suite.log'
    excerpt_path.write_text(excerpt)
    write('workspace-map-suite-verification.json', {
        'recordedAt': recorded_at, 'sourceRevision': source, 'conclusion': 'success',
        'harness': 'backend/bluets/tests/ge5_source_maps.rs',
        'selectedFunctions': 43, 'passed': 43, 'failed': 0, 'ignored': 21, 'filtered': 0,
        'passedNames': passed, 'ignoredNames': ignored,
        'log': excerpt_path.name, 'logSha256': sha(excerpt_path),
        'compilerSha256': compiler,
        'fresh8407x2MapReportSha256': sha(report_path),
        'scope': 'All ordinary workspace source_maps functions; the 21 ignored Native functions pass separately in the complete 64-function Native harness. Overall workspace is still pending.'})
    print('Independently verified fresh8407x2 workspace report and exact43 passed/21 ignored source_maps names; overall workspace still pending.')


if __name__ == '__main__':
    main()
