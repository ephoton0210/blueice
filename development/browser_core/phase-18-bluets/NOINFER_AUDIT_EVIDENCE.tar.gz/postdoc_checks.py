# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
"""Retain the real post-documentation checks without rerunning accepted tests."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PHASE = REPO / 'development/browser_core/phase-18-bluets'
EXAMPLE = REPO / 'target/debug/examples/compatibility_inventory'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    source = json.loads((ROOT / 'frozen-source-preflight.json').read_text())['sourceRevision']
    receipt = {'schema': 1, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceRevision': source, 'scope': 'Post-documentation consistency and archive integrity; complete runtime acceptance is in NOINFER_MEASUREMENT.json.',
        'conclusion': 'in_progress', 'checks': []}
    destination = PHASE / 'NOINFER_PUBLICATION_CHECKS.json'
    if destination.exists():
        previous = json.loads(destination.read_text())
        if previous.get('conclusion') == 'failure':
            receipt['priorAttempts'] = previous.pop('priorAttempts', []) + [previous]

    def save():
        destination.write_text(json.dumps(receipt, indent=2) + '\n')

    save()
    checks = [
        ('source', [str(EXAMPLE), '--check-staged']),
        ('cases', [str(EXAMPLE), '--check-cases-staged']),
        ('account-write', ['python3', str(PHASE / 'tools/account_inventory_rows.py'), '--write']),
        ('status-write', ['python3', str(PHASE / 'tools/check_compatibility_status.py'), '--write']),
        ('account', ['python3', str(PHASE / 'tools/account_inventory_rows.py'), '--check']),
        ('status', ['python3', str(PHASE / 'tools/check_compatibility_status.py'), '--check']),
        ('publication', ['python3', str(ROOT / 'check_publication.py')]),
        ('diff', ['git', 'diff', '--check']),
    ]
    for label, command in checks:
        print('START', label, flush=True)
        result = subprocess.run(command, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        receipt['checks'].append({'label': label, 'command': command, 'exit': result.returncode,
            'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
            'stdoutSha256': sha(result.stdout), 'stderrSha256': sha(result.stderr)})
        save()
        print('END', label, result.returncode, flush=True)
        if result.returncode:
            receipt['conclusion'] = 'failure'
            save()
            raise RuntimeError(f'{label}: {result.stderr.decode()}{result.stdout.decode()}')
    files = [PHASE / name for name in ['NOINFER_ACCEPTANCE.md', 'NOINFER_FOLLOWUP.md',
        'TODO.md', 'PLAN.md', 'STANDARD_LIBRARY.md', 'COMPATIBILITY_INVENTORY.md',
        'COMPATIBILITY_CASES.json', 'COMPATIBILITY_SUITES.json', 'COMPATIBILITY_MEASUREMENT.json',
        'NOINFER_MEASUREMENT.json', 'NOINFER_ARTIFACTS.json']] + [REPO / 'CLAUDE.md']
    receipt.update(conclusion='success', finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        inventoryExampleSha256=sha(EXAMPLE.read_bytes()),
        documentsSha256={str(path.relative_to(REPO)): sha(path.read_bytes()) for path in files},
        completedPackages=['P0-A'], broaderFeatureRowsOpen=22, fullTypeScriptParity=False)
    save()
    print('Complete post-documentation checks retained in NOINFER_PUBLICATION_CHECKS.json', flush=True)


if __name__ == '__main__':
    main()
