# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile
from audit_acceptance import audit, ROOT, REPO, PHASE, read, sha


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def archive(name, selected):
    files = set()
    for path in selected:
        assert path.exists() and not path.is_symlink(), path
        if path.is_dir():
            for child in path.rglob('*'):
                assert not child.is_symlink(), child
                if child.is_file():
                    files.add(child)
        else:
            files.add(path)
    destination = PHASE / name
    with tarfile.open(destination, 'w:gz') as output:
        for path in sorted(files):
            output.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    assert destination.stat().st_size < 95 * 1024 * 1024, 'split the archive without dropping evidence'
    with tarfile.open(destination) as output:
        members = output.getmembers()
        names = [member.name for member in members]
        assert len(names) == len(set(names))
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names)
        assert all(member.isfile() for member in members)
    return {'path': name, 'bytes': destination.stat().st_size, 'sha256': sha(destination)}


def main():
    # This call refuses publication until every complete real gate is present.
    receipt = audit()
    write(ROOT / 'acceptance-audit.json', receipt)
    source = receipt['sourceRevision']
    frozen = read(ROOT / 'frozen-source-preflight.json')
    gates = read(ROOT / 'acceptance-gates.json')
    (ROOT / 'accepted-source.patch').write_bytes(subprocess.check_output([
        'git', 'diff', '--binary', 'HEAD', '--', 'backend',
        'development/browser_core/phase-18-bluets/tools'], cwd=REPO))
    archives = []
    archives.append(archive('NOINFER_COMPILERS.tar.gz', [ROOT / name for name in [
        'accepted-native-cli', 'accepted-workspace-cli', 'baseline-accepted-cli',
        'native-build.log', 'workspace-build.log', 'frozen-source-preflight.json']]))
    archives.append(archive('NOINFER_NATIVE_EVIDENCE.tar.gz', [ROOT / name for name in [
        'accepted-native', 'native-capture', 'native-declaration-map-report.json',
        'native-map-binding.json', 'baseline-replay', 'baseline-replay.json',
        'baseline-replay.log', 'baseline_replay.cjs', 'baseline-presence',
        'presence-baseline.cjs', 'presence-baseline.log', 'presence-corrected',
        'presence-corrected.json', 'project-defu', 'project-mitt',
        'project-reproductions', 'project-interchange']]))
    archives.append(archive('NOINFER_WORKSPACE_EVIDENCE.tar.gz', [ROOT / name for name in [
        'workspace-capture', 'workspace-declaration-map-report.json',
        'workspace-map-binding.json', 'workspace.log', 'workspace-build.log',
        'workspace-callable-oracles.log', 'workspace-receiver-oracles.log',
        'workspace-noinfer-oracles.log', 'workspace-noinfer-regressions.log']]))
    metadata = [path for path in ROOT.iterdir() if path.is_file() and path.suffix in ['.json', '.log', '.cjs', '.py', '.patch']]
    metadata += [ROOT / name for name in [
        'recovery', 'windows', 'retired-windows-f98c.tar.gz', 'retired-windows-62b.tar.gz']]
    archives.append(archive('NOINFER_AUDIT_EVIDENCE.tar.gz', metadata))
    destination = PHASE / 'NOINFER_WINDOWS_EVIDENCE.tar.gz'
    shutil.copy2(ROOT / 'windows-evidence.tar.gz', destination)
    assert sha(destination) == receipt['windows']['archiveSha256']
    archives.append({'path': destination.name, 'bytes': destination.stat().st_size, 'sha256': sha(destination)})
    artifacts = {'schema': 1, 'sourceRevision': source, 'artifacts': archives}
    write(PHASE / 'NOINFER_ARTIFACTS.json', artifacts)
    report_refs = receipt['noInferReports']
    for kind in ['native', 'workspace']:
        for key in report_refs[kind]:
            report_refs[kind][key]['archive'] = 'NOINFER_' + kind.upper() + '_EVIDENCE.tar.gz'
    report_refs['windows'] = {
        'archive': 'NOINFER_WINDOWS_EVIDENCE.tar.gz',
        'scope': 'Archive members results-noinfer-v20/noinfer-observations/{blue-*,regressions-*}/report.json; independently checked by verify_windows.py.',
        'compilerSha256': receipt['windows']['actualCompilerSha256']}
    projects = {}
    for name in ['defu', 'mitt', 'reproductions', 'interchange']:
        path = ROOT / ('project-' + name + '/report.json')
        projects[name] = {'archive': 'NOINFER_NATIVE_EVIDENCE.tar.gz',
            'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
            'sourceRevision': source, 'compilerSha256': gates['nativeCompilerSha256']}
    summary = {'schema': 1, 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion': 'completed-within-frozen-scope', 'source': frozen,
        'gates': gates, 'nativeMeasurement': {'path': 'COMPATIBILITY_MEASUREMENT.json',
            'sha256': sha(ROOT / 'accepted-native/measurement.json'), 'suites': 185, 'functions': 1053},
        'primaryForms': 94, 'profiles': 3, 'primaryObservations': 282,
        'diagnosticRegressionObservations': 4, 'directObservations': 286,
        'acceptedDeclarationInventories': 153, 'declarationFiles': 159,
        'isolatedConsumers': 306, 'selectedEditionParses': 159, 'executions': 6,
        'ownerChecks': 3, 'budgetControls': 9, 'controlsExcludedFromDirectDenominator': True,
        'noInferReports': report_refs, 'mapBindings': receipt['mapBindings'],
        'completeNativeRoleFamilies': receipt['completeNativeRoleFamilies'],
        'partialNativeRoleReports': receipt['partialNativeRoleReports'],
        'baseline': {'sourceRevision': read(ROOT / 'baseline-replay.json')['sourceRevision'],
            'compilerSha256': sha(ROOT / 'baseline-accepted-cli'), 'observations': 282,
            'completeAgreements': 6, 'accepted': 12,
            'archive': 'NOINFER_NATIVE_EVIDENCE.tar.gz', 'path': 'baseline-replay.json'},
        'presenceInventory': {'baseline': read(ROOT / 'baseline-presence/presence-corrected.json'),
            'corrected': read(ROOT / 'presence-corrected.json'), 'excludedFromDirectDenominator': True},
        'projects': projects, 'windows': receipt['windows'],
        'casePreservation': receipt['casePreservation'],
        'modules': {'files': 538, 'maximumLines': receipt['maximumModuleLines'],
            'auditPath': 'all-source-module-size-audit.json',
            'auditSha256': sha(ROOT / 'all-source-module-size-audit.json')},
        'retiredWindowsEvidence': receipt['retiredWindowsEvidence'],
        'evidenceRecovery': read(ROOT / 'evidence-recovery.json'),
        'broaderFeatureRowsOpen': 22, 'fullTypeScriptParity': False,
        'artifacts': archives}
    write(PHASE / 'NOINFER_MEASUREMENT.json', summary)
    print('Published NoInfer implementation measurements after complete same-source acceptance.')


if __name__ == '__main__':
    main()
