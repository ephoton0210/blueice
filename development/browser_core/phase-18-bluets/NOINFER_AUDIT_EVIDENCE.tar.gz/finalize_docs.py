# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
import json
import re
from audit_acceptance import ROOT, PHASE, read, sha


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


def main():
    pending = {}
    measurement = read(PHASE / 'NOINFER_MEASUREMENT.json')
    assert measurement['conclusion'] == 'completed-within-frozen-scope'
    assert measurement['gates']['conclusion'] == 'success'
    assert read(ROOT / 'acceptance-audit.json')['conclusion'] == 'success'
    for artifact in read(PHASE / 'NOINFER_ARTIFACTS.json')['artifacts']:
        path = PHASE / artifact['path']
        assert path.stat().st_size == artifact['bytes'] and sha(path) == artifact['sha256']
    date = measurement['recordedAt'][:10]
    source = measurement['source']['sourceRevision']
    gates = measurement['gates']
    accepted = f'''# P0-A — NoInfer acceptance

Accepted {date}, source `{source}`, against TypeScript 5.9.3.
The [measurement](NOINFER_MEASUREMENT.json), [artifact manifest](NOINFER_ARTIFACTS.json)
and [frozen design](NOINFER_FOLLOWUP.md) bind this finite package.
Full TypeScript parity remains **OFF**; all 22 broader open feature rows remain open.

The type model carries an inference barrier through ordinary substitution and
aliases. Candidate and dependency collection respect that operation; checking
still validates the instantiated operand. Conditional infer, contextual result
evidence, rest packs and callback/overload contexts share these boundaries.
Trusted embedded intrinsic lowering supplies NoInfer; local, imported and owner
declarations retain precedence. The type-only declaration adds no runtime binding.
Native declaration identities remain exact, including retained object/array
wrappers and reduced scalar forms. Diagnostic rendering preserves ordinary named
owners and complete import-type spans.

| Frozen acceptance | Actual result |
| --- | --- |
| Primary programs | 94 forms × 3 strict target/module/library profiles = 282 observations; 153 accepts, 129 rejects |
| Supplementary diagnostics | Four independent named-key/operator cases; complete primary/related diagnostics and UTF-16 positions |
| Accepted declarations, per actual compiler | 153 byte-exact inventories / 159 files |
| Isolated declaration consumers | 306 positive/negative consumers per compiler |
| Syntax and execution | 159 selected-edition parses and six executions per compiler |
| Separate boundaries | Three owner/local/runtime controls and nine work/depth refusals; excluded from direct agreement |
| Complete Native catalog | 185 suites / 1,053 functions; zero failed, ignored or filtered |
| Complete local workspace | {gates['workspace']['passed']:,} passed, zero failed; explicit Native-only cases are separately selected above |
| Complete maps | Fresh process-bound 8,407 configurations × two builds for both actual local compiler profiles; zero differences |
| Windows x86_64 | Retained same-source 82/82 core oracles, 25/25 path cases and all seven complete regression cohorts |
| Real projects and tooling | Full mitt/defu, eight prerequisite reproductions and interchange; formatting, warnings-denied workspace Clippy, Node/Python and accounting gates pass |
| Module size | 538 source files audited; maximum 1,477 lines, none over 1,500 |

The unchanged previous accepted compiler has six complete agreements and twelve
accepted builds across the same 282 primary observations. Its executable was
recovered from the hash-verified receiver acceptance archive; all 282 raw baseline
observations were reproduced. Baseline and corrected 22-name/two-profile presence
witnesses are separate from the direct denominator. Five selected utility names
remain missing in ES2022; ES5 additionally needs Awaited and its supporting types.

The original local temporary evidence directory became unavailable after the
interruption. This acceptance uses a fresh complete local run at the unchanged
source and unchanged 588 oracle tools, and the byte-identical Windows archive
recovered from the VM. Earlier failed Windows candidates and recovered historical
tool records are retained separately, with no pass credit for this source.
The missing earlier local raw logs are not represented as retained evidence.

All 39,927 previous suite-qualified case IDs and comparison/status/scope/reason
classifications are preserved. The 282 primary and four supplementary observations
add 286 assertions, making **N = 40,213**. These are case assertions, not unique
programs or a TypeScript language-completeness percentage. P0-B and P0-C remain
unchecked; broader category closure needs its own explicit contract.

The stored gate commands select all ignored Native tests, then run the complete
local workspace, explicit declaration-consumer oracles, formatting, Clippy and
tool checks. Reproduction requires pinned TypeScript 5.9.3 and Acorn 8.15.0;
compiler, source, input, library, command and raw-report hashes are in the
measurement and archives. Windows evidence is the original same-source run,
independently reverified after recovery; no new hosted-CI or OS gate is added.
'''
    pending[PHASE / 'NOINFER_ACCEPTANCE.md'] = accepted
    path = PHASE / 'NOINFER_FOLLOWUP.md'
    text = path.read_text()
    text = replace_once(text, 'Status: Native input/reference frozen; implementation and complete acceptance pending.',
        f'Status: complete within the frozen scope ({date}). See [acceptance](NOINFER_ACCEPTANCE.md) and [measurement](NOINFER_MEASUREMENT.json).')
    old = '''Authoring calibration failures and the original 21 semantic probes are retained
separately from the frozen comparison denominator. The calibration identified
literal preservation after candidate blocking and ordinary result-context
inference for both scalar and rest-pack calls. No expected bytes may be changed
to fit BlueTS after this freeze.'''
    new = '''Authoring calibration and the original 21 semantic probes are historical design
context outside the frozen comparison denominator. They identified literal
preservation after candidate blocking and ordinary scalar/rest result-context
inference. The original temporary evidence directory later became unavailable;
recovered tool records are retained separately. Fresh complete local acceptance
and the hash-identical recovered Windows archive support the current result.
The earlier missing local raw logs receive no retained-evidence claim. Frozen
input and Native-reference bytes remain unchanged.'''
    text = replace_once(text, old, new)
    text = replace_once(text, '''Before checking P0-A or committing its implementation, require all frozen
diagnostics and UTF-16 primary/related positions, exact declarations, consumers,
syntax, execution and separate owner/budget controls. Complete the same-source
Native catalog, local workspace, both compiler profiles' complete map reports,
current project regressions, formatting/Clippy/tooling and the existing Windows
82-core boundary with its path/regression cohorts. Publish implementation and
corresponding measurements together, then push. The broader goal remains active
for later TODO priorities.''', '''The accepted package passes all frozen diagnostics and UTF-16 primary/related
positions, exact declarations, consumers, syntax, execution and separate
owner/budget controls. Acceptance also includes the complete same-source Native
catalog, local workspace, both actual compiler profiles' complete map reports,
current project regressions, formatting/Clippy/tooling and the Windows 82-core
boundary with its path/regression cohorts. The [acceptance](NOINFER_ACCEPTANCE.md)
and [measurement](NOINFER_MEASUREMENT.json) retain the source and raw evidence
bindings. Keep implementation and corresponding measurements together when
committing. P0-B/P0-C and later TODO priorities remain open.''')
    pending[path] = text

    path = PHASE / 'TODO.md'
    text = path.read_text()
    before_ticks = text.count('- [x]')
    start = text.index('- [ ] **P0-A —')
    end = text.index('- [ ] **P0-B —', start)
    text = text[:start] + '''- [x] **P0-A — NoInfer and shared candidate boundaries.** Delivered the frozen
  282 primary and four supplementary diagnostic comparisons across
  G-T2/G-T4/G-T6/G-T7/G-T8. All diagnostics and declaration bytes match;
  each actual compiler passes 159 declaration files, 306 isolated consumers,
  159 syntax checks and six executions. Complete same-source Native/local,
  Windows-82, maps, project and tooling gates pass. Three owner controls and
  nine budget refusals remain separate. [Acceptance](NOINFER_ACCEPTANCE.md) ·
  [measurement](NOINFER_MEASUREMENT.json). Broader rows remain open.
''' + text[end:]
    assert text.count('- [x]') == before_ticks + 1
    assert '- [ ] **P0-B —' in text and '- [ ] **P0-C —' in text
    start = text.index('**Latest completed follow-up:**')
    end = text.index('## Open gaps and implementation priority', start)
    text = text[:start] + '''**Latest completed follow-up:** P0-A supplies the frozen NoInfer inference
boundary through shared candidate, contextual, conditional and checking paths.
[Acceptance](NOINFER_ACCEPTANCE.md) binds complete Native/local/Windows gates,
exact declarations, isolated consumers, maps and project regressions to its
source. Earlier callable and receiver packages retain their dated evidence.
All 22 broader rows remain open; continue with P0-B, then P0-C.

''' + text[end:]
    text = replace_once(text, 'six missing utility names in the ES2022 probe', 'five remaining utility names in the current ES2022 probe')
    start = text.index('The [accepted presence probe]')
    end_marker = 'two profiles, not the full library catalog or semantic completeness.'
    end = text.index(end_marker, start) + len(end_marker)
    text = text[:start] + '''The [current presence witnesses](NOINFER_MEASUREMENT.json#/presenceInventory/corrected)
retain NonNullable, Uppercase, Lowercase, Capitalize and Uncapitalize as missing
in ES2022; ES5 additionally reports Awaited and its supporting PromiseLike type.
NoInfer now passes. This probes 22 selected names under two profiles; semantic
acceptance is separately recorded, and broader catalogs remain open.''' + text[end:]
    text = replace_once(text, 'bounded operator expansion. Start here.',
        'bounded operator expansion. Continue with P0-B, then P0-C.')
    assert text.count('- [x]') == before_ticks + 1
    pending[path] = text

    path = PHASE / 'STANDARD_LIBRARY.md'
    text = path.read_text()
    text = replace_once(text, 'NonNullable, Uppercase, Lowercase, Capitalize, Uncapitalize, NoInfer, ES5 Awaited',
        'NonNullable, Uppercase, Lowercase, Capitalize, Uncapitalize, ES5 Awaited')
    marker = 'Broader generic inference, structural protocols, overloads, index signatures'
    text = replace_once(text, marker, '''The [NoInfer follow-up](NOINFER_ACCEPTANCE.md) adds its trusted static intrinsic
to the core layer while preserving ordinary owner/local/imported declarations.
Its shared inference barrier suppresses candidates and preserves checking,
conditional patterns, exact declaration identities and bounded expansion.
The frozen 282 primary observations plus four diagnostic regressions pass full
same-source acceptance; three owner/runtime and nine budget controls remain
separate. No runtime binding is installed. Other utility/catalog compositions
retain their open scope.

''' + marker)
    pending[path] = text
    path = PHASE / 'COMPATIBILITY_INVENTORY.md'
    lines = path.read_text().splitlines()
    for index, line in enumerate(lines):
        if not any(line.startswith('| ' + identifier + ' |') for identifier in ['G-T2', 'G-T4', 'G-T6', 'G-T7', 'G-T8']):
            continue
        line = line.replace('NonNullable, four string intrinsics, NoInfer, ES5 Awaited', 'NonNullable, four string intrinsics, ES5 Awaited')
        parts = line.split(' | ')
        assert len(parts) == 4
        parts[2] += ' The [NoInfer follow-up](NOINFER_ACCEPTANCE.md) accepts the frozen candidate-boundary compositions with exact diagnostics/declarations and complete source-bound gates; combinations outside that matrix remain open.'
        lines[index] = ' | '.join(parts)
    pending[path] = '\n'.join(lines) + '\n'
    path = PHASE / 'PLAN.md'
    text = path.read_text()
    assert '## P0-A — NoInfer follow-up acceptance' not in text
    text += f'''\n## P0-A — NoInfer follow-up acceptance ({date})

Source `{source}` completes the finite shared inference-barrier package.
The [acceptance](NOINFER_ACCEPTANCE.md) and [measurement](NOINFER_MEASUREMENT.json)
record 282 frozen primary observations plus four diagnostic regressions,
153 exact declaration inventories / 159 files, 306 isolated consumers,
159 syntax checks and six executions per actual compiler. Three owner/runtime
and nine configured-budget controls remain separate. Complete Native
185-suite/1,053-function and local workspace gates, both fresh 8,407×2 map
profiles, Windows 82-core/25-path/seven-cohort evidence, project regressions
and all tooling pass. All prior case identities/classifications are preserved;
N is 40,213. P0-B/P0-C and all 22 broader feature rows remain open; full parity
is OFF. The acceptance record explains temporary-evidence recovery and uses
fresh local proof plus the hash-identical retained Windows run.
'''
    pending[path] = text
    for path, body in pending.items():
        path.write_text(body)
    print('Documented complete P0-A acceptance; checked exactly one TODO package.')


if __name__ == '__main__':
    main()
