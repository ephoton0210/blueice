# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Package unchanged successful R10 tests; retain the original packaging failure."""
from pathlib import Path
import ast
import base64
import datetime
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time

CONTRACT = Path(__file__).resolve().parent
REPO = CONTRACT.parent.parent
ROOT = REPO/'target/higher-order-inference-acceptance-20261114-r10'
RECOVERY = CONTRACT/'r10-windows-packaging-recovery-1'
RECOVERY.mkdir()
BASE = 'B:/BlueIce/gm3-20261109-360d7d921/'
PREFIX = 'p0g-r10-packaging-recovery-1'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('r10_packaging_qga', REPO/'target/noinfer-acceptance-20261112/recovery/qga_transfer.py')
qga = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qga)
state = {'pid':os.getpid(), 'conclusion':'in_progress', 'stage':'preserving-original-failure',
    'sourceRevision':read(ROOT/'frozen-source-preflight.json')['sourceRevision'],
    'testReruns':0, 'runtimeDriversChanged':0,
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = RECOVERY/'state.tmp'
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(RECOVERY/'state.json')


def terminal(pid, name):
    while True:
        value = qga.call({'execute':'guest-exec-status','arguments':{'pid':pid}})
        if value.get('exited'):
            for key in ['out-data','err-data']:
                if key in value:
                    value[key] = base64.b64decode(value[key]).decode('utf-8-sig',errors='replace')
            (RECOVERY/name).write_text(json.dumps(value,indent=2)+'\n')
            assert value['exitcode'] == 0, value
            return value
        state['lastGuestStatus'] = value
        save()
        time.sleep(10)


try:
    save()
    preserved = {}
    for name in ['windows/package-evidence.py','windows/package-terminal.json',
            'windows/package-failure-observation-1.json','windows/complete-state.json',
            'windows/finalize-state.json','windows/bootstrap-terminal.json',
            'windows/terminal-test-observation-1.json','windows-supervisor.log','windows/finish-driver.log']:
        source = ROOT/name
        destination = RECOVERY/'original'/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,destination)
        preserved[name] = {'sha256':sha(destination),'bytes':destination.stat().st_size}
    (RECOVERY/'original-manifest.json').write_text(json.dumps(preserved,indent=2)+'\n')
    old_terminal = read(ROOT/'windows/package-terminal.json')
    assert old_terminal['exitcode'] == 1 and "len(measurement['followups']) == 26" in old_terminal['err-data']
    assert read(ROOT/'windows/complete-state.json')['conclusion'] == 'failure'
    measurement = read(ROOT/'windows/terminal-test-observation-1.json')
    assert measurement['sourceRevision'] == state['sourceRevision']
    assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
    assert measurement['core82Passed'] and measurement['core82Exit'] == 0
    assert len(measurement['followups']) == 27 and all(r['passed'] and r['exit'] == 0 for r in measurement['followups'])
    original = (ROOT/'windows/package-evidence.py').read_text()
    corrected = original
    replacements = {
        "len(measurement['followups']) == 26":"len(measurement['followups']) == 27",
        "== {'higher_order_inference',":"== {'diagnostics', 'higher_order_inference',",
        "'p0g-r10-evidence-state.json'":repr(PREFIX+'-evidence-state.json'),
        "'p0g-r10-full-source.tar.gz'":repr(PREFIX+'-full-source.tar.gz'),
        "'p0g-r10-windows-evidence.tar.gz'":repr(PREFIX+'-windows-evidence.tar.gz'),
        "'p0g-r10-windows-evidence.json'":repr(PREFIX+'-windows-evidence.json'),
    }
    for old,new in replacements.items():
        assert corrected.count(old) == 1, old
        corrected = corrected.replace(old,new)
    destination = RECOVERY/'package-evidence.py'
    destination.write_text(corrected)
    # Replay only the two packaging assertions against the actual terminal
    # measurement. The original must reject; corrected count and exact set pass.
    outcomes = {}
    for label,code in [('original',original),('corrected',corrected)]:
        assertions = [n for n in ast.walk(ast.parse(code)) if isinstance(n,ast.Assert)
            and 'measurement[\'followups\']' in ast.get_source_segment(code,n)]
        assert len(assertions) == 2
        try:
            exec(compile(ast.Module(body=assertions,type_ignores=[]),label,'exec'),{'measurement':measurement})
            outcomes[label] = 'accepted'
        except AssertionError:
            outcomes[label] = 'rejected'
    assert outcomes == {'original':'rejected','corrected':'accepted'}
    proof = {'sourceRevision':state['sourceRevision'],'originalPackageSha256':sha(ROOT/'windows/package-evidence.py'),
        'correctedPackageSha256':sha(destination),'terminalMeasurementSha256':sha(ROOT/'windows/terminal-test-observation-1.json'),
        'assertionReplay':outcomes,'actualCohorts':len(measurement['followups']),
        'replacements':replacements,'testReruns':0,'originalFailureUnchanged':True}
    (RECOVERY/'repair-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    remote_script = BASE+PREFIX+'-package-evidence.py'
    fresh = [remote_script]+[BASE+PREFIX+suffix for suffix in ['-evidence-state.json','-full-source.tar.gz','-windows-evidence.tar.gz','-windows-evidence.json']]
    code = 'from pathlib import Path; paths='+repr(fresh)+'; assert not [p for p in paths if Path(p).exists()]'
    process = qga.call({'execute':'guest-exec','arguments':{'path':'C:\\Program Files\\Python312\\python.exe','arg':['-B','-c',code],'capture-output':True}})
    terminal(process['pid'],'fresh-namespace-terminal.json')
    content = destination.read_bytes()
    handle = qga.call({'execute':'guest-file-open','arguments':{'path':remote_script,'mode':'wb'}})
    try:
        for offset in range(0,len(content),65536):
            chunk = content[offset:offset+65536]
            result = qga.call({'execute':'guest-file-write','arguments':{'handle':handle,'buf-b64':base64.b64encode(chunk).decode()}})
            assert result['count'] == len(chunk)
    finally:
        qga.call({'execute':'guest-file-close','arguments':{'handle':handle}})
    process = qga.call({'execute':'guest-exec','arguments':{'path':'C:\\Program Files\\Python312\\python.exe','arg':['-B',remote_script],'capture-output':True}})
    (RECOVERY/'package-process.json').write_text(json.dumps(process,indent=2)+'\n')
    state.update(stage='packaging-unchanged-terminal-tests',guestPackagingPid=process['pid'])
    save()
    terminal(process['pid'],'package-terminal.json')
    state['stage'] = 'receiving-evidence'
    save()
    qga.download(BASE+PREFIX+'-windows-evidence.json',ROOT/'windows/windows-evidence-receipt.json')
    qga.download(BASE+'results-higher-order-inference-r10/measurement.json',ROOT/'windows/windows-measurement.json')
    assert (ROOT/'windows/windows-measurement.json').read_bytes() == (ROOT/'windows/terminal-test-observation-1.json').read_bytes()
    receipt = read(ROOT/'windows/windows-evidence-receipt.json')
    qga.download(receipt['archive'],ROOT/'windows-evidence.tar.gz')
    assert sha(ROOT/'windows-evidence.tar.gz') == receipt['archiveSha256']
    assert (ROOT/'windows-evidence.tar.gz').stat().st_size == receipt['archiveBytes']
    state['stage'] = 'independent-audit-with-unchanged-frozen-verifier'
    save()
    assert sha(ROOT/'verify_windows.py') == sha(ROOT/'orchestration-start-snapshot/verify_windows.py')
    with (RECOVERY/'verify-windows.log').open('xb') as output:
        result = subprocess.run([sys.executable,'-B',str(ROOT/'verify_windows.py')],cwd=REPO,stdout=output,stderr=subprocess.STDOUT)
    assert result.returncode == 0, (RECOVERY/'verify-windows.log').read_text()[-3000:]
    verified = read(ROOT/'windows/windows-acceptance-verification.json')
    assert verified['conclusion'] == 'success' and len(verified['regressionCohorts']) == 27
    for name,row in preserved.items():
        assert sha(ROOT/name) == row['sha256'], name
    state.update(stage='complete',conclusion='success',originalWindowsSupervisorConclusion='failure',
        originalPackagingExit=1,correctedPackagingExit=0,
        verificationSha256=sha(ROOT/'windows/windows-acceptance-verification.json'),
        archiveSha256=receipt['archiveSha256'],originalFailureManifestSha256=sha(RECOVERY/'original-manifest.json'),
        repairProofSha256=sha(RECOVERY/'repair-proof.json'))
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    if state['conclusion'] != 'in_progress':
        state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state),flush=True)
