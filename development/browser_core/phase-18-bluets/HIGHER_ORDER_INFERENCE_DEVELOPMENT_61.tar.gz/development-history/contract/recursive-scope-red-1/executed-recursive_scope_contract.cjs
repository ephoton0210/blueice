// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const {spawnSync} = require('node:child_process');
const c = require('../../development/browser_core/phase-18-bluets/tools/higher_order_inference/common.cjs');
const {fs, path, assert, sha} = c;
const root = path.resolve(process.argv[2]);
const compiler = path.resolve(process.argv[3]);
assert(!fs.existsSync(root)); fs.mkdirSync(root, {recursive: true});
const merger = 'type Merger = <T extends object, K extends keyof T>(object: T, key: keyof T, value: T[K]) => any;\n';
const recursive = 'export function recur<T>(base: T, defaults: any, merger?: Merger): T {\n const result = Object.assign({}, defaults);\n for (const key in base) { const value: unknown = base[key]; result[key] = recur(value, result[key], merger); }\n return result;\n}\n';
const entries = [
  {id: 'closed-dependent-callback', source: merger + recursive},
  {id: 'renamed-closed-callback', source: merger.replaceAll('T', 'Item') + recursive},
  {id: 'closed-dependent-default', source: merger.replace('K extends keyof T>', 'K extends keyof T = keyof T>') + recursive},
  {id: 'closed-value-default', source: merger.replace('<T extends object, K extends keyof T>', '<T extends object = {}, K extends keyof T = keyof T>') + recursive},
  {id: 'closed-callback-in-property', source: merger + recursive.replace('merger?: Merger', 'merger?: { apply: Merger }')},
  {id: 'closed-callback-import', source: 'import type { Merger } from "./callback";\n' + recursive, files: {'callback.ts': 'export ' + merger}},
  {id: 'captured-result-remains-inferable', source: 'declare function consume<T>(callback: <U>(value: U) => T): T;\ndeclare function value<U>(input: U): string;\nexport const result = consume(value);\n'},
  {id: 'captured-result-mismatch-is-rejected', source: 'declare function consume<T>(value: T, callback: <U>(input: U) => T): T;\ndeclare function numeric<U>(input: U): number;\nexport const result = consume("s", numeric);\n'},
];
const input = {schema: 1, scope: 'Supplementary regression controls; zero inventory credit. Frozen higher-order 384-case contract is unchanged.',
  options: {strict: true, lib: ['ES2022'], module: 'CommonJS', declaration: true, noEmitOnError: true},
  profiles: [{id: 'es5', compilerOptions: {target: 'ES5'}}, {id: 'es2022', compilerOptions: {target: 'ES2022'}}], cases: entries};
fs.writeFileSync(path.join(root, 'cases.json'), JSON.stringify(input, null, 2) + '\n');
const ctx = c.context();
const report = {schema: 1, compilerSha256: sha(fs.readFileSync(compiler)), implementationSha256: sha(fs.readFileSync(ctx.implementation)),
  inputSha256: sha(fs.readFileSync(path.join(root, 'cases.json'))), inventoryCredit: 0, cases: [], conclusion: 'in_progress'};
const save = () => fs.writeFileSync(path.join(root, 'report.json'), JSON.stringify(report, null, 2) + '\n'); save();
for (const profile of input.profiles) for (const entry of entries) {
  const native = c.prepare(path.join(root, 'native'), input, profile, entry);
  const wanted = c.nativeProject(ctx, native.cwd, native.config);
  const expected = {accepts: !wanted.diagnostics.length, diagnostics: wanted.diagnostics,
    declarations: Object.fromEntries(Object.entries(wanted.outputs).filter(([name]) => name.endsWith('.d.ts')))};
  const project = c.prepare(path.join(root, 'blue'), input, profile, entry);
  const result = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'], {cwd: project.cwd, encoding: 'utf8', timeout: 120000});
  if (result.error || result.status === null) throw result.error || Error('terminated process');
  fs.writeFileSync(path.join(project.cwd, 'build.stdout'), result.stdout || '');
  fs.writeFileSync(path.join(project.cwd, 'build.stderr'), result.stderr || '');
  const observed = {accepts: result.status === 0,
    diagnostics: (result.stderr || '').split(/\r?\n/).filter(Boolean).map(line => c.blueDiagnostic(JSON.parse(line))),
    declarations: Object.fromEntries(Object.entries(c.inventory(path.join(project.cwd, 'dist'))).filter(([name]) => name.endsWith('.d.ts')))};
  let agrees = true, error = null;
  try { assert.deepEqual(observed, expected); } catch (e) { agrees = false; error = e.message; }
  report.cases.push({id: profile.id + '/' + entry.id, expected, observed, agrees, error}); save();
}
report.agreements = report.cases.filter(row => row.agrees).length;
report.conclusion = report.agreements === report.cases.length ? 'success' : 'measured-differences';
save();
console.log(JSON.stringify({conclusion: report.conclusion, agreements: report.agreements, comparisons: report.cases.length,
  failures: report.cases.filter(row => !row.agrees).map(row => ({id: row.id, expectedAccepts: row.expected.accepts, observedAccepts: row.observed.accepts}))}));
