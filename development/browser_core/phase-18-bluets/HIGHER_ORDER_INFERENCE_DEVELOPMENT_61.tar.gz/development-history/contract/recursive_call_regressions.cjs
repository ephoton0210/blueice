// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const {spawnSync} = require('node:child_process');
const c = require('../../development/browser_core/phase-18-bluets/tools/higher_order_inference/common.cjs');
const {fs, path, assert, sha} = c;
const output = path.resolve(process.argv[2]);
assert(!fs.existsSync(output));
fs.mkdirSync(output, {recursive: true});
const compilers = {
  acceptedParent: path.resolve('target/higher-order-inference-contract-20261114/baseline-1/baseline-cli'),
  current: path.resolve('target/higher-order-inference-acceptance-20261114-r5/accepted-native-cli'),
};
const entries = [
  {id: 'recursive-unknown', source: 'export function recur<T>(value: T): T { const next: unknown = value; recur(next); return value; }\n'},
  {id: 'recursive-any', source: 'export function recur<T>(value: T): T { const next: any = value; recur(next); return value; }\n'},
  {id: 'recursive-self', source: 'export function recur<T>(value: T): T { recur(value); return value; }\n'},
  {id: 'recursive-indexed', source: 'export function recur<T>(value: T): T { for (const key in value) { const next = value[key]; recur(next); } return value; }\n'},
  {id: 'recursive-indexed-assignment', source: 'export function recur<T>(value: T, defaults: any): T { const result = Object.assign({}, defaults); for (const key in value) { const next = value[key]; result[key] = recur(next, result[key]); } return result; }\n'},
  {id: 'recursive-renamed-parameter', source: 'export function recur<Source>(value: Source): Source { const next: unknown = value; recur(next); return value; }\n'},
  {id: 'external-unknown', source: 'declare function recur<T>(value: T): T; export function call<U>(value: U): U { const next: unknown = value; recur(next); return value; }\n'},
  {id: 'external-colliding-name', source: 'declare function recur<T>(value: T): T; export function call<T>(value: T): T { const next: unknown = value; recur(next); return value; }\n'},
];
const input = {options: {strict: true, lib: ['ES2022'], module: 'CommonJS', target: 'ES2022', declaration: true, noEmitOnError: true}};
const profile = {id: 'strict-commonjs', compilerOptions: {}}, ctx = c.context();
const report = {schema: 1, recordedAt: new Date().toISOString(), inventoryCredit: 0,
  sourceRevision: 'backend-tree:20ed07888d4b564c37e93fcbc0f0e742e99d9c41',
  compilers: Object.fromEntries(Object.entries(compilers).map(([name, file]) => [name, {file, sha256: sha(fs.readFileSync(file))}])),
  implementationSha256: sha(fs.readFileSync(ctx.implementation)), cases: [], conclusion: 'in_progress'};
const save = () => fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
save();
for (const entry of entries) {
  const native = c.prepare(path.join(output, 'native'), input, profile, entry);
  const wanted = c.nativeProject(ctx, native.cwd, native.config);
  const expected = {accepts: !wanted.diagnostics.length, diagnostics: wanted.diagnostics,
    declarations: Object.fromEntries(Object.entries(wanted.outputs).filter(([name]) => name.endsWith('.d.ts')))};
  const row = {id: entry.id, source: entry.source, expected, compilers: {}};
  for (const [label, compiler] of Object.entries(compilers)) {
    const project = c.prepare(path.join(output, label), input, profile, entry);
    const result = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'], {cwd: project.cwd, encoding: 'utf8', timeout: 120000});
    if (result.error || result.status === null) throw result.error || Error('terminated: ' + label);
    fs.writeFileSync(path.join(project.cwd, 'build.stdout'), result.stdout || '');
    fs.writeFileSync(path.join(project.cwd, 'build.stderr'), result.stderr || '');
    const observed = {accepts: result.status === 0,
      diagnostics: (result.stderr || '').split(/\r?\n/).filter(Boolean).map(line => c.blueDiagnostic(JSON.parse(line))),
      declarations: Object.fromEntries(Object.entries(c.inventory(path.join(project.cwd, 'dist'))).filter(([name]) => name.endsWith('.d.ts')))};
    let agrees = true, error = null;
    try { assert.deepEqual(observed, expected); } catch (e) { agrees = false; error = e.message; }
    row.compilers[label] = {exit: result.status, agrees, observed, error};
  }
  report.cases.push(row); save();
}
report.conclusion = 'measured';
report.summary = Object.fromEntries(Object.keys(compilers).map(label => [label, {
  comparisons: entries.length, agreements: report.cases.filter(row => row.compilers[label].agrees).length,
  failures: report.cases.filter(row => !row.compilers[label].agrees).map(row => row.id),
}]));
save();
console.log(JSON.stringify(report.summary));
