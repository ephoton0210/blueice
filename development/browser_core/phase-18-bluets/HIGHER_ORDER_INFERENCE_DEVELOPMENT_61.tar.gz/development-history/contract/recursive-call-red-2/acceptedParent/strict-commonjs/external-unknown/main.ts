declare function recur<T>(value: T): T; export function call<U>(value: U): U { const next: unknown = value; recur(next); return value; }
