export function recur<T>(value: T): T { const next: any = value; recur(next); return value; }
