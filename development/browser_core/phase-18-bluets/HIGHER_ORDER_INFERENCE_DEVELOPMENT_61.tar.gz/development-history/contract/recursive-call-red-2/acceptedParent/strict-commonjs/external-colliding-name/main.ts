declare function recur<T>(value: T): T; export function call<T>(value: T): T { const next: unknown = value; recur(next); return value; }
