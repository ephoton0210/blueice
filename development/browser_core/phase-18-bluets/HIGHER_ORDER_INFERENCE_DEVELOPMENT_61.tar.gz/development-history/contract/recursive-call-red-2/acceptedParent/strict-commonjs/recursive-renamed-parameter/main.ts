export function recur<Source>(value: Source): Source { const next: unknown = value; recur(next); return value; }
