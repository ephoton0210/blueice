export function recur<T>(value: T): T { for (const key in value) { const next = value[key]; recur(next); } return value; }
