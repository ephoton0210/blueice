export function recur<T>(value: T): T { recur(value); return value; }
