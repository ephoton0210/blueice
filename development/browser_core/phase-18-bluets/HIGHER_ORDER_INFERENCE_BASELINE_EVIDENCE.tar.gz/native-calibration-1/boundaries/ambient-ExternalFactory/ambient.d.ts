type ExternalFactory = new <T>(value: T) => { value: T };
