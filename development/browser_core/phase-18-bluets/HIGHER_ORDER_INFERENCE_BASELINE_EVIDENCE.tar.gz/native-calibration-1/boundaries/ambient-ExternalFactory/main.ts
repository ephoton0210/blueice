declare const factory: ExternalFactory;
export const result = factory;
