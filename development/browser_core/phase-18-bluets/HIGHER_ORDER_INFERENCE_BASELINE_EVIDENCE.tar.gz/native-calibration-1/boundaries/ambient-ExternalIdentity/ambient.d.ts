type ExternalIdentity = <T>(value: T) => T;
