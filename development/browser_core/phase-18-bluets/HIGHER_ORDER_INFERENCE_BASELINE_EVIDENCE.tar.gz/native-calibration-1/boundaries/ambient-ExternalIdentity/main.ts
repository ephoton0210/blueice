export const result: ExternalIdentity = <T>(value: T): T => value;
