type Handler = <T>(value: T) => <U>(other: U) => [T, U];
declare const value: Handler;
export const result = value;
