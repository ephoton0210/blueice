# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Prepare final acceptance after the independently proven G-T7 host repair."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess
import sys

contract = Path(__file__).resolve().parent
repo = contract.parent.parent
old = repo/'target/higher-order-inference-acceptance-20261114-r8'
root = repo/'target/higher-order-inference-acceptance-20261114-r9'
assert sys.argv[1:] in ([], ['--preview'])
preview = sys.argv[1:] == ['--preview']
if preview:
    root = repo/'target/higher-order-inference-preparation-20261114-r9-preview-1'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
quality = contract/'gt7-host-worktree-quality-1'
q = read(quality/'measurement.json')
assert q['conclusion'] in ('in_progress', 'success')
assert all(row['exit'] == 0 and 'reusedFrom' not in row for row in q['steps'])
if not preview:
    assert q['conclusion'] == 'success' and q['stage'] == 'complete' and len(q['steps']) == 7
assert read(contract/'gt7-host-windows-preflight-1/state.json')['conclusion'] == 'success'
assert read(old/'launch-state.json')['conclusion'] == 'failure'
assert read(old/'windows/failed-evidence-preservation-1/state.json')['conclusion'] == 'success'
assert all(sha(repo/name) == digest for name,digest in read(quality/'source-manifest.json').items())
root.mkdir()
(root/'windows').mkdir()
names = [
    'launch.py','run_mac.py','freeze_source.py','prepare_windows.py',
    'upload_windows.py','complete_windows.py','finish_windows.py','verify_windows.py',
    'run_native_gates.py','measure_priority.cjs','run_project_gates.py',
    'run_local_gates.py','watch_maps.py','replay_original_discovery.cjs',
    'audit_symbolic_keys.py','audit_conditional_inference.py','audit_higher_order_inference.py',
    'baseline-native-durations.json','windows/windows-runner.cjs','windows/package-evidence.py',
]
for name in names + [path.name for path in old.glob('g_*.py')]:
    text = (old/name).read_text().replace('acceptance-20261114-r8','acceptance-20261114-r9')
    text = text.replace('p0g-r8','p0g-r9').replace('results-higher-order-inference-r8','results-higher-order-inference-r9')
    (root/name).write_text(text)
for name in ['original-discovery24/inputs.json','original-discovery24/native-reference.json',
             'accepted-parent-source.tar.gz','accepted-parent-source-manifest.json']:
    destination = root/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(old/name,destination)

p = root/'prepare_windows.py'
s = p.read_text().replace("'higher-order-inference-acceptance-20261114-r6'","'higher-order-inference-acceptance-20261114-r8'")
s = s.replace('backend-tree:c746a2387175ac4df07d8a4ec91e983fb5d5ecec','backend-tree:9f6e4f033200e519f62f3573685b6cbe04f873a3')
s = s.replace("'/p0g-r6-source-manifest.json'","'/p0g-r8-source-manifest.json'")
s = s.replace(".replace('p0g-r6', 'p0g-r9')",".replace('p0g-r8', 'p0g-r9')")
p.write_text(s)

p = root/'freeze_source.py'
s = p.read_text().replace("quality = contract/'promise-worktree-quality-3'","quality = contract/'gt7-host-worktree-quality-1'")
start = s.index("previous = repo/'target/higher-order-inference-acceptance-20261114-r6'")
end = s.index("prior = read(repo/",start)
s = s[:start]+'''previous = repo/'target/higher-order-inference-acceptance-20261114-r8'
assert read(previous/'launch-state.json')['conclusion'] == 'failure'
assert read(previous/'mac-driver.json')['conclusion'] == 'failure'
assert read(previous/'windows/complete-state.json')['conclusion'] == 'failure'
assert read(previous/'windows/failed-evidence-preservation-1/state.json')['conclusion'] == 'success'
preserved = read(contract/'r8-oracle-failure-preservation-1/receipt.json')
assert sha(contract/'r8-oracle-failure-preservation-1/frozen-source.tar.gz') == preserved['archiveSha256']
assert len(report['steps']) == 7 and all('reusedFrom' not in row for row in report['steps'])
assert report['actualCompilerSha256'] == focused['actualCompilerSha256']
probe = read(contract/'gt7-host-windows-preflight-1/measurement.json')
assert probe['conclusion'] == 'success' and probe['passed'] == 7
assert probe['originalGuestSourceRestoredExactly'] and probe['nativeReferenceUnchanged']
assert probe['repairedRecorderSha256'] == files['development/browser_core/phase-18-bluets/tools/record_gt7_library_manifest.cjs']
''' + s[end:]
p.write_text(s)

p = root/'g_acceptance_audit.py'
s = p.read_text().replace("promise-worktree-quality-3'","gt7-host-worktree-quality-1'")
start = s.index("    quality_report = read(quality/'measurement.json')")
end = s.index("    native_gates = read(ROOT/'native-gates.json')",start)
s = s[:start]+'''    quality_report = read(quality/'measurement.json')
    assert all('reusedFrom' not in row for row in quality_report['steps'])
    assert re.search(r'Ran 13 tests in ',(quality/'python-tools.log').read_text())
    assert (quality/'python-tools.log').read_text().rstrip().endswith('OK')
    superseded = quality.parent/'promise-worktree-quality-3'
    previous_files = read(superseded/'source-manifest.json')
    recorder = 'development/browser_core/phase-18-bluets/tools/record_gt7_library_manifest.cjs'
    assert set(previous_files) == set(frozen['files'])
    assert [name for name,value in previous_files.items() if frozen['files'][name] != value] == [recorder]
    probe = quality.parent/'gt7-host-windows-preflight-1/measurement.json'
    observed = read(probe)
    assert observed['conclusion'] == 'success' and observed['passed'] == 7
    assert observed['failed'] == observed['ignored'] == observed['filtered'] == 0
    assert observed['originalGuestSourceRestoredExactly'] and observed['nativeReferenceUnchanged']
    assert observed['repairedRecorderSha256'] == frozen['files'][recorder]
    replay = quality.parent/'gt7-host-worktree-preflight-1/native-replay-result.json'
    assert read(replay)['conclusion'] == 'success' and read(replay)['nativeObservations'] == 434
    preflight_provenance = {'sourceIdenticalReusedSteps':0,'freshCompleteExactSourceSteps':7,'freshPythonTests':13,
        'acceptedPreflight':'development-history/contract/gt7-host-worktree-quality-1/measurement.json',
        'acceptedPreflightSha256':sha(quality/'measurement.json'),
        'supersededPreflight':'development-history/contract/promise-worktree-quality-3/measurement.json',
        'supersededPreflightSha256':sha(superseded/'measurement.json'),
        'supersededManifest':'development-history/contract/promise-worktree-quality-3/source-manifest.json',
        'supersededManifestSha256':sha(superseded/'source-manifest.json'),
        'windowsHostPreflight':'development-history/contract/gt7-host-windows-preflight-1/measurement.json',
        'windowsHostPreflightSha256':sha(probe),
        'nativeHostReplay':'development-history/contract/gt7-host-worktree-preflight-1/native-replay-result.json',
        'nativeHostReplaySha256':sha(replay),'changedTool':recorder,
        'previousToolSha256':previous_files[recorder],'repairedToolSha256':frozen['files'][recorder],
        'sourceManifestSha256':sha(quality/'source-manifest.json'),'earlierFailedOutcomesPreserved':True}
''' + s[end:]
p.write_text(s)

p = root/'g_verify_publication.py'
s = p.read_text()
start = s.index("        assert preflight['sourceIdenticalReusedSteps']==4")
end = s.index("        assert owners[prefix['preflightReport']]",start)
s = s[:start]+'''        assert preflight['sourceIdenticalReusedSteps']==0 and preflight['freshCompleteExactSourceSteps']==7
        assert preflight['freshPythonTests']==13
        for path_field,sha_field in [('acceptedPreflight','acceptedPreflightSha256'),
            ('supersededPreflight','supersededPreflightSha256'),('supersededManifest','supersededManifestSha256'),
            ('windowsHostPreflight','windowsHostPreflightSha256'),('nativeHostReplay','nativeHostReplaySha256')]:
            assert owners[preflight[path_field]]['sha256']==preflight[sha_field]
        accepted_quality=json.loads(content(preflight['acceptedPreflight']))
        assert accepted_quality['conclusion']=='success' and len(accepted_quality['steps'])==7
        assert all(row['exit']==0 and 'reusedFrom'not in row for row in accepted_quality['steps'])
        for row in accepted_quality['steps']:
            name='development-history/contract/gt7-host-worktree-quality-1/'+row['log']
            assert owners[name]['sha256']==row['logSha256']
        old_manifest=json.loads(content(preflight['supersededManifest']))
        assert set(old_manifest)==set(frozen['files'])
        assert [name for name,value in old_manifest.items() if frozen['files'][name]!=value]==[preflight['changedTool']]
        assert old_manifest[preflight['changedTool']]==preflight['previousToolSha256']
        assert frozen['files'][preflight['changedTool']]==preflight['repairedToolSha256']
        host=json.loads(content(preflight['windowsHostPreflight']))
        assert host['conclusion']=='success' and host['passed']==7
        assert host['failed']==host['ignored']==host['filtered']==0
        assert host['originalGuestSourceRestoredExactly'] and host['nativeReferenceUnchanged']
        assert host['repairedRecorderSha256']==preflight['repairedToolSha256']
''' + s[end:]
s = s.replace("'failed-r6','failed-r7'}","'failed-r6','failed-r7','failed-r8'}")
p.write_text(s)

p = root/'g_history_audit.py'
s = p.read_text()
marker = "    return {'conclusion':'success','parentCommit':frozen['parentCommit'],"
assert s.count(marker) == 1
s = s.replace(marker, '''    r8 = repo/'target/higher-order-inference-acceptance-20261114-r8'
    eighth = read(r8/'launch-state.json')
    assert eighth['conclusion'] == 'failure'
    assert eighth['platforms']['mac']['exit'] == eighth['platforms']['windows']['exit'] == 1
    partial = read(r8/'accepted-native/measurement.json')
    gt7_native = next(row for row in partial['suites'] if row['harness'].endswith('/gt7_library_manifest.rs'))
    assert gt7_native['conclusion'] == 'success' and gt7_native['passed'] == 7
    assert read(r8/'owned-mac-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
    preserved8 = root/'r8-oracle-failure-preservation-1'
    receipt8 = read(preserved8/'receipt.json')
    assert receipt8['wholeAcceptanceCredit'] == 0 and receipt8['sourceFiles'] == len(receipt8['files']) == 14738
    assert sha(preserved8/'frozen-source.tar.gz') == receipt8['archiveSha256']
    assert sha(preserved8/'actual-native-cli') == receipt8['actualNativeCompilerSha256']
    with tarfile.open(preserved8/'frozen-source.tar.gz','r|gz') as archive:
        source8 = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                   for member in archive if member.isfile()}
    assert source8 == receipt8['files']
    windows8 = r8/'windows/failed-evidence-preservation-1'
    checked8 = read(windows8/'state.json')
    assert checked8['conclusion'] == 'success' and checked8['originalFailureUnchanged']
    assert checked8['verifiedSourceFiles'] == 14822
    assert sha(windows8/'failed-evidence.tar.gz') == checked8['archiveSha256']
    assert '"code":6053' in (r8/'windows/gt7-failure-observation-1/gt7_library_manifest.stderr').read_text()
    with tarfile.open(windows8/'failed-evidence.tar.gz','r|gz') as archive:
        windows_sources = {member.name[len('source/'):]:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                           for member in archive if member.isfile() and member.name.startswith('source/')}
    assert windows_sources == read(r8/'windows/windows-source-manifest.json')['files']
    failures['r8'] = {'audit':str((windows8/'state.json').relative_to(repo)),
        'sha256':sha(windows8/'state.json'),'acceptanceCredit':0,
        'completePackageFailedAt':'Windows-gt7-Native-virtual-host-path',
        'preservedMacSourceFiles':14738,'preservedWindowsSourceFiles':14822,
        'nativeGt7Passed':7,'remainingMacTestsExplicitlyStopped':True}
''' + marker)
s = s.replace("['r4','r5','r6','r7']","['r4','r5','r6','r7','r8']")
p.write_text(s)

p = root/'g_preserve_evidence.py'
s = p.read_text()
marker = "('failed-r7',REPO/'target/higher-order-inference-acceptance-20261114-r7'),"
assert s.count(marker) == 1
s = s.replace(marker,marker+"\n        ('failed-r8',REPO/'target/higher-order-inference-acceptance-20261114-r8'),")
s = s.replace('five failed full-acceptance attempts','six failed full-acceptance attempts')
p.write_text(s)

p = root/'g_finalize_docs.py'
s = p.read_text()
start = s.index('All seven quality steps are bound to the final source.')
end = s.index('The earlier Windows run passed its tests,',start)
s = s[:start]+'''The r8 Windows run then exposed a G-T7 Native virtual-host path defect:
the recorder compared raw platform filenames and TypeScript reported 6053
for a virtual source. Five G-T7 public tests passed; its two external-oracle
tests failed. The same complete Mac cohort passed all seven tests. That failed
full run retains all 14,738 Mac source/build files, all 14,822 Windows source
files, actual compilers/test executable, original logs and terminal outcomes.
The remaining owned Mac tests were explicitly stopped after source preservation.
The recorder now uses the existing cross-platform virtual compiler host.
Native source strings, expectations and declaration bytes are unchanged.
All 434 Native observations, 14 library controls, five owner controls and the
unchanged complete Windows seven-test cohort pass in separate preflights.
The temporary Windows preflight overlay is restored byte for byte afterward.

All seven final-source quality steps run afresh, including eleven affected
cohorts with the complete higher-order and G-T7 tests. Earlier four-plus-three
quality provenance remains historical evidence and is not reused as final
quality credit. The complete final Native catalog has 1088 functions because
both supplementary public regression tests are permanent.

''' + s[end:]
p.write_text(s)

for p in root.rglob('*.py'):
    ast.parse(p.read_text(),filename=str(p))
for p in root.rglob('*.cjs'):
    subprocess.run(['node','--check',str(p)],check=True)
shutil.copy2(__file__,root/Path(__file__).name)
(root/'prepared.json').write_text(json.dumps({'conclusion':'preview-not-launched' if preview else 'prepared-not-launched',
    'runtimeDrivers':names[:17],'expectedSourceRevision':'backend-tree:9f6e4f033200e519f62f3573685b6cbe04f873a3',
    'backendUnchanged':True,'oracleToolChanges':1,'freshQualitySteps':7,
    'expectedNativeSuites':191,'expectedNativeFunctions':1088,'expectedWindowsCohorts':26,
    'originalR8FailurePreserved':True,'preview':preview,'acceptanceCredit':0,
    'qualityConclusionWhenPrepared':q['conclusion'],'completedQualitySteps':len(q['steps'])},indent=2)+'\n')
print(json.dumps({'prepared':str(root),'preview':preview,'launched':False,'acceptanceCredit':0}))
