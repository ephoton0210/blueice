# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Stop only the verified owned Cargo subtree after preserving the r9 failure."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

repo = Path('/Users/ephoton/git/blueice-bluets')
root = repo/'target/higher-order-inference-acceptance-20261114-r9'
preserved = repo/'target/higher-order-inference-contract-20261114/r9-diagnostics-version-failure-preservation-1'
read = lambda p: json.loads(p.read_bytes())
receipt = read(preserved/'receipt.json')
assert receipt['conclusion'] == 'source-preserved-before-test-repair'
assert receipt['sourceFiles'] == 14738 and receipt['wholeAcceptanceCredit'] == 0
failure = (preserved/'original-diagnostics-failure.log').read_bytes()
assert hashlib.sha256(failure).hexdigest() == receipt['failureLogSha256']
assert failure in (root/'workspace.log').read_bytes()
out = root/'owned-workspace-stop-1'
out.mkdir()
shutil.copy2(__file__,out/Path(__file__).name)
state = {'conclusion':'in_progress','signals':[],
    'reason':'The genuine diagnostics version assertion failed (v13 actual/v12 expected). Source, both actual compilers and failed test executable are preserved before stopping the remaining owned workspace work.',
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceArchiveSha256':receipt['archiveSha256'],'wholeAcceptanceCredit':0}
def save():
    (out/'receipt.json').write_text(json.dumps(state,indent=2)+'\n')
def processes():
    result = {}
    for line in subprocess.check_output(['ps','-axo','pid=,ppid=,state=,command='],text=True).splitlines():
        a = line.strip().split(None,3)
        if len(a) == 4:
            result[int(a[0])] = {'parent':int(a[1]),'status':a[2],'command':a[3]}
    return result
def send(pid,kind):
    try:
        os.kill(pid,kind)
        state['signals'].append({'pid':pid,'signal':kind.name})
    except ProcessLookupError:
        state['signals'].append({'pid':pid,'signal':kind.name,'alreadyExited':True})

save()
snapshot = processes()
assert snapshot[80863]['parent'] == 27749
assert snapshot[80863]['command'].endswith('higher-order-inference-acceptance-20261114-r9/run_local_gates.py')
jobs = [pid for pid,item in snapshot.items() if item['parent'] == 80863
        and item['command'] == 'cargo test --workspace --no-fail-fast --locked --offline'
        and not item['status'].startswith('Z')]
assert len(jobs) <= 1, jobs
owned = set(jobs)
identities = {pid:snapshot[pid] for pid in jobs}
for pid in jobs:
    send(pid,signal.SIGSTOP)
for _ in range(4):
    current = processes()
    while True:
        children = {pid:item for pid,item in current.items()
                    if pid not in owned and item['parent'] in owned and not item['status'].startswith('Z')}
        if not children:
            break
        for pid,item in children.items():
            owned.add(pid)
            identities[pid] = item
            send(pid,signal.SIGSTOP)
    time.sleep(0.2)
state['ownedProcesses'] = {str(pid):item for pid,item in identities.items()}
save()
for pid in reversed(list(identities)):
    send(pid,signal.SIGTERM)
    send(pid,signal.SIGCONT)
for _ in range(30):
    current = processes()
    alive = {pid:item for pid,item in current.items() if pid in owned and not item['status'].startswith('Z')}
    if not alive:
        break
    time.sleep(0.5)
assert not alive,alive
assert failure in (root/'workspace.log').read_bytes()
state.update(conclusion='owned-workspace-subtree-stopped' if jobs else 'already-terminal-no-signals-needed',
    verifiedNoLiveOwnedTestProcesses=True,originalDiagnosticsFailureUnchanged=True,
    finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
print(json.dumps({k:v for k,v in state.items() if k != 'ownedProcesses'}))
