# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Audit every retained E baseline product against frozen P0-F expectations."""
from pathlib import Path
import hashlib
import json


def audit(root, repo):
    sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    read = lambda path: json.loads(path.read_bytes())
    paths = list((root / 'baseline').glob('*/report.json'))
    assert len(paths) == 1
    path = paths[0]
    report = read(path)
    fixture = repo / 'backend/bluets/tests/fixtures/conditional_inference'
    frozen = read(fixture / 'FROZEN.json')
    baseline = report['baseline']
    assert baseline == frozen['productionBaseline']
    assert baseline['commit'] == 'd4694f775e8d3e1ef2b45bc438ddaca7b8ac080c'
    assert baseline['sourceRevision'] == 'backend-tree:02abdba6835124bb585bf13149d5b6dcaf072911'
    assert baseline['compilerSha256'] == sha(root / 'baseline-cli') == '683cc89a0417661178c05b7bfd2a0abab19e0088616562fc30744a3fe28576f6'
    assert report['frozenInputs'] == frozen['sha256']
    expected = {row['id']: row for row in read(fixture / 'reference.json')['cases']}
    assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 384
    assert {row['id'] for row in report['cases']} == set(expected)
    agreements = published_count = 0
    hashes = {}
    for row in report['cases']:
        wanted = {key: expected[row['id']][key] for key in ['accepts', 'diagnostics', 'declarations']}
        ordinary_path = path.parent / row['id'] / 'observation.json'
        assert read(ordinary_path) == row
        outputs = {file.relative_to(ordinary_path.parent / 'dist').as_posix(): file.read_bytes()
                   for file in (ordinary_path.parent / 'dist').rglob('*') if file.is_file()}
        assert {name: hashlib.sha256(data).hexdigest() for name, data in outputs.items()} == row['outputsSha256']
        declarations = {name: data.decode('utf-8') for name, data in outputs.items() if name.endswith('.d.ts')}
        assert declarations == row['observed']['declarations']
        published = not wanted['accepts'] and bool(outputs)
        agrees = row['observed'] == wanted
        assert row['agrees'] == agrees and row['publishedOnRejectedNativeInput'] == published
        assert row['observed']['accepts'] == (row['exit'] == 0) and row['signal'] is None
        agreements += agrees
        published_count += published
        hashes[row['id']] = sha(ordinary_path)
    assert report['comparisons'] == 384
    assert report['completeAgreements'] == agreements == 144
    assert report['completeDifferences'] == 384 - agreements == 240
    assert report['publishedOnRejectedNativeInputs'] == published_count == 16
    return {'report': str(path.relative_to(root)), 'sha256': sha(path),
            'sourceCommit': baseline['commit'], 'sourceRevision': baseline['sourceRevision'],
            'compilerSha256': baseline['compilerSha256'], 'comparisons': 384,
            'completeAgreements': 144, 'completeDifferences': 240,
            'rawObservationSha256': hashes, 'acceptanceCredit': False}


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    result = audit(root, root.parent.parent)
    (root / 'baseline-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rawObservationSha256'}))
