# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Bounded archive groups and small, separately hashed member manifests."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import json
import tarfile

PREFIX = 'CONDITIONAL_INFERENCE_'
LIMIT = 95 * 1024 * 1024
GROUP_BYTES = 64 * 1024 * 1024
MANIFEST_ROWS = 4000


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def write_json(path, value):
    data = (json.dumps(value, indent=2) + '\n').encode()
    if path.exists():
        assert path.read_bytes() == data, ('refuse to replace published evidence', path)
    else:
        with path.open('xb') as output:
            output.write(data)
    return {'path': path.name, 'bytes': len(data), 'sha256': digest(path)}


def safe_name(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '..' not in path.parts, name
    return name


def verify_archive(path, entries):
    expected = {row['path']: row for row in entries}
    seen = set()
    with tarfile.open(path, 'r|gz') as archive:
        for member in archive:
            safe_name(member.name)
            assert member.isfile() and member.name in expected and member.name not in seen
            seen.add(member.name)
            row = expected[member.name]
            assert member.size == row['bytes']
            value = hashlib.sha256()
            source = archive.extractfile(member)
            for block in iter(lambda: source.read(1024 * 1024), b''):
                value.update(block)
            assert value.hexdigest() == row['sha256'], member.name
    assert seen == set(expected)


def publish_group(root, phase, source_revision, label, paths):
    batches, batch, length = [], [], 0
    for path in sorted(paths):
        assert path.is_file() and not path.is_symlink(), path
        size = path.stat().st_size
        assert size < 80 * 1024 * 1024, ('unreviewed oversized member', path, size)
        if batch and length + size > GROUP_BYTES:
            batches.append(batch)
            batch, length = [], 0
        batch.append(path)
        length += size
    if batch:
        batches.append(batch)
    result = []
    for index, paths in enumerate(batches, 1):
        destination = phase / f'{PREFIX}{label}_{index:02}.tar.gz'
        entries = [{'path': safe_name(path.relative_to(root).as_posix()),
                    'bytes': path.stat().st_size, 'sha256': digest(path)} for path in paths]
        if not destination.exists():
            temporary = destination.with_suffix('.gz.tmp')
            assert not temporary.exists(), ('inspect an interrupted archive before retry', temporary)
            with temporary.open('xb') as raw:
                with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
                    with tarfile.open(fileobj=compressed, mode='w|') as archive:
                        for path, entry in zip(paths, entries):
                            info = archive.gettarinfo(str(path), arcname=entry['path'])
                            info.uid = info.gid = 0
                            info.uname = info.gname = ''
                            info.mtime = 0
                            info.mode &= 0o777
                            with path.open('rb') as source:
                                archive.addfile(info, source)
            assert temporary.stat().st_size < LIMIT
            verify_archive(temporary, entries)
            temporary.rename(destination)
        else:
            verify_archive(destination, entries)
        assert destination.stat().st_size < LIMIT
        manifests = []
        for start in range(0, len(entries), MANIFEST_ROWS):
            name = destination.name.removesuffix('.tar.gz') + f'_MEMBERS_{start // MANIFEST_ROWS + 1:02}.json'
            part = entries[start:start + MANIFEST_ROWS]
            manifest = write_json(phase / name, {'schema': 1, 'sourceRevision': source_revision,
                'archive': destination.name, 'entries': part})
            manifest['members'] = len(part)
            manifests.append(manifest)
        result.append({'path': destination.name, 'bytes': destination.stat().st_size,
            'sha256': digest(destination), 'members': len(entries), 'memberManifests': manifests})
        print('ARCHIVED', destination.name, destination.stat().st_size, flush=True)
    return result
