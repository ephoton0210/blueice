# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
import datetime, re
from audit_acceptance import ROOT, PHASE, read, sha

PREFIX = 'STRING_INTRINSIC_'

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old,new,1)

def main():
    data = read(PHASE / (PREFIX + 'MEASUREMENT.json'))
    audit = read(ROOT / 'acceptance-audit.json')
    assert data['conclusion'] == 'completed-within-frozen-scope'
    assert audit['conclusion'] == 'success' and audit['sourceRevision'] == data['source']['sourceRevision']
    for row in data['artifacts']:
        assert sha(PHASE / row['path']) == row['sha256']
    source = data['source']['sourceRevision']; native = data['nativeMeasurement']; workspace = data['gates']['workspace']
    date = datetime.date.today().isoformat()
    acceptance = f'''# P0-C — Shared string-intrinsic acceptance

Accepted {date}, source `{source}`, against pinned TypeScript5.9.3.
The [measurement]({PREFIX}MEASUREMENT.json), [artifact manifest]({PREFIX}ARTIFACTS.json)
and [frozen follow-up]({PREFIX}FOLLOWUP.md) bind this finite package.
All22 broader feature rows remain open; full TypeScript parity remains **OFF**.

Uppercase, Lowercase, Capitalize and Uncapitalize use shared bounded operations.
Lossless UTF-16 units retain semantic identity separately from source spelling
and physical declaration serialization. Upper/lower conversion handles scalar
runs and contextual sigma; capitalize/uncapitalize transforms the first code unit.
Unpaired units remain distinct from each other and U+FFFD in type/debugger identity.

Intrinsic definitions retain their declaring symbol and obey Native defining-name
and arity checks. Ordinary local/imported/ambient definitions retain precedence.
Shared substitution, inference, relations, union/template expansion and declaration
alias recovery preserve computed and symbolic results. Static intrinsic names
grant no runtime authority. Configured work/depth refusal remains ResourceLimit
without a Native counterpart or output; no any/unknown fallback was introduced.

Generated literal contexts now survive ordinary and array/tuple inference and
diagnostics. Template spelling suggestions read semantic string values. The
pre-ES2019 JavaScript string pass escapes raw line/paragraph separators while
preserving continuations, comments and raw template chunks; it uses mapped edits
and participates in compiler fingerprints.

| Frozen acceptance | Actual result |
| --- | --- |
| Primary programs | 245 authored forms × four profiles =980 complete comparisons |
| Verdicts and diagnostics | 772 accepts /208 rejects; all primary/related diagnostics and UTF-16 positions match |
| Declarations, per actual compiler | 772 exact inventories /804 physical declaration files |
| Isolated consumers | 1544 positive/negative declaration-only Native consumers |
| Syntax/runtime | 804 selected-edition parses and16 executions |
| Separate boundaries | Four ambient owners, four runtime-authority refusals and12 configured work/parser-depth controls |
| Supplementary regressions | Ten separately calibrated array/tuple/call/overload rows; no added primary or inventory credit |
| Full Native catalog | {native['suites']} suites /{native['functions']} functions; zero failed, ignored or filtered |
| Full local workspace | {workspace['passed']:,} passed; zero failed; ignored functions selected in full Native above |
| Full maps | Fresh process-bound8407×2 reports for both actual local compiler profiles; zero differences |
| Windows x86_64 | Same-source82 core oracles,25 paths and nine complete regression cohorts |
| Projects/tooling | defu, mitt, prerequisite reproductions and interchange; fmt, warnings-denied workspace/all-targets Clippy, Node/Python and accounting pass |
| Production module size | 559 files; maximum1477 lines; none above1500 |

The unchanged accepted-B compiler has32/980 complete agreements. Its exact
compiler, source binding and all raw baseline observations are preserved. The
same22-name/two-profile presence witnesses now pass44/44; this is no semantic
percentage and adds no cases to the frozen denominator.

All40636 earlier suite-qualified IDs and comparison/status/scope/reason classes
remain unchanged. The980 direct and20 separate policy assertions add1000,
making **N=41636**. These assertions are neither unique programs nor a language
coverage percentage. The supplementary ten regression rows add no inventory credit.

Failed authoring attempts and the retired C6 formal candidate retain their raw
diagnostics and exact source evidence, without whole-candidate pass credit.
C6 passed its initial C suite but failed existing G-T3 and diagnostic matrices;
the final source was remeasured completely. C8 authoring preflight passed before
the final source freeze. Both complete C6/C8 backend snapshots were independently
hashed. Earlier standalone/core results remain preparation evidence.

All actual compiler profiles, complete source snapshots, raw logs, per-case
observations, consumers and map bindings are retained in hashed archives.
Two unchanged older integration harnesses remain maintenance debt outside the
production-module audit. Hosted CI, extra OS profiles and coverage remain
supplementary to the accepted full-local/Windows82 boundary.

P0-C is complete within this frozen scope. Broader inference/operator/library
compositions require new explicit contracts and independent Native expectations.
'''
    (PHASE / (PREFIX + 'ACCEPTANCE.md')).write_text(acceptance)
    path = PHASE / (PREFIX + 'FOLLOWUP.md'); text = path.read_text()
    status = next(line for line in text.splitlines() if line.startswith('Status:'))
    text = replace_once(text,status,'Status: completed within the frozen scope. See [acceptance](STRING_INTRINSIC_ACCEPTANCE.md), [measurement](STRING_INTRINSIC_MEASUREMENT.json) and [artifacts](STRING_INTRINSIC_ARTIFACTS.json). All22 broader feature rows remain open; full parity remains OFF.')
    marker = 'The complete C8 authoring preflight passed.'
    assert marker in text
    text = text[:text.index(marker)] + f'''The complete C8 authoring preflight passed before source freeze. Final source
`{source}` passed all187 Native suites /1064 functions, the full local workspace,
both fresh8407×2 map reports, all projects and tooling checks, and Windows82 core
oracles plus25 paths and nine full regression cohorts. See the acceptance and
measurement above for exact compiler/source/artifact bindings. The supplementary
ten rows remain outside the primary/inventory denominator; all40636 old case
classes are unchanged and1000 new assertions produce N41636.
'''
    path.write_text(text)
    path = PHASE / 'TODO.md'; text = path.read_text()
    a = text.index('**Latest completed follow-up:**'); b = text.index('\n## Open gaps',a)
    text = text[:a] + '''**Latest completed follow-up:** P0-C supplies the four string intrinsics through
shared bounded UTF-16 operations, preserving source-owner identity and separate
runtime/resource boundaries. [Acceptance](STRING_INTRINSIC_ACCEPTANCE.md) binds
the complete Native/local/Windows gates, exact declarations, consumers, maps and
project regressions to its source. P0-A/P0-B retain their dated evidence.
All22 broader rows remain open; continue prioritizing shared inference/operator/
library compositions using newly frozen counterexamples.
''' + text[b:]
    a = text.index('The [current presence witnesses]'); b = text.index('\n- [x] **P0-A',a)
    text = text[:a] + '''The [current presence witnesses](STRING_INTRINSIC_MEASUREMENT.json#/presenceInventory/corrected)
pass all22 names in both selected profiles. These44 witnesses carry no semantic
denominator credit; broader catalogs and compositions remain open. The three
finite packages below have complete source-bound acceptance.
''' + text[b:]
    pattern = r'- \[ \] \*\*P0-C — One string-intrinsic implementation for four utilities\.\*\*.*?(?=\n\nEach package needs)'
    replacement = '''- [x] **P0-C — One string-intrinsic implementation for four utilities.** Delivered
  245 forms × four profiles =980 complete comparisons, with772 accepted exact
  inventories /804 declaration files,1544 isolated consumers,804 syntax checks
  and16 executions per actual compiler. Twenty owner/runtime/resource controls
  remain separate; ten supplemental context regressions add no inventory credit.
  Complete same-source Native/local/Windows, maps, projects and tooling pass.
  All40636 earlier cases/classes remain unchanged;1000 new assertions bring N to
  41636. [Acceptance](STRING_INTRINSIC_ACCEPTANCE.md) ·
  [measurement](STRING_INTRINSIC_MEASUREMENT.json). Broader rows remain open.'''
    text,count = re.subn(pattern,replacement,text,flags=re.S); assert count == 1
    text = text.replace('Continue with P0-C.','Continue with newly frozen shared inference/operator/library counterexamples.')
    (PHASE / 'TODO.md').write_text(text)
    path = PHASE / 'STANDARD_LIBRARY.md'; text = path.read_text()
    old = 'resource controls remain separate. Uppercase, Lowercase, Capitalize,\nUncapitalize and broader library compositions remain open.'
    new = '''resource controls remain separate. Broader library compositions remain open.

The [string-intrinsic follow-up](STRING_INTRINSIC_ACCEPTANCE.md) supplies Uppercase,
Lowercase, Capitalize and Uncapitalize through shared bounded UTF-16 operations.
Its980 complete comparisons require804 exact declaration files,1544 isolated
consumers,804 parses and16 executions per actual compiler. Four ambient owners,
four runtime-authority refusals and12 resource controls remain separate. Ten
supplementary context regressions add no inventory credit. No runtime binding
is installed; wider utility/catalog compositions remain open.'''
    path.write_text(replace_once(text,old,new))
    print('Rendered accepted C evidence and checked only P0-C after complete publication.',flush=True)

if __name__ == '__main__':
    main()
