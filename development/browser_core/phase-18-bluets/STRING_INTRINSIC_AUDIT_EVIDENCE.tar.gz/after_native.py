# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, time

repo = Path('/Users/ephoton/git/blueice-bluets')
root = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = read(root / 'frozen-source-preflight.json')
state_path = root / 'post-native.json'
assert not state_path.exists(), 'Inspect the existing supervisor before any retry'
state = {'pid': os.getpid(), 'sourceRevision': frozen['sourceRevision'],
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'stage': 'verify-native-driver', 'conclusion': 'in_progress', 'steps': []}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = root / 'post-native.tmp'; p.write_text(json.dumps(state, indent=2) + '\n')
    p.replace(state_path)

def driver_matches(command):
    args = shlex.split(command)
    return (bool(args) and Path(args[0]).name.lower().startswith('python')
            and Path(args[-1]).name == 'run_native_gates.py'
            and Path(args[-1]).parent.name == root.name)

def source_check():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == frozen['parentCommit']
    for name, digest in frozen['files'].items():
        assert sha(repo / name) == digest, name

try:
    save(); native = read(root / 'native-gates.json')
    assert native['sourceRevision'] == frozen['sourceRevision']
    if native['conclusion'] == 'in_progress':
        matches = []
        for line in subprocess.check_output(['ps', '-axo', 'pid,command'], text=True).splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) == 2 and driver_matches(parts[1]):
                matches.append(int(parts[0]))
        assert len(matches) == 1, ('Native driver identity count', len(matches))
        state['nativeDriverPid'] = matches[0]
        state['nativeDriverIdentityVerified'] = True
        state['stage'] = 'waiting-native'; save()
        print('VERIFIED LIVE Native driver', matches[0], flush=True)
        while True:
            native = read(root / 'native-gates.json')
            if native['conclusion'] != 'in_progress':
                break
            observed = subprocess.run(['ps', '-p', str(matches[0]), '-o', 'command='], capture_output=True, text=True)
            if observed.returncode or not driver_matches(observed.stdout.strip()):
                native = read(root / 'native-gates.json')
                assert native['conclusion'] != 'in_progress', 'Native driver ended without terminal acceptance evidence; do not restart'
                break
            state['nativeProcessVerifiedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat(); save()
            time.sleep(10)
    assert native['conclusion'] == 'success', native.get('error', native['conclusion'])
    report = read(root / 'accepted-native/measurement.json')
    assert report['conclusion'] == 'success' and report['source_revision'] == frozen['sourceRevision']
    assert len(report['suites']) == frozen['expectedNativeSuites'] == 187
    assert sum(s['passed'] for s in report['suites']) == frozen['expectedNativeFunctions'] == 1064
    assert all(s['failed'] == s['ignored'] == s['filtered'] == 0 for s in report['suites'])
    assert sha(root / 'accepted-native-cli') == native['nativeCompilerSha256'] == report['compilerSha256']
    state['verifiedNative'] = {'suites':187, 'functions':1064, 'measurementSha256':sha(root / 'accepted-native/measurement.json')}; save()
    for label, name in [('projects', 'run_project_gates.py'), ('local', 'run_local_gates.py')]:
        source_check(); state['stage'] = label; save()
        log = root / (label + '-driver.log')
        print('START', label, flush=True)
        with log.open('xb') as output:
            child = subprocess.Popen(['python3', '-B', str(root / name)], cwd=repo, stdout=output, stderr=subprocess.STDOUT)
            state['childPid'] = child.pid; save(); code = child.wait()
        state['steps'].append({'label':label, 'exit':code, 'log':log.name, 'sha256':sha(log)}); save()
        print('END', label, code, flush=True)
        assert code == 0, (label, code)
    source_check(); state.update(stage='local-complete-awaiting-windows-and-publication', conclusion='success',
                                finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()); save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error), finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(); raise
