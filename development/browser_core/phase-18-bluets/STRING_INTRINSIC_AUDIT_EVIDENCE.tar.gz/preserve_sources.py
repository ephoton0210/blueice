# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, json, shutil, subprocess, tarfile

repo = Path('/Users/ephoton/git/blueice-bluets')
root = Path(__file__).resolve().parent
old = repo / 'target/string-intrinsics-acceptance-20261113-r1'
output = root / 'source-snapshots'; output.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipts = []
for label, source in [('retired-c6', old), ('frozen-c8', root)]:
    manifest = json.loads((source / 'frozen-source-preflight.json').read_bytes())
    expected = manifest['files']; destination = output / (label + '-backend.tar.gz')
    args = ['git', 'archive', '--format=tar', '--prefix=backend/', manifest['backendTree']]
    child = subprocess.Popen(args, cwd=repo, stdout=subprocess.PIPE)
    with destination.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as archive:
            shutil.copyfileobj(child.stdout, archive, length=1024 * 1024)
    assert child.wait() == 0
    observed = {}
    with tarfile.open(destination, 'r|gz') as archive:
        for member in archive:
            relative = PurePosixPath(member.name)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert member.isdir() or member.isfile(), member.name
            if member.isdir():
                continue
            assert member.name in expected and member.name not in observed, member.name
            digest = hashlib.sha256(); data = archive.extractfile(member)
            for chunk in iter(lambda: data.read(1024 * 1024), b''):
                digest.update(chunk)
            assert digest.hexdigest() == expected[member.name], member.name
            observed[member.name] = digest.hexdigest()
    assert set(observed) == set(expected)
    receipt = {'label':label, 'sourceRevision':manifest['sourceRevision'],
               'archive':destination.name, 'archiveBytes':destination.stat().st_size,
               'archiveSha256':sha(destination), 'verifiedFiles':len(observed),
               'sourceManifestSha256':sha(source / 'frozen-source-preflight.json'),
               'everyCanonicalBackendFileVerified':True, 'memberSha256':observed,
               'acceptanceCredit':False, 'scope':'Exact source preservation only; acceptance is recorded separately.'}
    (output / (label + '-verification.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    receipts.append({k:v for k,v in receipt.items() if k!='memberSha256'})
    print(json.dumps(receipts[-1]), flush=True)
(output / 'manifest.json').write_text(json.dumps({'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sources':receipts}, indent=2) + '\n')
