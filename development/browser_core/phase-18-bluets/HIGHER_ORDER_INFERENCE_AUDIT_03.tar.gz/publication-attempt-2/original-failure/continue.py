# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Publish successful gates with an independently verified packaging-only recovery."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

DELIVERY = Path(__file__).resolve().parent
REPO = DELIVERY.parent.parent
ROOT = DELIVERY.parent/'higher-order-inference-acceptance-20261114-r10'
STATE = DELIVERY/'state.json'
SOURCE = 'backend-tree:7be6eb17296278ce86fe4a5d6a5de1c40259f9bb'
assert not STATE.exists(), 'Observe the existing continuation; do not restart'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = {'pid':os.getpid(), 'conclusion':'in_progress',
    'stage':'observing-existing-platform-acceptance', 'sourceRevision':SOURCE,
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'steps':[], 'commitPerformed':False, 'pushPerformed':False}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(STATE)


def observe_process(pid, suffix):
    process = subprocess.run(['ps','-p',str(pid),'-o','command='],text=True,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert process.returncode == 0 and process.stdout.strip().endswith(suffix), (
        'Expected supervisor missing or changed; inspect retained state, never relaunch', pid,
        process.stdout, process.stderr)
    state['lastSupervisorProcessVerifiedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()


def run(label,args):
    state['stage'] = label
    save()
    log = DELIVERY/(label+'.log')
    with log.open('xb') as output:
        child = subprocess.Popen(args,cwd=REPO,stdout=output,stderr=subprocess.STDOUT)
        state['childPid'] = child.pid
        save()
        code = child.wait()
    state.pop('childPid',None)
    state['steps'].append({'label':label,'command':args,'exit':code,
        'log':log.name,'sha256':sha(log)})
    save()
    assert code == 0, label+': inspect preserved '+str(log)


try:
    save()
    assert (ROOT/'launch-state.json').exists(), 'Start only after the existing launcher has a receipt'
    initial = read(ROOT/'launch-state.json')
    state.update(stage='observing-existing-platform-acceptance',observedAcceptancePid=initial['pid'])
    save()
    while True:
        observed = read(ROOT/'launch-state.json')
        assert observed['pid'] == initial['pid']
        if 'sourceRevision' in observed:
            assert observed['sourceRevision'] == SOURCE
        if observed['conclusion'] != 'in_progress':
            break
        observe_process(initial['pid'],'higher-order-inference-acceptance-20261114-r10/launch.py')
        time.sleep(10)
    assert observed['conclusion'] == 'failure', observed
    assert observed['sourceRevision'] == SOURCE
    assert observed['stage'] == 'platform-failure-observing-other-running-platform'
    assert set(observed['platforms']) == {'mac','windows'}
    assert observed['platforms']['mac']['exit'] == 0
    assert observed['platforms']['windows']['exit'] == 1
    assert read(ROOT/'mac-driver.json')['conclusion'] == 'success'
    assert read(ROOT/'windows/complete-state.json')['conclusion'] == 'failure'
    recovery = ROOT.parent/'higher-order-inference-contract-20261114/r10-windows-packaging-recovery-1/state.json'
    while read(recovery)['conclusion'] == 'in_progress':
        state['stage'] = 'waiting-existing-packaging-recovery'
        save()
        time.sleep(10)
    assert read(recovery)['conclusion'] == 'success'
    old_delivery = ROOT.parent/'higher-order-inference-delivery-20261114-r10/state.json'
    while read(old_delivery)['conclusion'] == 'in_progress':
        time.sleep(10)
    assert read(old_delivery)['conclusion'] == 'failure'
    sys.path.insert(0,str(ROOT))
    from g_acceptance_audit import verified_platform_completion
    verified_platform_completion()
    state['stage'] = 'snapshot-publication-tools'
    save()
    snapshot = ROOT/'publication-start-snapshot'
    snapshot.mkdir()
    tool_hashes = {}
    for path in sorted(ROOT.glob('*.py'))+sorted(ROOT.glob('*.cjs')):
        shutil.copy2(path,snapshot/path.name)
        tool_hashes[path.name] = sha(path)
    shutil.copy2(__file__,ROOT/'publication-supervision-source.py')
    (ROOT/'publication-start-manifest.json').write_text(json.dumps({
        'sourceRevision':SOURCE,'allPlatformProcessesTerminal':True,
        'tools':tool_hashes,'supervisionSourceSha256':sha(Path(__file__)),
        'scope':'Post-acceptance publication and document verification; command logs live outside the immutable artifact collection.'},indent=2)+'\n')
    phase = REPO/'development/browser_core/phase-18-bluets'
    steps = [
        ('publish',[sys.executable,'-B',str(ROOT/'g_publish.py')]),
        ('verify-before-todo',[sys.executable,'-B',str(ROOT/'g_verify_publication.py'),'--before-todo']),
        ('finalize-docs',[sys.executable,'-B',str(ROOT/'g_finalize_docs.py')]),
        ('verify-after-todo',[sys.executable,'-B',str(ROOT/'g_verify_publication.py')]),
        ('account-check',[sys.executable,str(phase/'tools/account_inventory_rows.py'),'--check']),
        ('status-check',[sys.executable,str(phase/'tools/check_compatibility_status.py'),'--check']),
        ('diff-check',['git','diff','--check']),
    ]
    for label,args in steps:
        assert all(sha(ROOT/name) == digest for name,digest in tool_hashes.items())
        run(label,args)
    state.update(conclusion='success',
        stage='publication-verified-docs-ready-awaiting-diff-review-commit-push',
        measurementSha256=sha(phase/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'))
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
