# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Recheck earlier finite contracts against the two actual G acceptance compilers."""
import hashlib
import json
from g_audit_mapped import audit as mapped
from audit_symbolic_keys import audit as symbolic
from audit_conditional_inference import audit as conditional


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def physical(directory, row):
    for name, text in row['declarations'].items():
        assert (directory/'dist'/name).read_bytes() == text.encode('utf-8'), (directory,name)
    for name, digest in row.get('javascriptSha256',{}).items():
        assert sha(directory/'dist'/name) == digest, (directory,name)
    if row.get('accepts') is False:
        assert not any((directory/'dist').rglob('*'))


def audit(root, repo, source, gates):
    configurations = [
        ('noinfer','noinfer',['reference.json'],'blue-*/report.json',282,153,159,306,159,6,False),
        ('nonnullable-awaited','nonnullable_awaited',['reference.json','operator-reference.json'],
            'blue-*/report.json',396,315,331,630,331,12,True),
        ('string-intrinsics','string_intrinsics',['reference.json'],
            'bluets-string-intrinsics-blue-*/report.json',980,772,804,1544,804,16,True),
    ]
    result = {}
    for family,folder,references,pattern,total,accepted,declarations,consumers,syntax,runtime,ordinary in configurations:
        fixture = repo/'backend/bluets/tests/fixtures'/folder
        gold = [read(fixture/name) for name in references]
        expected = {row['id']:row for reference in gold for row in reference['cases']}
        assert len(expected) == total and sum(row['accepts'] for row in expected.values()) == accepted
        result[family] = {}
        for kind in ['native','workspace']:
            base = root/(kind+'-capture')/family
            found = list(base.glob(pattern))
            assert len(found) == 1, (family,kind,found)
            path = found[0]
            report = read(path)
            assert report['conclusion'] in ['pass','success'] and report['sourceRevision'] == source
            assert report['compilerSha256'] == gates[kind+'CompilerSha256']
            assert report['implementationSha256'] == gold[0]['implementationSha256']
            assert report['libraries'] == gold[0]['libraries']
            assert (report['declarationFiles'],report['consumers'],report['syntax'],report['runtime']) == (
                declarations,consumers,syntax,runtime)
            all_verdicts = family == 'string-intrinsics'
            selected = expected if all_verdicts else {key:row for key,row in expected.items() if row['accepts']}
            assert len(report['cases']) == len({row['id'] for row in report['cases']}) == len(selected)
            assert {row['id'] for row in report['cases']} == set(selected)
            for row in report['cases']:
                wanted = selected[row['id']]
                assert row['declarations'] == wanted['declarations']
                assert row.get('consumers') == wanted.get('consumers')
                assert row.get('runtime') == wanted.get('runtime')
                if all_verdicts:
                    assert all(row[key] == wanted[key] for key in ['accepts','diagnostics'])
                physical(path.parent/row['id'],row)
            ordinary_hashes = {}
            if ordinary:
                for ident,wanted in expected.items():
                    observation_path = base/ident/'observation.json'
                    observed = read(observation_path)
                    assert observed['agrees'] and not observed['publishedOnRejectedNativeInput']
                    assert all(observed[key] == wanted[key] for key in ['id','accepts','diagnostics','declarations'])
                    physical(observation_path.parent,observed)
                    ordinary_hashes[ident] = sha(observation_path)
            supplementary = {}
            if family == 'noinfer':
                extra = list(base.glob('regressions-*/report.json'))
                assert len(extra) == 1
                observed = read(extra[0])
                assert observed['conclusion'] == 'pass' and observed['sourceRevision'] == source
                assert observed['compilerSha256'] == gates[kind+'CompilerSha256']
                assert len(observed['cases']) == 4 and all(row['agrees'] for row in observed['cases'])
                assert observed['inputSha256'] == sha(fixture/'keyof-diagnostics.json')
                supplementary['keyof'] = {'path':str(extra[0].relative_to(root)),'sha256':sha(extra[0])}
            elif family == 'nonnullable-awaited':
                controls = read(fixture/'demand-reference.json')['cases']
                assert len(controls) == 6
                for wanted in controls:
                    observation_path = base/'demand'/wanted['id']/'observation.json'
                    observed = read(observation_path)
                    assert observed['agrees'] and not observed['publishedOnRejectedNativeInput']
                    assert all(observed[key] == wanted[key] for key in ['accepts','diagnostics','declarations'])
                    physical(observation_path.parent,observed)
                    supplementary[wanted['id']] = {'path':str(observation_path.relative_to(root)),
                        'sha256':sha(observation_path)}
            else:
                controls = read(fixture/'literal-context-regressions.json')['cases']
                assert len(controls) == 10
                for wanted in controls:
                    observation_path = base/'literal-context-regressions'/wanted['id']/'observation.json'
                    observed = read(observation_path)
                    assert all(observed[key] == wanted[key] for key in ['id','accepts','diagnostics','declarations'])
                    physical(observation_path.parent,observed)
                    supplementary[wanted['id']] = {'path':str(observation_path.relative_to(root)),
                        'sha256':sha(observation_path)}
            result[family][kind] = {'path':str(path.relative_to(root)),'sha256':sha(path),
                'compilerSha256':gates[kind+'CompilerSha256'],'primaryComparisons':total,
                'declarationFiles':declarations,'consumers':consumers,'syntax':syntax,'runtime':runtime,
                'ordinaryObservationsSha256':ordinary_hashes,'supplementary':supplementary}
    result['mapped-inference'] = mapped(root,repo,source,gates)
    result['symbolic-keys'] = symbolic(root,repo,source,gates)
    result['conditional-inference'] = conditional(root,repo,source,gates)
    return result
