# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Audit P0-G completion from actual source, complete gates and physical products."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
from audit_higher_order_inference import audit_products
from g_prior_audit import audit as prior_contracts
from g_role_audit import audit as role_reports
from g_history_audit import audit as history
from g_recursive_scope_audit import audit as recursive_scope
from g_windows_packaging_recovery import audit as packaging_recovery

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PHASE = REPO/'development/browser_core/phase-18-bluets'


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            value.update(block)
    return value.hexdigest()


def command(*args):
    return subprocess.check_output(args,cwd=REPO,text=True).strip()


def summaries(text):
    return [(status,*map(int,counts)) for status,*counts in re.findall(
        r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',text)]


def verify_steps(report,expected,hash_key='sha256',base=ROOT):
    assert report['conclusion'] == 'success'
    labels = [step['label'] for step in report['steps']]
    assert set(labels) == set(expected) and len(labels) == len(set(labels))
    for step in report['steps']:
        assert step['exit'] == 0 and sha(base/step['log']) == step[hash_key],step['label']


def original_discovery(source,gates):
    directory = ROOT/'original-discovery24'
    discovery = REPO/'target/higher-order-inference-discovery-20261114'
    assert (directory/'inputs.json').read_bytes() == (discovery/'inputs.json').read_bytes()
    inputs = read(directory/'inputs.json')
    expected = {row['id']:row for row in read(directory/'native-reference.json')['cases']}
    primary = {row['id']:row for row in read(REPO/'backend/bluets/tests/fixtures/higher_order_inference/cases.json')['cases']}
    assert len(expected) == len(inputs['cases']) == 24
    for row in inputs['cases']:
        assert row['source'] == primary[row['id']]['source']
        assert row['files'] == primary[row['id']].get('files',{})
    bindings = {}
    for kind in ['native','workspace']:
        path = directory/('replay-'+kind)/'report.json'
        observed = read(path)
        assert observed['conclusion'] == 'success' and observed['inventoryCredit'] == 0
        assert observed['sourceRevision'] == source and observed['compilerSha256'] == gates[kind+'CompilerSha256']
        assert observed['inputSha256'] == sha(directory/'inputs.json')
        assert len(observed['cases']) == len({row['id'] for row in observed['cases']}) == 24
        for row in observed['cases']:
            assert row['agrees'] and not row['publishedOnRejectedNativeInput']
            wanted = expected[row['id']]
            assert row['observed'] == {key:wanted[key] for key in ['accepts','diagnostics','declarations']}
            project = path.parent/'blue'/row['id']
            assert read(project/'tsconfig.json')['compilerOptions'] == inputs['options']
            assert (project/'main.ts').read_bytes() == primary[row['id']]['source'].encode()
            for name,text in wanted['declarations'].items():
                assert (project/'dist'/name).read_bytes() == text.encode('utf-8')
            if not wanted['accepts']:
                assert not any((project/'dist').rglob('*'))
        bindings[kind] = {'path':str(path.relative_to(ROOT)),'sha256':sha(path),'comparisons':24,'inventoryCredit':0}
    return bindings


def verified_platform_completion():
    frozen = read(ROOT/'frozen-source-preflight.json')
    launch = read(ROOT/'launch-state.json')
    assert launch['conclusion'] == 'failure'
    assert launch['stage'] == 'platform-failure-observing-other-running-platform'
    assert launch['sourceRevision'] == frozen['sourceRevision']
    assert set(launch['platforms']) == {'mac','windows'}
    assert launch['platforms']['mac']['exit'] == 0
    assert launch['platforms']['windows']['exit'] == 1
    assert read(ROOT/'mac-driver.json')['conclusion'] == 'success'
    recovery = packaging_recovery(ROOT)
    path = ROOT/'windows/windows-acceptance-verification.json'
    verified = read(path)
    assert verified['conclusion'] == 'success' and verified['sourceRevision'] == frozen['sourceRevision']
    assert verified['regressionCohorts']['gm2_incremental_options'] == {'passed':7,'failed':0,'ignored':0,'filtered':0}
    assert verified['regressionCohorts']['higher_order_inference'] == {'passed':7,'failed':0,'ignored':0,'filtered':0}
    assert sha(ROOT/'verify_windows.py') == sha(ROOT/'orchestration-start-snapshot/verify_windows.py')
    assert verified['archiveSha256'] == sha(ROOT/'windows-evidence.tar.gz')
    return {'conclusion':'all-required-platform-gates-proven',
        'originalLauncherConclusion':'failure','windowsSupervisorConclusion':'failure',
        'packagingRecovery':recovery,
        'windowsVerification':'windows/windows-acceptance-verification.json',
        'windowsVerificationSha256':sha(path),'windowsArchiveSha256':verified['archiveSha256']}


def audit():
    frozen = read(ROOT/'frozen-source-preflight.json')
    source = frozen['sourceRevision']
    platform_completion = verified_platform_completion()
    mac = read(ROOT/'mac-driver.json')
    assert mac['conclusion'] == 'success' and mac['sourceRevision'] == source
    assert mac['stage'] == 'mac-gates-complete-awaiting-windows-and-publication'
    for name,digest in mac['driverHashes'].items():
        assert sha(ROOT/name) == sha(ROOT/'orchestration-start-snapshot'/name) == digest,name
    assert command('git','rev-parse','HEAD') == frozen['parentCommit']
    tree = command('git','write-tree')
    assert command('git','rev-parse',tree+':backend') == frozen['backendTree']
    assert not command('git','diff','--name-only','--','backend','development/browser_core/phase-18-bluets/tools')
    for name,digest in frozen['files'].items():
        assert sha(REPO/name) == digest,name
    backend = sorted(name for name in frozen['files'] if name.startswith('backend/'))
    actual = subprocess.check_output(['git','ls-files','-z','--','backend'],cwd=REPO).decode().split(chr(0))[:-1]
    assert set(actual) == set(backend) and len(backend) == frozen['backendFiles'] == 14117
    assert hashlib.sha256('\0'.join(sorted(backend,key=lambda name:name.encode())).encode()).hexdigest() == frozen['backendPathSetSha256']
    quality = REPO/'target/higher-order-inference-contract-20261114/diagnostics-version-worktree-quality-1'
    assert sha(quality/'measurement.json') == frozen['qualityMeasurementSha256']
    assert sha(quality/'source-manifest.json') == frozen['qualityManifestSha256']
    assert read(quality/'source-manifest.json') == frozen['files']
    verify_steps(read(quality/'measurement.json'),['library','affected-callers','call-chain-regressions','fmt','clippy','node-tools','python-tools'],'logSha256',quality)
    quality_report = read(quality/'measurement.json')
    assert all('reusedFrom' not in row for row in quality_report['steps'])
    assert re.search(r'Ran 13 tests in ',(quality/'python-tools.log').read_text())
    assert (quality/'python-tools.log').read_text().rstrip().endswith('OK')
    superseded = quality.parent/'promise-worktree-quality-3'
    previous_files = read(superseded/'source-manifest.json')
    recorder = 'development/browser_core/phase-18-bluets/tools/record_gt7_library_manifest.cjs'
    assert set(previous_files) == set(frozen['files'])
    assert [name for name,value in previous_files.items() if frozen['files'][name] != value] == ['backend/bluets/tests/diagnostics.rs',recorder]
    probe = quality.parent/'gt7-host-windows-preflight-1/measurement.json'
    observed = read(probe)
    assert observed['conclusion'] == 'success' and observed['passed'] == 7
    assert observed['failed'] == observed['ignored'] == observed['filtered'] == 0
    assert observed['originalGuestSourceRestoredExactly'] and observed['nativeReferenceUnchanged']
    assert observed['repairedRecorderSha256'] == frozen['files'][recorder]
    replay = quality.parent/'gt7-host-worktree-preflight-1/native-replay-result.json'
    assert read(replay)['conclusion'] == 'success' and read(replay)['nativeObservations'] == 434
    preflight_provenance = {'sourceIdenticalReusedSteps':0,'freshCompleteExactSourceSteps':7,'freshPythonTests':13,
        'acceptedPreflight':'development-history/contract/diagnostics-version-worktree-quality-1/measurement.json',
        'acceptedPreflightSha256':sha(quality/'measurement.json'),
        'supersededPreflight':'development-history/contract/promise-worktree-quality-3/measurement.json',
        'supersededPreflightSha256':sha(superseded/'measurement.json'),
        'supersededManifest':'development-history/contract/promise-worktree-quality-3/source-manifest.json',
        'supersededManifestSha256':sha(superseded/'source-manifest.json'),
        'windowsHostPreflight':'development-history/contract/gt7-host-windows-preflight-1/measurement.json',
        'windowsHostPreflightSha256':sha(probe),
        'nativeHostReplay':'development-history/contract/gt7-host-worktree-preflight-1/native-replay-result.json',
        'nativeHostReplaySha256':sha(replay),'changedTool':recorder,
        'previousToolSha256':previous_files[recorder],'repairedToolSha256':frozen['files'][recorder],
        'sourceManifestSha256':sha(quality/'source-manifest.json'),'earlierFailedOutcomesPreserved':True,'publicDiagnosticsTests':10,
        'sourceDifferencesSinceSupersededPreflight':['backend/bluets/tests/diagnostics.rs',recorder]}
    diagnostics = re.search(r'Running tests/diagnostics\.rs[^\n]*\n(.*?)(?=\n\s*Running tests/|\Z)',(quality/'call-chain-regressions.log').read_text(),re.S)
    assert diagnostics and 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in diagnostics.group(1)
    native_gates = read(ROOT/'native-gates.json')
    project_gates = read(ROOT/'project-gates.json')
    local_gates = read(ROOT/'local-gates.json')
    for report in [native_gates,project_gates,local_gates]:
        assert report['sourceRevision'] == source
    verify_steps(native_gates,['suite-write','source-check','case-audit','native-build','native'])
    verify_steps(project_gates,['project-defu','project-mitt','project-reproductions','project-interchange'])
    verify_steps(local_gates,['cases-write','suite-labels','account-write','status-write','workspace-build','workspace',
        'workspace-callable-oracles','workspace-receiver-oracles','workspace-noinfer-oracles',
        'workspace-nonnullable-awaited-oracles','workspace-string-intrinsics-oracles',
        'workspace-mapped-inference-oracles','workspace-symbolic-keys-oracles','workspace-conditional-inference-oracles',
        'workspace-higher-order-inference-oracles','workspace-noinfer-regressions','fmt-check','clippy',
        'node-tools','python-tools','source-final','cases-final','account-final','status-final'])
    gates = {**local_gates,'steps':native_gates['steps']+project_gates['steps']+local_gates['steps']}
    assert gates['nativeCompilerSha256'] == native_gates['nativeCompilerSha256'] == project_gates['compilerSha256']
    native = read(ROOT/'accepted-native/measurement.json')
    catalog = read(PHASE/'COMPATIBILITY_SUITES.json')
    tools = read(ROOT/'frozen-final-oracle-tools.json')['sha256']
    for name,digest in tools.items():
        assert sha(PHASE/'tools'/name) == frozen['files']['development/browser_core/phase-18-bluets/tools/'+name] == digest
    assert len(tools) == frozen['oracleToolFilesExpected'] == 618
    assert native['conclusion'] == 'success' and native['source_revision'] == catalog['source_revision'] == source
    assert native['oracle_tools_sha256'] == tools and native['suite_jobs'] == 4
    assert native['runner_script_sha256'] == sha(ROOT/'measure_priority.cjs')
    assert native['compilerSha256'] == gates['nativeCompilerSha256']
    assert len(native['suites']) == len(catalog['suites']) == len(set(native['execution_order'])) == 191
    assert set(native['execution_order']) == {row['harness'] for row in catalog['suites']}
    for row in native['suites']:
        assert row['conclusion'] == 'success' and row['exit_code'] == 0
        assert row['failed'] == row['ignored'] == row['filtered'] == 0
        assert len(row['test_names']) == len(set(row['test_names'])) == row['passed']
        suite = next(suite for suite in catalog['suites'] if suite['harness'] == row['harness'])
        assert sorted(row['pinned_tests']) == sorted(suite['ignored_tests'])
        log = ROOT/'accepted-native'/row['log']
        assert sha(log) == row['log_sha256']
        assert summaries(log.read_text())[-1] == ('ok',row['passed'],0,0,0)
    assert sum(row['passed'] for row in native['suites']) == 1088
    higher_order_suite = next(row for row in native['suites']
        if row['harness'] == 'backend/bluets/tests/higher_order_inference.rs')
    prefix_test = 'returned_calls_preserve_prefix_result_types_and_argument_checks'
    assert higher_order_suite['passed'] == 7 and prefix_test in higher_order_suite['test_names']
    contract = REPO/'target/higher-order-inference-contract-20261114'
    module_control = contract/'call-chain-module-green-3/report.json'
    module_red = read(contract/'call-chain-module-red-1/report.json')
    candidate = read(contract/'promise-worktree-regressions-1/measurement.json')
    module_green = read(module_control)
    assert module_green['conclusion'] == 'success' and module_green['agreements'] == 7
    assert len(module_green['cases']) == 7 and all(row['agrees'] for row in module_green['cases'])
    assert module_red['conclusion'] == 'measured-differences' and module_red['agreements'] == 3
    assert module_green['compilerSha256'] == candidate['actualCompilerSha256'] == sha(contract/'promise-worktree-regressions-1/actual-cli')
    assert all(frozen['files'].get(name) == digest for name,digest in candidate['source'].items())
    assert len(candidate['source']) == 582 and set(candidate['source']) < set(frozen['files'])
    assert 'backend/bluets/tests/diagnostics.rs' not in candidate['source']
    assert not any(name.startswith('development/browser_core/phase-18-bluets/tools/') for name in candidate['source'])
    prefix_regressions = {'permanentTest':prefix_test,'permanentPublicControls':4,
        'inventoryCredit':0,'preflightModuleComparisons':7,'oldPreflightDifferences':4,
        'newPreflightDifferences':0,'preflightReport':'development-history/contract/call-chain-module-green-3/report.json',
        'preflightReportSha256':sha(module_control),'preflightCompilerSha256':module_green['compilerSha256'],
        'preflightRecordedInputsMatchAcceptance':True,'preflightRecordedInputs':582,
        'preflightManifestIsSubsetOfAcceptance':True,'preflightSourceDifference':[],
        'preflightDoesNotCoverAllTestsOrOracleTools':True,'preflightDoesNotReplaceFinalCompilerTests':True}
    assert (PHASE/'COMPATIBILITY_MEASUREMENT.json').read_bytes() == (ROOT/'accepted-native/measurement.json').read_bytes()
    workspace = summaries((ROOT/'workspace.log').read_text())
    assert workspace and all(status == 'ok' and failed == filtered == 0 for status,passed,failed,ignored,filtered in workspace)
    assert sum(row[1] for row in workspace) == gates['workspace']['passed']
    assert sum(row[3] for row in workspace) == gates['workspace']['ignored']
    assert len(workspace) == gates['workspace']['groups']
    def cases(value):
        return {(suite['harness'],row['id']):{key:row.get(key) for key in ['comparison','status','scope','reason']}
            for suite in value['suites'] for row in suite['cases']}
    before = cases(read(ROOT/'baseline-cases.json'))
    after = cases(read(PHASE/'COMPATIBILITY_CASES.json'))
    assert len(before) == 42716 and len(after) == 43112
    assert all(after.get(key) == value for key,value in before.items())
    added = set(after)-set(before)
    assert len(added) == 396 and all(key[0] == 'backend/bluets/tests/higher_order_inference.rs' for key in added)
    assert gates['casePreservation'] == {'previous':42716,'current':43112,'added':396,'allOldCasesUnchanged':True}
    bindings,product_reports = {},{}
    for kind in ['native','workspace']:
        compiler = gates[kind+'CompilerSha256']
        assert sha(ROOT/('accepted-'+kind+'-cli')) == compiler
        binding = read(ROOT/(kind+'-map-binding.json'))
        report_path = ROOT/(kind+'-declaration-map-report.json')
        report = read(report_path)
        assert binding['verified'] and binding['sourceRevision'] == source
        assert binding['compilerSha256'] == compiler == sha(Path(binding['compilerSnapshot']))
        assert sha(Path(binding['testExecutableSnapshot'])) == binding['testExecutableSha256']
        assert binding['reportFreshSinceBinding'] and binding['reportSha256'] == sha(report_path)
        assert binding['reportModifiedEpoch'] >= binding['reportNotBeforeEpoch']
        assert datetime.datetime.fromisoformat(binding['observedAt']).timestamp() <= binding['reportModifiedEpoch']
        assert report['configurations'] == 8407 and report['buildsPerConfiguration'] == 2 and not report['differences']
        bindings[kind] = binding
        base = ROOT/(kind+'-capture/higher-order-inference')
        names = [path.relative_to(ROOT).as_posix() for path in base.rglob('*') if path.is_file()]
        product_reports[kind] = audit_products(REPO,source,compiler,kind+'-capture/higher-order-inference',
            names,lambda name:(ROOT/name).read_bytes(),kind == 'native')
    projects = {}
    for name in ['defu','mitt','reproductions','interchange']:
        path = ROOT/('project-'+name)/'report.json'
        report = read(path)
        assert report['sourceRevision'] == source and report['compilerSha256'] == gates['nativeCompilerSha256']
        if name in ['defu','mitt']:
            assert report['compatible']
        elif name == 'reproductions':
            assert report['verdictAgreements'] == 8
        else:
            assert report['conclusion'] == 'current-policy-verified'
        projects[name] = {'path':str(path.relative_to(ROOT)),'sha256':sha(path)}
    windows = read(ROOT/'windows/windows-acceptance-verification.json')
    assert windows['conclusion'] == 'success' and windows['sourceRevision'] == source
    assert windows['coreOracles'] == 82 and windows['paths'] == 25 and windows['virtualHostRegressions'] == 6
    assert len(windows['regressionCohorts']) == 27
    assert windows['allSelectedNamesPassedExactly'] and windows['allCanonicalBackendPathsVerified']
    assert windows['actualCompilerArchiveHashMatches'] and windows['archiveSha256'] == sha(ROOT/'windows-evidence.tar.gz')
    assert windows['regressionCohorts']['diagnostics'] == {'passed':10,'failed':0,'ignored':0,'filtered':0}
    assert windows['higherOrderInferenceReports']['comparisons'] == 384
    modules = []
    for folder in ['backend/bluets/src','backend/bluets-bluejs/src']:
        for path in (REPO/folder).rglob('*'):
            if path.is_file() and (path.suffix == '.rs' or path.name.endswith('.d.ts')):
                modules.append({'path':path.relative_to(REPO).as_posix(),'sha256':sha(path),
                    'lines':len(path.read_bytes().splitlines())})
    assert len(modules) == 580 and all(row['lines'] < 1500 for row in modules)
    scope_records = recursive_scope(ROOT,REPO,source,gates)
    return {'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion':'success','sourceRevision':source,'nativeSuites':191,'nativeFunctions':1088,
        'workspace':gates['workspace'],'gates':gates,'casePreservation':gates['casePreservation'],
        'higherOrderReports':product_reports,'priorContractReports':prior_contracts(ROOT,REPO,source,gates),
        'nativeRoleReports':role_reports(ROOT,REPO,native,gates),'preimplementationHistory':history(REPO),
        'prefixRegressions':prefix_regressions,
        'recursiveScopeRegressions':scope_records['recursive'],
        'promiseScopeRegressions':scope_records['promise'],
        'preflightProvenance':preflight_provenance,
        'platformCompletion':platform_completion,
        'originalDiscovery24':original_discovery(source,gates),'mapBindings':bindings,'projects':projects,
        'windows':windows,'moduleFiles':len(modules),'maximumModuleLines':max(row['lines'] for row in modules),
        'moduleSources':modules,'broaderFeatureRowsOpen':22,'fullTypeScriptParity':False}


if __name__ == '__main__':
    result = audit()
    path = ROOT/'g-acceptance-audit.json'
    assert not path.exists(),'Retain every audit attempt'
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items()
        if key in ['conclusion','sourceRevision','nativeSuites','nativeFunctions','workspace','casePreservation']}))
