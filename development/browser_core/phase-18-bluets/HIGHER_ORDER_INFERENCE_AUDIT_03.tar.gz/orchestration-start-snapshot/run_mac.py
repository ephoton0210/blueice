# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent.parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state_path = root / 'mac-driver.json'
assert not state_path.exists(), 'Inspect the existing handle; never restart a live run'
frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
state = {'pid':os.getpid(),'conclusion':'in_progress','stage':'preflight','steps':[],
    'sourceRevision':frozen['sourceRevision'],
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
snapshot = root / 'orchestration-start-snapshot'
snapshot.mkdir()
driver_names = [
    'launch.py','run_mac.py','freeze_source.py','prepare_windows.py',
    'upload_windows.py','complete_windows.py','finish_windows.py','verify_windows.py',
    'run_native_gates.py','measure_priority.cjs','run_project_gates.py',
    'run_local_gates.py','watch_maps.py','replay_original_discovery.cjs',
    'audit_symbolic_keys.py','audit_conditional_inference.py','audit_higher_order_inference.py',
]
# Freeze every file used by the platform acceptance processes. Independent
# publication tools run only after both processes are terminal and preserve
# their own code in the final evidence; they are not runtime test drivers.
for path in sorted(root/name for name in driver_names):
    shutil.copy2(path,snapshot / path.name)
state['driverHashes'] = {path.name:sha(path) for path in sorted(snapshot.iterdir())}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = state_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(state_path)

def unchanged():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == frozen['parentCommit']
    assert all(sha(repo / name) == digest for name,digest in frozen['files'].items())
    assert all(sha(root / name) == digest for name,digest in state['driverHashes'].items())

def run(label,args,environment=None):
    unchanged()
    state['stage'] = label
    save()
    print('START',label,flush=True)
    log = root / (label+'-driver.log')
    with log.open('xb') as output:
        child = subprocess.Popen(args,cwd=repo,env=environment,stdout=output,stderr=subprocess.STDOUT)
        state['childPid'] = child.pid
        save()
        code = child.wait()
    state['steps'].append({'label':label,'command':args,'exit':code,'log':log.name,'sha256':sha(log)})
    state.pop('childPid',None)
    save()
    print('END',label,code,flush=True)
    assert code == 0, label

watcher = None
try:
    save()
    unchanged()
    with (root/'maps-driver.log').open('xb') as log:
        watcher = subprocess.Popen([sys.executable,'-B',str(root/'watch_maps.py')],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    state['mapWatcherPid'] = watcher.pid
    save()
    environment = dict(os.environ,
        BLUEICE_BLUETSC_ORACLE=str(repo/'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'),
        BLUEICE_ACORN_ORACLE=str(repo/'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn'))
    for label,script in [('native','run_native_gates.py'),('projects','run_project_gates.py'),('local','run_local_gates.py')]:
        run(label,[sys.executable,'-B',str(root/script)])
        if label in ['native','local']:
            profile = 'native' if label == 'native' else 'workspace'
            run('original-discovery24-'+profile,['node',str(root/'replay_original_discovery.cjs'),profile],environment)
    state['stage'] = 'waiting-map-bindings'
    save()
    code = watcher.wait()
    state['mapWatcherExit'] = code
    assert code == 0
    unchanged()
    state.update(conclusion='success',stage='mac-gates-complete-awaiting-windows-and-publication')
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    if watcher is not None and watcher.poll() is None:
        watcher.terminate()
        state['mapWatcherExit'] = watcher.wait()
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
