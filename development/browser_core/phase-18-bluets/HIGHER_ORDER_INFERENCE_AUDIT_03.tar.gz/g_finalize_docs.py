# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Record finite G completion only after source-bound publication verification."""
import re
from g_acceptance_audit import ROOT,PHASE,read,sha


def main():
    verified=read(ROOT/'g-publication-before-todo-verification.json')
    measurement=PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'
    data=read(measurement)
    source=data['source']['sourceRevision']
    assert verified['conclusion']=='success' and verified['todoExpectedOpen'] is True
    assert verified['archiveOnly'] is False and verified['measurementSha256']==sha(measurement)
    assert verified['sourceRevision']==source and data['conclusion']=='completed-within-frozen-scope'
    assert data['broaderFeatureRowsOpen']==22 and data['fullTypeScriptParity'] is False
    workspace=data['gates']['workspace'];modules=data['modules']
    acceptance=f'''# P0-G — Higher-order generic inference and callable identities

Accepted within the frozen P0-G contract. Compiler source: `{source}`.
The frozen manifest separately identifies all 618 oracle-tool files and the
platform runtime drivers. The backend revision alone does not identify tooling.

Higher-order inference preserves eligible parameters introduced by a generic
callable argument, including constraints, defaults, rest positions and lexical
owner identities. Returned callables can be specialized and called sequentially.
Contextual signature inputs retain their parameter shape; non-propagating
boundaries retain Native unknown behavior. Copied private/imported callables
retain exact `typeof` identities and declaration spelling. Fresh wrappers keep
their own call-site identity and diagnostic origin. Existing budgets are unchanged.

Both actual Mac compiler profiles replay the original 24 programs and options
unchanged. All complete primary/related diagnostics, UTF-16 positions and physical
declaration bytes match pinned TypeScript 5.9.3. No sorting or newline repair is used.

| Acceptance requirement | Verified result |
| --- | --- |
| Primary matrix | 48 forms × 8 profiles = 384 comparisons; 352 accepted, 32 rejected |
| Exact declarations | 424 files per actual compiler |
| Isolated declaration consumers | 704 positive/negative programs per actual compiler |
| Selected-edition syntax / execution | 424 parses /48 executions per actual compiler |
| Separate owner/runtime/resource controls | 12; excluded from direct-agreement credit |
| Supplementary ES5 emission/label controls | Eight; zero inventory credit |
| Permanent prefix-call controls | Four public CLI programs; zero inventory credit |
| Recursive callback scope controls | 16 complete observations per actual compiler: 14 accepts, two rejects, 16 declaration files; zero inventory credit |
| Library alias capture controls | 12 complete observations per actual compiler: six accepts, six rejects, six declaration files; zero inventory credit |
| Complete Native catalog | 191 suites /1088 functions; zero failed, ignored or filtered |
| Complete local workspace | {workspace['passed']} passed; {workspace['failed']} failed; {workspace['ignored']} ignored, with the complete Native catalog selected separately |
| Declaration/JavaScript maps | 8407 configurations ×2 builds per actual Mac compiler profile; zero differences |
| Complete Native role families | 28, with two ordinary partial reports explicitly excluded from family credit |
| Real projects | defu, mitt, reproductions and interchange pass |
| Windows x86_64 | Same source: 82 core oracles, 25 path cases and 27 selected complete regression cohorts and six virtual-host checks |
| Tooling | Format, warnings-denied workspace/all-target Clippy, Node/Python and accounting checks pass |
| Module size | {modules['files']} production Rust/declaration files; maximum {modules['maximumLines']} lines |

The preimplementation freeze, independent Native replay and test-first red run
precede production edits. The complete accepted-parent baseline has 48 agreements
and 336 differences, and the red run independently reproduces all 384 observations.
Every frozen primary difference is repaired with zero new primary differences.
All 42,716 earlier assertion IDs and their comparison/status/scope/reason classes
are unchanged. The 384 primary observations plus 12 separate controls add 396
assertions, yielding N=43,112. Supplemental controls and original-profile replay
add no denominator credit. Rejected inputs publish no artifacts.

Earlier candidate build, ES5 syntax and label-boundary failures are retained.
The first full acceptance exposed a TS2589 diagnostic-span regression. The
second exposed a Windows G-T10 virtual-host path defect. The third exposed
ordinary library-call routing regressions in unary result types and generator
diagnostics. Their original sources, compilers, logs and partial Windows outputs
are preserved with zero acceptance credit. Returned-call routing now preserves
the original member-call checker, while prefix operands still validate arguments.
Seven additional module controls improve from four differences to full agreement.
An ad hoc script declaration difference also reproduces on the accepted parent;
that broader declaration gap remains open and is not credited as repaired here.

A preflight-only attempt failed Python accounting after an interrupted run left
an obsolete generated catalog. That failure and the subsequent source-identical
metadata repair remain historical evidence. A later full run passed all 191
Native suites/1086 functions, then exposed a new defu cold-build rejection:
closed callback-local generic names reopened the recursive caller's inference
candidate. That original full run, both delivery failures, actual compiler and
complete source are preserved. Renaming the upstream generic was used only to
localize the defect; the unchanged upstream source is used for acceptance.

Sixteen separately frozen ES5/ES2022 controls reproduce ten incorrect
rejections and two incomplete diagnostic differences before repair. Dependency
checks now shield callback binders in constraints, defaults, parameters and
results while preserving real outer captures. Equally quantified generic return
errors retain their nested reason, and empty object defaults emit exact `{{}}`
bytes. Inference, diagnostic and declaration cache versions advance together.
All sixteen complete observations and the entire unchanged defu acceptance pass.
A subsequent preflight-only launch encountered a transient Git index lock
before source freeze or either platform started. That terminal r7 failure and
its original log are retained. The fresh r8 launcher retries only the specific
Git write-tree index-lock error at most five times, retaining every failed
command and error. It never deletes a lock or reclassifies that failed launch.

The r8 Windows run then exposed a G-T7 Native virtual-host path defect:
the recorder compared raw platform filenames and TypeScript reported 6053
for a virtual source. Five G-T7 public tests passed; its two external-oracle
tests failed. The same complete Mac cohort passed all seven tests. That failed
full run retains all 14,738 Mac source/build files, all 14,822 Windows source
files, actual compilers/test executable, original logs and terminal outcomes.
The remaining owned Mac tests were explicitly stopped after source preservation.
The recorder now uses the existing cross-platform virtual compiler host.
Native source strings, expectations and declaration bytes are unchanged.
All 434 Native observations, 14 library controls, five owner controls and the
unchanged complete Windows seven-test cohort pass in separate preflights.
The temporary Windows preflight overlay is restored byte for byte afterward.

The r9 run passed all 191 Native suites/1088 functions, four real projects and
Windows82/25paths/26 complete cohorts. Its workspace then exposed a stale test
epoch: the public diagnostics test still expected v12 after diagnostic semantics
advanced to v13. All frozen source, both actual Mac compilers, failed test binary
and original failure are preserved. The remaining owned workspace work was
explicitly stopped. Only that test expectation changes; no compiler or oracle
byte changes. All ten public diagnostics tests pass. The final Windows cohort
selection also includes these ten tests and requires 27 complete cohorts.

The r10 Windows tests passed all 82 oracles, 25 path cases, 27 complete cohorts
and six virtual-host checks. Its original evidence packager still required the
old 26-cohort set, so packaging and the original supervisors retain failure.
A separate packaging-only recovery corrects that count and adds diagnostics to
the exact target set, writes fresh archive/receipt names, and uses the unchanged
frozen Windows verifier. The terminal test measurement remains byte-identical;
no compiler, source, runtime driver or completed test is changed or rerun.
The completion audit binds the successful Mac gates and recovered Windows
archive while preserving the original failed packaging and launcher outcomes.

All seven final-source quality steps run afresh, including eleven affected
cohorts with the complete higher-order and G-T7 tests, plus the complete ten-test
public diagnostics boundary. Earlier four-plus-three
quality provenance remains historical evidence and is not reused as final
quality credit. The complete final Native catalog has 1088 functions because
both supplementary public regression tests are permanent.

The earlier Windows run passed its tests, then exposed an audit-only expected
count error: an eighth G-M2 source function is guarded by `#[cfg(unix)]`. Its
original verifier failure and separate seven-function correction are retained
without rerunning or rewriting that historical test run. The final Windows run
is fresh, uses the final source and its frozen verifier, and records each
cohort's actual compiled function list. All compiled names must match the passed
names exactly, including seven G-M2, seven higher-order and seven G-T7 functions, with zero
ignored or filtered functions. Supplementary scope products are independently
checked on both actual Mac compiler profiles and Windows as well.

The following complete Native run exposed two original G-T7 Promise adoption
regressions: a nested Promise was inferred instead of adopting its resolved
value. That failed source, actual compiler/test executable and partial results
remain unchanged. Only the remaining owned Mac test subtree was stopped; its
supervisors recorded failure normally. The old Windows run completed and its
archive was independently verified before the main source changed.

Twelve further inputs were frozen before an isolated repair; the old compiler
agreed on twelve while the failing compiler differed on six. Alias arguments
now retain their enclosing parameter's scoped identity before nested generic
methods introduce same-spelled binders. This corrects the ownership collision
without a Promise-specific branch and retains the earlier closed-callback fix.
All twelve new and sixteen earlier supplementary observations pass. Both full
higher-order and G-T7 cohorts, four real projects and the source-bound quality
steps pass before integration. Exactly five repair/test/fixture files are
integrated after the old Windows evidence is final. Fresh complete final
Native/workspace/Windows acceptance then runs against the integrated source.

[Measurement](HIGHER_ORDER_INFERENCE_MEASUREMENT.json),
[artifact index](HIGHER_ORDER_INFERENCE_ARTIFACTS.json),
[independent verification](HIGHER_ORDER_INFERENCE_VERIFICATION.json),
[contract/history](HIGHER_ORDER_INFERENCE_FOLLOWUP.md) and
[reproduction guide](HIGHER_ORDER_INFERENCE_REPRODUCTION.md) retain complete
source/authority snapshots, actual compilers, raw products/logs and pinned
oracle packages with licenses. Every bounded archive and member is hashed;
large original files reconstruct byte for byte from ordered verified chunks.

Only finite P0-G is complete. All 22 broader rows remain open and full TypeScript
parity stays OFF. Hosted CI and other platforms remain supplementary to the
user-approved complete-local/Windows82 acceptance boundary.
'''
    reproduction='''# Reproduce the frozen P0-G boundary

Select the source and actual compiler profile from
`HIGHER_ORDER_INFERENCE_MEASUREMENT.json`. Verify its artifact-index hash, every
archive hash and every separately hashed member manifest before extracting into
a fresh directory under this checkout's `target/`. Each archive entry is a
regular relative file; reject duplicate names, absolute paths, parent traversal
and links. Do not overwrite an existing observation or acceptance directory.

The archives preserve complete backend/oracle source in `source-snapshots/files`,
accepted cases/suites/measurement in `authority-snapshots`, original compilers,
an accepted-source patch and all raw products/logs. The Windows archive also
preserves complete selected workspace source including root Cargo files.
`oracle-dependencies.tar.gz` retains TypeScript 5.9.3 and Acorn 8.15.0 regular files,
their licenses and third-party notices. No npm installation is required.

After verifying/extracting the indexed archives, run their retained helpers:

```sh
python3 -B /absolute/restored/g_restore_large_members.py
python3 -B /absolute/restored/g_verify_publication.py --archive-only
```

The first reconstructs every original large member with exact sizes, hashes and
file modes. Failed partial reconstructions are retained under distinct names.
The second verifies archive/member bytes, source/authority snapshots, both actual
compiler profiles' physical G products, all bindings and preserved earlier
failures. Archive-only verification supports a later checkout without asserting
that its current source is the historical accepted source. It does not rerun tests.

From a checkout/materialization of the recorded source, restore the oracle
archive to a separate directory and set absolute paths:

```sh
export BLUEICE_BLUETSC_ORACLE=/absolute/oracles/node_modules/typescript/bin/tsc
export BLUEICE_ACORN_ORACLE=/absolute/oracles/node_modules/acorn/bin/acorn
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
cargo test -p blueice-bluets --test higher_order_inference -- --include-ignored
```

That suite checks 384 complete CLI observations,12 separate API policy controls,
four prefix-call regression controls,16 separately frozen recursive-scope
observations,12 separately frozen generic-library capture observations and fresh
Native/BlueTS declaration
consumers, selected-edition syntax and execution. Frozen references are
verification-only; they must not be replaced with BlueTS results.

To compare an archived actual compiler without rebuilding it:

```sh
node development/browser_core/phase-18-bluets/tools/record_higher_order_inference.cjs --verify
export BLUEICE_HIGHER_ORDER_INFERENCE_COMPILER=/absolute/accepted-compiler
export BLUEICE_HIGHER_ORDER_INFERENCE_EXPECTED_COMPILER_SHA256=the-selected-actual-sha256
export BLUEICE_HIGHER_ORDER_INFERENCE_SOURCE_REVISION=the-recorded-backend-tree
export BLUEICE_HIGHER_ORDER_INFERENCE_OBSERVATIONS=/absolute/fresh-observations
node development/browser_core/phase-18-bluets/tools/verify_higher_order_inference.cjs
```

These focused commands do not constitute complete acceptance. The full gate
requires all 191 Native suites/1088 functions, full workspace tests, both actual
Mac profiles' 8407×2 map reports, four real-project gates, format, warnings-denied
workspace/all-target Clippy, Node/Python and accounting checks. Windows requires
82 core oracles, 25 path cases and 27 selected complete regression cohorts and six host regressions.
Retained runtime scripts include original machine paths and fresh-run guards;
adapt paths into a new output namespace without rewriting earlier receipts.
The final Windows verifier compares every cohort's actual compiled function
catalog with every passed name and expected platform count. It requires seven
G-M2 functions because the eighth source function is Unix-only. Historical r5 verifier/supervisor failures and their separate correction,
and the r6 G-T7/owned-stop/Windows evidence remain unchanged in
`development-history/failed-r5` and `development-history/failed-r6`; they do not
replace fresh final acceptance.

All 22 broader feature rows remain open. N counts suite-qualified assertions,
not unique programs or a percentage of TypeScript language support.
'''
    todo_path=PHASE/'TODO.md';todo=todo_path.read_text()
    assert '- [ ] **P0-G —'in todo
    start=todo.index('- [ ] **P0-G —');end=todo.index('\n\nEach package',start)
    row='''- [x] **P0-G — Higher-order generic inference and callable identities.**
  All 384 frozen complete observations,424 declaration files,704 consumers,
  424 parses and 48 executions per actual compiler pass. Twelve separate policy
  controls, eight emission controls, four permanent prefix controls and sixteen
  supplementary recursive-scope comparisons and twelve alias-capture controls pass.
  Complete Native/local/Windows, both map profiles, projects and tooling are
  source-bound and independently verified. All 42,716 old IDs/classes remain;
  396 additions yield N=43,112. [Acceptance](HIGHER_ORDER_INFERENCE_ACCEPTANCE.md)
  · [measurement](HIGHER_ORDER_INFERENCE_MEASUREMENT.json). Broader rows remain open.'''
    todo=todo[:start]+row+todo[end:]
    latest=todo.index('**Latest completed follow-up:**');latest_end=todo.index('\n## ',latest)
    todo=todo[:latest]+'''**Latest completed follow-up:** P0-G preserves higher-order generic parameters,
callable ownership and exact retained identities, with complete declaration,
consumer, syntax and execution checks. [Acceptance](HIGHER_ORDER_INFERENCE_ACCEPTANCE.md)
binds Native/local/Windows, maps, projects and tooling to the measured source.
All 22 broader rows remain open and require separate closure contracts.
'''+todo[latest_end:]
    followup_path=PHASE/'HIGHER_ORDER_INFERENCE_FOLLOWUP.md';followup=followup_path.read_text()
    start=followup.index('Status:');end=followup.index('Accepted baseline:',start)
    followup=followup[:start]+f'''Status: accepted within the frozen P0-G contract. Source: `{source}`.
Complete current acceptance, independently verified artifacts and reproduction
instructions are recorded in [acceptance](HIGHER_ORDER_INFERENCE_ACCEPTANCE.md).
Only P0-G is complete; all 22 broader rows remain open and full parity is OFF.

'''+followup[end:]
    followup=followup.replace('## Current measured progress — not final acceptance',
        '## Development history — earlier focused results')
    followup=followup.replace('P0-G remains open and uncommitted.',
        'That intermediate result did not complete P0-G; final acceptance is recorded above.')
    followup=followup.replace('complete acceptance is now running under','complete acceptance ran under')
    followup=followup.replace('Complete acceptance now runs under','Complete acceptance ran under')
    assert len(re.findall(r'(?m)^\d+\. \*\*',followup)) == 6
    followup=re.sub(r'(?m)^(\d+)\. \*\*',r'\1. [x] **',followup)
    before=ROOT/'final-docs-before';before.mkdir()
    for path in [todo_path,followup_path]:
        (before/path.name).write_bytes(path.read_bytes())
    for name,text in [('HIGHER_ORDER_INFERENCE_ACCEPTANCE.md',acceptance),
        ('HIGHER_ORDER_INFERENCE_REPRODUCTION.md',reproduction)]:
        path=PHASE/name;assert not path.exists();path.write_text(text)
    todo_path.write_text(todo);followup_path.write_text(followup)
    print('Recorded finite G completion after independent publication verification; all 22 broader rows remain open.')


if __name__=='__main__':
    main()
