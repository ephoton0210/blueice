# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Finish publication after all tests pass; preserve the failed Unicode audit."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

DELIVERY = Path(__file__).resolve().parent
REPO = DELIVERY.parent.parent
ROOT = DELIVERY.parent/'higher-order-inference-acceptance-20261114-r10'
STATE = DELIVERY/'state.json'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not STATE.exists(), 'Observe this publication attempt; never overwrite it'
state = {'pid':os.getpid(),'conclusion':'in_progress','stage':'preflight',
    'sourceRevision':read(ROOT/'frozen-source-preflight.json')['sourceRevision'],
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'steps':[],'commitPerformed':False,'pushPerformed':False}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(STATE)


try:
    save()
    assert read(ROOT/'mac-driver.json')['conclusion'] == 'success'
    assert read(ROOT/'local-gates.json')['conclusion'] == 'success'
    assert read(ROOT/'windows/windows-acceptance-verification.json')['conclusion'] == 'success'
    assert read(ROOT.parent/'higher-order-inference-contract-20261114/r10-windows-packaging-recovery-1/state.json')['conclusion'] == 'success'
    manifest = read(ROOT/'publication-attempt-3/manifest.json')
    phase = REPO/'development/browser_core/phase-18-bluets'
    entry = [sys.executable,'-B',str(ROOT/'publish_attempt_3.py')]
    steps = [('publish',entry+['publish']),('verify-before-todo',entry+['verify-before']),
        ('finalize-docs',entry+['finalize']),('verify-after-todo',entry+['verify-after']),
        ('account-check',[sys.executable,str(phase/'tools/account_inventory_rows.py'),'--check']),
        ('status-check',[sys.executable,str(phase/'tools/check_compatibility_status.py'),'--check']),
        ('diff-check',['git','diff','--check'])]
    for label,args in steps:
        assert all(sha(ROOT/name) == digest for name,digest in manifest['actors'].items())
        assert all(sha(ROOT/name) == digest for name,digest in manifest['baseTools'].items())
        state['stage'] = label; save()
        log = DELIVERY/(label+'.log')
        with log.open('xb') as output:
            child = subprocess.Popen(args,cwd=REPO,stdout=output,stderr=subprocess.STDOUT)
            state['childPid'] = child.pid; save(); code = child.wait()
        state.pop('childPid',None)
        state['steps'].append({'label':label,'command':args,'exit':code,'log':log.name,'sha256':sha(log)})
        save()
        assert code == 0, label+': inspect preserved '+str(log)
    state.update(conclusion='success',stage='publication-verified-docs-ready-awaiting-diff-review-commit-push',
        measurementSha256=sha(phase/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'))
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state),flush=True)
