# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Collect auditor assumptions only; never publish, finalize, or grant credit."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT/'publication-diagnostics-1'
DESTINATION.mkdir()
SOURCE = ROOT/'g_acceptance_audit.py'
source = SOURCE.read_text()
failures = []


def record(condition,line,expression):
    if not condition:
        failures.append({'line':line,'expression':expression})


class DiagnosticAssertions(ast.NodeTransformer):
    def visit_Assert(self,node):
        expression = ast.get_source_segment(source,node.test)
        return ast.copy_location(ast.Expr(value=ast.Call(func=ast.Name(id='_diagnostic_assert',ctx=ast.Load()),
            args=[node.test,ast.Constant(node.lineno),ast.Constant(expression)],keywords=[])),node)


tree = DiagnosticAssertions().visit(ast.parse(source))
ast.fix_missing_locations(tree)
environment = {'__name__':'diagnostic_only','__file__':str(SOURCE),'_diagnostic_assert':record}
state = {'scope':'Auditor diagnostic execution only. Assertions are recorded, not accepted; zero test, acceptance, publication or TODO credit.',
    'conclusion':'in_progress','sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'failures':failures,
    'testReruns':0,'publicationPerformed':False,'todoModified':False}
try:
    exec(compile(tree,str(SOURCE)+' [diagnostic-only]', 'exec'),environment)
    environment['audit']()
    state['conclusion'] = 'diagnostic-observations-only'
except BaseException as error:
    state['conclusion'] = 'diagnostic-exception'
    state['error'] = repr(error)
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (DESTINATION/'report.json').write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state),flush=True)
