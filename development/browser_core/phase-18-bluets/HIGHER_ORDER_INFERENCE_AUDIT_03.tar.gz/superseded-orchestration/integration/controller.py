# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Observe the existing quality run, then launch fresh r10 gates and publication."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

contract=Path(__file__).resolve().parent
repo=contract.parent.parent
quality=contract/'diagnostics-version-worktree-quality-1'
quality_pid=int(sys.argv[1])
assert quality_pid>0
root=repo/'target/higher-order-inference-acceptance-20261114-r10'
output=repo/'target/higher-order-inference-integration-20261114-r10'
output.mkdir()
shutil.copy2(__file__,output/'controller.py')
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=read(contract/'r9-diagnostics-version-repair-1/source-revision.json')['sourceRevision']
state={'pid':os.getpid(),'conclusion':'in_progress','stage':'observing-existing-quality-run',
    'qualityPid':quality_pid,'sourceRevision':source,'steps':[],
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'commitPerformed':False,'pushPerformed':False}
def save():
    state['recordedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=output/'state.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(output/'state.json')
def run(label,args):
    state['stage']=label;save();log=output/(label+'.log')
    with log.open('xb') as stream:
        child=subprocess.Popen(args,cwd=repo,stdout=stream,stderr=subprocess.STDOUT)
        state['childPid']=child.pid;save();code=child.wait()
    state.pop('childPid',None)
    state['steps'].append({'label':label,'command':args,'exit':code,'log':log.name,'sha256':sha(log)})
    save();assert code==0,label
try:
    save()
    while True:
        q=read(quality/'measurement.json')
        if q['conclusion']!='in_progress':break
        observed=subprocess.run(['ps','-p',str(quality_pid),'-o','command='],capture_output=True,text=True)
        assert observed.returncode==0 and observed.stdout.strip().endswith(
            'diagnostics_version_worktree_quality.py diagnostics-version-worktree-quality-1'),observed
        state['qualityStage']=q['stage']
        state['lastQualityProcessVerifiedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        save();time.sleep(10)
    assert q['conclusion']=='success' and q['stage']=='complete' and len(q['steps'])==7
    assert all(row['exit']==0 for row in q['steps'])
    assert all(sha(repo/name)==value for name,value in read(quality/'source-manifest.json').items())
    run('fresh-project-preflight',[sys.executable,'-B',str(contract/'diagnostics_version_projects_preflight.py')])
    run('prepare-r10',[sys.executable,'-B',str(contract/'prepare_r10.py')])
    run('driver-contract-preflight',[sys.executable,'-B',str(contract/'audit_r10_preparation.py'),str(root)])
    assert not (root/'launch-state.json').exists()
    state['stage']='observing-r10-full-acceptance';save()
    with (output/'r10-launch.log').open('xb') as main_log:
        child=subprocess.Popen([sys.executable,'-B',str(root/'launch.py')],cwd=repo,stdout=main_log,stderr=subprocess.STDOUT)
        state['r10MainPid']=child.pid;save()
        while not (root/'launch-state.json').exists():
            assert child.poll() is None,'Launcher ended before recording its state'
            time.sleep(0.1)
        delivery=repo/'target/higher-order-inference-delivery-20261114-r10';delivery.mkdir()
        template=repo/'target/higher-order-inference-delivery-20261114-r9/continue.py'
        text=template.read_text().replace('acceptance-20261114-r9','acceptance-20261114-r10')
        text=text.replace('delivery-20261114-r9','delivery-20261114-r10').replace('existing r9 run','existing r10 run')
        old_source='backend-tree:9f6e4f033200e519f62f3573685b6cbe04f873a3'
        assert text.count(old_source)==1
        text=text.replace(old_source,source);ast.parse(text)
        (delivery/'continue.py').write_text(text)
        with (output/'r10-delivery.log').open('xb') as delivery_log:
            observer=subprocess.Popen([sys.executable,'-B',str(delivery/'continue.py')],cwd=repo,stdout=delivery_log,stderr=subprocess.STDOUT)
            state['deliveryPid']=observer.pid;save()
            while child.poll() is None:save();time.sleep(10)
            state['r10Exit']=child.returncode;save()
            while observer.poll() is None:
                state['stage']='observing-r10-publication-verification';save();time.sleep(10)
            state['deliveryExit']=observer.returncode
    assert state['r10Exit']==state['deliveryExit']==0
    state.update(conclusion='success',stage='complete-evidence-and-docs-awaiting-diff-review-commit-push')
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(state))
