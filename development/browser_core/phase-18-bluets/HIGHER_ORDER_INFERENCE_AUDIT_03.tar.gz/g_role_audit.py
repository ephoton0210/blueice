# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import hashlib
import json


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root, repo, native, gates):
    ROOT, REPO = root, repo
    rows = native['suites']
    role_paths = set()
    for row in rows:
        for key, raw_path in row.get('artifact_paths', {}).items():
            path = Path(raw_path)
            if key == 'BLUEICE_GE5_ROLE_REPORT_DIRECTORY' and path.exists():
                role_paths.update(path.rglob('*.json'))
            elif key.startswith('BLUEICE_GE5_') and key.endswith('_REPORT') and path.exists():
                role_paths.add(path)
    interop = next(row for row in rows if row['harness'] == 'backend/bluets/tests/ge5_interop_module_maps.rs')
    expression = next(row for row in rows if row['harness'] == 'backend/bluets/tests/ge5_interop_expression_maps.rs')
    interop_directory = Path(interop['artifact_paths']['BLUEICE_GE5_ROLE_REPORT_DIRECTORY'])
    full_interop_path = interop_directory / 'interop-complete-module-acceptance.json'
    full_interop = read(full_interop_path)
    expected_interop = {index for index, row in enumerate(read(REPO / 'backend/bluets/tests/fixtures/ge5_source_maps/cases.json')['cases'])
                        if row['form'] == 'ge2_module_helpers/interop-exportstar-cycle'}
    assert len(expected_interop) == full_interop['configurations'] == 363
    assert full_interop['completeFamily'] is True and not full_interop['failures']
    assert full_interop['maps'] == len(full_interop['products']) == 1452
    assert len(full_interop['executions']) == 363 and full_interop['selectedEditionSyntaxPrograms'] == 2904
    assert {row['index'] for row in full_interop['products']} == expected_interop
    assert {row['index'] for row in full_interop['executions']} == expected_interop
    assert full_interop['compilerSha256'] == gates['nativeCompilerSha256']
    scoped_reports = {
        interop_directory / 'interop-complete-module-acceptance-partial.json': (3, 12),
        Path(expression['artifact_paths']['BLUEICE_GE5_ROLE_REPORT_DIRECTORY']) / 'interop-expression-maps.json': (1, 4),
    }
    complete_families, partial_reports = [], []
    for path in sorted(role_paths):
        report = read(path)
        if not isinstance(report, dict):
            continue
        assert not report.get('positiveOnly', False), path
        if 'completeFamily' in report:
            if report['completeFamily'] is True:
                complete_families.append(str(path.relative_to(ROOT)))
            else:
                # The frozen harnesses also retain bounded ordinary observations.
                # They are not complete-family evidence. Require their exact
                # known scope and the independently complete 363-row counterpart.
                assert report['completeFamily'] is False and path in scoped_reports, path
                assert (report['configurations'], report['maps']) == scoped_reports[path]
                assert report['failures'] == []
                if path.name.endswith('-partial.json'):
                    assert len(report['products']) == 12 and len(report['executions']) == 3
                    assert {row['index'] for row in report['products']} == {4892, 4933, 5013}
                    assert {row['index'] for row in report['executions']} == {4892, 4933, 5013}
                else:
                    assert report['scope'] == 'Complete original declaration syntax, expression interiors and logical endpoints; module closure pending'
                partial_reports.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                    'configurations': report['configurations'], 'maps': report['maps'],
                    'completeFamily': False, 'completeFamilyCredit': False,
                    'completeCounterpart': str(full_interop_path.relative_to(ROOT)),
                    'scope': report.get('scope', 'Three frozen ordinary module-boundary observations, outside complete-family credit.')})
        if 'compilerSha256' in report:
            assert report['compilerSha256'] == gates['nativeCompilerSha256'], path
    assert len(complete_families) == 28, 'all 28 complete role-family reports are required'
    assert {ROOT / row['path'] for row in partial_reports} == set(scoped_reports)
    return {'completeNativeRoleFamilies':complete_families,'partialNativeRoleReports':partial_reports}
