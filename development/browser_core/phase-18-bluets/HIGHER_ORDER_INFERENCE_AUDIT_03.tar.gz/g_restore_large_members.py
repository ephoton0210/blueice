# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Reconstruct original large evidence files from verified bounded chunks."""
from pathlib import Path
import hashlib
import json
from g_artifact_pack import safe_name,digest

ROOT=Path(__file__).resolve().parent


def destination(name):
    path=ROOT/safe_name(name)
    assert not path.is_symlink(),path
    for parent in path.parents:
        if parent==ROOT:
            break
        assert ROOT in parent.parents and not parent.is_symlink(),parent
    return path


def main():
    manifest=json.loads((ROOT/'large-members.json').read_bytes())
    restored=[]
    for row in manifest['members']:
        assert isinstance(row['mode'],int) and 0<=row['mode']<=0o777
        target=destination(row['path'])
        if target.exists():
            assert target.is_file() and target.stat().st_size==row['bytes']
            assert digest(target)==row['sha256']
            restored.append({'path':row['path'],'alreadyPresentAndVerified':True})
            continue
        target.parent.mkdir(parents=True,exist_ok=True)
        directory=ROOT/'large-reconstruction-audits'/hashlib.sha256(row['path'].encode()).hexdigest()[:20]
        directory.mkdir(parents=True,exist_ok=True)
        number=1
        while (directory/('attempt-'+str(number)+'.tmp')).exists():
            number+=1
        temporary=directory/('attempt-'+str(number)+'.tmp')
        expected_offset=0;whole=hashlib.sha256()
        with temporary.open('xb')as output:
            for part in row['parts']:
                path=destination(part['path'])
                assert path.is_file() and path.stat().st_size==part['bytes']
                assert part['offset']==expected_offset and digest(path)==part['sha256']
                with path.open('rb')as stream:
                    for block in iter(lambda:stream.read(1024*1024),b''):
                        whole.update(block);output.write(block);expected_offset+=len(block)
        assert expected_offset==row['bytes'] and whole.hexdigest()==row['sha256']
        assert not target.exists()
        temporary.rename(target)
        target.chmod(row['mode'])
        restored.append({'path':row['path'],'bytes':row['bytes'],'sha256':row['sha256']})
    print(json.dumps({'sourceRevision':manifest['sourceRevision'],'conclusion':'success',
        'verifiedOriginalLargeMembers':len(restored)}))


if __name__=='__main__':
    main()
