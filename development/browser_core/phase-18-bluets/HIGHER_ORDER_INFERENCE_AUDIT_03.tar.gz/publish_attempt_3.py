# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Use a preserved one-line path-decoding repair; leave the first tools intact."""
from pathlib import Path
import hashlib
import importlib.util
import json
import runpy
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
PHASE = REPO/'development/browser_core/phase-18-bluets'
ATTEMPT = ROOT/'publication-attempt-3'
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
mode = sys.argv[1]
assert mode in ['publish','verify-before','finalize','verify-after']
manifest = read(ATTEMPT/'manifest.json')
proof = read(ATTEMPT/'repair-proof.json')
assert sha(ROOT/'publication-start-manifest.json') == manifest['basePublicationManifestSha256']
assert all(sha(ROOT/name) == digest for name,digest in manifest['baseTools'].items())
assert all(sha(ROOT/name) == digest for name,digest in manifest['actors'].items())
original = (ROOT/'g_acceptance_audit.py').read_text()
expected_source = original
for change in proof['changes']:
    assert expected_source.count(change['old']) == 1
    expected_source = expected_source.replace(change['old'],change['new'])
fixed = ROOT/'g_acceptance_audit_recorded_scope_fixed.py'
assert fixed.read_text() == expected_source
assert sha(fixed) == proof['correctedAuditorSha256']
spec = importlib.util.spec_from_file_location('g_acceptance_audit',fixed)
module = importlib.util.module_from_spec(spec)
sys.modules['g_acceptance_audit'] = module
spec.loader.exec_module(module)
assert module.ROOT == ROOT


def verify_attempt(before):
    verification = read(ROOT/('g-publication-before-todo-verification.json' if before else 'g-publication-verification.json'))
    assert verification['conclusion'] == 'success' and verification['todoExpectedOpen'] is before
    measurement = read(PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json')
    index = read(PHASE/measurement['artifactIndex']['path'])
    owners = {}
    for artifact in index['artifacts']:
        for part in artifact['memberManifests']:
            for row in read(PHASE/part['path'])['entries']:
                owners[row['path']] = {'archive':artifact['path'],**row}

    def archived(name):
        row = owners[name]
        with tarfile.open(PHASE/row['archive']) as archive:
            data = archive.extractfile(name).read()
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert len(data) == row['bytes']
        return data

    assert archived('publication-attempt-3/manifest.json') == (ATTEMPT/'manifest.json').read_bytes()
    for name,digest in {**manifest['actors'],**manifest['evidence']}.items():
        assert hashlib.sha256(archived(name)).hexdigest() == digest == sha(ROOT/name)
    archived_expected = archived('g_acceptance_audit.py').decode()
    for change in proof['changes']:
        assert archived_expected.count(change['old']) == 1
        archived_expected = archived_expected.replace(change['old'],change['new'])
    assert archived('g_acceptance_audit_recorded_scope_fixed.py').decode() == archived_expected
    frozen = read(ROOT/'frozen-source-preflight.json')
    paths = archived('publication-attempt-3/backend-paths.nul').decode().split(chr(0))[:-1]
    expected = {name for name in frozen['files'] if name.startswith('backend/')}
    assert len(paths) == len(set(paths)) == len(expected) == 14117 and set(paths) == expected
    assert hashlib.sha256(chr(0).join(sorted(paths,key=lambda name:name.encode())).encode()).hexdigest() == frozen['backendPathSetSha256']
    quoted = archived('publication-attempt-3/original-quoted-paths.txt').decode().splitlines()
    assert sorted(set(quoted)-expected) == proof['originalQuotedOnly']
    assert sorted(expected-set(quoted)) == proof['originalMissing']
    assert proof['originalMissing'] == ['backend/bluets/tests/fixtures/project_config/config-unicode-glob/src/冰.ts']
    failed = json.loads(archived('publication-attempt-3/original-failure/state.json'))
    assert failed['conclusion'] == 'failure' and failed['stage'] == 'publish'
    assert failed['steps'][0]['exit'] == 1
    assert "candidate['source']" in archived('publication-attempt-3/original-failure/publish.log').decode()
    recorded = json.loads(archived('development-history/contract/promise-worktree-regressions-1/measurement.json'))['source']
    assert len(recorded) == 582 and set(recorded) < set(frozen['files'])
    assert all(frozen['files'][name] == digest for name,digest in recorded.items())
    prefix = measurement['prefixRegressions']
    assert prefix['preflightRecordedInputsMatchAcceptance'] and prefix['preflightRecordedInputs'] == 582
    assert prefix['preflightSourceDifference'] == [] and prefix['preflightManifestIsSubsetOfAcceptance']
    assert prefix['preflightDoesNotCoverAllTestsOrOracleTools'] and prefix['preflightDoesNotReplaceFinalCompilerTests']
    result = {'conclusion':'success','sourceRevision':frozen['sourceRevision'],
        'scope':'Independent archived publication-tool correction; original failure retained, no compiler/runtime/test changes.',
        'manifestSha256':sha(ATTEMPT/'manifest.json'),'correctedAuditorSha256':sha(fixed),
        'measurementSha256':sha(PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'),
        'artifactIndexSha256':verification['artifactIndexSha256'],'beforeTodo':before,
        'backendFiles':14117,'testReruns':0,'runtimeDriverChanges':0}
    from g_artifact_pack import write_json
    write_json(ROOT/('g-publication-attempt3-before-todo-verification.json' if before else 'g-publication-attempt3-verification.json'),result)
    if not before:
        write_json(PHASE/'HIGHER_ORDER_INFERENCE_PUBLICATION_RECOVERY_VERIFICATION.json',result)
    print(json.dumps(result))


if mode == 'finalize':
    previous = read(ROOT/'g-publication-attempt3-before-todo-verification.json')
    assert previous['conclusion'] == 'success' and previous['beforeTodo'] is True
    assert previous['manifestSha256'] == sha(ATTEMPT/'manifest.json')
    assert previous['measurementSha256'] == sha(PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json')

tool = {'publish':'g_publish.py','verify-before':'g_verify_publication.py',
        'finalize':'g_finalize_docs.py','verify-after':'g_verify_publication.py'}[mode]
sys.argv = [str(ROOT/tool)] + (['--before-todo'] if mode == 'verify-before' else [])
runpy.run_path(str(ROOT/tool),run_name='__main__')
if mode in ['verify-before','verify-after']:
    verify_attempt(mode == 'verify-before')
