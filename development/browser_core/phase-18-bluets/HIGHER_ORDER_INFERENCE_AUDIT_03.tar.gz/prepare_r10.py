# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Prepare fresh acceptance after preserving the r9 public version-test failure."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess
import sys

contract = Path(__file__).resolve().parent
repo = contract.parent.parent
old = repo/'target/higher-order-inference-acceptance-20261114-r9'
root = repo/'target/higher-order-inference-acceptance-20261114-r10'
assert sys.argv[1:] in ([],['--preview'])
preview = bool(sys.argv[1:])
if preview:
    root = next(repo/f'target/higher-order-inference-preparation-20261114-r10-preview-{n}'
        for n in range(1,101) if not (repo/f'target/higher-order-inference-preparation-20261114-r10-preview-{n}').exists())
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
quality = contract/'diagnostics-version-worktree-quality-1'
q = read(quality/'measurement.json')
assert q['conclusion'] in ('in_progress','success')
assert all(row['exit'] == 0 for row in q['steps'])
if not preview:
    assert q['conclusion'] == 'success' and len(q['steps']) == 7
    assert read(contract/'diagnostics-version-projects-preflight-1/measurement.json')['conclusion'] == 'success'
assert read(old/'launch-state.json')['conclusion'] == 'failure'
assert read(old/'mac-driver.json')['conclusion'] == 'failure'
assert read(old/'windows/complete-state.json')['conclusion'] == 'success'
assert read(old/'owned-workspace-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
preserved = contract/'r9-diagnostics-version-failure-preservation-1'
assert read(preserved/'terminal/manifest.json')['conclusion'] == 'original-terminal-failures-preserved'
assert sha(preserved/'frozen-source.tar.gz') == read(preserved/'receipt.json')['archiveSha256']
files = read(quality/'source-manifest.json')
assert all(sha(repo/name) == value for name,value in files.items())
previous = read(old/'frozen-source-preflight.json')['files']
test = 'backend/bluets/tests/diagnostics.rs'
assert set(files) == set(previous)
assert [name for name,value in previous.items() if files[name] != value] == [test]
revision = read(contract/'r9-diagnostics-version-repair-1/source-revision.json')['sourceRevision']
backend = revision.removeprefix('backend-tree:')
root.mkdir()
(root/'windows').mkdir()
names = ['launch.py','run_mac.py','freeze_source.py','prepare_windows.py',
    'upload_windows.py','complete_windows.py','finish_windows.py','verify_windows.py',
    'run_native_gates.py','measure_priority.cjs','run_project_gates.py','run_local_gates.py',
    'watch_maps.py','replay_original_discovery.cjs','audit_symbolic_keys.py',
    'audit_conditional_inference.py','audit_higher_order_inference.py',
    'baseline-native-durations.json','windows/windows-runner.cjs','windows/package-evidence.py']
def namespace(s):
    return s.replace('acceptance-20261114-r9','acceptance-20261114-r10').replace('p0g-r9','p0g-r10').replace('results-higher-order-inference-r9','results-higher-order-inference-r10')
for name in names+[p.name for p in old.glob('g_*.py')]:
    (root/name).write_text(namespace((old/name).read_text()))
for name in ['original-discovery24/inputs.json','original-discovery24/native-reference.json',
             'accepted-parent-source.tar.gz','accepted-parent-source-manifest.json']:
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/name,p)
def change(name,fn):
    p=root/name;p.write_text(fn(p.read_text()))

# The remote baseline is the retained successful Windows r9 source, not the new source.
change('prepare_windows.py',lambda s:s.replace("'higher-order-inference-acceptance-20261114-r8'","'higher-order-inference-acceptance-20261114-r9'").replace("'/p0g-r8-source-manifest.json'","'/p0g-r9-source-manifest.json'").replace(".replace('p0g-r8', 'p0g-r10')",".replace('p0g-r9', 'p0g-r10')").replace('26 complete affected cohorts','27 complete affected cohorts'))
change('windows/windows-runner.cjs',lambda s:s.replace("const cohorts = ['higher_order_inference'","const cohorts = ['diagnostics', 'higher_order_inference'").replace('twenty-six complete cohorts','twenty-seven complete cohorts'))
change('verify_windows.py',lambda s:s.replace("len(cohorts) == 26","len(cohorts) == 27").replace("    'higher_order_inference', 'gt7_library_manifest'","    'diagnostics', 'higher_order_inference', 'gt7_library_manifest'").replace("{'higher_order_inference': 7,","{'diagnostics': 10, 'higher_order_inference': 7,").replace('26 complete affected cohorts','27 complete affected cohorts'))

# This previously reviewed preparation template already binds fresh focused products.
template=repo/'target/higher-order-inference-preparation-20261114-r9-preview-2/freeze_source.py'
s=namespace(template.read_text()).replace('gt7-host-worktree-quality-1','diagnostics-version-worktree-quality-1')
s=s.replace("assert backend_tree == '9f6e4f033200e519f62f3573685b6cbe04f873a3'",'assert backend_tree == '+repr(backend))
s=s.replace('promise-projects-preflight-1','diagnostics-version-projects-preflight-1')
start=s.index("previous = repo/'target/higher-order-inference-acceptance-20261114-r8'")
end=s.index('probe = read(contract/',start)
s=s[:start]+'''previous = repo/'target/higher-order-inference-acceptance-20261114-r9'
assert read(previous/'launch-state.json')['conclusion'] == 'failure'
assert read(previous/'mac-driver.json')['conclusion'] == 'failure'
assert read(previous/'windows/complete-state.json')['conclusion'] == 'success'
assert read(previous/'owned-workspace-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
preserved = contract/'r9-diagnostics-version-failure-preservation-1'
assert sha(preserved/'frozen-source.tar.gz') == read(preserved/'receipt.json')['archiveSha256']
old_files = read(previous/'frozen-source-preflight.json')['files']
assert set(old_files) == set(files)
assert [name for name,value in old_files.items() if files[name] != value] == ['backend/bluets/tests/diagnostics.rs']
assert len(report['steps']) == 7 and all('reusedFrom' not in row for row in report['steps'])
diagnostics = re.search(r'Running tests/diagnostics\\.rs[^\\n]*\\n(.*?)(?=\\n\\s*Running tests/|\\Z)',(quality/'call-chain-regressions.log').read_text(),re.S)
assert diagnostics and 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in diagnostics.group(1)
''' +s[end:]
s=s.replace("'expectedWindowsCohorts':26","'expectedWindowsCohorts':27")
(root/'freeze_source.py').write_text(s)

new_quality='diagnostics-version-worktree-quality-1'
change('g_recursive_scope_audit.py',lambda s:s.replace('gt7-host-worktree-quality-1',new_quality))
p=root/'g_acceptance_audit.py';s=p.read_text()
s=s.replace("quality = REPO/'target/higher-order-inference-contract-20261114/gt7-host-worktree-quality-1'","quality = REPO/'target/higher-order-inference-contract-20261114/"+new_quality+"'")
s=s.replace("== [recorder]","== ['backend/bluets/tests/diagnostics.rs',recorder]")
s=s.replace("'acceptedPreflight':'development-history/contract/gt7-host-worktree-quality-1/measurement.json'","'acceptedPreflight':'development-history/contract/"+new_quality+"/measurement.json'")
s=s.replace("'earlierFailedOutcomesPreserved':True}","'earlierFailedOutcomesPreserved':True,'publicDiagnosticsTests':10,\n        'sourceDifferencesSinceSupersededPreflight':['backend/bluets/tests/diagnostics.rs',recorder]}")
marker="    native_gates = read(ROOT/'native-gates.json')"
s=s.replace(marker,"    diagnostics = re.search(r'Running tests/diagnostics\\.rs[^\\n]*\\n(.*?)(?=\\n\\s*Running tests/|\\Z)',(quality/'call-chain-regressions.log').read_text(),re.S)\n    assert diagnostics and 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in diagnostics.group(1)\n"+marker)
s=s.replace("assert all(frozen['files'][name] == digest for name,digest in candidate['source'].items())","assert [name for name,digest in candidate['source'].items() if frozen['files'][name] != digest] == ['backend/bluets/tests/diagnostics.rs']")
s=s.replace("'preflightSourceBytesMatchAcceptance':True","'preflightCompilerAndOracleBytesMatchAcceptance':True,'preflightSourceDifference':['backend/bluets/tests/diagnostics.rs']")
s=s.replace("len(windows['regressionCohorts']) == 26","len(windows['regressionCohorts']) == 27")
s=s.replace("    assert windows['higherOrderInferenceReports']['comparisons'] == 384","    assert windows['regressionCohorts']['diagnostics'] == {'passed':10,'failed':0,'ignored':0,'filtered':0}\n    assert windows['higherOrderInferenceReports']['comparisons'] == 384")
p.write_text(s)
change('g_verify_publication.py',lambda s:s.replace('development-history/contract/gt7-host-worktree-quality-1/', 'development-history/contract/'+new_quality+'/').replace("==[preflight['changedTool']]","==preflight['sourceDifferencesSinceSupersededPreflight']").replace("assert preflight['freshPythonTests']==13","assert preflight['freshPythonTests']==13 and preflight['publicDiagnosticsTests']==10").replace("len(data['windows']['regressionCohorts'])==26","len(data['windows']['regressionCohorts'])==27").replace("'failed-r7','failed-r8'}","'failed-r7','failed-r8','failed-r9'}"))

p=root/'g_history_audit.py';s=p.read_text();marker="    return {'conclusion':'success','parentCommit':frozen['parentCommit'],"
assert s.count(marker)==1
block='''    r9 = repo/'target/higher-order-inference-acceptance-20261114-r9'
    ninth = read(r9/'launch-state.json')
    assert ninth['conclusion'] == 'failure'
    assert ninth['platforms']['mac']['exit'] == 1 and ninth['platforms']['windows']['exit'] == 0
    native9 = read(r9/'accepted-native/measurement.json')
    assert native9['conclusion'] == 'success' and len(native9['suites']) == 191
    assert sum(row['passed'] for row in native9['suites']) == 1088
    assert read(r9/'project-gates.json')['conclusion'] == 'success'
    assert read(r9/'owned-workspace-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
    preserved9 = root/'r9-diagnostics-version-failure-preservation-1'
    receipt9 = read(preserved9/'receipt.json')
    assert receipt9['sourceFiles'] == len(receipt9['files']) == 14738
    assert receipt9['wholeAcceptanceCredit'] == 0
    assert sha(preserved9/'frozen-source.tar.gz') == receipt9['archiveSha256']
    with tarfile.open(preserved9/'frozen-source.tar.gz','r|gz') as archive:
        source9 = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                   for member in archive if member.isfile()}
    assert source9 == receipt9['files']
    for name,row in receipt9['products'].items():
        assert sha(preserved9/name) == row['sha256']
    failed9 = (preserved9/'original-diagnostics-failure.log').read_text()
    assert 'test result: FAILED. 9 passed; 1 failed;' in failed9
    assert 'typescript-5.9.3-diagnostics-v13' in failed9 and 'typescript-5.9.3-diagnostics-v12' in failed9
    win9 = read(r9/'windows/windows-acceptance-verification.json')
    assert win9['conclusion'] == 'success' and win9['coreOracles'] == 82
    assert win9['paths'] == 25 and len(win9['regressionCohorts']) == 26
    assert sha(r9/'windows-evidence.tar.gz') == win9['archiveSha256']
    failures['r9'] = {'acceptanceCredit':0,'completePackageFailedAt':'workspace-diagnostics-version-assertion',
        'preservedSourceFiles':14738,'nativeSuites':191,'nativeFunctions':1088,
        'windowsCoreOracles':82,'windowsCompleteCohorts':26,'remainingWorkspaceExplicitlyStopped':True,
        'originalFailureUnchanged':True,'sourceArchiveSha256':receipt9['archiveSha256']}
'''
s=s.replace(marker,block+marker).replace("['r4','r5','r6','r7','r8']","['r4','r5','r6','r7','r8','r9']");p.write_text(s)
change('g_preserve_evidence.py',lambda s:s.replace("('failed-r8',REPO/'target/higher-order-inference-acceptance-20261114-r8'),","('failed-r8',REPO/'target/higher-order-inference-acceptance-20261114-r8'),\n        ('failed-r9',REPO/'target/higher-order-inference-acceptance-20261114-r9'),").replace('six failed full-acceptance attempts','seven failed full-acceptance attempts'))
change('g_finalize_docs.py',lambda s:s.replace('26 selected complete regression cohorts','27 selected complete regression cohorts').replace('including eleven affected\ncohorts with the complete higher-order and G-T7 tests.','including eleven affected\ncohorts with the complete higher-order and G-T7 tests, plus the complete ten-test\npublic diagnostics boundary.').replace('All seven final-source quality steps run afresh,','The r9 run passed all 191 Native suites/1088 functions, four real projects and\nWindows82/25paths/26 complete cohorts. Its workspace then exposed a stale test\nepoch: the public diagnostics test still expected v12 after diagnostic semantics\nadvanced to v13. All frozen source, both actual Mac compilers, failed test binary\nand original failure are preserved. The remaining owned workspace work was\nexplicitly stopped. Only that test expectation changes; no compiler or oracle\nbyte changes. All ten public diagnostics tests pass. The final Windows cohort\nselection also includes these ten tests and requires 27 complete cohorts.\n\nAll seven final-source quality steps run afresh,'))
for p in root.rglob('*.py'):
    ast.parse(p.read_text(),filename=str(p))
for p in root.rglob('*.cjs'):
    subprocess.run(['node','--check',str(p)],check=True)
shutil.copy2(__file__,root/Path(__file__).name)
(root/'prepared.json').write_text(json.dumps({'conclusion':'preview-not-launched' if preview else 'prepared-not-launched',
    'runtimeDrivers':names[:17],'expectedSourceRevision':revision,'compilerAndOracleBytesUnchangedFromR9':True,
    'changedSourceFiles':[test],'expectedNativeSuites':191,'expectedNativeFunctions':1088,
    'expectedWindowsCohorts':27,'publicDiagnosticsPreflightTests':10,'preview':preview,
    'acceptanceCredit':0,'qualityConclusionWhenPrepared':q['conclusion']},indent=2)+'\n')
print(json.dumps({'prepared':str(root),'preview':preview,'launched':False,'sourceRevision':revision}))
