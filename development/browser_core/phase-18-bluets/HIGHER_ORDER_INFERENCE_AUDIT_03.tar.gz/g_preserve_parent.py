# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Preserve the accepted parent source as independently verifiable regular files."""
import gzip
import hashlib
import io
import subprocess
import tarfile
from g_acceptance_audit import ROOT,REPO,read,sha
from g_artifact_pack import safe_name,verify_archive,write_json


def preserve_parent():
    frozen=read(ROOT/'frozen-source-preflight.json');parent=frozen['parentCommit']
    selectors=['backend','development/browser_core/phase-18-bluets/tools',
        'Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']
    raw=subprocess.check_output(['git','ls-tree','-r','-z',parent,'--',*selectors],cwd=REPO)
    entries=[]
    for row in raw.split(b'\0'):
        if not row:continue
        header,name=row.split(b'\t',1);mode,kind,oid=header.decode().split()
        assert kind=='blob' and mode in ['100644','100755']
        entries.append({'path':safe_name(name.decode()),'mode':int(mode,8)&0o777,'gitBlob':oid})
    expected_path=ROOT/'accepted-parent-source-manifest.json'
    archive=ROOT/'accepted-parent-source.tar.gz'
    if expected_path.exists():
        manifest=read(expected_path)
        assert manifest['parentCommit']==parent and manifest['archiveSha256']==sha(archive)
        assert [{key:row[key]for key in ['path','mode','gitBlob']}for row in manifest['entries']]==entries
        verify_archive(archive,manifest['entries']);return manifest
    requests=''.join(row['gitBlob']+'\n'for row in entries).encode()
    result=subprocess.run(['git','cat-file','--batch'],cwd=REPO,input=requests,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    stream=io.BytesIO(result.stdout);temporary=ROOT/'accepted-parent-source.tar.gz.tmp'
    assert not archive.exists() and not temporary.exists()
    with temporary.open('xb')as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as compressed:
            with tarfile.open(fileobj=compressed,mode='w|')as package:
                for row in entries:
                    header=stream.readline().split();assert len(header)==3 and header[0].decode()==row['gitBlob'] and header[1]==b'blob'
                    data=stream.read(int(header[2]));assert stream.read(1)==b'\n'
                    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['gitBlob']
                    row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
                    info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=row['mode'];info.mtime=0
                    package.addfile(info,io.BytesIO(data))
    assert stream.read()==b''
    verify_archive(temporary,entries);temporary.rename(archive)
    backend=subprocess.check_output(['git','rev-parse',parent+':backend'],cwd=REPO,text=True).strip()
    manifest={'parentCommit':parent,'parentCompilerSource':'backend-tree:'+backend,
        'archive':'accepted-parent-source.tar.gz','archiveBytes':archive.stat().st_size,
        'archiveSha256':sha(archive),'entries':entries,'acceptanceCreditForCurrentG':0,
        'scope':'Complete accepted-parent backend, oracle tools and root Cargo controls; Git blob and SHA256 verified independently of the current worktree.'}
    write_json(expected_path,manifest);return manifest


if __name__=='__main__':
    value=preserve_parent();print({'parentCompilerSource':value['parentCompilerSource'],
        'files':len(value['entries']),'archiveBytes':value['archiveBytes'],'currentGAcceptanceCredit':0})
