# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Verify the preimplementation contract, complete baseline, red run and prior failures."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import tarfile
from g_artifact_pack import verify_archive


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(repo):
    root = repo/'target/higher-order-inference-contract-20261114'
    phase = repo/'development/browser_core/phase-18-bluets'
    fixture = repo/'backend/bluets/tests/fixtures/higher_order_inference'
    frozen = read(fixture/'FROZEN.json')
    assert frozen['productionStarted'] is False
    assert frozen['forms'] == 48 and frozen['profiles'] == 8 and frozen['primaryComparisons'] == 384
    assert frozen['boundaryControls'] == 12 and frozen['typescript'] == '5.9.3'
    for name,digest in frozen['sha256'].items():
        assert sha(fixture/name) == digest,name
    before = read(root/'preimplementation-receipt.json')
    started = read(root/'implementation-started.json')
    assert before['productionStarted'] is False and started['allNativeAndRedPrerequisitesComplete']
    assert started['productionDiffBeforeStart'] == []
    assert before['parentCommit'] == started['parentCommit'] == frozen['parentCommit']
    assert before['frozenSha256'] == started['frozenSha256'] == sha(fixture/'FROZEN.json')
    assert datetime.datetime.fromisoformat(frozen['frozenAt']) < datetime.datetime.fromisoformat(before['recordedAt']) < datetime.datetime.fromisoformat(started['recordedAt'])
    source_hashes = before['productionSourceHashes']
    red = read(root/'red-1/measurement.json')
    keys = sorted(source_hashes)
    requests = ''.join(frozen['parentCommit']+':'+name+'\n' for name in keys).encode()
    result = subprocess.run(['git','cat-file','--batch'],cwd=repo,input=requests,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    stream = io.BytesIO(result.stdout)
    for name in keys:
        header = stream.readline().split()
        assert len(header) == 3 and header[1] == b'blob'
        data = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
        assert hashlib.sha256(data).hexdigest() == source_hashes[name],name
        assert red['source'][name] == source_hashes[name],name
        retained = root/'red-1/source'/name
        if retained.exists():
            assert sha(retained) == source_hashes[name],name
    assert stream.read() == b''
    for field,path in [('nativeCalibrationSha256','native-calibration-1/measurement.json'),
        ('nativeReplaySha256','native-replay-1/measurement.json'),
        ('runtimeNegativeChecksSha256','runtime-tests-1/measurement.json'),
        ('baselineSha256','baseline-1/measurement.json'),('redSha256','red-1/measurement.json')]:
        assert sha(root/path) == before[field],field
    baseline = read(root/'baseline-1/measurement.json')
    assert baseline['conclusion'] == 'measured-baseline' and baseline['inventoryCredit'] == 0
    assert red['conclusion'] == 'expected-red' and red['productionSourcesUnchanged']
    assert red['rust'] == {'passed':1,'failed':2,'ignored':1,'filtered':0,'exit':101}
    assert red['all384BaselineObservationsReproduced']
    assert (baseline['comparisons'],baseline['completeAgreements'],baseline['completeDifferences']) == (384,48,336)
    assert baseline['classifications'] == {'exact-declaration-difference':204,'incorrect-rejection':116,
        'complete-diagnostic-difference':16,'complete-agreement':48}
    expected = {row['id']:row for row in read(fixture/'reference.json')['cases']}
    rows = {row['id']:row for row in baseline['cases']}
    assert len(rows) == 384 and set(rows) == set(expected)
    for ident,row in rows.items():
        observed = read(root/'red-1/capture'/ident/'observation.json')
        assert all(observed[key] == row[key] for key in ['id','accepts','diagnostics','declarations','agrees','publishedOnRejectedNativeInput'])
        agrees = all(row[key] == expected[ident][key] for key in ['accepts','diagnostics','declarations'])
        assert agrees == row['agrees'] and not row['publishedOnRejectedNativeInput']
        for name,text in row['declarations'].items():
            assert (root/'baseline-1'/ident/'dist'/name).read_bytes() == text.encode()
            assert (root/'red-1/capture'/ident/'dist'/name).read_bytes() == text.encode()
    assert sha(root/'baseline-1/baseline-cli') == baseline['compilerSha256']
    assert sha(root/'red-1/actual-cli') == red['actual-cliSha256']
    assert sha(root/'red-1/actual-test-executable') == red['actual-test-executableSha256']
    parent_probe = read(root/'call-chain-script-parent-baseline-1/report.json')
    assert parent_probe['compilerSha256'] == baseline['compilerSha256']
    script_case = next(row for row in parent_probe['cases'] if row['id'] == 'lib-method-unary-chain-valid')
    assert script_case['expected']['accepts'] and script_case['observed']['accepts']
    assert script_case['expected']['diagnostics'] == script_case['observed']['diagnostics'] == []
    assert script_case['expected']['declarations']['main.d.ts'] and script_case['observed']['declarations']['main.d.ts'] == ''
    probe_input = root/'call-chain-script-parent-baseline-1/blue/default/lib-method-unary-chain-valid/main.ts'
    original_path = 'backend/bluets/tests/fixtures/typescript_oracle/lib-method-unary-chain-valid/main.ts'
    assert probe_input.read_bytes() == subprocess.check_output(['git','show',frozen['parentCommit']+':'+original_path],cwd=repo)
    archives = {}
    for label in ['DISCOVERY','BASELINE']:
        publication = read(phase/('HIGHER_ORDER_INFERENCE_'+label+'.json'))
        archive = phase/publication['evidence']['path']
        manifest = phase/publication['memberManifest']['path']
        assert sha(archive) == publication['evidence']['sha256']
        assert sha(manifest) == publication['memberManifest']['sha256']
        entries = read(manifest)['entries']
        verify_archive(archive,entries)
        archives[label.lower()] = {'archive':archive.name,'sha256':sha(archive),
            'memberManifest':manifest.name,'memberManifestSha256':sha(manifest),'members':len(entries)}
    failures = {}
    for label,subdir,name in [('r1','windows/cancellation-1','interrupted-evidence-audit.json'),
        ('r2','windows/failure-observation-1','failed-evidence-audit.json'),
        ('r3','windows/interrupted-evidence-1','audit.json')]:
        directory = repo/('target/higher-order-inference-acceptance-20261114-'+label)
        receipt = read(directory/subdir/name)
        assert receipt['acceptanceCredit'] == 0 and receipt['sourceFilesIndependentlyVerified'] == 14818
        failures[label] = {'audit':str((directory/subdir/name).relative_to(repo)),
            'sha256':sha(directory/subdir/name),'acceptanceCredit':0}
    r4 = repo/'target/higher-order-inference-acceptance-20261114-r4/launch-state.json'
    r4_state = read(r4)
    assert r4_state['conclusion'] == 'failure' and r4_state['platforms'] == {}
    r5 = repo/'target/higher-order-inference-acceptance-20261114-r5'
    original_launch = read(r5/'launch-state.json')
    original_mac = read(r5/'mac-driver.json')
    assert original_launch['conclusion'] == 'failure'
    assert original_launch['platforms']['mac']['exit'] == original_launch['platforms']['windows']['exit'] == 1
    assert original_mac['conclusion'] == 'failure' and original_mac['stage'] == 'projects'
    original_native = read(r5/'accepted-native/measurement.json')
    assert original_native['conclusion'] == 'success' and len(original_native['suites']) == 191
    assert sum(row['passed'] for row in original_native['suites']) == 1086
    original_project = read(r5/'project-defu/report.json')
    assert original_project['conclusion'] == 'blocked' and original_project['nativeBaselineValid']
    assert original_project['bluets']['cold']['exit'] != 0
    preserved = root/'r5-project-failure-preservation-1'
    receipt = read(preserved/'receipt.json')
    manifest = read(preserved/'frozen-source-manifest.json')
    assert receipt['conclusion'] == 'preserved' and receipt['originalFailureUnchanged']
    assert receipt['sourceFiles'] == len(manifest['files']) == 14734
    assert receipt['sourceRevision'] == original_native['source_revision']
    assert receipt['actualCompilerSha256'] == original_native['compilerSha256']
    assert sha(preserved/'actual-failed-cli') == receipt['actualCompilerSha256']
    assert sha(preserved/'frozen-source.tar.gz') == receipt['archiveSha256'] == manifest['archiveSha256']
    with tarfile.open(preserved/'frozen-source.tar.gz') as archive:
        hashes = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                  for member in archive if member.isfile()}
    assert hashes == manifest['files']
    for name,value in receipt['retained'].items():
        assert sha(r5/name) == sha(preserved/'failure'/name) == value
    failures['r4'] = {'audit':str(r4.relative_to(repo)), 'sha256':sha(r4),
        'acceptanceCredit':0, 'platformTestsStarted':False}
    failures['r5'] = {'audit':str((preserved/'receipt.json').relative_to(repo)),
        'sha256':sha(preserved/'receipt.json'), 'acceptanceCredit':0,
        'partialNativeSuites':191, 'partialNativeFunctions':1086,
        'completePackageFailedAt':'defu-cold-project', 'preservedSourceFiles':14734}
    r6 = repo/'target/higher-order-inference-acceptance-20261114-r6'
    r6_launch = read(r6/'launch-state.json')
    assert r6_launch['conclusion'] == 'failure' and r6_launch['platforms']['mac']['exit'] == 1
    assert r6_launch['platforms']['windows']['exit'] == 0
    assert read(r6/'mac-driver.json')['conclusion'] == 'failure'
    r6_native = read(r6/'accepted-native/measurement.json')
    gt7 = next(row for row in r6_native['suites'] if row['harness'].endswith('/gt7_library_manifest.rs'))
    assert gt7['conclusion'] == 'failure' and gt7['exit_code'] == 101 and gt7['signal'] is None
    assert 'Promise<Promise<string>>' in (r6/'accepted-native'/gt7['log']).read_text()
    stopped = read(r6/'owned-mac-stop-1/receipt.json')
    assert stopped['verifiedNoLiveOwnedTestProcesses'] and stopped['originalGt7FailureUnchanged']
    preserved6 = root/'r6-gt7-failure-preservation-1'
    receipt6 = read(preserved6/'receipt.json')
    assert receipt6['conclusion'] == 'source-preserved-before-owned-Mac-stop' and receipt6['wholeAcceptanceCredit'] == 0
    assert receipt6['sourceFiles'] == len(receipt6['files']) == 14736
    assert sha(preserved6/'frozen-source.tar.gz') == receipt6['archiveSha256']
    assert sha(preserved6/'actual-failed-cli') == receipt6['actualCompilerSha256']
    with tarfile.open(preserved6/'frozen-source.tar.gz') as archive:
        source6 = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                   for member in archive if member.isfile()}
    assert source6 == receipt6['files']
    verified6 = read(r6/'windows/windows-acceptance-verification.json')
    assert verified6['conclusion'] == 'success' and verified6['sourceRevision'] == receipt6['sourceRevision']
    assert verified6['archiveSha256'] == sha(r6/'windows-evidence.tar.gz')
    failures['r6'] = {'audit':str((preserved6/'receipt.json').relative_to(repo)),
        'sha256':sha(preserved6/'receipt.json'),'acceptanceCredit':0,
        'preservedSourceFiles':14736,'completePackageFailedAt':'gt7-promise-adoption',
        'remainingMacTestsExplicitlyStopped':True,'windowsArchiveIndependentlyVerified':True}
    r7 = repo/'target/higher-order-inference-acceptance-20261114-r7'
    seventh = read(r7/'launch-state.json')
    assert seventh['conclusion'] == 'failure' and seventh['stage'] == 'freeze'
    assert seventh['platforms'] == {} and not (r7/'frozen-source-preflight.json').exists()
    assert "index.lock': File exists." in (r7/'freeze-launch.log').read_text()
    assert seventh['steps'][-1]['exit'] == 1
    assert sha(r7/'freeze-launch.log') == seventh['steps'][-1]['sha256']
    failures['r7'] = {'audit':str((r7/'launch-state.json').relative_to(repo)),
        'sha256':sha(r7/'launch-state.json'),'acceptanceCredit':0,
        'platformTestsStarted':False,'completePackageFailedAt':'git-index-lock-preflight'}
    r8 = repo/'target/higher-order-inference-acceptance-20261114-r8'
    eighth = read(r8/'launch-state.json')
    assert eighth['conclusion'] == 'failure'
    assert eighth['platforms']['mac']['exit'] == eighth['platforms']['windows']['exit'] == 1
    partial = read(r8/'accepted-native/measurement.json')
    gt7_native = next(row for row in partial['suites'] if row['harness'].endswith('/gt7_library_manifest.rs'))
    assert gt7_native['conclusion'] == 'success' and gt7_native['passed'] == 7
    assert read(r8/'owned-mac-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
    preserved8 = root/'r8-oracle-failure-preservation-1'
    receipt8 = read(preserved8/'receipt.json')
    assert receipt8['wholeAcceptanceCredit'] == 0 and receipt8['sourceFiles'] == len(receipt8['files']) == 14738
    assert sha(preserved8/'frozen-source.tar.gz') == receipt8['archiveSha256']
    assert sha(preserved8/'actual-native-cli') == receipt8['actualNativeCompilerSha256']
    with tarfile.open(preserved8/'frozen-source.tar.gz','r|gz') as archive:
        source8 = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                   for member in archive if member.isfile()}
    assert source8 == receipt8['files']
    windows8 = r8/'windows/failed-evidence-preservation-1'
    checked8 = read(windows8/'state.json')
    assert checked8['conclusion'] == 'success' and checked8['originalFailureUnchanged']
    assert checked8['verifiedSourceFiles'] == 14822
    assert sha(windows8/'failed-evidence.tar.gz') == checked8['archiveSha256']
    assert '"code":6053' in (r8/'windows/gt7-failure-observation-1/gt7_library_manifest.stderr').read_text()
    with tarfile.open(windows8/'failed-evidence.tar.gz','r|gz') as archive:
        windows_sources = {member.name[len('source/'):]:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                           for member in archive if member.isfile() and member.name.startswith('source/')}
    assert windows_sources == read(r8/'windows/windows-source-manifest.json')['files']
    failures['r8'] = {'audit':str((windows8/'state.json').relative_to(repo)),
        'sha256':sha(windows8/'state.json'),'acceptanceCredit':0,
        'completePackageFailedAt':'Windows-gt7-Native-virtual-host-path',
        'preservedMacSourceFiles':14738,'preservedWindowsSourceFiles':14822,
        'nativeGt7Passed':7,'remainingMacTestsExplicitlyStopped':True}
    r9 = repo/'target/higher-order-inference-acceptance-20261114-r9'
    ninth = read(r9/'launch-state.json')
    assert ninth['conclusion'] == 'failure'
    assert ninth['platforms']['mac']['exit'] == 1 and ninth['platforms']['windows']['exit'] == 0
    native9 = read(r9/'accepted-native/measurement.json')
    assert native9['conclusion'] == 'success' and len(native9['suites']) == 191
    assert sum(row['passed'] for row in native9['suites']) == 1088
    assert read(r9/'project-gates.json')['conclusion'] == 'success'
    assert read(r9/'owned-workspace-stop-1/receipt.json')['verifiedNoLiveOwnedTestProcesses']
    preserved9 = root/'r9-diagnostics-version-failure-preservation-1'
    receipt9 = read(preserved9/'receipt.json')
    assert receipt9['sourceFiles'] == len(receipt9['files']) == 14738
    assert receipt9['wholeAcceptanceCredit'] == 0
    assert sha(preserved9/'frozen-source.tar.gz') == receipt9['archiveSha256']
    with tarfile.open(preserved9/'frozen-source.tar.gz','r|gz') as archive:
        source9 = {member.name:hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                   for member in archive if member.isfile()}
    assert source9 == receipt9['files']
    for name,row in receipt9['products'].items():
        assert sha(preserved9/name) == row['sha256']
    failed9 = (preserved9/'original-diagnostics-failure.log').read_text()
    assert 'test result: FAILED. 9 passed; 1 failed;' in failed9
    assert 'typescript-5.9.3-diagnostics-v13' in failed9 and 'typescript-5.9.3-diagnostics-v12' in failed9
    win9 = read(r9/'windows/windows-acceptance-verification.json')
    assert win9['conclusion'] == 'success' and win9['coreOracles'] == 82
    assert win9['paths'] == 25 and len(win9['regressionCohorts']) == 26
    assert sha(r9/'windows-evidence.tar.gz') == win9['archiveSha256']
    failures['r9'] = {'acceptanceCredit':0,'completePackageFailedAt':'workspace-diagnostics-version-assertion',
        'preservedSourceFiles':14738,'nativeSuites':191,'nativeFunctions':1088,
        'windowsCoreOracles':82,'windowsCompleteCohorts':26,'remainingWorkspaceExplicitlyStopped':True,
        'originalFailureUnchanged':True,'sourceArchiveSha256':receipt9['archiveSha256']}
    return {'conclusion':'success','parentCommit':frozen['parentCommit'],
        'productionStartedOnlyAfterFrozenNativeAndRed':True,'preimplementationSourceFilesVerified':len(keys),
        'completeBaselineComparisons':384,'baselineAgreements':48,'baselineDifferences':336,
        'redComparisonsIndependentlyMatched':384,'publishedPreRepairArchives':archives,
        'priorWindowsFailureEvidence':{key:failures[key] for key in ['r1','r2','r3']},
        'priorWholeGateFailureEvidence':{key:failures[key] for key in ['r4','r5','r6','r7','r8','r9']},'baselineInventoryCredit':0}
