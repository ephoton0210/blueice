# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Prove packaging-only recovery without rewriting the failed R10 supervisors."""
from pathlib import Path
import ast
import hashlib
import json


def audit(root):
    read = lambda p: json.loads(p.read_bytes())
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    recovery = root.parent/'higher-order-inference-contract-20261114/r10-windows-packaging-recovery-1'
    state = read(recovery/'state.json')
    assert state['conclusion'] == 'success' and state['stage'] == 'complete'
    assert state['sourceRevision'] == read(root/'frozen-source-preflight.json')['sourceRevision']
    assert state['testReruns'] == state['runtimeDriversChanged'] == 0
    assert state['originalWindowsSupervisorConclusion'] == 'failure'
    assert state['originalPackagingExit'] == 1 and state['correctedPackagingExit'] == 0
    assert read(recovery/'package-terminal.json')['exitcode'] == 0
    preserved = read(recovery/'original-manifest.json')
    assert sha(recovery/'original-manifest.json') == state['originalFailureManifestSha256']
    for name,row in preserved.items():
        assert sha(root/name) == sha(recovery/'original'/name) == row['sha256'], name
    terminal = read(root/'windows/package-terminal.json')
    assert terminal['exitcode'] == 1 and "len(measurement['followups']) == 26" in terminal['err-data']
    assert read(root/'windows/complete-state.json')['conclusion'] == 'failure'
    final = read(root/'windows/finalize-state.json')
    assert final['conclusion'] == 'failure' and final['downloadAttempts'] == 0
    assert read(root/'windows/bootstrap-terminal.json')['exitcode'] == 0
    original = (root/'windows/package-evidence.py').read_text()
    corrected = (recovery/'package-evidence.py').read_text()
    expected = original
    prefix = 'p0g-r10-packaging-recovery-1'
    replacements = {
        "len(measurement['followups']) == 26":"len(measurement['followups']) == 27",
        "== {'higher_order_inference',":"== {'diagnostics', 'higher_order_inference',",
        "'p0g-r10-evidence-state.json'":repr(prefix+'-evidence-state.json'),
        "'p0g-r10-full-source.tar.gz'":repr(prefix+'-full-source.tar.gz'),
        "'p0g-r10-windows-evidence.tar.gz'":repr(prefix+'-windows-evidence.tar.gz'),
        "'p0g-r10-windows-evidence.json'":repr(prefix+'-windows-evidence.json'),
    }
    for old,new in replacements.items():
        assert expected.count(old) == 1
        expected = expected.replace(old,new)
    assert corrected == expected
    measurement_path = root/'windows/windows-measurement.json'
    assert measurement_path.read_bytes() == (root/'windows/terminal-test-observation-1.json').read_bytes()
    measurement = read(measurement_path)
    assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
    assert len(measurement['followups']) == 27
    assert all(row['passed'] and row['exit'] == 0 for row in measurement['followups'])
    outcomes = {}
    for label,code in [('original',original),('corrected',corrected)]:
        assertions = [node for node in ast.walk(ast.parse(code)) if isinstance(node,ast.Assert)
            and 'measurement[\'followups\']' in ast.get_source_segment(code,node)]
        assert len(assertions) == 2
        try:
            exec(compile(ast.Module(body=assertions,type_ignores=[]),label,'exec'),{'measurement':measurement})
            outcomes[label] = 'accepted'
        except AssertionError:
            outcomes[label] = 'rejected'
    assert outcomes == {'original':'rejected','corrected':'accepted'}
    proof = read(recovery/'repair-proof.json')
    assert proof['assertionReplay'] == outcomes and proof['replacements'] == replacements
    assert proof['originalPackageSha256'] == sha(root/'windows/package-evidence.py')
    assert proof['correctedPackageSha256'] == sha(recovery/'package-evidence.py')
    assert proof['terminalMeasurementSha256'] == sha(measurement_path)
    assert state['repairProofSha256'] == sha(recovery/'repair-proof.json')
    verification = root/'windows/windows-acceptance-verification.json'
    assert state['verificationSha256'] == sha(verification)
    assert state['archiveSha256'] == read(verification)['archiveSha256'] == sha(root/'windows-evidence.tar.gz')
    return {'receipt':'development-history/contract/r10-windows-packaging-recovery-1/state.json',
        'receiptSha256':sha(recovery/'state.json'),
        'originalFailureManifest':'development-history/contract/r10-windows-packaging-recovery-1/original-manifest.json',
        'originalFailureManifestSha256':sha(recovery/'original-manifest.json'),
        'repairProof':'development-history/contract/r10-windows-packaging-recovery-1/repair-proof.json',
        'repairProofSha256':sha(recovery/'repair-proof.json'),
        'originalPackagingExit':1,'correctedPackagingExit':0,
        'testReruns':0,'runtimeDriversChanged':0,'originalTerminalMeasurementUnchanged':True}
