# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import json

REPO = Path(__file__).resolve().parents[2]
DEST = REPO / 'backend/bluets/tests/fixtures/mapped_inference'
DEST.mkdir(exist_ok=False)
seeds = json.loads((REPO / 'target/p0-shared-inference-discovery-20261113/inputs.json').read_text())['cases']
cases = [{**row, 'family': 'original-discovery'} for row in seeds]


def add(identifier, source, family, **extra):
    assert identifier not in {row['id'] for row in cases}
    cases.append({'id': identifier, 'source': source, 'family': family, **extra})


def unpack(identifier, setup, argument, *, constraint='', value='{value: T[K]}',
           modifier='', optional='', extra_options=None):
    source = f'declare function unpack<T{constraint}>(x: {{{modifier}[K in keyof T]{optional}: {value}}}): T;\n'
    source += setup + f'export const result = unpack({argument});\n'
    add(identifier, source, 'sequence-shapes', **({'compilerOptions': extra_options} if extra_options else {}))


for name, setup, argument in [
    ('empty-unconstrained', '', '[]'),
    ('homogeneous-literal', '', '[{value: 1}, {value: 2}]'),
    ('single-literal', '', '[{value: "Ada"}]'),
    ('ordinary-array-variable', 'declare const input: {value: string}[];\n', 'input'),
    ('heterogeneous-array-variable', 'declare const input: ({value: string} | {value: number})[];\n', 'input'),
    ('mutable-tuple-variable', 'declare const input: [{value: string}, {value: number}];\n', 'input'),
    ('labeled-tuple-variable', 'declare const input: [name: {value: string}, count: {value: number}];\n', 'input'),
    ('optional-tuple-variable', 'declare const input: [name: {value: string}, count?: {value: number}];\n', 'input'),
    ('readonly-labeled-tuple', 'declare const input: readonly [name: {value: string}, count: {value: number}];\n', 'input'),
    ('readonly-optional-tuple', 'declare const input: readonly [name: {value: string}, count?: {value: number}];\n', 'input'),
    ('rest-tuple-variable', 'declare const input: [head: {value: string}, ...tail: {value: number}[]];\n', 'input'),
    ('readonly-rest-tuple', 'declare const input: readonly [head: {value: string}, ...tail: {value: number}[]];\n', 'input'),
    ('leading-rest-tuple', 'declare const input: [...prefix: {value: string}[], last: {value: number}];\n', 'input'),
    ('optional-rest-tuple', 'declare const input: [first?: {value: string}, ...tail: {value: number}[]];\n', 'input'),
    ('spread-fixed-tuple', 'declare const input: [{value: string}, {value: number}];\n', '[...input]'),
    ('spread-variable-array', 'declare const input: {value: number}[];\n', '[{value: "Ada"}, ...input]'),
    ('nested-wrapper-array', '', '[{value: {inner: "Ada"}}, {value: {inner: 3}}]'),
]:
    unpack(name, setup, argument)

for name, modifier, optional in [
    ('add-readonly', 'readonly ', ''),
    ('remove-readonly', '-readonly ', ''),
    ('add-optional', '', '?'),
    ('remove-optional', '', '-?'),
]:
    for shape, setup, argument in [
        ('literal', '', '[{value: "Ada"}, {value: 3}]'),
        ('readonly-tuple', 'declare const input: readonly [name: {value: string}, count: {value: number}];\n', 'input'),
        ('record', '', '{name: {value: "Ada"}, count: {value: 3}}'),
    ]:
        unpack(name + '-' + shape, setup, argument, modifier=modifier, optional=optional)

unpack('nested-value-tuple', '', '[{inner: {value: "Ada"}}, {inner: {value: 3}}]', value='{inner: {value: T[K]}}')
unpack('callback-return-tuple', '', '[{value: () => "Ada"}, {value: () => 3}]', value='{value: () => T[K]}')
unpack('array-element-wrapper', '', '[["Ada"], [3]]', value='T[K][]')
unpack('tuple-element-wrapper', '', '[["Ada"], [3]]', value='[T[K]]')
unpack('constraint-mutable', '', '[{value: "Ada"}, {value: 3}]', constraint=' extends unknown[]')
unpack('constraint-readonly', '', '[{value: "Ada"}, {value: 3}]', constraint=' extends readonly unknown[]')
unpack('constraint-record-rejects-array', '', '[{value: "Ada"}, {value: 3}]', constraint=' extends {name: string}')
unpack('literal-union-elements', '', '[{value: "Ada" as "Ada" | "Grace"}, {value: 1 as 1 | 2}]')
unpack('null-undefined-elements', '', '[{value: null}, {value: undefined}]')
unpack('empty-record', '', '{}')
unpack('optional-exact-flag', 'declare const input: [name: {value: string}, count?: {value: number}];\n', 'input', extra_options={'exactOptionalPropertyTypes': True})
unpack('unchecked-index-flag', 'declare const input: [head: {value: string}, ...tail: {value: number}[]];\n', 'input', extra_options={'noUncheckedIndexedAccess': True})

add('imported-box-alias', 'import {unpack} from "./helper";\nexport const result = unpack([{value: "Ada"}, {value: 3}]);\n', 'aliases', files={'helper.ts': 'export type Box<T> = {value: T};\nexport type Boxes<T> = {[K in keyof T]: Box<T[K]>};\nexport declare function unpack<T>(x: Boxes<T>): T;\n'})
add('imported-generic-return', 'import {unpack} from "./helper";\nexport function result() { return unpack([{value: "Ada"}, {value: 3}]); }\n', 'aliases', files={'helper.ts': 'export declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;\n'}, resultKind='function')
add('nested-alias-tuple', 'type Inner<T> = {value: T};\ntype Outer<T> = {inner: Inner<T>};\ndeclare function unpack<T>(x: {[K in keyof T]: Outer<T[K]>}): T;\nexport const result = unpack([{inner: {value: "Ada"}}, {inner: {value: 3}}]);\n', 'aliases')
add('callback-array-context', 'declare function unpack<T>(x: {[K in keyof T]: {value: T[K]; consume: (value: T[K]) => void}}): T;\nexport const result = unpack([{value: "Ada", consume: value => { const checked: string = value; }}, {value: 3, consume: value => { const checked: number = value; }}]);\n', 'callbacks')
add('callback-record-incompatible', 'declare function unpack<T>(x: {[K in keyof T]: {value: T[K]; consume: (value: T[K]) => void}}): T;\nexport const result = unpack({name: {value: "Ada", consume: (value: number) => {}}});\n', 'callbacks')
add('explicit-wrong-box-key', 'declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;\nexport const result = unpack<[string, number]>([{missing: "Ada"}, {value: 3}]);\n', 'rejections')
add('explicit-too-short', 'declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;\nexport const result = unpack<[string, number]>([{value: "Ada"}]);\n', 'rejections')
add('explicit-too-long', 'declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;\nexport const result = unpack<[string]>([{value: "Ada"}, {value: 3}]);\n', 'rejections')
add('identity-runtime', 'function identity<T>(x: {[K in keyof T]: T[K]}): T { return x as T; }\nexport const result = identity(["Ada", 3]);\nexport const runtime = result[0] === "Ada" && result[1] === 3 ? 2 : 0;\n', 'runtime', runtime=True)
add('boxed-runtime', 'function unpack<T extends unknown[]>(x: {[K in keyof T]: {value: T[K]}}): T { return [x[0].value, x[1].value] as unknown as T; }\nexport const result = unpack([{value: "Ada"}, {value: 3}]);\nexport const runtime = result[0] === "Ada" && result[1] === 3 ? 2 : 0;\n', 'runtime', runtime=True)

for word in ['number', 'string', 'boolean', 'bigint', 'symbol', 'any', 'unknown', 'never', 'object', 'readonly', 'keyof', 'infer', 'as', 'is', 'asserts', 'type', 'of', 'satisfies', 'namespace', 'module', 'declare', 'abstract', 'override', 'async', 'from', 'get', 'set', 'constructor', 'require', 'global']:
    add('binding-' + word, f'const {word}: number = 3;\nexport const result = {word};\n', 'contextual-bindings')
for word in ['class', 'return', 'true', 'this']:
    add('reserved-binding-' + word, f'const {word}: number = 3;\nexport const result = 3;\n', 'reserved-rejections')

profiles = [{'id': target.lower() + '-' + module.lower() + '-strict', 'compilerOptions': {'target': target, 'module': module}}
            for target in ['ES5', 'ES2022'] for module in ['CommonJS', 'ESNext']]
data = {'schema': 1, 'options': {'strict': True, 'declaration': True, 'noEmitOnError': True, 'lib': ['ES5']}, 'profiles': profiles, 'cases': cases}
(DEST / 'cases.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'forms': len(cases), 'profiles': len(profiles), 'comparisons': len(cases) * len(profiles), 'families': sorted({row['family']for row in cases})}))
