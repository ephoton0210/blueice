# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile
from audit_acceptance import ROOT, REPO, PHASE, read, sha, command

PREFIX = 'MAPPED_INFERENCE_'


def main():
    measurement = read(PHASE / (PREFIX + 'MEASUREMENT.json'))
    assert measurement['conclusion'] == 'completed-within-frozen-scope'
    assert measurement['fullTypeScriptParity'] is False and measurement['broaderFeatureRowsOpen'] == 22
    source = measurement['source']['sourceRevision']
    assert source == read(ROOT / 'acceptance-audit.json')['sourceRevision']
    tree = command('git', 'write-tree')
    assert command('git', 'rev-parse', tree + ':backend') == source.split(':', 1)[1]
    assert not command('git', 'diff', '--numstat', '--', 'backend')
    artifacts = read(PHASE / (PREFIX + 'ARTIFACTS.json'))
    assert artifacts['sourceRevision'] == source and artifacts['artifacts'] == measurement['artifacts']
    rows = artifacts['artifacts']
    assert len({row['path'] for row in rows}) == len(rows) >= 6
    owners = {}
    for row in rows:
        path = PHASE / row['path']
        assert path.stat().st_size == row['bytes'] < 95 * 1024 * 1024
        assert sha(path) == row['sha256']
        expected = dict(row.get('membersSha256', {}))
        seen = set()
        with tarfile.open(path, 'r|gz') as archive:
            for member in archive:
                assert member.isfile() and not Path(member.name).is_absolute()
                assert '..' not in Path(member.name).parts and member.name not in seen
                seen.add(member.name)
                if row.get('originalWindowsArchive'):
                    continue
                assert member.name in expected, (path, member.name)
                digest = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                assert digest == expected.pop(member.name)
                assert member.name not in owners, member.name
                owners[member.name] = {'archive': row['path'], 'path': member.name, 'sha256': digest}
        if not row.get('originalWindowsArchive'):
            assert not expected, (path, expected.keys())
        else:
            assert row['sha256'] == measurement['windows']['archiveSha256']
    for kind in ['native', 'workspace']:
        assert owners['accepted-' + kind + '-cli']['sha256'] == measurement['gates'][kind + 'CompilerSha256']
        for family in ['mappedInferenceReports', 'stringIntrinsicReports']:
            reference = measurement[family][kind]
            assert owners[reference['path']] == reference
        for reference in measurement['noInferReports'][kind].values():
            assert owners[reference['path']] == reference
        assert owners[kind + '-declaration-map-report.json']['sha256'] == measurement['mapBindings'][kind]['reportSha256']
    for kind in ['native','workspace']:
        reference = measurement['nonNullableAwaitedReports'][kind]
        assert owners[reference['path']] == reference
    for prior in measurement['retiredCandidates']:
        assert owners[prior['reference']['path']] == prior['reference']
        assert owners[prior['windowsAudit']['path']] == prior['windowsAudit']
        assert owners['retired-native-' + prior['label'] + '/windows-retired-evidence.tar.gz']['sha256'] == prior['windowsArchiveSha256']
        assert prior['passCredit'] is False
    assert owners['source-snapshots/manifest.json'] == measurement['sourceSnapshots']
    assert measurement['directObservations'] == 404 and measurement['caseInventoryAdditions'] == 416
    assert measurement['supplementaryControls'] == 21 and measurement['supplementaryInventoryCredit'] == 0
    assert measurement['supplementaryNativeAgreements'] == 11 and measurement['supplementaryOwnerRefusals'] == 10
    assert owners['baseline-cli']['sha256'] == measurement['baseline']['compilerSha256']
    assert owners['baseline-accepted-c-bridge.json'] == measurement['baseline']['reference']
    assert len(measurement['baseline']['rawObservations']) == 404
    for row in measurement['baseline']['rawObservations']:
        assert owners[row['observation']['path']] == row['observation']
    assert owners[measurement['supplementaryNativeReplay']['path']] == measurement['supplementaryNativeReplay']
    native = read(PHASE / 'COMPATIBILITY_MEASUREMENT.json')
    assert owners['accepted-native/measurement.json']['sha256'] == sha(PHASE / 'COMPATIBILITY_MEASUREMENT.json') == measurement['nativeMeasurement']['sha256']
    assert len(native['suites']) == measurement['nativeMeasurement']['suites'] == 188
    assert sum(row['passed'] for row in native['suites']) == measurement['nativeMeasurement']['functions'] == 1070
    for suite in native['suites']:
        assert owners['accepted-native/' + suite['log']]['sha256'] == suite['log_sha256']
    for step in measurement['gates']['steps']:
        assert owners[step['log']]['sha256'] == step['sha256']
    for reference in measurement['projects'].values():
        assert owners[reference['path']] == reference
    assert measurement['casePreservation'] == {'previous': 41636, 'current': 42052, 'added': 416, 'allOldCasesUnchanged': True}
    assert owners['all-source-module-size-audit.json'] == measurement['modules']['audit']
    assert measurement['modules']['files'] == 566 and measurement['modules']['maximumLines'] < 1500
    old = (ROOT / 'todo-before-acceptance.md').read_text()
    todo = (PHASE / 'TODO.md').read_text()
    before = re.findall(r'^\s*- \[([ x])\]', old, re.MULTILINE)
    after = re.findall(r'^\s*- \[([ x])\]', todo, re.MULTILINE)
    assert len(before) == len(after)
    assert [(a, b) for a, b in zip(before, after) if a != b] == [(' ', 'x')]
    assert '- [x] **P0-A —' in todo and '- [x] **P0-B —' in todo and '- [x] **P0-C —' in todo and '- [x] **P0-D —' in todo
    inventory = (PHASE / 'COMPATIBILITY_INVENTORY.md').read_text()
    feature_rows = re.findall(r'^\| (G-[A-Z]\d+) \| ([^|]+) \|', inventory, re.MULTILINE)
    assert len(feature_rows) == len({identifier for identifier, _ in feature_rows}) == 23
    assert sum(status.strip() == 'open' for _, status in feature_rows) == 22
    assert all(status.strip() == 'open' for identifier, status in feature_rows if identifier != 'G-C2')
    for name in ['MAPPED_INFERENCE_ACCEPTANCE.md', 'MAPPED_INFERENCE_FOLLOWUP.md', 'TODO.md']:
        path = PHASE / name
        assert b'\r' not in path.read_bytes(), name
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', path.read_text()):
            if target.startswith(('https://', 'http://', '#')):
                continue
            filename = target.split('#', 1)[0].strip('<>')
            assert (path.parent / filename).exists(), (name, target)
    subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=REPO, check=True)
    result = {'conclusion': 'success', 'sourceRevision': source, 'artifacts': len(rows),
              'allArchivedMemberHashesVerified': True, 'exactlyOneTodoPackageChecked': True,
              'broaderRowsOpen': 22, 'fullTypeScriptParity': False}
    (ROOT / 'publication-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
