type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E, K extends string>(values: Map<string, List<E[keyof E]>>, key: K, event: E[keyof E]) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }
