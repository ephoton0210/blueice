export function result<P>(input: P) { const fn: <P>(value: P) => P = value => value; return fn; }
