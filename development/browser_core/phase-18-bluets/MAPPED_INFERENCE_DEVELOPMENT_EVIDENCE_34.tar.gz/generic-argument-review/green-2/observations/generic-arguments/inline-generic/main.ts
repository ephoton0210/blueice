export function result<P>(handler: (event: P) => void, event: P) { return handler(event); }
