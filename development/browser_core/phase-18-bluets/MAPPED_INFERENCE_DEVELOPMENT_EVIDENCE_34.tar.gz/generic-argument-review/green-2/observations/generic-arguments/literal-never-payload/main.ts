type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result(values: Map<string, List<never>>, key: string, event: never) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }
