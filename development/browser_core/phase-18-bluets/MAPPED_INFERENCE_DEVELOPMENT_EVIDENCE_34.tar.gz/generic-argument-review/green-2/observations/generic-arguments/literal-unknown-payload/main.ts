type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result(values: Map<string, List<unknown>>, key: string, event: unknown) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }
