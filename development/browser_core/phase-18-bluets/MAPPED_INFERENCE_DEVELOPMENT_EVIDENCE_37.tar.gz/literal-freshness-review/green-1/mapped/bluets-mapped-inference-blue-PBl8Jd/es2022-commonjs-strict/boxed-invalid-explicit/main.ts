declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack<[string, number]>([{value: "Ada"}, {value: false}]);
