export declare const result: readonly [name: string, count: number];
