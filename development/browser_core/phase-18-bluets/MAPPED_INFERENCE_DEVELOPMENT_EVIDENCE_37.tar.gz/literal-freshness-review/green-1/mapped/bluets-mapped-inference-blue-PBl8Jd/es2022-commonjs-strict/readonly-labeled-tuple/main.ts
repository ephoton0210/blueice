declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: readonly [name: {value: string}, count: {value: number}];
export const result = unpack(input);
