const infer: number = 3;
export const result = infer;
