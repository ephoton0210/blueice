export declare const result: [head: string, ...tail: number[]];
