declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack({name: {value: "Ada"}, count: {value: 3}});
