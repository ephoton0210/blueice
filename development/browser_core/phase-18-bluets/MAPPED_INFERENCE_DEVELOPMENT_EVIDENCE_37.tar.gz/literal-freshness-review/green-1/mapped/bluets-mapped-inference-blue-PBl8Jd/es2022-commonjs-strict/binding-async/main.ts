const async: number = 3;
export const result = async;
