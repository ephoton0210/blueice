const never: number = 3;
export const result = never;
