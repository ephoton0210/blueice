const set: number = 3;
export const result = set;
