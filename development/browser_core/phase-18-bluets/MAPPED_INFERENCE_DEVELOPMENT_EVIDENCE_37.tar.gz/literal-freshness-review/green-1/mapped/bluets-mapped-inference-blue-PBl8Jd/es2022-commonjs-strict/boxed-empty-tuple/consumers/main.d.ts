export declare const result: [];
