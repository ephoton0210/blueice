const satisfies: number = 3;
export const result = satisfies;
