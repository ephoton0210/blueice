declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack([{value: "Ada" as "Ada" | "Grace"}, {value: 1 as 1 | 2}]);
