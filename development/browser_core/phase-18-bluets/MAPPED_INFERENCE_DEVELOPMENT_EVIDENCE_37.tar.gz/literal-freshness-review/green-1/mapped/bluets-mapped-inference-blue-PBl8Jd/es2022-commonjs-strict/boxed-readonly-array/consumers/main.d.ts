export declare const result: readonly string[];
