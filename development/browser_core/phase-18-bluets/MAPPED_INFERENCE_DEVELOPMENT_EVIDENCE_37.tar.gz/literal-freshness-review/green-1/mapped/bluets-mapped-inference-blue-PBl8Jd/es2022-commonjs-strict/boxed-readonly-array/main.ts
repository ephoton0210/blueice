declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: readonly {value: string}[];
export const result = unpack(input);
