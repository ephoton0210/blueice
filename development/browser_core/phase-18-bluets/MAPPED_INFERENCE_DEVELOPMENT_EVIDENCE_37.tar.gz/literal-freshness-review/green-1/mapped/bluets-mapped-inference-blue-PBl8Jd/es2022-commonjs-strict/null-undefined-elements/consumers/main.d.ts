export declare const result: [null, undefined];
