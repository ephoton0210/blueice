declare function unpack<T>(x: {[K in keyof T]: {inner: {value: T[K]}}}): T;
export const result = unpack([{inner: {value: "Ada"}}, {inner: {value: 3}}]);
