const require: number = 3;
export const result = require;
