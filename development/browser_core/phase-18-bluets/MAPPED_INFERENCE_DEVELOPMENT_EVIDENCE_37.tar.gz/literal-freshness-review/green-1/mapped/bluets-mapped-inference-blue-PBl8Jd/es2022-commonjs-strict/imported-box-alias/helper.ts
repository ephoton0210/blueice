export type Box<T> = {value: T};
export type Boxes<T> = {[K in keyof T]: Box<T[K]>};
export declare function unpack<T>(x: Boxes<T>): T;
