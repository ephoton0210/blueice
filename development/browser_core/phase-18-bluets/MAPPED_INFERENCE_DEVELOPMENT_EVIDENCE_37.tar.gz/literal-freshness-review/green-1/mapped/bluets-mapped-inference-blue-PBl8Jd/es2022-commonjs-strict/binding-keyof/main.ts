const keyof: number = 3;
export const result = keyof;
