declare function unpack<T>(x: {[K in keyof T]: {value: T[K]; consume: (value: T[K]) => void}}): T;
export const result = unpack({name: {value: "Ada", consume: (value: number) => {}}});
