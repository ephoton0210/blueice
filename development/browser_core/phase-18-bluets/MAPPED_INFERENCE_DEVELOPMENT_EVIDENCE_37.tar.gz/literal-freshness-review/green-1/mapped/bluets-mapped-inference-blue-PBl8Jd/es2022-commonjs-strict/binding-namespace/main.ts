const namespace: number = 3;
export const result = namespace;
