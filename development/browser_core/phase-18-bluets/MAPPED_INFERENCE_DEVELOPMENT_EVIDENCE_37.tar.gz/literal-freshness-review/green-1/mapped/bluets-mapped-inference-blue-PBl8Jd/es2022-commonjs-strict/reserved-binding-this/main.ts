const this: number = 3;
export const result = 3;
