declare function unpack<T>(x: {[K in keyof T]: [T[K]]}): T;
export const result = unpack([["Ada"], [3]]);
