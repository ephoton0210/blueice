const any: number = 3;
export const result = any;
