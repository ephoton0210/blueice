export declare const result: {
    name: string;
    count: number;
};
