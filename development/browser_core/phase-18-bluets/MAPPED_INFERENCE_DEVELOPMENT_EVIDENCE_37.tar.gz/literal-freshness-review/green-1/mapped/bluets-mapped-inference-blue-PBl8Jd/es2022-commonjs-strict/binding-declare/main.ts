const declare: number = 3;
export const result = declare;
