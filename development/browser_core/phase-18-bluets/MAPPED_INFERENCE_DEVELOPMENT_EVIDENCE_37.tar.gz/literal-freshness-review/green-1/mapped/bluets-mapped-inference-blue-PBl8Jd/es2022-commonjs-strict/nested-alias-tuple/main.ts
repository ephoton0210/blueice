type Inner<T> = {value: T};
type Outer<T> = {inner: Inner<T>};
declare function unpack<T>(x: {[K in keyof T]: Outer<T[K]>}): T;
export const result = unpack([{inner: {value: "Ada"}}, {inner: {value: 3}}]);
