export declare const result: [...prefix: string[], last: number];
