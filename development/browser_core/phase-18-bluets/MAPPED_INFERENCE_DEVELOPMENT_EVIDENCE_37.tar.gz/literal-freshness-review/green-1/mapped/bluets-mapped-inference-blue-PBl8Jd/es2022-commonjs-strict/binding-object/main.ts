const object: number = 3;
export const result = object;
