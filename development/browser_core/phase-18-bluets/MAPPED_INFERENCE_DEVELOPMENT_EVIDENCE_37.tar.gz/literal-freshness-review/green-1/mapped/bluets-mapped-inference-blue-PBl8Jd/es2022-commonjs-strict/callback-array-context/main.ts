declare function unpack<T>(x: {[K in keyof T]: {value: T[K]; consume: (value: T[K]) => void}}): T;
export const result = unpack([{value: "Ada", consume: value => { const checked: string = value; }}, {value: 3, consume: value => { const checked: number = value; }}]);
