const override: number = 3;
export const result = override;
