const unknown: number = 3;
export const result = unknown;
