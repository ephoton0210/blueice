const is: number = 3;
export const result = is;
