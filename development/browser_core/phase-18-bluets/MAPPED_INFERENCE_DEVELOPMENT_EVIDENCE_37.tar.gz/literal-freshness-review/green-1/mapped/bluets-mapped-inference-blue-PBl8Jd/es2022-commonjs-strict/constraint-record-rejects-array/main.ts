declare function unpack<T extends {name: string}>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack([{value: "Ada"}, {value: 3}]);
