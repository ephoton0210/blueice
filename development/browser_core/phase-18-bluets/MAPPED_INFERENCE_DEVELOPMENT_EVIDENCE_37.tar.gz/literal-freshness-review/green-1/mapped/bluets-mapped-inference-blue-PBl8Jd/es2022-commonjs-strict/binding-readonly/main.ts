const readonly: number = 3;
export const result = readonly;
