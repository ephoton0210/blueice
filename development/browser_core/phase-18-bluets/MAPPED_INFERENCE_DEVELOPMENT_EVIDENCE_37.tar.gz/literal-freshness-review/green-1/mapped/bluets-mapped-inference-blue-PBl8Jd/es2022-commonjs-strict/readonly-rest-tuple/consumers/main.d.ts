export declare const result: readonly [head: string, ...tail: number[]];
