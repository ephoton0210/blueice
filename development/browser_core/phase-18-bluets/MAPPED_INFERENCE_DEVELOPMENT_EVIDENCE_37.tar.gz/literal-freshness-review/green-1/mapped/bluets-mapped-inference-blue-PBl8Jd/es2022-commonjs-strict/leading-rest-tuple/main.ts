declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: [...prefix: {value: string}[], last: {value: number}];
export const result = unpack(input);
