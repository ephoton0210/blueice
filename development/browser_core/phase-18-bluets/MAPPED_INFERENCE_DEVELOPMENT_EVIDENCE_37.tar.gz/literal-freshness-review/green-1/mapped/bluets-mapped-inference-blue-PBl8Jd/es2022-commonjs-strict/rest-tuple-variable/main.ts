declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: [head: {value: string}, ...tail: {value: number}[]];
export const result = unpack(input);
