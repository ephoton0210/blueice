type Box<T> = {value: T};
type Boxes<T> = {[K in keyof T]: Box<T[K]>};
declare function unpack<T>(x: Boxes<T>): T;
export const result = unpack([{value: "Ada"}, {value: 3}]);
