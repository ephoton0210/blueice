const global: number = 3;
export const result = global;
