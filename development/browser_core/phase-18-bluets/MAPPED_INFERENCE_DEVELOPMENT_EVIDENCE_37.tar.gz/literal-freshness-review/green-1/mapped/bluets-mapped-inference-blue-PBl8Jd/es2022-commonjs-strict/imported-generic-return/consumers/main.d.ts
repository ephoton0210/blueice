export declare function result(): [string, number];
