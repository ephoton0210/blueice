const module: number = 3;
export const result = module;
