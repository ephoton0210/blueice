export declare const result: [{
    inner: string;
}, {
    inner: number;
}];
