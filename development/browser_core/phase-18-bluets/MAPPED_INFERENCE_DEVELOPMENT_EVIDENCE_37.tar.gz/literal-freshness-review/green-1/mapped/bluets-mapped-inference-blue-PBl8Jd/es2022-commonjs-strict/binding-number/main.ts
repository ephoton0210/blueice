const number: number = 3;
export const result = number;
