declare function unpack<T>(x: {readonly [K in keyof T]: {value: T[K]}}): T;
export const result = unpack([{value: "Ada"}, {value: 3}]);
