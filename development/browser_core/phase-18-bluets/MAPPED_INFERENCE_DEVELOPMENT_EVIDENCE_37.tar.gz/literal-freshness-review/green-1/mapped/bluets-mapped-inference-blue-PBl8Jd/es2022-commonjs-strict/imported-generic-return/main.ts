import {unpack} from "./helper";
export function result() { return unpack([{value: "Ada"}, {value: 3}]); }
