const as: number = 3;
export const result = as;
