const symbol: number = 3;
export const result = symbol;
