export declare const result: [string];
