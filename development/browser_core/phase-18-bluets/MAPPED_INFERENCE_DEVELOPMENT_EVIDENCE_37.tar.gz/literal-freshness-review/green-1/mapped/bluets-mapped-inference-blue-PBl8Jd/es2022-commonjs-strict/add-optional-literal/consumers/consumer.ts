import {result} from "./main";
const rejected: never = result;
