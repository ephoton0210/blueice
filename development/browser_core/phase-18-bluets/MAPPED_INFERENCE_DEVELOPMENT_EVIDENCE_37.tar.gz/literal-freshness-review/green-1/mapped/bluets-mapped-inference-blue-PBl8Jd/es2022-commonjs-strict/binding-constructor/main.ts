const constructor: number = 3;
export const result = constructor;
