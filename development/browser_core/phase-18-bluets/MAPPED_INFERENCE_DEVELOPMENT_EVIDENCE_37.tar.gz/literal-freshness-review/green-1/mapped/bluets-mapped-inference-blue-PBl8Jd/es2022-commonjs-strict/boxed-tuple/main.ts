declare function unpack<T extends unknown[]>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack([{value: "Ada"}, {value: 3}]);
