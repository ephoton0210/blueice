declare function identity<T>(x: {[K in keyof T]?: T[K]}): T;
export const result = identity({name: "Ada", count: 3});
