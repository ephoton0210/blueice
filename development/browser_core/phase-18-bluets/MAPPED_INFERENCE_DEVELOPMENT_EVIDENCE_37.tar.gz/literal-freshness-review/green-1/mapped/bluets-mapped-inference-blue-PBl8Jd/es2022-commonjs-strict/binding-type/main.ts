const type: number = 3;
export const result = type;
