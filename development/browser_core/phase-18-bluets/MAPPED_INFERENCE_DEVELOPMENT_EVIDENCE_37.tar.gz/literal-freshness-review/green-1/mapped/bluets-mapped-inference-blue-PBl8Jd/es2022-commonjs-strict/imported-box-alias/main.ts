import {unpack} from "./helper";
export const result = unpack([{value: "Ada"}, {value: 3}]);
