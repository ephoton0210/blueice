const bigint: number = 3;
export const result = bigint;
