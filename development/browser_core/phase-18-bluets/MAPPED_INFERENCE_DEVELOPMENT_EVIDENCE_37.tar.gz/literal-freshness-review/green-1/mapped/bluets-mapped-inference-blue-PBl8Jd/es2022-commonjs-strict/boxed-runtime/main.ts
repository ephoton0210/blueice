function unpack<T extends unknown[]>(x: {[K in keyof T]: {value: T[K]}}): T { return [x[0].value, x[1].value] as unknown as T; }
export const result = unpack([{value: "Ada"}, {value: 3}]);
export const runtime = result[0] === "Ada" && result[1] === 3 ? 2 : 0;
