export declare const result: [string, number];
export declare const runtime: number;
