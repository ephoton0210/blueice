declare function identity<T extends unknown[]>(x: {[K in keyof T]: T[K]}): T;
export const result = identity(["Ada", 3]);
