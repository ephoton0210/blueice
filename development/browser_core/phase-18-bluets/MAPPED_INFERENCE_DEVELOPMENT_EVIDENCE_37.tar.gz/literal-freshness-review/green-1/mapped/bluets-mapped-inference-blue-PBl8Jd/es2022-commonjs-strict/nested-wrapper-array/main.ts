declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
export const result = unpack([{value: {inner: "Ada"}}, {value: {inner: 3}}]);
