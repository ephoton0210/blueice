export declare const result: readonly ["Ada", 3];
