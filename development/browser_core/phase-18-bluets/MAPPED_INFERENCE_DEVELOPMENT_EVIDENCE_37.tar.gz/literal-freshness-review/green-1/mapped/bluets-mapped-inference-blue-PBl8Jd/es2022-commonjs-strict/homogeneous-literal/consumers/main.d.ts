export declare const result: [number, number];
