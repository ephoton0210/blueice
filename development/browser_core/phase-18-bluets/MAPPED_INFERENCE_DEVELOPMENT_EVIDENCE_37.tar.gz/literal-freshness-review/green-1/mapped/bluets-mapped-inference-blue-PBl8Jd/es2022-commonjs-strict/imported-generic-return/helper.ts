export declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
