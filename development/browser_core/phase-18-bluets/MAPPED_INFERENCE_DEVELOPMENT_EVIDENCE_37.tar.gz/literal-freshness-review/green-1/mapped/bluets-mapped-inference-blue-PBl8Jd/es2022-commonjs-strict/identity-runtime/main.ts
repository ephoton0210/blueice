function identity<T>(x: {[K in keyof T]: T[K]}): T { return x as T; }
export const result = identity(["Ada", 3]);
export const runtime = result[0] === "Ada" && result[1] === 3 ? 2 : 0;
