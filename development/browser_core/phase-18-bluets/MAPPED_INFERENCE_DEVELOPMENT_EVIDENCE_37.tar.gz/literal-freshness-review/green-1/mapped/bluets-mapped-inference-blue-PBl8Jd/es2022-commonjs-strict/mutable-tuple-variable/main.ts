declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: [{value: string}, {value: number}];
export const result = unpack(input);
