declare function unpack<T>(x: {[K in keyof T]: {value: T[K]}}): T;
declare const input: {value: number}[];
export const result = unpack([{value: "Ada"}, ...input]);
