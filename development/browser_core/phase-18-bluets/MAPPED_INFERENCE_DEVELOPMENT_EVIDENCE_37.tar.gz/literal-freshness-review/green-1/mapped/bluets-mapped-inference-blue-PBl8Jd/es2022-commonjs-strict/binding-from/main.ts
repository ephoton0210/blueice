const from: number = 3;
export const result = from;
