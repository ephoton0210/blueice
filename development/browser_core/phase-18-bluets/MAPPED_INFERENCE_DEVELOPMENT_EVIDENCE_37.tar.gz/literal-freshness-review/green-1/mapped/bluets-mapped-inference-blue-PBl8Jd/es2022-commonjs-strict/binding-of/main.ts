const of: number = 3;
export const result = of;
