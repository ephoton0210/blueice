export declare const result: ["Ada" | "Grace", 1 | 2];
