const abstract: number = 3;
export const result = abstract;
