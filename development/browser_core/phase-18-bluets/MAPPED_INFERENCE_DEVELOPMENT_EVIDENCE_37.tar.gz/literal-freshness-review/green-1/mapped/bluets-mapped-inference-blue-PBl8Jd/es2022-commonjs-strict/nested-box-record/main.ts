declare function unpack<T>(x: {[K in keyof T]: {inner: {value: T[K]}}}): T;
export const result = unpack({name: {inner: {value: "Ada"}}, count: {inner: {value: 3}}});
