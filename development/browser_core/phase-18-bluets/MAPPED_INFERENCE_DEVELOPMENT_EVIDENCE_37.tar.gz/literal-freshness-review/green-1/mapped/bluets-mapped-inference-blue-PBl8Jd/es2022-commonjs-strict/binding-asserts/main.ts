const asserts: number = 3;
export const result = asserts;
