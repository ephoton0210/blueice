const get: number = 3;
export const result = get;
