export declare const result: [first?: string | undefined, ...tail: number[]];
