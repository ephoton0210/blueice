const boolean: number = 3;
export const result = boolean;
