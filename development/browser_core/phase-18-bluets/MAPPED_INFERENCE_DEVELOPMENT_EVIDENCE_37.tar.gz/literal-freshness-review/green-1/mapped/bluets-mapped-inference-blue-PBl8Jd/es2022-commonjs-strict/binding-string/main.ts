const string: number = 3;
export const result = string;
