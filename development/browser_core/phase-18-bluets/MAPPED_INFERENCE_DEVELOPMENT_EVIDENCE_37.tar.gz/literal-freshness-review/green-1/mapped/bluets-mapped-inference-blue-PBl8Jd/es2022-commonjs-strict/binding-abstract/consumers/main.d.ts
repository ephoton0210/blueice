export declare const result: number;
