import { value } from "./main";
const observed: "bad" = value;
