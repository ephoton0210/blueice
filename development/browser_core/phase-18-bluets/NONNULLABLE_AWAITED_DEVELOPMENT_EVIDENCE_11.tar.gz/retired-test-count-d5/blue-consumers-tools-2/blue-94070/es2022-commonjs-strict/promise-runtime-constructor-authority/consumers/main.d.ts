export declare const value: PromiseConstructor;
