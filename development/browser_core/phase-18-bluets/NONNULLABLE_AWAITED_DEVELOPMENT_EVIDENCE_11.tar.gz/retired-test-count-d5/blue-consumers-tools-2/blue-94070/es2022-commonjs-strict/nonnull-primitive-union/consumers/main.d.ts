export declare const value: NonNullable<string | number | null | undefined>;
