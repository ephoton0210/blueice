import type { Awaited } from "./types";
export declare const value: Awaited<number>;
