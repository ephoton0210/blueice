import { value } from "./main";
const observed: (x: number) => number = value;
