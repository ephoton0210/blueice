import { value } from "./main";
const observed: never = value;
