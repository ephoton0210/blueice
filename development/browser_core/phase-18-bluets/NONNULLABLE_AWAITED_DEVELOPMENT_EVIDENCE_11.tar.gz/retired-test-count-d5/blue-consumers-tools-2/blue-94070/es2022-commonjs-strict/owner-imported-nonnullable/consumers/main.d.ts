import type { NonNullable } from "./types";
export declare const value: NonNullable<number>;
