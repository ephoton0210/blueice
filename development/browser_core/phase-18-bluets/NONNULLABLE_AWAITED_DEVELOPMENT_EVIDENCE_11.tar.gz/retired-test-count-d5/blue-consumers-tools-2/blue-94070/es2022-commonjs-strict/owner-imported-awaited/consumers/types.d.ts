export type Awaited<T> = {
    owned: T;
};
