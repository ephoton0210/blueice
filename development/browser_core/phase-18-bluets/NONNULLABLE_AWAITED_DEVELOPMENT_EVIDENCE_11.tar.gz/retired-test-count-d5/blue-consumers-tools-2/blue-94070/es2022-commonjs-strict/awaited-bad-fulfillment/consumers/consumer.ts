import { value } from "./main";
const observed: typeof value = 1;
