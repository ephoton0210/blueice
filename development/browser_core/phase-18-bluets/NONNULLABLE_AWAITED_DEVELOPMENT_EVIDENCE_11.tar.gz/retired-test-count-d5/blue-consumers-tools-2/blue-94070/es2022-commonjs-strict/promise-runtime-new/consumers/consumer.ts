import { value } from "./main";
const observed: Promise<string> = value;
