import { value } from "./main";
const observed: {x: number; y: string} = value;
