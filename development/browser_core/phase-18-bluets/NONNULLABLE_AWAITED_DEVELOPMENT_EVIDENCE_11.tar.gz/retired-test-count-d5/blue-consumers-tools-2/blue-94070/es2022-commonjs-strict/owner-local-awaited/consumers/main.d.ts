type Awaited<T> = {
    owned: T;
};
export declare const value: Awaited<number>;
export {};
