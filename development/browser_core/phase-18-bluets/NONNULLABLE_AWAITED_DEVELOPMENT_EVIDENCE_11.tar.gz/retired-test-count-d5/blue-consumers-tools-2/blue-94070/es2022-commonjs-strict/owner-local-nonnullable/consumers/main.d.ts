type NonNullable<T> = {
    owned: T;
};
export declare const value: NonNullable<number>;
export {};
