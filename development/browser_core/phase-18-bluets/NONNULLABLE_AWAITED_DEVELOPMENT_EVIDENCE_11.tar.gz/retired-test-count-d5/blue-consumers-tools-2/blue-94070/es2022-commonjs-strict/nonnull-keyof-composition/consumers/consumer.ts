import { value } from "./main";
const observed: "c" = value;
