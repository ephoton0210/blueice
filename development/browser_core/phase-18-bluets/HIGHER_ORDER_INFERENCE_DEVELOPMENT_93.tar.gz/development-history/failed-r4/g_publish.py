# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Publish complete G evidence only after independent acceptance succeeds."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
from g_acceptance_audit import ROOT,REPO,PHASE,audit,read,sha
from g_preserve_evidence import preserve
from g_artifact_pack import PREFIX,publish_group,write_json


def main():
    result = audit()
    audit_path = ROOT/'g-acceptance-audit.json'
    if not audit_path.exists():
        write_json(audit_path,result)
    else:
        old = read(audit_path)
        assert {key:value for key,value in old.items() if key != 'recordedAt'} == {
            key:value for key,value in result.items() if key != 'recordedAt'}
        result = old
    preserve()
    frozen = read(ROOT/'frozen-source-preflight.json')
    source = frozen['sourceRevision']
    patch = subprocess.check_output(['git','diff','--binary','HEAD','--','backend',
        'development/browser_core/phase-18-bluets/tools'],cwd=REPO)
    patch_path = ROOT/'accepted-source.patch'
    if patch_path.exists():
        assert patch_path.read_bytes() == patch
    else:
        patch_path.write_bytes(patch)
    groups = {name:[] for name in ['COMPILERS','NATIVE','WORKSPACE','DEVELOPMENT','AUDIT']}
    paths = [path for path in ROOT.rglob('*') if path.is_file()
        and '__pycache__' not in path.parts and not path.name.endswith('.pyc')
        and 'large-members' not in path.relative_to(ROOT).parts]
    large = []
    selected = []
    for path in sorted(paths):
        assert not path.is_symlink(),path
        if path.stat().st_size < 80*1024*1024:
            selected.append(path)
            continue
        original = path.relative_to(ROOT).as_posix()
        folder = ROOT/'large-members'/hashlib.sha256(original.encode()).hexdigest()[:20]
        folder.mkdir(parents=True,exist_ok=True)
        record = {'path':original,'bytes':path.stat().st_size,'sha256':sha(path),
            'mode':path.stat().st_mode & 0o777,'parts':[]}
        with path.open('rb') as stream:
            offset = 0
            while True:
                block = stream.read(48*1024*1024)
                if not block:
                    break
                destination = folder/(str(len(record['parts'])).zfill(4)+'.bin')
                if destination.exists():
                    assert destination.read_bytes() == block
                else:
                    destination.write_bytes(block)
                record['parts'].append({'path':destination.relative_to(ROOT).as_posix(),
                    'offset':offset,'bytes':len(block),'sha256':sha(destination)})
                offset += len(block)
                selected.append(destination)
        assert offset == record['bytes']
        large.append(record)
    large_manifest = ROOT/'large-members.json'
    write_json(large_manifest,{'sourceRevision':source,'members':large})
    selected.append(large_manifest)
    compiler_names = {'accepted-native-cli','accepted-workspace-cli','native-cli-snapshot',
        'workspace-cli-snapshot','native-map-test-executable','workspace-map-test-executable'}
    native_names = {'accepted-native','native-capture','project-defu','project-mitt',
        'project-reproductions','project-interchange'}
    for path in sorted(set(selected)):
        relative = path.relative_to(ROOT)
        first = relative.parts[0]
        if len(relative.parts) == 1 and first in compiler_names:
            group = 'COMPILERS'
        elif first in native_names or first.startswith('native-declaration-map') or first == 'native-map-binding.json':
            group = 'NATIVE'
        elif first == 'workspace-capture' or first.startswith('workspace-') or first == 'workspace.log':
            group = 'WORKSPACE'
        elif first in ['development-history','source-snapshots']:
            group = 'DEVELOPMENT'
        else:
            group = 'AUDIT'
        groups[group].append(path)
    artifacts = []
    for label,paths in groups.items():
        assert paths,label
        artifacts.extend(publish_group(ROOT,PHASE,source,label,paths))
    owners = {}
    for artifact in artifacts:
        for manifest in artifact['memberManifests']:
            assert sha(PHASE/manifest['path']) == manifest['sha256']
            for row in read(PHASE/manifest['path'])['entries']:
                assert row['path'] not in owners,row['path']
                owners[row['path']] = {'archive':artifact['path'],'path':row['path'],'sha256':row['sha256']}
    reference = lambda name:owners[Path(name).as_posix()]
    index = write_json(PHASE/(PREFIX+'ARTIFACTS.json'),{'schema':1,'sourceRevision':source,
        'artifacts':artifacts,'largeMembers':large,'scope':'Complete source-bound current and historical evidence, with independently hashed members. Large original members reconstruct byte-for-byte from ordered chunks.'})
    data = {'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion':'completed-within-frozen-scope','source':{key:value for key,value in frozen.items() if key != 'files'},
        'sourceManifest':reference('frozen-source-preflight.json'),'gates':result['gates'],
        'nativeMeasurement':{'path':'COMPATIBILITY_MEASUREMENT.json','sha256':sha(ROOT/'accepted-native/measurement.json'),
            'suites':191,'functions':1086},'primaryForms':48,'profiles':8,'directObservations':384,
        'accepted':352,'rejected':32,'declarationFiles':424,'isolatedConsumers':704,
        'selectedEditionParses':424,'executions':48,'boundaryControls':12,
        'boundaryControlsExcludedFromDirectDenominator':True,'supplementaryControls':8,
        'supplementaryInventoryCredit':0,'caseInventoryAdditions':396,
        'casePreservation':result['casePreservation'],'higherOrderReports':result['higherOrderReports'],
        'prefixRegressions':result['prefixRegressions'],
        'priorContractReports':result['priorContractReports'],'nativeRoleReports':result['nativeRoleReports'],
        'originalDiscovery24':result['originalDiscovery24'],'mapBindings':result['mapBindings'],
        'projects':result['projects'],'windows':result['windows'],'preimplementationHistory':result['preimplementationHistory'],
        'modules':{'files':result['moduleFiles'],'maximumLines':result['maximumModuleLines'],'sources':result['moduleSources']},
        'sourceSnapshots':reference('source-snapshots/manifest.json'),
        'sourceAuthorities':reference('authority-snapshots/manifest.json'),
        'developmentHistory':reference('development-history/index.json'),
        'oracleDependencies':reference('oracle-dependencies.json'),
        'oracleDependencyProvenance':reference('oracle-dependency-provenance.json'),
        'windowsArchiveMembers':reference('windows/all-archive-members.json'),
        'acceptanceAudit':reference('g-acceptance-audit.json'),'largeMembers':reference('large-members.json'),
        'artifactIndex':index,'broaderFeatureRowsOpen':22,'fullTypeScriptParity':False}
    measurement_path = PHASE/(PREFIX+'MEASUREMENT.json')
    if measurement_path.exists():
        previous = read(measurement_path)
        assert {key:value for key,value in previous.items() if key != 'recordedAt'} == {
            key:value for key,value in data.items() if key != 'recordedAt'}
        data = previous
    write_json(measurement_path,data)
    print(json.dumps({'conclusion':'published-awaiting-independent-verification',
        'sourceRevision':source,'archives':len(artifacts),'members':len(owners),'largeOriginalMembers':len(large)}))


if __name__ == '__main__':
    main()
