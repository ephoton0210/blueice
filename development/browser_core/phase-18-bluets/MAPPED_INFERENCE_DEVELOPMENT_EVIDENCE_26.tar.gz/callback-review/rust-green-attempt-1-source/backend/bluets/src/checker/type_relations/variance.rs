// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Bound parameters remain rigid while declared variance directs instantiations.
use super::*;
use crate::parser::Variance;

pub(super) fn assignable(
    actual: &Type,
    expected: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    visited: &mut HashSet<String>,
    budget: &mut TypeExpansionBudget,
) -> Option<bool> {
    if actual == expected || matches!(expected, Type::Union(parts) if parts.contains(actual)) {
        return Some(true);
    }
    if let (Type::KeyOf(actual), Type::KeyOf(expected)) = (actual, expected) {
        // A scoped constraint uses its declaration identity while a member
        // signature can still contain the lexical spelling of that parameter.
        // Compare that identity before expanding either parameter's constraint.
        if let Some(identity) = parameter_reference(actual, aliases) {
            if parameter_reference(expected, aliases) == Some(identity) {
                return Some(budget.consume());
            }
        }
    }
    // Lexical source names point at declaration identities. Resolve them before
    // parameter rigidity, including when a method shadows its class parameter.
    for (value, other, actual_side) in [(actual, expected, true), (expected, actual, false)] {
        let Type::Named { name, arguments } = value else {
            continue;
        };
        if !arguments.is_empty() {
            continue;
        }
        let Some(definition) = aliases.get(name).filter(|definition| {
            definition.kind == TypeDefinitionKind::Alias && definition.parameters.is_empty()
        }) else {
            continue;
        };
        let Type::Named {
            name: target,
            arguments,
        } = &definition.value
        else {
            continue;
        };
        if !arguments.is_empty()
            || !aliases
                .get(target)
                .is_some_and(|definition| definition.kind == TypeDefinitionKind::Parameter)
        {
            continue;
        }
        if !budget.consume() {
            return Some(false);
        }
        return Some(if actual_side {
            is_assignable(&definition.value, other, aliases, visited, budget)
        } else {
            is_assignable(other, &definition.value, aliases, visited, budget)
        });
    }
    if let Type::Named { name, .. } = actual {
        if let Some(definition) = aliases
            .get(name)
            .filter(|definition| definition.kind == TypeDefinitionKind::Parameter)
        {
            if let Type::Union(options) = expected {
                if options.iter().any(|option| {
                    is_assignable(actual, option, aliases, &mut visited.clone(), budget)
                }) {
                    return Some(true);
                }
            }
            if !visited.insert(format!("parameter:{name}:{}", type_identity(expected)))
                || !budget.consume()
            {
                return Some(false);
            }
            return Some(is_assignable(
                &definition.value,
                expected,
                aliases,
                visited,
                budget,
            ));
        }
    }
    if let Type::Named { name, .. } = expected {
        if aliases
            .get(name)
            .is_some_and(|definition| definition.kind == TypeDefinitionKind::Parameter)
            && !matches!(actual, Type::Any | Type::Never)
        {
            if !budget.checking.strict_null_checks && matches!(actual, Type::Null | Type::Undefined)
            {
                return Some(true);
            }
            return Some(false);
        }
    }
    let (
        Type::Named {
            name: a,
            arguments: aa,
        },
        Type::Named {
            name: e,
            arguments: ea,
        },
    ) = (actual, expected)
    else {
        return None;
    };
    if a != e {
        return None;
    }
    let definition = aliases.get(a)?;
    // Quote spelling does not make two otherwise identical library
    // instantiations different. Avoid repeatedly expanding recursive iterator
    // protocols for this identity case; no subtype or budget rule is relaxed.
    if definition.kind == TypeDefinitionKind::LibraryInterface
        && aa.len() == ea.len()
        && aa.iter().zip(ea).all(|(a, e)| same_argument(a, e))
    {
        return Some(true);
    }
    if !definition
        .parameters
        .iter()
        .any(|parameter| parameter.variance.is_some())
    {
        return None;
    }
    let actual = complete_type_arguments(&definition.parameters, aa)?;
    let expected = complete_type_arguments(&definition.parameters, ea)?;
    Some(
        definition
            .parameters
            .iter()
            .zip(actual.iter().zip(&expected))
            .all(|(parameter, (a, e))| match parameter.variance {
                Some(Variance::Out) => is_assignable(a, e, aliases, &mut visited.clone(), budget),
                Some(Variance::In) => is_assignable(e, a, aliases, &mut visited.clone(), budget),
                Some(Variance::InOut) => {
                    is_assignable(a, e, aliases, &mut visited.clone(), budget)
                        && is_assignable(e, a, aliases, &mut visited.clone(), budget)
                }
                None => is_assignable(a, e, aliases, &mut visited.clone(), budget),
            }),
    )
}

fn parameter_reference<'a>(
    value: &Type,
    aliases: &'a BTreeMap<String, TypeDefinition>,
) -> Option<&'a str> {
    let Type::Named { name, arguments } = value else {
        return None;
    };
    if !arguments.is_empty() {
        return None;
    }
    let (name, definition) = aliases.get_key_value(name)?;
    if definition.kind == TypeDefinitionKind::Parameter {
        return Some(name);
    }
    if definition.kind != TypeDefinitionKind::Alias || !definition.parameters.is_empty() {
        return None;
    }
    let Type::Named { name, arguments } = &definition.value else {
        return None;
    };
    if !arguments.is_empty() {
        return None;
    }
    let (name, definition) = aliases.get_key_value(name)?;
    (definition.kind == TypeDefinitionKind::Parameter).then_some(name.as_str())
}

fn same_argument(actual: &Type, expected: &Type) -> bool {
    if actual == expected {
        return true;
    }
    if let (Some(actual), Some(expected)) = (actual.string_value(), expected.string_value()) {
        return actual == expected;
    }
    if let (Type::Literal(actual), Type::Literal(expected)) = (actual, expected) {
        if actual.starts_with(['\'', '"']) && expected.starts_with(['\'', '"']) {
            if let (Some(actual), Some(expected)) = (
                crate::enum_eval::decode_plain_string(actual),
                crate::enum_eval::decode_plain_string(expected),
            ) {
                return actual == expected;
            }
        }
    }
    false
}
