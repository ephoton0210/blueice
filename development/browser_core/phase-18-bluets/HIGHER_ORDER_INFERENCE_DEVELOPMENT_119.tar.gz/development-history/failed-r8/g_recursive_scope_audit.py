# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Audit complete supplementary scope observations from physical source/products."""
from pathlib import Path
import hashlib
import json
import re
import tarfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def fixture(repo, folder='higher_order_recursive_scope'):
    directory = repo / 'backend/bluets/tests/fixtures' / folder
    raw = (directory / 'cases.json').read_bytes()
    inputs = json.loads(raw)
    reference = json.loads((directory / 'reference.json').read_bytes())
    assert digest(raw) == reference['inputSha256']
    assert reference['typescript'] == '5.9.3' and reference['inventoryCredit'] == 0
    counts = {'higher_order_recursive_scope': (2,8,16,14,16), 'higher_order_promise_scope': (1,12,12,6,6)}[folder]
    profiles, forms, comparisons, accepted, declarations = counts
    assert len(inputs['profiles']) == profiles and len(inputs['cases']) == forms
    expected = {row['id']: row for row in reference['cases']}
    assert len(expected) == comparisons and sum(row['accepts'] for row in expected.values()) == accepted
    assert sum(len(row['declarations']) for row in expected.values()) == declarations
    return inputs, reference, expected


def diagnostic(value):
    value = value.get('typescript', value)
    assert isinstance(value, dict), 'Every rejection needs its complete Native counterpart'
    return {'code': value['code'], 'message': value['message'],
            'file': value['span']['module'], 'position': value['position'],
            'relatedInformation': [diagnostic(row) for row in value['relatedInformation']]}


def products(repo, prefix, names, content, build_logs=True, folder='higher_order_recursive_scope'):
    inputs, reference, expected = fixture(repo, folder)
    names = set(names)
    records = []
    for profile in inputs['profiles']:
        for entry in inputs['cases']:
            ident = profile['id'] + '/' + entry['id']
            wanted = expected[ident]
            directory = prefix.rstrip('/') + '/' + ident
            sources = {'main.ts': entry['source'], **entry.get('files', {})}
            source_hashes = {}
            for name, text in sources.items():
                raw = content(directory + '/' + name)
                assert raw == text.encode('utf-8'), (ident, name)
                source_hashes[name] = digest(raw)
            config = content(directory + '/tsconfig.json')
            assert json.loads(config) == {
                'compilerOptions': {**inputs['options'], **profile['compilerOptions'], 'outDir': 'dist'},
                'files': list(sources),
            }, ident
            actual_names = {name[len(directory + '/dist/'):] for name in names
                            if name.startswith(directory + '/dist/') and name.endswith('.d.ts')}
            assert actual_names == set(wanted['declarations']), ident
            declarations = {}
            for name, text in wanted['declarations'].items():
                raw = content(directory + '/dist/' + name)
                assert raw == text.encode('utf-8'), (ident, name)
                declarations[name] = digest(raw)
            record = {'id': ident, 'sourceSha256': source_hashes,
                      'configSha256': digest(config), 'declarationSha256': declarations}
            if build_logs:
                stdout = content(directory + '/build.stdout')
                stderr = content(directory + '/build.stderr')
                if wanted['accepts']:
                    assert re.fullmatch(
                        rb'built [1-9][0-9]* entry point\(s\), [1-9][0-9]* module\(s\), fingerprint bts-project-[0-9a-f]{16}\r?\n',
                        stdout), ident
                else:
                    assert stdout == b'', ident
                observed = [diagnostic(json.loads(line)) for line in stderr.decode('utf-8').splitlines() if line]
                assert observed == wanted['diagnostics'], ident
                assert bool(observed) != wanted['accepts'], ident
                record.update(stdoutSha256=digest(stdout), stderrSha256=digest(stderr))
            if not wanted['accepts']:
                assert not any(name.startswith(directory + '/dist/') for name in names), ident
            records.append(record)
    assert len(records) == len(expected)
    accepted = sum(row['accepts'] for row in expected.values())
    return {'comparisons': len(expected), 'accepted': accepted, 'rejected': len(expected)-accepted,
            'declarationFiles': sum(len(row['declarations']) for row in expected.values()),
            'inventoryCredit': 0, 'products': records,
            'inputSha256': reference['inputSha256'],
            'implementationSha256': reference['implementationSha256']}


def audit(root, repo, source, gates):
    contract = repo/'target/higher-order-inference-contract-20261114'
    measured = contract/'promise-worktree-regressions-1/measurement.json'
    preflight = json.loads(measured.read_bytes())
    assert preflight['conclusion'] == 'success' and preflight['exit'] == 0
    configurations = [
        ('recursive','higher_order_recursive_scope','recursive-scope',16,
         'recursive-scope-red-1/pre-repair-freeze.json',
         'recursive_calls_keep_closed_callback_parameters_in_their_own_scope'),
        ('promise','higher_order_promise_scope','promise-scope',12,
         'promise-scope-freeze-1/receipt.json',
         'generic_library_aliases_preserve_captured_inference_parameters'),
    ]
    result = {}
    with tarfile.open(root/'windows-evidence.tar.gz') as archive:
        windows_names = [member.name for member in archive if member.isfile()]
        for key,folder,directory,count,receipt_name,test_name in configurations:
            inputs,reference,expected = fixture(repo,folder)
            receipt_path = contract/receipt_name
            receipt = json.loads(receipt_path.read_bytes())
            assert receipt['beforeProductionRepair']
            for name,value in receipt.get('fixture',receipt.get('frozen',{})).items():
                assert digest((repo/'backend/bluets/tests/fixtures'/folder/name).read_bytes()) == value
            proof = {}
            for kind in ['native','workspace']:
                base = kind+'-capture/higher-order-inference/'+directory
                names = [path.relative_to(root).as_posix() for path in (root/base).rglob('*') if path.is_file()]
                proof[kind] = products(repo,base,names,lambda name:(root/name).read_bytes(),folder=folder)
                proof[kind]['compilerSha256'] = gates[kind+'CompilerSha256']
            proof['windows'] = products(repo,
                'results-higher-order-inference-r8/higher-order-inference-observations/'+directory,
                windows_names,lambda name:archive.extractfile(name).read(),folder=folder)
            windows = json.loads((root/'windows/windows-measurement.json').read_bytes())
            proof['windows']['compilerSha256'] = windows['compiler']['sha256']
            preflight_base = contract/'promise-worktree-regressions-1'
            preflight_names = [path.relative_to(preflight_base).as_posix()
                              for path in (preflight_base/'capture'/directory).rglob('*') if path.is_file()]
            preflight_products = products(repo,'capture/'+directory,preflight_names,
                lambda name:(preflight_base/name).read_bytes(),folder=folder)
            assert preflight_products['comparisons'] == count
            result[key] = {'sourceRevision':source,'comparisonsPerCompiler':count,'fixture':folder,
                'inventoryCredit':0,'permanentTest':test_name,
                'preRepairFreeze':'development-history/contract/'+receipt_name,
                'preRepairFreezeSha256':digest(receipt_path.read_bytes()),
                'preflightReport':'development-history/contract/promise-worktree-regressions-1/measurement.json',
                'preflightReportSha256':digest(measured.read_bytes()),
                'preflightCompilerSha256':preflight['actualCompilerSha256'],
                'actualCompilerProducts':proof}
    return result
