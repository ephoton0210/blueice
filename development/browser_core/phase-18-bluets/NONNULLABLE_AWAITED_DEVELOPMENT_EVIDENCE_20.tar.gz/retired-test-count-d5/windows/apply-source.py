from pathlib import Path, PurePosixPath
import hashlib, json, tarfile
base=Path(r'B:\BlueIce\gm3-20261109-360d7d921')
source=(base/'source').resolve()
manifest=json.loads((base/'p0b-source-manifest.json').read_text(encoding='utf-8'))
patch=base/'p0b-source-patch.tar.gz'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(patch)==manifest['followupPatchSha256']
with tarfile.open(patch) as archive:
    members=archive.getmembers()
    assert len(members)==len({m.name for m in members})
    assert {m.name for m in members}==set(manifest['files'])
    for member in members:
        name=PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts
        destination=source.joinpath(*name.parts)
        assert not destination.is_symlink()
        destination.parent.mkdir(parents=True,exist_ok=True)
        assert destination.resolve().is_relative_to(source)
        destination.write_bytes(archive.extractfile(member).read())
        assert sha(destination)==manifest['files'][member.name],member.name
backend=sorted((name for name in manifest['files'] if name.startswith('backend/')),key=lambda name:name.encode())
assert len(backend)==manifest['backendFiles']
assert hashlib.sha256(chr(0).join(backend).encode()).hexdigest()==manifest['backendPathSetSha256']
print(json.dumps({'sourceRevision':manifest['sourceRevision'],'verifiedFiles':len(manifest['files']),'verifiedBackendFiles':len(backend)}))
