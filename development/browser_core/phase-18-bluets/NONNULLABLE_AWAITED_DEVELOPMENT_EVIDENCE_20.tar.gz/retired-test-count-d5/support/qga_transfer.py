# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import base64
import hashlib
import json
import shlex
import subprocess
import sys


def call(request):
    command = shlex.join([
        'virsh', 'qemu-agent-command', 'omnisolve-winui-automation',
        '--timeout', '20', json.dumps(request),
    ])
    result = subprocess.run([
        'ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10',
        'pb60g.bravotekcorp.cc', command,
    ], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr.strip())
    value = json.loads(result.stdout)
    if 'error' in value:
        raise RuntimeError(value['error'])
    return value['return']


def download(remote, destination):
    destination = Path(destination)
    handle = call({'execute': 'guest-file-open', 'arguments': {
        'path': remote, 'mode': 'rb',
    }})
    digest = hashlib.sha256()
    size = 0
    try:
        with destination.open('xb') as output:
            while True:
                value = call({'execute': 'guest-file-read', 'arguments': {
                    'handle': handle, 'count': 65536,
                }})
                chunk = base64.b64decode(value.get('buf-b64', ''), validate=True)
                assert len(chunk) == value['count']
                output.write(chunk)
                digest.update(chunk)
                size += len(chunk)
                if value.get('eof'):
                    break
                assert chunk, 'nonterminal empty read'
    finally:
        call({'execute': 'guest-file-close', 'arguments': {'handle': handle}})
    print(json.dumps({'remote': remote, 'local': str(destination),
                      'bytes': size, 'sha256': digest.hexdigest()}), flush=True)


if __name__ == '__main__':
    download(sys.argv[1], sys.argv[2])
