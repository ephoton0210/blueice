# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
frozen = read(root / 'frozen-source-preflight.json')
directory = root / 'windows'
measurement = read(directory / 'windows-measurement.json')
manifest_path = directory / 'windows-source-manifest.json'
manifest = read(manifest_path)
archive_path = root / 'windows-evidence.tar.gz'
archive_receipt = read(directory / 'windows-evidence-receipt.json')
assert sha(archive_path.read_bytes()) == archive_receipt['archiveSha256']
assert archive_path.stat().st_size == archive_receipt['archiveBytes']
assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
assert measurement['sourceRevision'] == manifest['sourceRevision'] == frozen['sourceRevision']
assert measurement['expectedSourceManifestSha256'] == sha(manifest_path.read_bytes())
assert measurement['verifiedSourceFiles'] == len(manifest['files']) == 14697
assert measurement['verifiedBackendFiles'] == manifest['backendFiles'] == 14025
canonical = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(canonical) == {p for p in manifest['files'] if p.startswith('backend/')}
canonical.sort(key=lambda path: path.encode())
assert sha('\0'.join(canonical).encode()) == manifest['backendPathSetSha256'] == measurement['backendPathSetSha256']
for name in canonical + ['Cargo.toml', 'Cargo.lock']:
    assert sha((repo / name).read_bytes()) == manifest['files'][name], name
for name in ['record_noinfer.cjs', 'verify_noinfer.cjs', 'verify_noinfer_regressions.cjs', 'record_nonnullable_awaited.cjs', 'verify_nonnullable_awaited.cjs']:
    path = 'development/browser_core/phase-18-bluets/tools/' + name
    assert sha((repo / path).read_bytes()) == manifest['files'][path], path

def summary(text):
    rows = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', text)
    assert rows
    status, passed, failed, ignored, filtered = rows[-1]
    assert status == 'ok' and int(failed) == int(ignored) == 0
    return {'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored), 'filtered': int(filtered)}

selection = measurement['core82Selection']
assert measurement['core82Passed'] and measurement['core82Exit'] == 0
assert len(selection['selected']) == len(set(selection['selected'])) == len(selection['passed']) == 82
assert sorted(selection['selected']) == sorted(selection['passed']) and selection['ordinarySupportFiltered'] == 6
assert len(measurement['cases']) == 25 and all(row['passed'] and row['exit'] == 0 for row in measurement['cases'])
assert len({row['id'] for row in measurement['cases']}) == 25
cohorts = measurement['followups']
assert len(cohorts) == 8 and {row['target'] for row in cohorts} == {
    'gc1_object_generic_methods', 'gm2_incremental_options', 'project_config',
    'defu_prerequisites', 'callable_utilities', 'receiver_utilities', 'noinfer', 'nonnullable_awaited',
}
assert all(row['passed'] and row['exit'] == 0 for row in cohorts)
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert len(names) == len(set(names))
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names)
    assert not any(member.issym() or member.islnk() for member in members)
    compiler = archive.extractfile('followup-bluetsc.exe').read()
    assert sha(compiler) == measurement['compiler']['sha256'] == archive_receipt['compilerSha256']
    pe = int.from_bytes(compiler[60:64], 'little')
    assert compiler[pe:pe+4] == bytes([80,69,0,0])
    assert int.from_bytes(compiler[pe+4:pe+6], 'little') == archive_receipt['compilerMachine'] == 0x8664
    patch = archive.extractfile('followup-patch.tar.gz').read()
    assert sha(patch) == measurement['sourcePatchSha256'] == manifest['followupPatchSha256']
    patched = set()
    with tarfile.open(fileobj=io.BytesIO(patch)) as sources:
        for member in sources:
            assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            assert member.isfile(), member.name
            assert member.name not in patched
            patched.add(member.name)
            assert sha(sources.extractfile(member).read()) == manifest['files'][member.name], member.name
    assert set(canonical) <= patched
    prefix = 'results-nonnullable-awaited-v1/'
    core = archive.extractfile(prefix + 'core82.stdout').read().decode().replace('\r\n', '\n')
    assert summary(core) == {'passed': 82, 'failed': 0, 'ignored': 0, 'filtered': 6}
    passed_names = re.findall(r'^test (.+) \.\.\. ok$', core, re.MULTILINE)
    assert sorted(passed_names) == sorted(selection['selected'])
    for row in measurement['cases']:
        assert Path(row['stdout']).name == row['stdout']
        text = archive.extractfile(prefix + row['stdout']).read().decode().replace('\r\n', '\n')
        assert summary(text)['passed'] == 1
        assert re.search(r'^test ' + re.escape(row['function']) + r' \.\.\. ok$', text, re.MULTILINE)
    results = {}
    for row in cohorts:
        text = archive.extractfile(prefix + row['target'] + '.stdout').read().decode()
        results[row['target']] = summary(text)
        assert results[row['target']]['filtered'] == 0
        assert results[row['target']]['passed'] == {'gc1_object_generic_methods':5,'gm2_incremental_options':7,'project_config':11,'defu_prerequisites':2,'callable_utilities':3,'receiver_utilities':3,'noinfer':5,'nonnullable_awaited':6}[row['target']]
    reports = {}
    for label, pattern in [('primary', '/noinfer-observations/blue-'), ('supplement', '/noinfer-observations/regressions-')]:
        found = [name for name in names if pattern in name and name.endswith('/report.json')]
        assert len(found) == 1
        report = json.loads(archive.extractfile(found[0]).read())
        assert report['sourceRevision'] == frozen['sourceRevision']
        assert report['compilerSha256'] == measurement['compiler']['sha256']
        assert report['conclusion'] == 'pass'
        reports[label] = report
    primary = reports['primary']
    assert primary['inputSha256'] == sha((repo/'backend/bluets/tests/fixtures/noinfer/cases.json').read_bytes())
    assert len(primary['cases']) == 153 and primary['declarationFiles'] == 159
    assert primary['consumers'] == 306 and primary['syntax'] == 159 and primary['runtime'] == 6
    b_reports = [name for name in names if '/nonnullable-awaited-observations/blue-' in name and name.endswith('/report.json')]
    assert len(b_reports) == 1
    b = json.loads(archive.extractfile(b_reports[0]).read())
    assert b['sourceRevision'] == frozen['sourceRevision'] and b['compilerSha256'] == measurement['compiler']['sha256']
    assert b['conclusion'] == 'pass' and len(b['cases']) == 315
    assert b['declarationFiles'] == b['syntax'] == 331 and b['consumers'] == 630 and b['runtime'] == 12
    assert set(row['id'] for row in b['cases']) == {row['id'] for file in ['reference.json', 'operator-reference.json'] for row in read(repo/'backend/bluets/tests/fixtures/nonnullable_awaited'/file)['cases'] if row['accepts']}
    supplement = reports['supplement']
    assert supplement['inputSha256'] == sha((repo / 'backend/bluets/tests/fixtures/noinfer/keyof-diagnostics.json').read_bytes())
    assert len(supplement['cases']) == 4 and all(row['agrees'] for row in supplement['cases'])

receipt = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision': frozen['sourceRevision'], 'conclusion': 'success',
    'paths': 25, 'coreOracles': 82, 'regressionCohorts': results,
    'allSelectedNamesPassedExactly': True, 'allCanonicalBackendPathsVerified': True,
    'backendFiles': len(canonical), 'selectedFiles': len(manifest['files']),
    'patchedFilesIndependentlyHashed': len(patched),
    'actualCompilerSha256': sha(compiler), 'actualCompilerArchiveHashMatches': True,
    'nonNullableAwaitedPrimaryComparisons': 396, 'nonNullableAwaitedSupplementaryNativeControls': 6,
    'nonNullableAwaitedDeclarationFiles': 331, 'nonNullableAwaitedConsumers': 630, 'nonNullableAwaitedSyntax': 331, 'nonNullableAwaitedExecutions': 12,
    'noInferPrimaryObservations': 282, 'noInferSupplementalObservations': 4,
    'noInferDeclarationFiles': 159, 'noInferConsumers': 306, 'noInferSyntax': 159, 'noInferExecutions': 6,
    'archiveSha256': sha(archive_path.read_bytes()),
    'scope': 'Current same-source Windows x86_64 acceptance: original82 core,25 paths and8 full regression cohorts, with all canonical backend bytes, actual PE compiler and NonNullable/Awaited consumer outputs independently checked. Broader GM3 platform combinations remain open.'}
(directory / 'windows-acceptance-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
