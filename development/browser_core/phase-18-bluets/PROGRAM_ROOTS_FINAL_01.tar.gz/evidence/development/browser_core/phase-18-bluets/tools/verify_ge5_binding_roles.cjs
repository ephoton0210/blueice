// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Exact frozen family selection, two public builds, and Native authority only.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const graph=require('./ge5_inputs.cjs'),authority=require('./ge5_native_authority.cjs'),{stream}=require('./ge5_role_stream.cjs'),{compare}=require('./ge5_binding_roles.cjs');
const root=path.resolve(__dirname,'../../../..'),directory=path.join(root,'backend/bluets/tests/fixtures/ge5_source_maps'),inputBytes=fs.readFileSync(path.join(directory,'cases.json')),referenceBytes=fs.readFileSync(path.join(directory,'reference.json'));
assert.equal(graph.sha256(inputBytes),'5b736263464566250127ae12beddc7dae3c488f48fcec018261c198ccc59e12e');assert.equal(graph.sha256(referenceBytes),'166af4ea3dd8b1af12aeb0c76c9f3f4a7f8b47aab0971bb2e93e72d01ded32f3');
const input=JSON.parse(inputBytes),reference=JSON.parse(referenceBytes),parents=graph.parents(root,input),form=process.argv[2];
assert(['array-nested-binding','object-nested-binding','mixed-nested-default','nested-parameter','binding-iterator-finally'].includes(form));
const ts=require(path.join(root,'backend/bluets/tests/fixtures/oracle_support/load_typescript.cjs'))(process.env.BLUEICE_BLUETSC_ORACLE||'tsc'),observations=JSON.parse(fs.readFileSync(0,'utf8'));
const selected=input.cases.flatMap((row,index)=>row.form==='ge1_downlevel/'+form?[index]:[]);assert.deepEqual(observations.map(row=>row.index),selected);
const compilerSha256=graph.sha256(fs.readFileSync(path.join(root,'target/debug/bluetsc'))),verified=[],failures=[];
(async()=>{
for(const row of observations) {
  const original=graph.resolve(input,input.cases[row.index],parents),expected=reference.cases[row.index];assert.equal(row.id,expected.id);assert.equal(row.compilerSha256,compilerSha256);assert.equal(row.repeatBuilds,2);assert.deepEqual(row.options,original.options);
  for(const [name,map]of Object.entries(expected.maps))if(map.kind==='javascript')try {
    const code=row.outputs[map.output],raw=name.endsWith('#inline')?Buffer.from(code.split('\n').find(line=>line.startsWith('//# sourceMappingURL=data:')).split('base64,')[1],'base64').toString('utf8'):row.outputs[name],native=stream(ts,reference.blobs[expected.outputs[map.output]],authority.raw(reference,expected,name)),actual=stream(ts,code,raw);
    const proof=compare(ts,native,actual,row.options,original.files['main.ts']);const controls=require('./ge5_binding_mutations.cjs').run(ts,native,actual,row.options,original.files['main.ts'],proof),runtime=await require('./ge5_binding_execution.cjs').run(ts,native,actual,row.options,form);verified.push({controls,runtime,id:row.id,map:name,actualJavaScriptSha256:graph.sha256(code),actualMapSha256:graph.sha256(raw),allCharactersClassified:true});
  }catch(error){failures.push({id:row.id,map:name,error:error.message,stack:error.stack});}
}
const report={form,configurations:observations.length,maps:verified.length+failures.length,repeatBuilds:2,compilerSha256,verified,failures};
if(process.env.BLUEICE_GE5_ROLE_REPORT_DIRECTORY){fs.mkdirSync(process.env.BLUEICE_GE5_ROLE_REPORT_DIRECTORY,{recursive:true});fs.writeFileSync(path.join(process.env.BLUEICE_GE5_ROLE_REPORT_DIRECTORY,'binding-'+form+'.json'),JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify(report,null,2));if(failures.length)process.exitCode=1;

})().catch(error=>{console.error(error);process.exitCode=1;});
