# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Independently verify published bytes, reconstructed large files and bindings."""
from pathlib import Path
import argparse
import contextlib
import hashlib
import json
import re
import subprocess
import tarfile
from g_artifact_pack import LIMIT,safe_name,verify_archive,write_json
from g_acceptance_audit import ROOT,REPO,PHASE,read,sha
from audit_higher_order_inference import audit_products


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--before-todo',action='store_true')
    parser.add_argument('--archive-only',action='store_true')
    options=parser.parse_args()
    data=read(PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json')
    assert data['conclusion']=='completed-within-frozen-scope'
    assert data['broaderFeatureRowsOpen']==22 and data['fullTypeScriptParity'] is False
    source=data['source']['sourceRevision']
    if not options.archive_only:
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==data['source']['parentCommit']
        tree=subprocess.check_output(['git','write-tree'],cwd=REPO,text=True).strip()
        assert 'backend-tree:'+subprocess.check_output(['git','rev-parse',tree+':backend'],cwd=REPO,text=True).strip()==source
        assert not subprocess.check_output(['git','diff','--name-only','--','backend','development/browser_core/phase-18-bluets/tools'],cwd=REPO)
    index_ref=data['artifactIndex'];index_path=PHASE/safe_name(index_ref['path'])
    assert sha(index_path)==index_ref['sha256'] and index_path.stat().st_size==index_ref['bytes']
    index=read(index_path);assert index['sourceRevision']==source
    owners={}
    for artifact in index['artifacts']:
        path=PHASE/safe_name(artifact['path'])
        assert sha(path)==artifact['sha256'] and path.stat().st_size==artifact['bytes']<LIMIT
        entries=[]
        for part in artifact['memberManifests']:
            file=PHASE/safe_name(part['path'])
            assert sha(file)==part['sha256'] and file.stat().st_size==part['bytes']<16*1024*1024
            manifest=read(file)
            assert manifest['sourceRevision']==source and manifest['archive']==artifact['path']
            assert len(manifest['entries'])==part['members']
            for row in manifest['entries']:
                name=safe_name(row['path'])
                assert name not in owners and re.fullmatch('[0-9a-f]{64}',row['sha256'])
                assert (ROOT/name).stat().st_size==row['bytes'] and sha(ROOT/name)==row['sha256'],name
                owners[name]={'archive':artifact['path'],'path':name,'sha256':row['sha256']}
            entries+=manifest['entries']
        assert len(entries)==artifact['members']
        verify_archive(path,entries)
    with contextlib.ExitStack()as stack:
        opened={}
        def content(name):
            row=owners[safe_name(name)]
            if row['archive']not in opened:
                opened[row['archive']]=stack.enter_context(tarfile.open(PHASE/row['archive']))
            raw=opened[row['archive']].extractfile(name).read()
            assert hashlib.sha256(raw).hexdigest()==row['sha256']
            return raw
        def reference(row):
            assert owners[row['path']]==row
            return json.loads(content(row['path']))
        large=reference(data['largeMembers'])['members']
        assert large==index['largeMembers']
        for row in large:
            assert row['path']not in owners
            offset=0;digest=hashlib.sha256()
            for part in row['parts']:
                raw=content(part['path'])
                assert offset==part['offset'] and len(raw)==part['bytes']
                assert hashlib.sha256(raw).hexdigest()==part['sha256']
                digest.update(raw);offset+=len(raw)
            assert offset==row['bytes'] and digest.hexdigest()==row['sha256']==sha(ROOT/row['path'])
        frozen=reference(data['sourceManifest'])
        assert frozen['sourceRevision']==source
        snapshot=reference(data['sourceSnapshots'])
        assert snapshot['sourceRevision']==source and snapshot['allFrozenCompilerAndOracleFilesPreserved']
        for name,digest in frozen['files'].items():
            assert digest==owners['source-snapshots/files/'+name]['sha256']
            if not options.archive_only:
                assert sha(REPO/name)==digest
            assert snapshot['files'][name]['sha256']==digest
        authorities=reference(data['sourceAuthorities'])
        assert authorities['sourceRevision']==source
        assert set(authorities['files'])=={'COMPATIBILITY_CASES.json','COMPATIBILITY_SUITES.json','COMPATIBILITY_MEASUREMENT.json'}
        for name,row in authorities['files'].items():
            assert owners['authority-snapshots/'+name]['sha256']==row['sha256']
            if not options.archive_only:
                assert sha(PHASE/name)==row['sha256']
        parent=reference(data['acceptedParentSources'])
        assert parent['parentCommit']==data['source']['parentCommit']
        assert parent['archiveSha256']==owners['accepted-parent-source.tar.gz']['sha256']
        verify_archive(ROOT/'accepted-parent-source.tar.gz',parent['entries'])
        with tarfile.open(ROOT/'accepted-parent-source.tar.gz')as archive:
            for row in parent['entries']:
                raw=archive.extractfile(row['path']).read()
                assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['gitBlob']
        audit=reference(data['acceptanceAudit'])
        assert audit['conclusion']=='success' and audit['sourceRevision']==source
        for field in ['gates','casePreservation','higherOrderReports','priorContractReports','nativeRoleReports',
            'originalDiscovery24','mapBindings','projects','windows','preimplementationHistory','prefixRegressions','preflightProvenance','platformCompletion']:
            assert data[field]==audit[field],field
        original_launch=json.loads(content('launch-state.json'))
        assert original_launch['conclusion']=='failure'
        assert original_launch['platforms']['mac']['exit']==0 and original_launch['platforms']['windows']['exit']==1
        completion=data['platformCompletion']
        assert completion['originalFailuresUnchanged'] and completion['testReruns']==0
        assert owners[completion['correctionReceipt']]['sha256']==completion['correctionReceiptSha256']
        corrected=json.loads(content(completion['correctedWindowsVerification']))
        assert owners[completion['correctedWindowsVerification']]['sha256']==completion['correctedWindowsVerificationSha256']
        assert corrected==data['windows'] and corrected['conclusion']=='success'
        native=json.loads(content('accepted-native/measurement.json'))
        assert native['conclusion']=='success' and native['source_revision']==source
        assert len(native['suites'])==data['nativeMeasurement']['suites']==191
        assert sum(row['passed']for row in native['suites'])==data['nativeMeasurement']['functions']==1086
        assert data['nativeMeasurement']['sha256']==owners['accepted-native/measurement.json']['sha256']
        if not options.archive_only:
            assert data['nativeMeasurement']['sha256']==sha(PHASE/'COMPATIBILITY_MEASUREMENT.json')
        for row in native['suites']:
            assert row['conclusion']=='success' and row['failed']==row['ignored']==row['filtered']==0
            assert owners['accepted-native/'+row['log']]['sha256']==row['log_sha256']
        prefix=data['prefixRegressions']
        assert prefix['permanentPublicControls']==4 and prefix['inventoryCredit']==0
        preflight=data['preflightProvenance']
        assert preflight['reusedCompleteExactSourceSteps']==6 and preflight['freshPythonTests']==13
        assert owners[preflight['failedMeasurement']]['sha256']==preflight['failedMeasurementSha256']
        assert owners[preflight['acceptedPreflight']]['sha256']==preflight['acceptedPreflightSha256']
        assert owners[prefix['preflightReport']]['sha256']==prefix['preflightReportSha256']
        higher=next(row for row in native['suites']if row['harness']=='backend/bluets/tests/higher_order_inference.rs')
        assert higher['passed']==5 and prefix['permanentTest']in higher['test_names']
        for step in data['gates']['steps']:
            assert step['exit']==0 and owners[step['log']]['sha256']==step['sha256']
        assert data['casePreservation']=={'previous':42716,'current':43112,'added':396,'allOldCasesUnchanged':True}
        assert (data['primaryForms'],data['profiles'],data['directObservations'])==(48,8,384)
        assert (data['accepted'],data['rejected'],data['declarationFiles'])==(352,32,424)
        assert (data['isolatedConsumers'],data['selectedEditionParses'],data['executions'])==(704,424,48)
        assert data['boundaryControls']==12 and data['boundaryControlsExcludedFromDirectDenominator']
        assert data['supplementaryControls']==8 and data['supplementaryInventoryCredit']==0
        for kind in ['native','workspace']:
            compiler=data['gates'][kind+'CompilerSha256']
            assert owners['accepted-'+kind+'-cli']['sha256']==compiler
            audit_repo=ROOT/'source-snapshots/files'if options.archive_only else REPO
            report=audit_products(audit_repo,source,compiler,kind+'-capture/higher-order-inference',
                list(owners),content,kind=='native')
            assert report==data['higherOrderReports'][kind]
            original=data['originalDiscovery24'][kind]
            assert owners[original['path']]['sha256']==original['sha256']
            assert all(row['agrees'] for row in json.loads(content(original['path']))['cases'])
            binding=data['mapBindings'][kind]
            assert binding['verified'] and binding['compilerSha256']==compiler
            assert owners[kind+'-declaration-map-report.json']['sha256']==binding['reportSha256']
            maps=json.loads(content(kind+'-declaration-map-report.json'))
            assert maps['configurations']==8407 and maps['buildsPerConfiguration']==2 and maps['differences']==[]
        modules=data['modules'];assert modules['files']==580 and modules['maximumLines']<1500
        for row in modules['sources']:
            raw=content('source-snapshots/files/'+row['path'])
            assert len(raw.splitlines())==row['lines']<1500 and hashlib.sha256(raw).hexdigest()==row['sha256']
        history=reference(data['developmentHistory'])
        assert set(history['history'])=={'contract','discovery','failed-r1','failed-r2','failed-r3','failed-r4'}
        for label,record in history['history'].items():
            assert record['acceptanceCredit']==0
            assert owners[record['manifest']]['sha256']==record['manifestSha256']
            members=json.loads(content(record['manifest']))
            assert len(members)==record['members']
            large_by_name={row['path']:row for row in large}
            for name,row in members.items():
                target='development-history/'+label+'/'+name
                assert (owners.get(target)or large_by_name[target])['sha256']==row['sha256']
        dependencies=reference(data['oracleDependencies']);provenance=reference(data['oracleDependencyProvenance'])
        assert dependencies['packages']=={'typescript':'5.9.3','acorn':'8.15.0'}
        assert dependencies['archiveSha256']==owners['oracle-dependencies.tar.gz']['sha256']==provenance['archiveSha256']
        assert provenance['allInstalledBytesIndependentlyMatch']
        with tarfile.open(ROOT/'oracle-dependencies.tar.gz')as package:
            expected=[{'path':name,'sha256':digest,'bytes':package.getmember(name).size}for name,digest in dependencies['files'].items()]
        verify_archive(ROOT/'oracle-dependencies.tar.gz',expected)
        win=reference(data['windowsArchiveMembers'])
        assert win['archiveSha256']==data['windows']['archiveSha256']
        assert sha(ROOT/'windows-evidence.tar.gz')==win['archiveSha256']
        verify_archive(ROOT/'windows-evidence.tar.gz',win['entries'])
        assert data['windows']['coreOracles']==82 and data['windows']['paths']==25
        assert len(data['windows']['regressionCohorts'])==25
        assert data['windows']['regressionCohorts']['higher_order_inference']['passed']==5
        assert len(data['nativeRoleReports']['completeNativeRoleFamilies'])==28
        assert len(data['nativeRoleReports']['partialNativeRoleReports'])==2
    if options.archive_only:
        pass
    elif options.before_todo:
        assert '- [ ] **P0-G —'in(PHASE/'TODO.md').read_text()
    else:
        assert '- [x] **P0-G —'in(PHASE/'TODO.md').read_text()
        text=(PHASE/'HIGHER_ORDER_INFERENCE_ACCEPTANCE.md').read_text()
        assert source in text and 'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'in text
    result={'conclusion':'success','sourceRevision':source,'artifactArchives':len(index['artifacts']),
        'independentlyVerifiedMembers':len(owners),'byteExactLargeMembersReconstructed':len(large),
        'measurementSha256':sha(PHASE/'HIGHER_ORDER_INFERENCE_MEASUREMENT.json'),
        'artifactIndexSha256':sha(index_path),'todoExpectedOpen':None if options.archive_only else options.before_todo,
        'archiveOnly':options.archive_only,
        'broaderFeatureRowsOpen':22,'fullTypeScriptParity':False}
    filename='g-publication-archive-verification.json'if options.archive_only else(
        'g-publication-before-todo-verification.json'if options.before_todo else'g-publication-verification.json')
    write_json(ROOT/filename,result)
    if not options.before_todo and not options.archive_only:
        write_json(PHASE/'HIGHER_ORDER_INFERENCE_VERIFICATION.json',result)
    print(json.dumps(result))


if __name__=='__main__':
    main()
