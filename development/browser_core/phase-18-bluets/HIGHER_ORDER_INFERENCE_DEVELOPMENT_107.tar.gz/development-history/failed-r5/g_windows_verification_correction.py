# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Record an audit-only correction without rewriting the original failed receipt."""
from pathlib import Path
import datetime
import json
import hashlib

ROOT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    directory=ROOT/'windows/verification-correction-1'
    plan=read(directory/'plan.json')
    execution=read(directory/'execution.json')
    corrected=read(ROOT/'windows/windows-acceptance-verification-r2.json')
    frozen=read(ROOT/'frozen-source-preflight.json')
    measured=read(ROOT/'windows/windows-measurement.json')
    listing=read(ROOT/'windows/gm2-function-list-result.json')
    assert execution['exit']==0 and execution['testReruns']==0
    assert execution['logSha256']==sha(directory/'verification.log')
    assert execution['planSha256']==sha(directory/'plan.json')
    assert corrected['conclusion']=='success' and measured['conclusion']=='success'
    assert corrected['sourceRevision']==measured['sourceRevision']==plan['sourceRevision']==frozen['sourceRevision']
    assert corrected['archiveSha256']==plan['archiveSha256']==sha(ROOT/'windows-evidence.tar.gz')
    assert plan['windowsMeasurementSha256']==sha(ROOT/'windows/windows-measurement.json')
    assert plan['functionListSha256']==sha(ROOT/'windows/gm2-function-list-result.json')
    assert plan['originalVerifierSha256']==sha(ROOT/'verify_windows.py')==sha(ROOT/'orchestration-start-snapshot/verify_windows.py')
    assert plan['correctedVerifierSha256']==sha(ROOT/'verify_windows_r2.py')
    assert plan['originalFailureLogSha256']==sha(ROOT/'windows/verify-windows.log')
    assert read(ROOT/'windows/complete-state.json')['conclusion']=='failure'
    assert read(ROOT/'windows/finalize-state.json')['conclusion']=='failure'
    assert read(ROOT/'windows/finalize-state.json')['stage']=='independent-audit'
    assert len(listing['names'])==7 and listing['allWindowsFunctionsPassedExactly'] and not listing['testExecutionPerformed']
    assert listing['unixOnlyFunctions']==['state_and_parent_symlinks_cannot_publish_outside_owner']
    assert corrected['regressionCohorts']['gm2_incremental_options']=={'passed':7,'failed':0,'ignored':0,'filtered':0}
    assert corrected['coreOracles']==82 and corrected['paths']==25 and len(corrected['regressionCohorts'])==25
    result={'conclusion':'success','recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceRevision':frozen['sourceRevision'],'scope':'Audit-only platform-conditional function-count correction on the unchanged completed Windows run.',
        'archiveSha256':plan['archiveSha256'],'originalFailedVerifierSha256':plan['originalVerifierSha256'],
        'originalFailureLogSha256':plan['originalFailureLogSha256'],'correctedVerifierSha256':plan['correctedVerifierSha256'],
        'correctedVerificationSha256':sha(ROOT/'windows/windows-acceptance-verification-r2.json'),
        'planSha256':sha(directory/'plan.json'),'compiledFunctionListSha256':plan['functionListSha256'],
        'originalWindowsSupervisorFailurePreserved':True,'originalPlatformTestRunSucceeded':True,
        'allSevenActualWindowsFunctionsPassedExactly':True,'unixOnlyEighthFunctionNotCompiledForWindows':True,
        'compilerAndOracleSourceUnchanged':True,'testOutputsUnchanged':True,'testReruns':0}
    destination=directory/'receipt.json';assert not destination.exists()
    destination.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':
    main()
