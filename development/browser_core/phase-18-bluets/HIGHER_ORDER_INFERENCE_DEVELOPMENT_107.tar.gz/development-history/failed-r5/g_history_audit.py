# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Verify the preimplementation contract, complete baseline, red run and prior failures."""
from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
from g_artifact_pack import verify_archive


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(repo):
    root = repo/'target/higher-order-inference-contract-20261114'
    phase = repo/'development/browser_core/phase-18-bluets'
    fixture = repo/'backend/bluets/tests/fixtures/higher_order_inference'
    frozen = read(fixture/'FROZEN.json')
    assert frozen['productionStarted'] is False
    assert frozen['forms'] == 48 and frozen['profiles'] == 8 and frozen['primaryComparisons'] == 384
    assert frozen['boundaryControls'] == 12 and frozen['typescript'] == '5.9.3'
    for name,digest in frozen['sha256'].items():
        assert sha(fixture/name) == digest,name
    before = read(root/'preimplementation-receipt.json')
    started = read(root/'implementation-started.json')
    assert before['productionStarted'] is False and started['allNativeAndRedPrerequisitesComplete']
    assert started['productionDiffBeforeStart'] == []
    assert before['parentCommit'] == started['parentCommit'] == frozen['parentCommit']
    assert before['frozenSha256'] == started['frozenSha256'] == sha(fixture/'FROZEN.json')
    assert datetime.datetime.fromisoformat(frozen['frozenAt']) < datetime.datetime.fromisoformat(before['recordedAt']) < datetime.datetime.fromisoformat(started['recordedAt'])
    source_hashes = before['productionSourceHashes']
    red = read(root/'red-1/measurement.json')
    keys = sorted(source_hashes)
    requests = ''.join(frozen['parentCommit']+':'+name+'\n' for name in keys).encode()
    result = subprocess.run(['git','cat-file','--batch'],cwd=repo,input=requests,
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    stream = io.BytesIO(result.stdout)
    for name in keys:
        header = stream.readline().split()
        assert len(header) == 3 and header[1] == b'blob'
        data = stream.read(int(header[2]))
        assert stream.read(1) == b'\n'
        assert hashlib.sha256(data).hexdigest() == source_hashes[name],name
        assert red['source'][name] == source_hashes[name],name
        retained = root/'red-1/source'/name
        if retained.exists():
            assert sha(retained) == source_hashes[name],name
    assert stream.read() == b''
    for field,path in [('nativeCalibrationSha256','native-calibration-1/measurement.json'),
        ('nativeReplaySha256','native-replay-1/measurement.json'),
        ('runtimeNegativeChecksSha256','runtime-tests-1/measurement.json'),
        ('baselineSha256','baseline-1/measurement.json'),('redSha256','red-1/measurement.json')]:
        assert sha(root/path) == before[field],field
    baseline = read(root/'baseline-1/measurement.json')
    assert baseline['conclusion'] == 'measured-baseline' and baseline['inventoryCredit'] == 0
    assert red['conclusion'] == 'expected-red' and red['productionSourcesUnchanged']
    assert red['rust'] == {'passed':1,'failed':2,'ignored':1,'filtered':0,'exit':101}
    assert red['all384BaselineObservationsReproduced']
    assert (baseline['comparisons'],baseline['completeAgreements'],baseline['completeDifferences']) == (384,48,336)
    assert baseline['classifications'] == {'exact-declaration-difference':204,'incorrect-rejection':116,
        'complete-diagnostic-difference':16,'complete-agreement':48}
    expected = {row['id']:row for row in read(fixture/'reference.json')['cases']}
    rows = {row['id']:row for row in baseline['cases']}
    assert len(rows) == 384 and set(rows) == set(expected)
    for ident,row in rows.items():
        observed = read(root/'red-1/capture'/ident/'observation.json')
        assert all(observed[key] == row[key] for key in ['id','accepts','diagnostics','declarations','agrees','publishedOnRejectedNativeInput'])
        agrees = all(row[key] == expected[ident][key] for key in ['accepts','diagnostics','declarations'])
        assert agrees == row['agrees'] and not row['publishedOnRejectedNativeInput']
        for name,text in row['declarations'].items():
            assert (root/'baseline-1'/ident/'dist'/name).read_bytes() == text.encode()
            assert (root/'red-1/capture'/ident/'dist'/name).read_bytes() == text.encode()
    assert sha(root/'baseline-1/baseline-cli') == baseline['compilerSha256']
    assert sha(root/'red-1/actual-cli') == red['actual-cliSha256']
    assert sha(root/'red-1/actual-test-executable') == red['actual-test-executableSha256']
    parent_probe = read(root/'call-chain-script-parent-baseline-1/report.json')
    assert parent_probe['compilerSha256'] == baseline['compilerSha256']
    script_case = next(row for row in parent_probe['cases'] if row['id'] == 'lib-method-unary-chain-valid')
    assert script_case['expected']['accepts'] and script_case['observed']['accepts']
    assert script_case['expected']['diagnostics'] == script_case['observed']['diagnostics'] == []
    assert script_case['expected']['declarations']['main.d.ts'] and script_case['observed']['declarations']['main.d.ts'] == ''
    probe_input = root/'call-chain-script-parent-baseline-1/blue/default/lib-method-unary-chain-valid/main.ts'
    original_path = 'backend/bluets/tests/fixtures/typescript_oracle/lib-method-unary-chain-valid/main.ts'
    assert probe_input.read_bytes() == subprocess.check_output(['git','show',frozen['parentCommit']+':'+original_path],cwd=repo)
    archives = {}
    for label in ['DISCOVERY','BASELINE']:
        publication = read(phase/('HIGHER_ORDER_INFERENCE_'+label+'.json'))
        archive = phase/publication['evidence']['path']
        manifest = phase/publication['memberManifest']['path']
        assert sha(archive) == publication['evidence']['sha256']
        assert sha(manifest) == publication['memberManifest']['sha256']
        entries = read(manifest)['entries']
        verify_archive(archive,entries)
        archives[label.lower()] = {'archive':archive.name,'sha256':sha(archive),
            'memberManifest':manifest.name,'memberManifestSha256':sha(manifest),'members':len(entries)}
    failures = {}
    for label,subdir,name in [('r1','windows/cancellation-1','interrupted-evidence-audit.json'),
        ('r2','windows/failure-observation-1','failed-evidence-audit.json'),
        ('r3','windows/interrupted-evidence-1','audit.json')]:
        directory = repo/('target/higher-order-inference-acceptance-20261114-'+label)
        receipt = read(directory/subdir/name)
        assert receipt['acceptanceCredit'] == 0 and receipt['sourceFilesIndependentlyVerified'] == 14818
        failures[label] = {'audit':str((directory/subdir/name).relative_to(repo)),
            'sha256':sha(directory/subdir/name),'acceptanceCredit':0}
    return {'conclusion':'success','parentCommit':frozen['parentCommit'],
        'productionStartedOnlyAfterFrozenNativeAndRed':True,'preimplementationSourceFilesVerified':len(keys),
        'completeBaselineComparisons':384,'baselineAgreements':48,'baselineDifferences':336,
        'redComparisonsIndependentlyMatched':384,'publishedPreRepairArchives':archives,
        'priorWindowsFailureEvidence':failures,'baselineInventoryCredit':0}
