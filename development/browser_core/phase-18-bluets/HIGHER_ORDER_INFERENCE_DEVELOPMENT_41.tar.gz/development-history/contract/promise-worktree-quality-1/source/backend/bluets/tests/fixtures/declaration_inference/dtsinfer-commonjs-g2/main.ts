// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

export class Box { value(answer: number): number; value(answer: string): string; value(answer: any): any { return answer; } } export const result = [new Box().value(42)];
