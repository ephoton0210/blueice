# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
"""Author inputs only; all verdicts and output bytes come from pinned Native."""
from pathlib import Path
import hashlib
import json

REPO = Path(__file__).resolve().parents[2]
ROOT = Path(__file__).resolve().parent
FIXTURE = REPO / 'backend/bluets/tests/fixtures/symbolic_keys'
old = json.loads((REPO / 'target/generic-key-next-discovery-20261113/symbolic-relations32/inputs.json').read_bytes())
cases = [{**row, 'origin': 'unchanged-discovery-32'} for row in old['cases']]
by_id = {row['id']: row for row in cases}


def consumers(identifier, positive, negative):
    by_id[identifier]['consumerSources'] = {
        'positive': 'import {result} from "./main";\n' + positive + '\n',
        'negative': 'import {result} from "./main";\n' + negative + '\n',
    }


def add(identifier, source, positive=None, negative=None, files=None, runtime=None):
    assert identifier not in by_id
    row = {'id': identifier, 'source': source + '\n', 'origin': 'extended-key-relations'}
    if files:
        row['files'] = files
    if runtime:
        row['runtime'] = runtime
    cases.append(row)
    by_id[identifier] = row
    if positive is not None:
        consumers(identifier, positive, negative)


pair = ('result<{x: number}, "x">("x", key => { const accepted: "x" = key; });',
        'result<{x: number}, "x">("y", () => {});')
for identifier in ['same-parameter', 'same-key-annotated-copy']:
    consumers(identifier, *pair)
consumers('same-parameter-capture',
          'result<{x: number}>(key => { const accepted: "x" = key; })<"x">("x");',
          'result<{x: number}>(() => {})<"y">("y");')
consumers('extends-forward',
          'result<{x: number; y: string}, {x: number}, "x">("x", key => { const accepted: "x" | "y" = key; });',
          'result<{x: number; y: string}, {x: number}, "y">("y", () => {});')
consumers('key-intersection',
          'result<{x: number; a: string}, {x: boolean; b: string}, "x">("x", () => {});',
          'result<{x: number; a: string}, {x: boolean; b: string}, "a">("a", () => {});')
consumers('never-argument', 'declare const key: never; result<{x: number}>(key, () => {});',
          'result<{x: number}>("x", () => {});')
consumers('any-argument', 'result<{x: number}>(true, key => { const accepted: "x" = key; });',
          'result<{x: number}>(true, (key: boolean) => {});')
for identifier in ['keys-to-propertykey', 'same-local-alias', 'required-string-key']:
    consumers(identifier, 'result<{x: number}>("x", () => {});', 'result<{x: number}>("y", () => {});')
consumers('required-number-key', 'result<{0: number}>(0, () => {});', 'result<{0: number}>(1, () => {});')
consumers('required-symbol-key',
          'declare const key: Parameters<typeof result>[0]; result(key, value => { const accepted: typeof key = value; });',
          'result("x", () => {});')
for identifier in ['any-keys-to-propertykey', 'never-keys-to-propertykey']:
    consumers(identifier, 'declare const key: symbol; result<{}>(key, value => { const accepted: PropertyKey = value; });',
              'result<{}>(true, () => {});')
consumers('unknown-keys-to-never', 'declare const key: never; result<{}>(key, () => {});', 'result<{}>("x", () => {});')
consumers('union-object-keys',
          'result<{x: number; a: string}, {x: boolean; b: string}>("x", () => {});',
          'result<{x: number; a: string}, {x: boolean; b: string}>("a", () => {});')
consumers('same-named-keys-alias', *pair)
consumers('constraint-chain', 'result<{x: number}, "x", "x">("x", () => {});',
          'result<{x: number}, "x", "y">("y", () => {});')
consumers('intersection-local-alias',
          'result<{x: number; a: string}, {x: boolean; b: string}>("x", () => {});',
          'result<{x: number; a: string}, {x: boolean; b: string}>("a", () => {});')

add('transitive-forward', 'export function result<E extends F, F extends G, G, K extends keyof G>(key: K, consume: (key: keyof E) => void) { consume(key); }',
    'result<{x: number; y: string}, {x: number}, {x: number}, "x">("x", () => {});',
    'result<{x: number; y: string}, {x: number}, {x: number}, "y">("y", () => {});')
add('transitive-reverse', 'export function result<E, F extends E, G extends F, K extends keyof G>(key: K, consume: (key: keyof E) => void) { consume(key); }')
add('imported-keys-forward', 'import type {Keys} from "./keys";\nexport function result<E extends F, F, K extends Keys<F>>(key: K, consume: (key: Keys<E>) => void) { consume(key); }',
    'result<{x: number; y: string}, {x: number}, "x">("x", () => {});',
    'result<{x: number; y: string}, {x: number}, "y">("y", () => {});',
    files={'keys.ts': 'export type Keys<T> = keyof T;\n'})
add('equal-index-constraints', 'export function result<E extends {[key: string]: unknown}, F extends {[key: string]: unknown}, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }')
add('captured-key-alias', 'export function result<E, F>(consume: (key: keyof E) => void) { type Key = keyof F; return (key: Key) => consume(key); }')
add('reordered-forward', 'export function result<F, E extends F, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }',
    'result<{x: number}, {x: number; y: string}, "x">("x", () => {});',
    'result<{x: number}, {x: number; y: string}, "y">("y", () => {});')
add('union-to-union', 'export function result<E, F>(key: keyof E | keyof F, consume: (key: keyof E | keyof F) => void) { consume(key); }',
    'result<{x: number}, {y: string}>("y", () => {});', 'result<{x: number}, {y: string}>("z", () => {});')
add('keys-to-key-union', 'export function result<E, F>(key: keyof E, consume: (key: keyof E | keyof F) => void) { consume(key); }',
    'result<{x: number}, {y: string}>("x", () => {});', 'result<{x: number}, {y: string}>("y", () => {});')
add('intersection-to-right', 'export function result<E, F>(key: keyof E & keyof F, consume: (key: keyof F) => void) { consume(key); }',
    'result<{x: number; a: string}, {x: boolean; b: string}>("x", () => {});',
    'result<{x: number; a: string}, {x: boolean; b: string}>("b", () => {});')
add('object-union-to-right', 'export function result<E, F>(key: keyof (E | F), consume: (key: keyof F) => void) { consume(key); }',
    'result<{x: number; a: string}, {x: boolean; b: string}>("x", () => {});',
    'result<{x: number; a: string}, {x: boolean; b: string}>("b", () => {});')
add('object-intersection-to-key-union', 'export function result<E, F>(key: keyof (E & F), consume: (key: keyof E | keyof F) => void) { consume(key); }',
    'result<{x: number}, {y: string}>("y", () => {});', 'result<{x: number}, {y: string}>("z", () => {});')
add('extra-key-beyond-object-constraint', 'export function result<E extends {x: number}, K extends keyof E>(key: K, consume: (key: "x") => void) { consume(key); }')
add('index-constraint-keeps-symbol-possibility', 'export function result<E extends {[key: string]: number}>(key: keyof E, consume: (key: string | number) => void) { consume(key); }')
add('alias-union-operand', 'type Keys<T> = keyof T;\nexport function result<E, F>(key: Keys<E | F>) { return key; }',
    'const accepted: "x" = result<{x: number; a: string}, {x: boolean; b: string}>("x");',
    'result<{x: number; a: string}, {x: boolean; b: string}>("a");')
add('alias-key-intersection', 'type Keys<T> = keyof T;\nexport function result<E, F>(key: Keys<E> & Keys<F>, consume: (key: Keys<E>) => void) { consume(key); }',
    'result<{x: number; a: string}, {x: boolean; b: string}>("x", () => {});',
    'result<{x: number; a: string}, {x: boolean; b: string}>("a", () => {});')
add('return-object-union-keys', 'export function result<E, F>(key: keyof (E | F)) { return key; }',
    'const accepted: "x" = result<{x: number; a: string}, {x: boolean; b: string}>("x");',
    'result<{x: number; a: string}, {x: boolean; b: string}>("a");')
add('return-object-intersection-keys', 'export function result<E, F>(key: keyof (E & F)) { return key; }',
    'const accepted: "x" | "y" = result<{x: number}, {y: string}>("y");',
    'result<{x: number}, {y: string}>("z");')
add('return-conditional-operand-keys', 'export function result<T extends boolean, E, F>(key: keyof (T extends true ? E : F)) { return key; }',
    'const accepted: "x" = result<true, {x: number}, {y: string}>("x");',
    'result<true, {x: number}, {y: string}>("y");')
add('return-array-operand-keys', 'export function result<E>(key: keyof E[]) { return key; }',
    'const accepted: keyof number[] = result<number>("length");', 'result<number>("absent");')
add('return-tuple-operand-keys', 'export function result<E, F>(key: keyof [E, F]) { return key; }',
    'const accepted: keyof [number, string] = result<number, string>("1");', 'result<number, string>("2");')
add('return-function-operand-keys', 'export function result<E>(key: keyof (() => E)) { return key; }',
    'declare const key: never; const accepted: never = result<number>(key);', 'result<number>("x");')
add('return-constructor-operand-keys', 'export function result<E>(key: keyof (new () => E)) { return key; }',
    'declare const key: never; const accepted: never = result<number>(key);', 'result<number>("x");')
add('return-mixed-operand-keys', 'export function result<E, F, G>(key: keyof ((E | F) & G)) { return key; }',
    'const accepted: "x" | "g" = result<{x: number; a: string}, {x: boolean; b: string}, {g: boolean}>("g");',
    'result<{x: number; a: string}, {x: boolean; b: string}, {g: boolean}>("a");')
add('owner-propertykey-rejects-global-domain', 'type PropertyKey = boolean;\nexport function result(key: keyof any, consume: (key: PropertyKey) => void) { consume(key); }')
add('owner-propertykey-keeps-own-domain', 'type PropertyKey = boolean;\nexport function result(key: PropertyKey) { return key; }',
    'const accepted: boolean = result(true);', 'result("x");')
add('return-primitive-symbol-keys', 'export function result(key: keyof symbol) { return key; }',
    'const accepted: keyof symbol = result("toString");', 'result("absent");')
add('any-keys-include-symbol', 'export function result(key: symbol, consume: (key: keyof any) => void) { consume(key); }',
    'declare const key: symbol; result(key, () => {});', 'result(true, () => {});')
add('never-keys-are-not-only-symbol', 'export function result(key: keyof never, consume: (key: symbol) => void) { consume(key); }')
add('unknown-keys-assign-to-any', 'export function result(key: keyof unknown, consume: (key: any) => void) { consume(key); }',
    'declare const key: never; result(key, () => {});', 'result("x", () => {});')
add('return-unknown-union-keys', 'export function result<E>(key: keyof (E | unknown)) { return key; }',
    'declare const key: never; const accepted: never = result<{}>(key);', 'result<{}>("x");')
add('return-unknown-intersection-keys', 'export function result<E>(key: keyof (E & unknown)) { return key; }',
    'const accepted: "x" = result<{x: number}>("x");', 'result<{x: number}>("y");')
add('imported-unrelated-keys', 'import type {Keys} from "./keys";\nexport function result<E, F>(key: Keys<F>, consume: (key: Keys<E>) => void) { consume(key); }',
    files={'keys.ts': 'export type Keys<T> = keyof T;\n'})

assert len(cases) == 64 and len(by_id) == 64
for identifier in ['same-parameter', 'extends-forward', 'key-intersection', 'union-object-keys', 'intersection-local-alias']:
    by_id[identifier]['runtime'] = 'var observed = ""; check("x", function(key) { observed = key; }); if (observed !== "x") throw Error("key callback");'
by_id['same-parameter-capture']['runtime'] = 'var observed = ""; check(function(key) { observed = key; })("x"); if (observed !== "x") throw Error("captured key callback");'
data = {'schema': 1, 'scope': 'P0-E authored contract; Native observations must be calibrated and frozen before production edits.',
        'options': {'strict': True, 'lib': ['ES5'], 'declaration': True, 'noEmitOnError': True},
        'profiles': [{'id': target.lower() + '-' + module.lower(), 'compilerOptions': {'target': target, 'module': module}}
                     for target in ['ES5', 'ES2022'] for module in ['CommonJS', 'ESNext']],
        'cases': cases}
FIXTURE.mkdir(parents=True, exist_ok=True)
path = FIXTURE / 'cases.json'
with path.open('x') as output:
    json.dump(data, output, indent=2, ensure_ascii=False)
    output.write('\n')
receipt = {'original32InputsSha256': hashlib.sha256((REPO / 'target/generic-key-next-discovery-20261113/symbolic-relations32/inputs.json').read_bytes()).hexdigest(),
           'originalSourcesUnchanged': all(row['source'] == by_id[row['id']]['source'] for row in old['cases']),
           'forms': len(cases), 'profiles': 4, 'comparisons': len(cases) * 4,
           'authoredInputSha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(ROOT / 'authored-input-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
