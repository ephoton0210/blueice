// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! ESM, declaration, and source-map emission from the shared checked graph.

use crate::checker::CheckedProject;
use crate::compiler::{
    fingerprint, is_declaration_module, is_external_library_module, CompilerOptions, Project,
};
use crate::diagnostic::{Diagnostic, DiagnosticCode, SourceSpan};
use crate::parser::{Declaration, Module, TextEdit, Type, TypeParameter};
use crate::strict_boundaries;
use std::collections::{BTreeMap, BTreeSet};

pub use decorators::DECORATOR_HELPER_V1_VERSION;
pub use legacy_decorators::LEGACY_DECORATOR_HELPER_V1_VERSION;
pub(crate) use literal_order::VERSION as LITERAL_ORDER_VERSION;
pub(crate) use module_wrappers::VERSION as MODULE_WRAPPERS_VERSION;
pub use private_lowering::CLASS_HELPER_V1_VERSION;
pub use source_map_lookup::{SourceMapLookupError, SourceMapOriginalPosition};
pub(crate) use system::HELPER_SOURCE as SYSTEM_HELPER_SOURCE;
pub use targets::TARGET_HELPER_V1_VERSION;
pub(crate) use targets::{STRING_LITERAL_LOWERING_VERSION, TARGET_HELPER_V1_SOURCES};

mod callable_objects;
mod class_expressions;
mod class_lowering;
mod classes;
mod commonjs;
mod computed_fields;
mod declaration_maps;
pub(crate) use declaration_maps::VERSION as DECLARATION_MAP_VERSION;
mod binding_patterns;
mod declarations;
mod decorators;
mod enums;
mod global_declarations;
mod helper_selection;
pub(crate) use helper_selection::VERSION as HELPER_SELECTION_VERSION;
mod inference_literals;
mod inferred_declarations;
mod inferred_returns;
mod javascript_maps;
mod jsx;
pub(crate) mod legacy_decorators;
mod literal_order;
mod module_lowering;
mod module_wrappers;
mod namespaces;
mod node_imports;
mod output_options;
mod private_lowering;
mod reexports;
mod relocations;
mod source_map_lookup;
mod system;
mod targets;
mod token_maps;
mod type_elision;

use declarations::{
    emit_declaration, emit_type_parameters, is_default_export_name, is_value_export_name,
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BuildOutput {
    pub fingerprint: String,
    pub artifacts: BTreeMap<String, BuildArtifact>,
    /// Root-relative declaration modules preserved for declaration-consuming
    /// builds. They are never JavaScript artifacts.
    pub declaration_modules: BTreeMap<String, String>,
    /// Original owner-authorized data, copied without JavaScript lowering.
    pub assets: BTreeMap<String, String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BuildArtifact {
    pub module_id: String,
    pub javascript: String,
    pub source_map: Option<SourceMap>,
    pub declaration: Option<String>,
    pub declaration_map: Option<SourceMap>,
    pub fingerprint: String,
    /// Present only when every admitted strict crossing has an emitted helper
    /// call. Publishers must verify these byte locations before release.
    pub strict_runtime: Option<EmittedStrictModule>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EmittedStrictModule {
    pub helper_version: String,
    pub helper_import: EmittedRuntimeSite,
    pub boundaries: Vec<EmittedRuntimeBoundary>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EmittedRuntimeBoundary {
    pub contract_id: String,
    pub function: String,
    pub source_span: SourceSpan,
    pub max_string_bytes: usize,
    pub ingress: Vec<EmittedRuntimeSite>,
    pub egress: EmittedRuntimeSite,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EmittedRuntimeSite {
    pub source_span: SourceSpan,
    pub generated_start: usize,
    pub expected_text: String,
}

/// A Source Map v3 payload.  It is kept as structured data until the CLI or a
/// host chooses an artifact location, preventing source-map URLs from leaking
/// filesystem paths into the shared compiler layer.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SourceMap {
    pub file: String,
    pub sources: Vec<String>,
    pub sources_content: Vec<String>,
    pub inline_sources: bool,
    pub source_root: String,
    /// Source Map v3 names referenced by optional fifth fields in mappings.
    pub names: Vec<String>,
    pub mappings: String,
}

impl SourceMap {
    pub fn to_json(&self) -> String {
        format!(
            "{{\"version\":3,\"file\":\"{}\",\"sourceRoot\":\"{}\",\"sources\":[{}]{},\"names\":[{}],\"mappings\":\"{}\"}}",
            json_escape(&self.file),
            json_escape(&self.source_root),
            self.sources
                .iter()
                .map(|source| format!("\"{}\"", json_escape(source)))
                .collect::<Vec<_>>()
                .join(","),
            if self.inline_sources {
                format!(",\"sourcesContent\":[{}]", self.sources_content
                    .iter()
                    .map(|source| format!("\"{}\"", json_escape(source)))
                    .collect::<Vec<_>>()
                    .join(","))
            } else { String::new() },
            self.names
                .iter()
                .map(|name| format!("\"{}\"", json_escape(name)))
                .collect::<Vec<_>>()
                .join(","),
            json_escape(&self.mappings),
        )
    }
}

pub(crate) fn emit(
    checked: &CheckedProject,
    project: &Project,
    options: &CompilerOptions,
) -> Result<BuildOutput, Diagnostic> {
    let build_fingerprint = fingerprint(project, options);
    let exported_enums = crate::checker::exported_enums(project);
    let artifacts = checked
        .modules
        .iter()
        .filter(|(id, _)| {
            !is_declaration_module(id)
                && !is_external_library_module(id)
                && !project.json_modules.contains_key(*id)
        })
        .map(|(id, checked_module)| {
            let mut file_options = options.clone();
            file_options.module_kind = project.module_kind(id, options.module_kind);
            file_options.isolated_modules |= options.verbatim_module_syntax;
            let (emitted, strict_runtime) = if options.emit_declaration_only {
                (
                    EmittedJavaScript {
                        javascript: String::new(),
                        provenance: Vec::new(),
                        segment_limit: None,
                        overflowed: false,
                    },
                    None,
                )
            } else {
                emit_javascript(
                    &checked_module.module,
                    project,
                    &exported_enums,
                    &file_options,
                )?
            };
            if options.source_map
                && !options.emit_declaration_only
                && (emitted.overflowed
                    || emitted.provenance.len() > options.limits.max_source_map_segments)
            {
                return Err(Diagnostic::error(
                    DiagnosticCode::ResourceLimit,
                    SourceSpan::new(id, 0, 0),
                    "emitted source map exceeded the segment limit",
                ));
            }
            let source_map = (options.source_map && !options.emit_declaration_only)
                .then(|| source_map(id, &checked_module.module.source, &emitted, options));
            let mut declaration_origins = BTreeMap::new();
            let declaration = options
                .declaration
                .then(|| {
                    let order = literal_order::Order::new(&checked_module.module, options)?;
                    let mut context = inferred_declarations::Context::new(
                        checked_module,
                        project,
                        &order,
                        options,
                    )?;
                    let text = emit_declaration(
                        &inferred_returns::declaration_module(checked_module, &order),
                        &checked_module.symbols,
                        Some(&context),
                        options,
                    )?;
                    declaration_origins = context.take_map_origins();
                    Ok::<_, Diagnostic>(text)
                })
                .transpose()?;
            let declaration = declaration.map(|text| output_options::format_text(text, options));
            let declaration_map = if options.declaration_map {
                declaration
                    .as_deref()
                    .map(|text| {
                        declaration_maps::build(
                            id,
                            &checked_module.module,
                            text,
                            &declaration_origins,
                            options,
                        )
                    })
                    .transpose()?
            } else {
                None
            };
            Ok((
                id.clone(),
                BuildArtifact {
                    module_id: id.clone(),
                    javascript: emitted.javascript,
                    source_map,
                    declaration,
                    declaration_map,
                    fingerprint: build_fingerprint.clone(),
                    strict_runtime,
                },
            ))
        })
        .collect::<Result<BTreeMap<_, _>, Diagnostic>>()?;
    let declaration_modules = if options.declaration {
        {
            checked
                .modules
                .iter()
                .filter(|(id, _)| {
                    is_declaration_module(id)
                        && !is_external_library_module(id)
                        && !project.is_ambient_declaration_module(id)
                })
                .map(|(id, checked_module)| (id.clone(), checked_module.module.source.clone()))
                .collect()
        }
    } else {
        BTreeMap::new()
    };
    Ok(BuildOutput {
        fingerprint: build_fingerprint,
        artifacts,
        declaration_modules,
        assets: project
            .json_modules
            .keys()
            .filter(|id| !is_external_library_module(id))
            .map(|id| (id.clone(), project.modules[id].source.clone()))
            .collect(),
    })
}

/// Preflight the copied-source token marks, edit boundaries and physical lines
/// before emitting a map. Later generated transforms have their own final
/// segment-count check because helper expansion is not bounded by source tokens.
pub(crate) fn validate_source_map_limits(
    checked: &CheckedProject,
    options: &CompilerOptions,
) -> Vec<Diagnostic> {
    let max_segments = options.limits.max_source_map_segments;
    checked
        .modules
        .iter()
        .filter(|(id, _)| !is_declaration_module(id))
        .filter_map(|(id, checked_module)| {
            let module = &checked_module.module;
            let physical_lines = module
                .source
                .chars()
                .filter(|character| matches!(character, '\r' | '\n'))
                .count()
                .saturating_add(1);
            let token_marks = crate::syntax::lex(id, &module.source)
                .map(|tokens| tokens.len().saturating_mul(2))
                .unwrap_or(0);
            let rewritten_imports = module
                .declarations
                .iter()
                .filter(|declaration| {
                    matches!(declaration, Declaration::Import(import) if !import.is_type_only())
                })
                .count();
            let strict_functions = module
                .declarations
                .iter()
                .filter_map(|declaration| match declaration {
                    Declaration::Function(function) if options.strict_runtime_boundaries.iter().any(
                        |boundary| boundary.span == function.span && boundary.function == function.name,
                    ) => Some(function.parameters.len()),
                    _ => None,
                })
                .collect::<Vec<_>>();
            let strict_edits = if strict_functions.is_empty() {
                0
            } else {
                1usize.saturating_add(strict_functions.len().saturating_mul(3))
            };
            let inserted_line_breaks = if strict_functions.is_empty() {
                0
            } else {
                1usize.saturating_add(strict_functions.iter().sum::<usize>())
            };
            let bound = physical_lines.saturating_add(token_marks).saturating_add(
                module
                    .edits
                    .len()
                    .saturating_add(rewritten_imports)
                    .saturating_add(strict_edits)
                    .saturating_mul(2),
            ).saturating_add(inserted_line_breaks);
            (bound > max_segments).then(|| {
                Diagnostic::error(
                    DiagnosticCode::ResourceLimit,
                    SourceSpan::new(id, 0, 0),
                    format!(
                        "source map requires up to {bound} segments, exceeding the {max_segments} segment limit"
                    ),
                )
            })
        })
        .collect()
}

struct EmittedJavaScript {
    javascript: String,
    provenance: Vec<ProvenanceSegment>,
    segment_limit: Option<usize>,
    overflowed: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ProvenanceSegment {
    generated_line: usize,
    generated_column: usize,
    source_line: usize,
    source_column: usize,
    mapped: bool,
    /// Index into `SourceMap::names`; absent for unnamed segments.
    name_index: Option<usize>,
}

fn emit_javascript(
    module: &Module,
    project: &Project,
    exported_enums: &BTreeMap<String, BTreeMap<String, crate::checker::ExportedEnum>>,
    options: &CompilerOptions,
) -> Result<(EmittedJavaScript, Option<EmittedStrictModule>), Diagnostic> {
    let mut script_options;
    let options = if options.import_helpers && !project.is_external_module(module) {
        script_options = options.clone();
        script_options.import_helpers = false;
        &script_options
    } else {
        options
    };
    let wrapper = options.module_kind;
    let mut wrapper_options;
    let options = if matches!(
        wrapper,
        crate::ModuleKind::Amd | crate::ModuleKind::Umd | crate::ModuleKind::System
    ) {
        wrapper_options = options.clone();
        wrapper_options.module_kind = crate::ModuleKind::CommonJs;
        if wrapper == crate::ModuleKind::System {
            wrapper_options.es_module_interop = false;
        }
        &wrapper_options
    } else {
        options
    };
    let emitting_module = if options.verbatim_module_syntax {
        std::borrow::Cow::Borrowed(module)
    } else {
        type_elision::queries(module, project, options)
    };
    let module = emitting_module.as_ref();
    let mut edits = module.edits.clone();
    output_options::erase_type_comments(module, &mut edits);
    if wrapper == crate::ModuleKind::System {
        system::validate(module, options)?;
    }
    let lexical = targets::es5::prepare(module, project, options, &mut edits)?;
    type_elision::lower(module, options.module_kind, &mut edits);
    node_imports::lower(module, options, &mut edits);
    for declaration in &module.declarations {
        let (specifier, span) = match declaration {
            Declaration::Import(import) if !import.is_type_only() => {
                (&import.specifier, &import.specifier_span)
            }
            Declaration::ValueExport(export)
                if export.specifier.is_some() && !export.is_type_only() =>
            {
                (
                    export.specifier.as_ref().unwrap(),
                    export.specifier_span.as_ref().unwrap(),
                )
            }
            _ => continue,
        };
        if options.module_kind == crate::compiler::ModuleKind::CommonJs {
            continue;
        }
        let raw = &module.source[span.start..span.end];
        let Some(quote) = raw.chars().next() else {
            continue;
        };
        let Some(last) = raw.chars().last() else {
            continue;
        };
        if quote != last || !matches!(quote, '\'' | '\"') {
            continue;
        }
        let emitted_specifier = javascript_specifier(
            specifier,
            options.jsx == Some(crate::compiler::JsxMode::Preserve),
        );
        edits.push(TextEdit {
            start: span.start,
            end: span.end,
            replacement: format!("{quote}{emitted_specifier}{quote}"),
        });
    }
    module_lowering::lower(
        module,
        project,
        exported_enums,
        options,
        &mut edits,
        wrapper,
    )?;
    let plan = strict_boundaries::plan_emission(module, options)?;
    let mut strict_runtime = None;
    if let Some((strict_edits, record)) = plan {
        edits.extend(strict_edits);
        strict_runtime = Some(record);
    }
    let token_anchors = if options.source_map {
        javascript_maps::token_anchors(module, options, &edits)
    } else {
        BTreeMap::new()
    };
    let emitted = decorators::targets::lower(
        apply_edits_with_anchors(
            &module.source,
            edits,
            options
                .source_map
                .then_some(options.limits.max_source_map_segments),
            token_anchors,
            if options.source_map {
                javascript_maps::token_end_anchors(module, options)
            } else {
                BTreeMap::new()
            },
            None,
        ),
        module,
        project,
        options,
    )?;
    let emitted = targets::lower(emitted, module, options)?;
    let emitted = targets::es5::lower_module(emitted, module, options, &lexical, wrapper)?;
    let emitted = if wrapper == crate::ModuleKind::System {
        targets::es5::lower_system_bindings(emitted, module, options)?
    } else {
        emitted
    };
    let emitted = helper_selection::lower(emitted, module, project, options)?;
    let emitted = type_elision::preserve_module_identity(emitted, module, options);
    let emitted = if wrapper == crate::ModuleKind::System {
        system::wrap(emitted, module, options)?
    } else {
        emitted
    };
    let emitted = module_wrappers::wrap(emitted, module, options, wrapper);
    let emitted = targets::lower_string_literals(emitted, module, options)?;
    let emitted = output_options::format_javascript(emitted, module, options)?;
    if let Some(record) = &mut strict_runtime {
        record.helper_import.expected_text =
            output_options::format_text(record.helper_import.expected_text.clone(), options);
        strict_boundaries::locate_emitted_calls(module, &emitted.javascript, record)?;
    }
    Ok((emitted, strict_runtime))
}

/// Every declaration of a module in source order, descending into namespace
/// bodies, each with whether it is inside one.
fn runtime_declarations(declarations: &[Declaration]) -> Vec<(&Declaration, bool)> {
    fn visit<'a>(
        declarations: &'a [Declaration],
        nested: bool,
        into: &mut Vec<(&'a Declaration, bool)>,
    ) {
        for declaration in declarations {
            into.push((declaration, nested));
            if let Declaration::Namespace(namespace) = declaration {
                visit(&namespace.body, true, into);
            }
        }
    }
    let mut all = Vec::new();
    visit(declarations, false, &mut all);
    all
}

/// The specifier an emitted module is imported by: a TypeScript extension becomes
/// the JavaScript one (`.tsx` stays `.jsx` when JSX is preserved).
pub fn javascript_specifier(specifier: &str, preserve_jsx: bool) -> String {
    for (source, output) in [(".mts", ".mjs"), (".cts", ".cjs")] {
        if let Some(stem) = specifier.strip_suffix(source) {
            return format!("{stem}{output}");
        }
    }
    if let Some(stem) = specifier.strip_suffix(".tsx") {
        return format!("{stem}{}", if preserve_jsx { ".jsx" } else { ".js" });
    }
    specifier
        .strip_suffix(".ts")
        .map(|stem| format!("{stem}.js"))
        .unwrap_or_else(|| specifier.to_string())
}

/// One-line text of an expression: runs of whitespace become one space, and a
/// space an erased annotation left before a closing bracket or comma goes
/// (outside string and template literals).
fn compact_expression(text: &str) -> String {
    let collapsed = text.split_whitespace().collect::<Vec<_>>().join(" ");
    let mut output = String::with_capacity(collapsed.len());
    let mut quote: Option<char> = None;
    let mut chars = collapsed.chars().peekable();
    let mut escaped = false;
    while let Some(character) = chars.next() {
        match quote {
            Some(open) => {
                output.push(character);
                if escaped {
                    escaped = false;
                } else if character == '\\' {
                    escaped = true;
                } else if character == open {
                    quote = None;
                }
            }
            None => {
                if matches!(character, '"' | '\'' | '`') {
                    quote = Some(character);
                    output.push(character);
                } else if character == ' '
                    && chars
                        .peek()
                        .is_some_and(|next| matches!(next, ')' | ']' | ','))
                {
                    // dropped
                } else {
                    output.push(character);
                }
            }
        }
    }
    output
}

fn apply_edits(source: &str, edits: Vec<TextEdit>) -> EmittedJavaScript {
    apply_edits_with_provenance(source, edits, None)
}

/// Provenance for a compiler-owned insertion, such as a selected runtime check.
pub(crate) fn source_anchor(offset: usize) -> String {
    relocations::source_anchor(offset)
}

fn apply_edits_with_provenance(
    source: &str,
    edits: Vec<TextEdit>,
    segment_limit: Option<usize>,
) -> EmittedJavaScript {
    apply_edits_with_anchors(
        source,
        edits,
        segment_limit,
        BTreeMap::new(),
        BTreeMap::new(),
        None,
    )
}

fn apply_edits_with_anchors(
    source: &str,
    mut edits: Vec<TextEdit>,
    segment_limit: Option<usize>,
    token_anchors: BTreeMap<usize, Option<usize>>,
    token_end_anchors: BTreeMap<usize, usize>,
    copied_boundaries: Option<Vec<usize>>,
) -> EmittedJavaScript {
    edits.sort_by_key(|edit| (edit.start, edit.end));
    // A replacement may carry relocation markers (see `decorators::relocated`):
    // the text of another source range, with the edits inside it applied.
    let relocating = edits.iter().any(|edit| edit.replacement.contains('\u{0}'));
    let snapshot = relocating.then(|| edits.clone());
    let mut emitted = ProvenanceEmitter::new(source, source.len(), segment_limit);
    emitted.token_anchors = token_anchors;
    emitted.token_end_anchors = token_end_anchors;
    emitted.copied_boundaries = copied_boundaries;
    let mut cursor = 0usize;
    for edit in edits {
        if edit.start < cursor || edit.end < edit.start || edit.end > source.len() {
            // A nested erase is fully covered by its outer erase.  Parser
            // ownership produces these intentionally for `declare function`.
            continue;
        }
        if cursor == 0
            && emitted.javascript.is_empty()
            && source[..edit.start].trim_start().starts_with("/*")
            && !edit.replacement.is_empty()
        {
            emitted.mark(0);
        }
        emitted.copy(&source[cursor..edit.start], cursor);
        let parts = snapshot
            .as_deref()
            .filter(|_| edit.replacement.contains('\u{0}'))
            .map(|all| relocations::expand(&edit.replacement, source, all));
        let replacement = parts.as_ref().map_or_else(
            || edit.replacement.clone(),
            |parts| parts.iter().map(relocations::Part::text).collect(),
        );
        let ends_explicit = parts.as_ref().is_some_and(|parts| {
            matches!(
                parts.last(),
                Some(relocations::Part::Unmapped | relocations::Part::Anchor(_))
            )
        });
        if replacement.is_empty() {
            // Preserve physical lines so line-level source maps, diagnostics,
            // and ordinary text diffs remain stable after type erasure.
            emitted.preserve_line_breaks(&source[edit.start..edit.end]);
        } else if segment_limit.is_some()
            && (decorators::is_helper_insertion(&edit)
                || legacy_decorators::is_helper_insertion(&edit)
                || (edit.start == edit.end && parts.is_none()))
        {
            emitted.insert_unmapped(&replacement);
        } else if let Some(parts) = parts {
            let mut anchored = false;
            for part in parts {
                match part {
                    relocations::Part::Generated(text) if anchored => {
                        emitted.append_generated(&text);
                        anchored = false;
                    }
                    relocations::Part::Generated(text) if edit.start == edit.end => {
                        emitted.insert_unmapped(&text);
                    }
                    relocations::Part::Generated(text) => emitted.replace(&text, edit.start),
                    relocations::Part::Anchor(offset) => {
                        if segment_limit.is_some() {
                            emitted.mark(offset);
                            anchored = true;
                        }
                    }
                    relocations::Part::Unmapped => {
                        if segment_limit.is_some() {
                            emitted.insert_unmapped("");
                            anchored = true;
                        }
                    }
                    relocations::Part::Relocated {
                        text,
                        start,
                        end,
                        erased,
                        rewritten,
                    } => {
                        emitted.relocate(&text, start, end, &erased, rewritten);
                        anchored = true;
                    }
                }
            }
        } else {
            emitted.replace(&replacement, edit.start);
        }
        if segment_limit.is_none()
            || (!replacement.is_empty()
                && edit.start != edit.end
                && !ends_explicit
                && !replacement.ends_with(['\r', '\n']))
        {
            emitted.mark(edit.end);
        }
        cursor = edit.end;
    }
    emitted.copy(&source[cursor..], cursor);
    emitted.finish()
}

fn type_to_ts(value: &Type) -> String {
    match value {
        Type::Conditional(_)
        | Type::StringMapping(_)
        | Type::InferenceBarrier(_)
        | Type::Infer(_)
        | Type::Mapped(_)
        | Type::TemplateLiteral(_)
        | Type::Readonly(_)
        | Type::IndexedRecord { .. } => value.operator_text(type_to_ts).expect("operator type"),
        Type::KeyOf(value) => format!("keyof {}", type_to_ts(value)),
        Type::IndexedAccess { object, index, .. } => {
            format!("{}[{}]", type_to_ts(object), type_to_ts(index))
        }
        Type::Predicate(predicate) => predicate.text(type_to_ts),
        Type::Any => "any".to_string(),
        Type::Unknown | Type::StrictUnknown => "unknown".to_string(),
        Type::BigInt => "bigint".to_string(),
        Type::Symbol => "symbol".to_string(),
        Type::UniqueSymbol(_) => "unique symbol".to_string(),
        Type::ConstAssertion => "const".to_string(),
        Type::Never => "never".to_string(),
        Type::Void => "void".to_string(),
        Type::Null => "null".to_string(),
        Type::Undefined => "undefined".to_string(),
        Type::Boolean => "boolean".to_string(),
        Type::Number => "number".to_string(),
        Type::String => "string".to_string(),
        Type::Literal(value) => value.clone(),
        Type::StringLiteral(value) => value.declaration_text(),
        Type::Intrinsic(_) => "intrinsic".to_string(),
        Type::Named { name, arguments } if arguments.is_empty() => {
            crate::parser::source_type_name(name).to_string()
        }
        Type::Named { name, arguments } => format!(
            "{}<{}>",
            crate::parser::source_type_name(name),
            arguments
                .iter()
                .map(type_to_ts)
                .collect::<Vec<_>>()
                .join(", ")
        ),
        Type::Array(value) => value.array_element_text(type_to_ts),
        Type::Tuple(values) => format!(
            "[{}]",
            values
                .iter()
                .map(|value| {
                    if let Some(label) = &value.label {
                        format!(
                            "{}{label}{}: {}",
                            if value.rest { "..." } else { "" },
                            if value.optional { "?" } else { "" },
                            type_to_ts(&value.annotation)
                        )
                    } else {
                        format!(
                            "{}{}{}",
                            if value.rest { "..." } else { "" },
                            type_to_ts(&value.annotation),
                            if value.optional { "?" } else { "" }
                        )
                    }
                })
                .collect::<Vec<_>>()
                .join(", ")
        ),
        Type::CallableRecord { fields, signatures } => callable_objects::render(fields, signatures),
        Type::Record(fields) => format!(
            "{{ {} }}",
            fields
                .iter()
                .map(|field| {
                    let name = format!(
                        "{}{}{}",
                        if field.readonly { "readonly " } else { "" },
                        field.name,
                        if field.optional { "?" } else { "" }
                    );
                    if let Type::Function { parameters, result } = &field.value {
                        format!("{name}{}", method_signature_to_ts(parameters, result))
                    } else {
                        format!("{name}: {}", type_to_ts(&field.value))
                    }
                })
                .collect::<Vec<_>>()
                .join("; ")
        ),
        Type::GenericFunction {
            type_parameters,
            parameters,
            result,
            ..
        } => {
            let mut generic = String::new();
            emit_type_parameters(&mut generic, type_parameters);
            format!(
                "{generic}{} => {}",
                method_parameters_to_ts(parameters),
                type_to_ts(result)
            )
        }
        Type::Function { parameters, result } => {
            format!(
                "{} => {}",
                method_parameters_to_ts(parameters),
                type_to_ts(result)
            )
        }
        Type::Union(values) => values
            .iter()
            .map(type_to_ts)
            .collect::<Vec<_>>()
            .join(" | "),
        Type::Intersection(values) => values
            .iter()
            .map(type_to_ts)
            .collect::<Vec<_>>()
            .join(" & "),
    }
}

fn method_parameters_to_ts(parameters: &[crate::parser::Parameter]) -> String {
    let members = parameters
        .iter()
        .map(|parameter| {
            format!(
                "{}{}{}: {}",
                if parameter.rest { "..." } else { "" },
                parameter.name,
                if parameter.optional { "?" } else { "" },
                parameter
                    .annotation
                    .as_ref()
                    .map(type_to_ts)
                    .unwrap_or_else(|| "unknown".to_string())
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    format!("({members})")
}

fn method_signature_to_ts(parameters: &[crate::parser::Parameter], result: &Type) -> String {
    format!(
        "{}: {}",
        method_parameters_to_ts(parameters),
        type_to_ts(result)
    )
}

struct ProvenanceEmitter<'a> {
    source: &'a str,
    javascript: String,
    provenance: Vec<ProvenanceSegment>,
    generated_line: usize,
    generated_column: usize,
    segment_limit: Option<usize>,
    overflowed: bool,
    tokens: Vec<crate::syntax::Token>,
    line_comment_starts: BTreeSet<usize>,
    line_comment_ends: BTreeSet<usize>,
    source_cursor: usize,
    source_line: usize,
    source_column: usize,
    token_anchors: BTreeMap<usize, Option<usize>>,
    token_end_anchors: BTreeMap<usize, usize>,
    copied_boundaries: Option<Vec<usize>>,
}

impl<'a> ProvenanceEmitter<'a> {
    fn new(source: &'a str, capacity: usize, segment_limit: Option<usize>) -> Self {
        let tokens = if segment_limit.is_some() {
            crate::syntax::lex("<source-map>", source).unwrap_or_default()
        } else {
            Vec::new()
        };
        let comments = output_options::comment_ranges_in_trivia(source, &tokens)
            .into_iter()
            .filter(|range| source[range.clone()].starts_with("//"))
            .collect::<Vec<_>>();
        Self {
            source,
            javascript: String::with_capacity(capacity),
            provenance: Vec::new(),
            generated_line: 0,
            generated_column: 0,
            segment_limit,
            overflowed: false,
            tokens,
            line_comment_starts: comments.iter().map(|range| range.start).collect(),
            line_comment_ends: comments.iter().map(|range| range.end).collect(),
            source_cursor: 0,
            source_line: 0,
            source_column: 0,
            token_anchors: BTreeMap::new(),
            token_end_anchors: BTreeMap::new(),
            copied_boundaries: None,
        }
    }

    fn copy(&mut self, value: &str, source_offset: usize) {
        if let Some(boundaries) = &self.copied_boundaries {
            let mut index = boundaries.partition_point(|offset| *offset < source_offset);
            self.mark(source_offset);
            let mut characters = value.char_indices().peekable();
            while let Some((offset, character)) = characters.next() {
                let position = source_offset + offset;
                if self.copied_boundaries.as_ref().unwrap().get(index) == Some(&position) {
                    self.mark(position);
                    index += 1;
                }
                self.push(
                    character,
                    characters.peek().map(|(_, character)| *character),
                );
            }
            if self.copied_boundaries.as_ref().unwrap().get(index)
                == Some(&(source_offset + value.len()))
            {
                self.mark(source_offset + value.len());
            }
            return;
        }
        let mut token_index = self
            .tokens
            .partition_point(|token| token.end <= source_offset);
        if !value.is_empty()
            && (self.segment_limit.is_none()
                || (source_offset == 0 && self.source.starts_with("//"))
                || (source_offset == 0
                    && self.javascript.is_empty()
                    && self.source.starts_with("/*")
                    && self
                        .tokens
                        .first()
                        .is_some_and(|token| value.len() >= token.end)))
        {
            self.mark(source_offset);
        }
        let mut characters = value.char_indices().peekable();
        while let Some((offset, character)) = characters.next() {
            let position = source_offset + offset;
            if let Some(&anchor) = self.token_anchors.get(&position) {
                if let Some(anchor) = anchor {
                    self.mark(anchor);
                } else {
                    self.insert_unmapped("");
                }
            } else if self.line_comment_starts.contains(&position)
                || self.line_comment_ends.contains(&position)
                || (self
                    .tokens
                    .get(token_index)
                    .is_some_and(|token| token.start == position)
                    && token_maps::mark_start(self.source, &self.tokens, token_index))
            {
                self.mark(position);
            }
            let next = characters.peek().map(|(_, character)| *character);
            self.push(character, next);
            if let Some(token) = self.tokens.get(token_index) {
                if token.end == position + character.len_utf8() {
                    if let Some(&anchor) = self.token_end_anchors.get(&token.end) {
                        self.mark(anchor);
                    } else if self.token_anchors.get(&token.start) != Some(&None)
                        && !(token.is("{") && self.token_anchors.contains_key(&token.start))
                        && token_maps::mark_end(&self.tokens, token_index)
                    {
                        self.mark(token.end);
                    }
                    token_index += 1;
                }
            }
        }
        let end = source_offset + value.len();
        if !value.is_empty() && self.line_comment_ends.contains(&end) {
            self.mark(end);
        }
    }

    fn preserve_line_breaks(&mut self, value: &str) {
        let mut characters = value.chars().peekable();
        while let Some(character) = characters.next() {
            let next = characters.peek().copied();
            if matches!(character, '\r' | '\n') {
                self.push(character, next);
            }
        }
    }

    fn replace(&mut self, value: &str, source_offset: usize) {
        self.mark(source_offset);
        let mut characters = value.chars().peekable();
        while let Some(character) = characters.next() {
            let next = characters.peek().copied();
            self.push(character, next);
            if is_line_break(character, next) {
                self.mark(source_offset);
            }
        }
    }

    fn insert_unmapped(&mut self, value: &str) {
        self.push_segment(ProvenanceSegment {
            generated_line: self.generated_line,
            generated_column: self.generated_column,
            source_line: 0,
            source_column: 0,
            mapped: false,
            name_index: None,
        });
        self.append_generated(value);
    }

    fn append_generated(&mut self, value: &str) {
        let mut characters = value.chars().peekable();
        while let Some(character) = characters.next() {
            self.push(character, characters.peek().copied());
        }
    }

    fn mark(&mut self, source_offset: usize) {
        let (source_line, source_column) = self.source_location(source_offset);
        self.push_segment(ProvenanceSegment {
            generated_line: self.generated_line,
            generated_column: self.generated_column,
            source_line,
            source_column,
            mapped: true,
            name_index: None,
        });
    }

    fn push_segment(&mut self, segment: ProvenanceSegment) {
        if self.provenance.last().is_some_and(|previous| {
            previous.generated_line == segment.generated_line
                && previous.generated_column == segment.generated_column
        }) {
            self.provenance.pop();
        }
        if self.overflowed
            || self
                .segment_limit
                .is_some_and(|limit| self.provenance.len() >= limit)
        {
            self.overflowed = true;
            return;
        }
        self.provenance.push(segment);
    }

    fn source_location(&mut self, offset: usize) -> (usize, usize) {
        if offset < self.source_cursor {
            self.source_cursor = 0;
            self.source_line = 0;
            self.source_column = 0;
        }
        let skip_leading_lf = self.source_cursor > 0
            && self.source[..self.source_cursor].ends_with('\r')
            && self.source[self.source_cursor..offset].starts_with('\n');
        let mut characters = self.source[self.source_cursor..offset].chars().peekable();
        let mut first = true;
        while let Some(character) = characters.next() {
            let next = characters.peek().copied();
            if !(first && skip_leading_lf && character == '\n') {
                if is_line_break(character, next) {
                    self.source_line += 1;
                    self.source_column = 0;
                } else {
                    self.source_column += character.len_utf16();
                }
            }
            first = false;
        }
        self.source_cursor = offset;
        (self.source_line, self.source_column)
    }

    fn push(&mut self, character: char, next: Option<char>) {
        self.javascript.push(character);
        if is_line_break(character, next) {
            self.generated_line += 1;
            self.generated_column = 0;
        } else {
            self.generated_column += character.len_utf16();
        }
    }

    fn finish(self) -> EmittedJavaScript {
        EmittedJavaScript {
            javascript: self.javascript,
            provenance: self.provenance,
            segment_limit: self.segment_limit,
            overflowed: self.overflowed,
        }
    }
}

fn is_line_break(character: char, next: Option<char>) -> bool {
    character == '\n' || (character == '\r' && next != Some('\n'))
}

fn source_line_column(source: &str, offset: usize) -> (usize, usize) {
    let prefix = &source[..offset];
    let mut line = 0usize;
    let mut column = 0usize;
    let mut characters = prefix.chars().peekable();
    while let Some(character) = characters.next() {
        if is_line_break(character, characters.peek().copied()) {
            line += 1;
            column = 0;
        } else {
            column += character.len_utf16();
        }
    }
    (line, column)
}

fn source_map(
    module_id: &str,
    source: &str,
    emitted: &EmittedJavaScript,
    options: &CompilerOptions,
) -> SourceMap {
    SourceMap {
        file: output_file_name(module_id),
        sources: vec![module_id.to_string()],
        sources_content: vec![source.to_string()],
        inline_sources: options.inline_sources,
        source_root: options
            .source_root
            .as_deref()
            .filter(|root| !root.is_empty())
            .map_or_else(String::new, |root| {
                if root.ends_with('/') {
                    root.to_string()
                } else {
                    format!("{root}/")
                }
            }),
        names: Vec::new(),
        mappings: encode_mappings(&emitted.provenance),
    }
}

fn encode_mappings(segments: &[ProvenanceSegment]) -> String {
    let last_line = segments
        .last()
        .map(|segment| segment.generated_line)
        .unwrap_or(0);
    let mut mappings = String::new();
    let mut index = 0usize;
    let mut previous_source_line = 0i64;
    let mut previous_source_column = 0i64;
    let mut previous_name_index = 0i64;
    for line in 0..=last_line {
        if line > 0 {
            mappings.push(';');
        }
        let mut previous_generated_column = 0i64;
        let mut first = true;
        while let Some(segment) = segments
            .get(index)
            .filter(|segment| segment.generated_line == line)
        {
            if !first {
                mappings.push(',');
            }
            first = false;
            mappings.push_str(&base64_vlq(
                segment.generated_column as i64 - previous_generated_column,
            ));
            if segment.mapped {
                mappings.push('A');
                mappings.push_str(&base64_vlq(
                    segment.source_line as i64 - previous_source_line,
                ));
                mappings.push_str(&base64_vlq(
                    segment.source_column as i64 - previous_source_column,
                ));
                if let Some(name_index) = segment.name_index {
                    mappings.push_str(&base64_vlq(name_index as i64 - previous_name_index));
                    previous_name_index = name_index as i64;
                }
                previous_source_line = segment.source_line as i64;
                previous_source_column = segment.source_column as i64;
            }
            previous_generated_column = segment.generated_column as i64;
            index += 1;
        }
    }
    mappings
}

fn output_file_name(module_id: &str) -> String {
    for (source, output) in [(".mts", ".mjs"), (".cts", ".cjs")] {
        if let Some(stem) = module_id
            .rsplit('/')
            .next()
            .unwrap_or(module_id)
            .strip_suffix(source)
        {
            return format!("{stem}{output}");
        }
    }
    module_id
        .rsplit('/')
        .next()
        .unwrap_or(module_id)
        .strip_suffix(".tsx")
        .or_else(|| {
            module_id
                .rsplit('/')
                .next()
                .unwrap_or(module_id)
                .strip_suffix(".ts")
        })
        .map(|stem| format!("{stem}.js"))
        .unwrap_or_else(|| format!("{module_id}.js"))
}

fn base64_vlq(value: i64) -> String {
    const BASE64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut encoded = String::new();
    let mut value = if value < 0 {
        ((-value) as u64) << 1 | 1
    } else {
        (value as u64) << 1
    };
    loop {
        let mut digit = (value & 0b1_1111) as usize;
        value >>= 5;
        if value != 0 {
            digit |= 0b10_0000;
        }
        encoded.push(BASE64[digit] as char);
        if value == 0 {
            break;
        }
    }
    encoded
}

fn json_escape(value: &str) -> String {
    let mut escaped = String::new();
    for character in value.chars() {
        match character {
            '\\' => escaped.push_str("\\\\"),
            '\"' => escaped.push_str("\\\""),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            character if character.is_control() => {
                escaped.push_str(&format!("\\u{:04x}", character as u32))
            }
            character => escaped.push(character),
        }
    }
    escaped
}

#[cfg(test)]
#[path = "emitter/tests.rs"]
mod tests;
