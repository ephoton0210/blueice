// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Key sets and projections preserve numeric keys, unions and optional fields.
use super::*;

pub(super) fn literal_key(name: &str) -> Type {
    Type::Literal(if name.parse::<f64>().is_ok() {
        name.to_string()
    } else {
        format!("{name:?}")
    })
}

pub(super) fn key_name(value: &Type) -> Option<String> {
    if let Some(value) = value.string_value() {
        return String::from_utf16(value.units()).ok();
    }
    let Type::Literal(text) = value else {
        return None;
    };
    Some(text.trim_matches(['\'', '"']).to_string())
}

pub(super) fn keyof(
    value: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    visited: &mut HashSet<String>,
    budget: &mut TypeExpansionBudget,
) -> Option<Type> {
    let value = expanded(value, aliases, visited, budget);
    let owner = match &value {
        Type::String | Type::StringLiteral(_) | Type::StringMapping(_) => Some("String"),
        Type::Number => Some("Number"),
        Type::Boolean => Some("Boolean"),
        Type::BigInt => Some("BigInt"),
        Type::Symbol | Type::UniqueSymbol(_) => Some("Symbol"),
        Type::Literal(text) if text.starts_with(['\'', '"']) => Some("String"),
        Type::Array(_) | Type::Tuple(_) => Some("Array"),
        Type::Readonly(inner) if matches!(inner.as_ref(), Type::Array(_) | Type::Tuple(_)) => {
            Some("ReadonlyArray")
        }
        _ => None,
    };
    if let Some(definition) =
        owner.and_then(|owner| aliases.get(&crate::type_operator_profiles::alias_name(owner)))
    {
        let mut result = definition.value.clone();
        let tuple = match &value {
            Type::Tuple(items) => Some(items),
            Type::Readonly(inner) => {
                if let Type::Tuple(items) = inner.as_ref() {
                    Some(items)
                } else {
                    None
                }
            }
            _ => None,
        };
        if let Some(items) = tuple {
            result = union(
                std::iter::once(result)
                    .chain((0..items.len()).map(|i| Type::Literal(format!("\"{i}\"")))),
            );
        }
        return Some(result);
    }
    match value {
        Type::Readonly(value) => keyof(&value, aliases, visited, budget),
        Type::IndexedRecord { object, indices } => {
            let mut keys = vec![keyof(&object, aliases, visited, budget)?];
            for index in indices {
                keys.push(
                    index
                        .mapped_domain
                        .clone()
                        .unwrap_or_else(|| index.key.clone()),
                );
                if index.mapped_domain.is_none() && index.key == Type::String {
                    keys.push(Type::Number);
                }
            }
            Some(union(keys))
        }
        Type::Any => Some(Type::Union(vec![
            Type::String,
            Type::Number,
            Type::Named {
                name: "symbol".into(),
                arguments: vec![],
            },
        ])),
        Type::Unknown | Type::StrictUnknown => Some(Type::Never),
        Type::Never => Some(Type::Union(vec![Type::String, Type::Number, Type::Symbol])),
        Type::Record(fields) | Type::CallableRecord { fields, .. } => {
            Some(union(fields.iter().map(|field| {
                crate::checker::computed_keys::key(&field.name, aliases)
                    .cloned()
                    .unwrap_or_else(|| literal_key(&field.name))
            })))
        }
        Type::Union(parts) => {
            let mut sets = Vec::new();
            for part in parts {
                if !budget.consume() {
                    return None;
                }
                let keys = keyof(&part, aliases, &mut visited.clone(), budget)?;
                sets.push(match keys {
                    Type::Union(keys) => keys,
                    Type::Never => vec![],
                    value => vec![value],
                });
            }
            let first = sets.first()?;
            Some(union(
                first
                    .iter()
                    .filter(|key| sets.iter().all(|set| set.contains(key)))
                    .cloned(),
            ))
        }
        Type::Intersection(parts) => {
            let mut keys = Vec::new();
            for part in parts {
                if !budget.consume() {
                    return None;
                }
                keys.push(keyof(&part, aliases, &mut visited.clone(), budget)?);
            }
            Some(union(keys))
        }
        Type::Array(_) | Type::Tuple(_) => {
            let mut keys = vec![Type::Number];
            keys.extend(
                [
                    "length",
                    "toString",
                    "toLocaleString",
                    "pop",
                    "push",
                    "concat",
                    "join",
                    "reverse",
                    "shift",
                    "slice",
                    "sort",
                    "splice",
                    "unshift",
                    "indexOf",
                    "lastIndexOf",
                    "every",
                    "some",
                    "forEach",
                    "map",
                    "filter",
                    "reduce",
                    "reduceRight",
                    "find",
                    "findIndex",
                    "fill",
                    "copyWithin",
                    "entries",
                    "keys",
                    "values",
                    "includes",
                    "flat",
                    "flatMap",
                ]
                .into_iter()
                .map(literal_key),
            );
            if let Type::Tuple(items) = &value {
                keys.extend((0..items.len()).map(|index| Type::Literal(format!("\"{index}\""))));
            }
            Some(union(keys))
        }
        _ => None,
    }
}

pub(super) fn indexed(
    object: &Type,
    index: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    visited: &mut HashSet<String>,
    budget: &mut TypeExpansionBudget,
) -> Option<Type> {
    let object = expanded(object, aliases, &mut visited.clone(), budget);
    let index = expanded(index, aliases, &mut visited.clone(), budget);
    if !matches!(
        object,
        Type::Record(_)
            | Type::CallableRecord { .. }
            | Type::IndexedRecord { .. }
            | Type::Array(_)
            | Type::Tuple(_)
            | Type::Readonly(_)
            | Type::Union(_)
            | Type::Intersection(_)
    ) {
        if let Some(key) = key_name(&index) {
            if let PropertyType::Found { value, .. } =
                property_type(&object, &key, aliases, &mut visited.clone(), budget)
            {
                return Some(value);
            }
        }
    }
    if let Type::Union(indices) = &index {
        let mut values = Vec::new();
        for index in indices {
            if !budget.consume() {
                return None;
            }
            values.push(indexed(
                &object,
                index,
                aliases,
                &mut visited.clone(),
                budget,
            )?);
        }
        return Some(union(values));
    }
    if let Type::Union(objects) = &object {
        let mut values = Vec::new();
        for object in objects {
            if !budget.consume() {
                return None;
            }
            values.push(indexed(
                object,
                &index,
                aliases,
                &mut visited.clone(),
                budget,
            )?);
        }
        return Some(union(values));
    }
    match &object {
        Type::Readonly(value) => indexed(value, &index, aliases, visited, budget),
        Type::IndexedRecord { object, indices } => {
            if let Some(value) = indexed(object, &index, aliases, &mut visited.clone(), budget) {
                return Some(value);
            }
            let direct = indices
                .iter()
                .find(|entry| {
                    is_assignable(&index, &entry.key, aliases, &mut visited.clone(), budget)
                })
                .map(|entry| entry.value.clone());
            if direct.is_some() {
                return direct;
            }
            // A symbolic key can span several index signatures. Their union
            // must cover the complete key domain before their values provide
            // an upper bound; an unresolved key never gains an any fallback.
            let domain = union(indices.iter().map(|entry| entry.key.clone()));
            if !indices.is_empty()
                && budget.consume()
                && is_assignable(&index, &domain, aliases, &mut visited.clone(), budget)
            {
                Some(union(indices.iter().map(|entry| entry.value.clone())))
            } else {
                None
            }
        }
        Type::Array(item)
            if index == Type::Number
                || key_name(&index).is_some_and(|key| key.parse::<usize>().is_ok()) =>
        {
            Some((**item).clone())
        }
        Type::Tuple(items) if index == Type::Number => {
            Some(union(items.iter().map(TupleTypeElement::indexed_type)))
        }
        Type::Tuple(items) => items
            .get(key_name(&index)?.parse::<usize>().ok()?)
            .map(TupleTypeElement::indexed_type),
        Type::Record(fields) | Type::CallableRecord { fields, .. } => {
            let field = fields.iter().find(|field| {
                crate::checker::computed_keys::key(&field.name, aliases) == Some(&index)
                    || key_name(&index).is_some_and(|key| field.name == key)
            })?;
            Some(if field.optional {
                union([field.value.clone(), Type::Undefined])
            } else {
                field.value.clone()
            })
        }
        Type::Intersection(parts) => {
            let values = parts
                .iter()
                .filter_map(|part| indexed(part, &index, aliases, &mut visited.clone(), budget))
                .collect::<Vec<_>>();
            if values.is_empty() {
                None
            } else {
                Some(Type::Intersection(values))
            }
        }
        Type::Any => Some(Type::Any),
        _ => None,
    }
}
