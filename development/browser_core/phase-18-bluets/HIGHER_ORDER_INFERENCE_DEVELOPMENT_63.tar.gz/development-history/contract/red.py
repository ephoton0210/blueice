# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
phase = repo / 'development/browser_core/phase-18-bluets'
output = root / 'red-1'
assert not output.exists(), 'Preserve every failed or successful test-first attempt'
baseline = json.loads((root / 'baseline-1/measurement.json').read_bytes())
assert baseline['conclusion'] == 'measured-baseline' and baseline['comparisons'] == 384
output.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', FORCE_COLOR='0',
    BLUEICE_HIGHER_ORDER_INFERENCE_OBSERVATIONS=str(output / 'capture'))
state = {'conclusion': 'in_progress', 'stage': 'build',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'frozenSha256': sha(fixture / 'FROZEN.json'), 'source': {}}
destination = output / 'measurement.json'
save = lambda: destination.write_text(json.dumps(state, indent=2) + '\n')
try:
    assert state['parentCommit'] == baseline['parentCommit']
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'backend/bluets/src', 'backend/bluetsc/src'], cwd=repo)
    tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend/bluets/src', 'backend/bluetsc/src'], cwd=repo).decode().split('\0')
    for name in tracked:
        if name:
            state['source'][name] = sha(repo / name)
    additions = [repo / 'backend/bluets/tests/higher_order_inference.rs', *sorted(fixture.glob('*')),
        *sorted((phase / 'tools/higher_order_inference').glob('*.cjs')),
        phase / 'tools/record_higher_order_inference.cjs', phase / 'tools/verify_higher_order_inference.cjs',
        phase / 'tools/higher_order_runtime.test.cjs']
    for path in additions:
        if not path.is_file():
            continue
        name = path.relative_to(repo)
        state['source'][str(name)] = sha(path)
        snapshot = output / 'source' / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, snapshot)
    save()
    build = ['cargo', 'test', '-p', 'blueice-bluets', '--test', 'higher_order_inference',
             '--no-run', '--message-format=json', '--locked', '--offline']
    with (output / 'build.jsonl').open('xb') as stdout, (output / 'build.stderr').open('xb') as stderr:
        result = subprocess.run(build, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    state['build'] = {'command': build, 'exit': result.returncode,
        'stdoutSha256': sha(output / 'build.jsonl'), 'stderrSha256': sha(output / 'build.stderr')}
    save()
    assert result.returncode == 0
    artifacts = [json.loads(line) for line in (output / 'build.jsonl').read_text().splitlines()]
    artifact = next(row for row in artifacts if row.get('reason') == 'compiler-artifact'
        and row['target']['name'] == 'higher_order_inference' and row.get('executable'))
    executable = Path(artifact['executable'])
    compiler = repo / 'target/debug/bluetsc'
    for name, path in [('actual-cli', compiler), ('actual-test-executable', executable)]:
        shutil.copy2(path, output / name)
        state[name + 'Sha256'] = sha(path)
        assert sha(output / name) == state[name + 'Sha256']
    state['stage'] = 'test-first-red'
    save()
    args = [str(executable), '--nocapture', '--test-threads=1']
    with (output / 'red.log').open('xb') as log:
        result = subprocess.run(args, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    text = (output / 'red.log').read_text(errors='replace')
    summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', text)
    assert len(summaries) == 1, summaries
    status, passed, failed, ignored, filtered = summaries[0]
    assert status == 'FAILED' and result.returncode != 0 and int(failed) > 0 and int(filtered) == 0
    assert 'complete differences:' in text
    expected = {row['id']: row for row in baseline['cases']}
    observed = {}
    for path in (output / 'capture').glob('*/*/observation.json'):
        row = json.loads(path.read_bytes())
        assert row['id'] not in observed
        before = expected[row['id']]
        for key in ['accepts', 'diagnostics', 'declarations', 'agrees', 'publishedOnRejectedNativeInput']:
            assert row[key] == before[key], (row['id'], key)
        observed[row['id']] = row
    assert set(observed) == set(expected) and len(observed) == 384
    assert all(sha(repo / name) == digest for name, digest in state['source'].items())
    assert sha(compiler) == state['actual-cliSha256']
    state.update(conclusion='expected-red', stage='public-boundary-baseline-reproduced',
        rust={'passed':int(passed),'failed':int(failed),'ignored':int(ignored),'filtered':int(filtered),'exit':result.returncode},
        all384BaselineObservationsReproduced=True, comparisons=384,
        completeAgreements=baseline['completeAgreements'], completeDifferences=baseline['completeDifferences'],
        rawLogSha256=sha(output / 'red.log'), productionSourcesUnchanged=True)
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in state.items() if key != 'source'}))
