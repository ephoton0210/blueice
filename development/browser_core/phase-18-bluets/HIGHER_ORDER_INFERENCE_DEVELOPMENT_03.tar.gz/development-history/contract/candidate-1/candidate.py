# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent.parent
phase = repo / 'development/browser_core/phase-18-bluets'
fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
output = root / sys.argv[1]
assert not output.exists(), 'Preserve every candidate and raw outcome'
output.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', FORCE_COLOR='0',
    BLUEICE_HIGHER_ORDER_INFERENCE_OBSERVATIONS=str(output / 'capture'))
state = {'conclusion': 'in_progress', 'stage': 'build',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'frozenSha256': sha(fixture / 'FROZEN.json'), 'source': {}}
save = lambda: (output / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
try:
    sources = [path for path in (repo / 'backend/bluets/src').rglob('*') if path.is_file()]
    sources += [repo / 'backend/bluets/tests/higher_order_inference.rs', *sorted(fixture.glob('*')),
        *sorted((phase / 'tools/higher_order_inference').glob('*.cjs')),
        phase / 'tools/record_higher_order_inference.cjs', phase / 'tools/verify_higher_order_inference.cjs',
        phase / 'tools/higher_order_runtime.test.cjs']
    for path in sources:
        if not path.is_file():
            continue
        name = path.relative_to(repo)
        state['source'][str(name)] = sha(path)
        snapshot = output / 'source' / name
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, snapshot)
    shutil.copy2(__file__, output / 'candidate.py')
    save()
    build = ['cargo', 'test', '-p', 'blueice-bluets', '--test', 'higher_order_inference',
             '--no-run', '--message-format=json', '--locked', '--offline']
    with (output / 'build.jsonl').open('xb') as stdout, (output / 'build.stderr').open('xb') as stderr:
        result = subprocess.run(build, cwd=repo, env=env, stdout=stdout, stderr=stderr)
    state['build'] = {'command': build, 'exit': result.returncode,
        'stdoutSha256': sha(output / 'build.jsonl'), 'stderrSha256': sha(output / 'build.stderr')}
    save()
    assert result.returncode == 0
    artifacts = [json.loads(line) for line in (output / 'build.jsonl').read_text().splitlines()]
    artifact = next(row for row in artifacts if row.get('reason') == 'compiler-artifact'
        and row['target']['name'] == 'higher_order_inference' and row.get('executable'))
    executable = Path(artifact['executable'])
    compiler = repo / 'target/debug/bluetsc'
    for name, path in [('actual-cli', compiler), ('actual-test-executable', executable)]:
        shutil.copy2(path, output / name)
        state[name + 'Sha256'] = sha(path)
        assert sha(output / name) == state[name + 'Sha256']
    state['stage'] = 'focused-public-tests'
    save()
    args = [str(executable), '--nocapture', '--test-threads=1']
    with (output / 'tests.log').open('xb') as log:
        result = subprocess.run(args, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    log = (output / 'tests.log').read_text(errors='replace')
    summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', log)
    assert len(summaries) == 1, summaries
    status, passed, failed, ignored, filtered = summaries[0]
    assert int(filtered) == 0
    baseline = json.loads((root / 'baseline-1/measurement.json').read_bytes())
    before = {row['id']: row for row in baseline['cases']}
    observations = [json.loads(path.read_bytes()) for path in sorted((output / 'capture').glob('*/*/observation.json'))]
    assert len(observations) == 384 and {row['id'] for row in observations} == set(before)
    differences = sum(not row['agrees'] for row in observations)
    state.update(rust={'passed':int(passed),'failed':int(failed),'ignored':int(ignored),'filtered':int(filtered),'exit':result.returncode},
        comparisons=384,completeAgreements=384-differences,completeDifferences=differences,
        repairedSinceBaseline=sum(before[row['id']]['agrees'] is False and row['agrees'] is True for row in observations),
        newDifferencesSinceBaseline=sum(before[row['id']]['agrees'] is True and row['agrees'] is False for row in observations),
        rejectedInputsPublishedArtifacts=sum(row['publishedOnRejectedNativeInput'] for row in observations),
        logSha256=sha(output / 'tests.log'),stage='focused-observations-complete',
        conclusion='focused-green' if result.returncode == 0 and status == 'ok' and differences == 0 else 'measured-differences')
    assert all(sha(repo / name) == digest for name, digest in state['source'].items())
    assert sha(compiler) == state['actual-cliSha256']
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps({key: value for key, value in state.items() if key != 'source'}))
