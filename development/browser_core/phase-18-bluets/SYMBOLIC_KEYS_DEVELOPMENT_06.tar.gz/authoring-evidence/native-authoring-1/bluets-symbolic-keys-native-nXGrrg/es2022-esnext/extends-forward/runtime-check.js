export function result(key, consume) { consume(key); }

var check = result;
var observed = ""; check("x", function(key) { observed = key; }); if (observed !== "x") throw Error("key callback");
