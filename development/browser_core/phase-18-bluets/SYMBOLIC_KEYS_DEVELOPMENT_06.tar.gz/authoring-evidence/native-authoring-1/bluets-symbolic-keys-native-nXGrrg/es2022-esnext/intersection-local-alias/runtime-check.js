export function result(key, consume) {  const local = key; consume(local); }

var check = result;
var observed = ""; check("x", function(key) { observed = key; }); if (observed !== "x") throw Error("key callback");
