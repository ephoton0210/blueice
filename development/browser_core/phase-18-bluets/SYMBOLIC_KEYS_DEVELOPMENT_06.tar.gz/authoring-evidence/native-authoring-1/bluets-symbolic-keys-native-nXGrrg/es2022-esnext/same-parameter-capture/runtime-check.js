export function result(consume) { return function (key) { consume(key); }; }

var check = result;
var observed = ""; check(function(key) { observed = key; })("x"); if (observed !== "x") throw Error("captured key callback");
