import {result} from "./main";
result<{x: number; y: string}, {x: number}, "x">("x", key => { const accepted: "x" | "y" = key; });
