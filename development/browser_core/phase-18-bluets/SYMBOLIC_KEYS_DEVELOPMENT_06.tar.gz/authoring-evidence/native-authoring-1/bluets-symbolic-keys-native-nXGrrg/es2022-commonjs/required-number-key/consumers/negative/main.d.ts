export declare function result<E extends {
    0: number;
}>(key: 0, consume: (key: keyof E) => void): void;
