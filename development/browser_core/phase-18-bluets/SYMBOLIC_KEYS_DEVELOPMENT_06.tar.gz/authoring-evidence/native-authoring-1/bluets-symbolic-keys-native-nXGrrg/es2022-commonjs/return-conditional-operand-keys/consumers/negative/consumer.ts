import {result} from "./main";
result<true, {x: number}, {y: string}>("y");
