import {result} from "./main";
result("absent");
