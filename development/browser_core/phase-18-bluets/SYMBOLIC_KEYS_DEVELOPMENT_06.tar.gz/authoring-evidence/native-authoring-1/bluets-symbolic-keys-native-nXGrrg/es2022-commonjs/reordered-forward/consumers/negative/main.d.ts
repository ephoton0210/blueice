export declare function result<F, E extends F, K extends keyof F>(key: K, consume: (key: keyof E) => void): void;
