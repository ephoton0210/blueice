export declare function result<E>(key: keyof E[]): keyof E[];
