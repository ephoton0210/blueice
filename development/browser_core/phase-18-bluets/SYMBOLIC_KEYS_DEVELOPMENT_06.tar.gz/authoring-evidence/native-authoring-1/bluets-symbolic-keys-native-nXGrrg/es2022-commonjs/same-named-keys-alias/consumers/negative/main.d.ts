type Keys<T> = keyof T;
export declare function result<E, K extends Keys<E>>(key: K, consume: (key: keyof E) => void): void;
export {};
