type Keys<T> = keyof T;
export declare function result<E, F>(key: Keys<E> & Keys<F>, consume: (key: Keys<E>) => void): void;
export {};
