export declare function result<E, F>(key: keyof E & keyof F, consume: (key: keyof E) => void): void;
