import {result} from "./main";
const accepted: "x" = result<{x: number; a: string}, {x: boolean; b: string}>("x");
