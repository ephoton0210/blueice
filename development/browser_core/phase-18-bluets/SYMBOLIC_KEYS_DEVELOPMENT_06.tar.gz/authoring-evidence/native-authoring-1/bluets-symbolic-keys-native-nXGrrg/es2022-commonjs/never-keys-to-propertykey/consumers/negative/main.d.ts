export declare function result<E>(key: keyof never, consume: (key: PropertyKey) => void): void;
