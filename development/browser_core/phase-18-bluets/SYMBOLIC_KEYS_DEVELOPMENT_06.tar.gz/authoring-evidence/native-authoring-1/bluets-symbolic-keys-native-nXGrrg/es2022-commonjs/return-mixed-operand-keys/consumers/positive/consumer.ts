import {result} from "./main";
const accepted: "x" | "g" = result<{x: number; a: string}, {x: boolean; b: string}, {g: boolean}>("g");
