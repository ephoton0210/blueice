type Keys<T> = keyof T;
export declare function result<E, F>(key: Keys<E | F>): keyof E & keyof F;
export {};
