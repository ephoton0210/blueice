import {result} from "./main";
declare const key: never; const accepted: never = result<{}>(key);
