import {result} from "./main";
result<{x: number; a: string}, {x: boolean; b: string}, "x">("x", () => {});
