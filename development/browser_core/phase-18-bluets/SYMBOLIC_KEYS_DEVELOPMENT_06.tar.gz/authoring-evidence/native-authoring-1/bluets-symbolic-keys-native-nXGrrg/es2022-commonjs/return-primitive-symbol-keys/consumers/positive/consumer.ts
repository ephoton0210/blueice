import {result} from "./main";
const accepted: keyof symbol = result("toString");
