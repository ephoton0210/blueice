export declare function result<E>(key: keyof (E & unknown)): keyof E;
