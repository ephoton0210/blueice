export declare function result<E, K extends keyof E, L extends K>(key: L, consume: (key: keyof E) => void): void;
