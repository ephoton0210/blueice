declare const token: unique symbol;
export declare function result<E extends {
    [token]: number;
}>(key: typeof token, consume: (key: keyof E) => void): void;
export {};
