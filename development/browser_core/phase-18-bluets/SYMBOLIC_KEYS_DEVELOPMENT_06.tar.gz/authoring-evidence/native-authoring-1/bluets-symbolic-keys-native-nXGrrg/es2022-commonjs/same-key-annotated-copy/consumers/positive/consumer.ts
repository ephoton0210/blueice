import {result} from "./main";
result<{x: number}, "x">("x", key => { const accepted: "x" = key; });
