export declare function result<E>(key: keyof (new () => E)): never;
