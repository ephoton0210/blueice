export declare function result<E>(consume: (key: keyof E) => void): <K extends keyof E>(key: K) => void;
