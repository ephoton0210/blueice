export declare function result<E, F>(key: keyof (E | F), consume: (key: keyof E) => void): void;
