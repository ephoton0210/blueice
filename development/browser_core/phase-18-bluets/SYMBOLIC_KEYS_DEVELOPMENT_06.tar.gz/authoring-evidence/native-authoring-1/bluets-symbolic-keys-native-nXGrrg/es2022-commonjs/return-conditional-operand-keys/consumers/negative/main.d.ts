export declare function result<T extends boolean, E, F>(key: keyof (T extends true ? E : F)): keyof (T extends true ? E : F);
