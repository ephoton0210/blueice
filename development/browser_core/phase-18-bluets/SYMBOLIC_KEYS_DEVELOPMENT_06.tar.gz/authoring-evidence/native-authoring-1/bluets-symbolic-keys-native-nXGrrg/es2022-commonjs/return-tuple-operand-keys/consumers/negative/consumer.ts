import {result} from "./main";
result<number, string>("2");
