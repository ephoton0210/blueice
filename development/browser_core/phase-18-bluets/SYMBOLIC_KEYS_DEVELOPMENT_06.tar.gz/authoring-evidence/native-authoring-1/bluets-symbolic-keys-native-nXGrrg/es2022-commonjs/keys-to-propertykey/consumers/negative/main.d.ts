export declare function result<E>(key: keyof E, consume: (key: PropertyKey) => void): void;
