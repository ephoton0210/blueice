import {result} from "./main";
result<{0: number}>(0, () => {});
