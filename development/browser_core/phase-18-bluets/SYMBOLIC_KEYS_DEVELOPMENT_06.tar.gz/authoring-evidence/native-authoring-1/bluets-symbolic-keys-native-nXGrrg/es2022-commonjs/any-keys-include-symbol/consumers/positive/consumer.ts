import {result} from "./main";
declare const key: symbol; result(key, () => {});
