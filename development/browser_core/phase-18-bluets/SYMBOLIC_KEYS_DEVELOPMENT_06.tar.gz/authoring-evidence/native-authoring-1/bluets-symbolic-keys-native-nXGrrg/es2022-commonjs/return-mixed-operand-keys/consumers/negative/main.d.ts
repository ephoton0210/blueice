export declare function result<E, F, G>(key: keyof ((E | F) & G)): (keyof E | keyof G) & (keyof G | keyof F);
