export declare function result<E>(key: keyof any, consume: (key: PropertyKey) => void): void;
