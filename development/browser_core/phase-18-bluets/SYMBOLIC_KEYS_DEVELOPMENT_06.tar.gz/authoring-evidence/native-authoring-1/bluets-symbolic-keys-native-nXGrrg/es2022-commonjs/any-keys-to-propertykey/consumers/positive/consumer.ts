import {result} from "./main";
declare const key: symbol; result<{}>(key, value => { const accepted: PropertyKey = value; });
