export declare function result<E, K extends keyof E>(key: K, consume: (key: keyof E) => void): void;
