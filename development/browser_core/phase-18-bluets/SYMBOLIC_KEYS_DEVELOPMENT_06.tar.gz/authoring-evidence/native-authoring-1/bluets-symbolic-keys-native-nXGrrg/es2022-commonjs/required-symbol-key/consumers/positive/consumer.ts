import {result} from "./main";
declare const key: Parameters<typeof result>[0]; result(key, value => { const accepted: typeof key = value; });
