import {result} from "./main";
result<{x: number}>(true, (key: boolean) => {});
