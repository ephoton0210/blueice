import {result} from "./main";
const accepted: "x" | "y" = result<{x: number}, {y: string}>("y");
