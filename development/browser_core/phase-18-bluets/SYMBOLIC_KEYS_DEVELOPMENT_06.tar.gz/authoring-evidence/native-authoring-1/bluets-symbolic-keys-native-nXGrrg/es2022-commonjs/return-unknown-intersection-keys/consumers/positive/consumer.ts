import {result} from "./main";
const accepted: "x" = result<{x: number}>("x");
