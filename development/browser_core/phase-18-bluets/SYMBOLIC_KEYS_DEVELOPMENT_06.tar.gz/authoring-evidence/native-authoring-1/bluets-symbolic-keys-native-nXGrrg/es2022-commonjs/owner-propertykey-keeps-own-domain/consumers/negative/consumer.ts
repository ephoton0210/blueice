import {result} from "./main";
result("x");
