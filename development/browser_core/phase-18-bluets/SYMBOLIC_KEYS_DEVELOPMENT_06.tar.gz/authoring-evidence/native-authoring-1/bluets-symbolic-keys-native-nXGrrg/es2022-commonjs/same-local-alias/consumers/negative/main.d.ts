export declare function result<E>(key: keyof E, consume: (key: keyof E) => void): void;
