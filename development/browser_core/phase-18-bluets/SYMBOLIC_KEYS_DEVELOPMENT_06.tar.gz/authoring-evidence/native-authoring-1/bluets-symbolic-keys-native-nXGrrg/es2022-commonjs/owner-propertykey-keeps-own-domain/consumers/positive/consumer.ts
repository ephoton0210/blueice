import {result} from "./main";
const accepted: boolean = result(true);
