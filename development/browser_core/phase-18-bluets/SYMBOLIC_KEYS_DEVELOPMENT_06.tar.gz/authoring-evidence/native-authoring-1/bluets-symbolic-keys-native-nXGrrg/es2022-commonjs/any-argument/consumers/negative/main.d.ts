export declare function result<E>(key: any, consume: (key: keyof E) => void): void;
