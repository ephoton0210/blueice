export declare function result<E>(key: never, consume: (key: keyof E) => void): void;
