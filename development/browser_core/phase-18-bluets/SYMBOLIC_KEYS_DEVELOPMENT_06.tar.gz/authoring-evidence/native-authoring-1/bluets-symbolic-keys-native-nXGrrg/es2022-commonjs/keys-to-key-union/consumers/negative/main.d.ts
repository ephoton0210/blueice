export declare function result<E, F>(key: keyof E, consume: (key: keyof E | keyof F) => void): void;
