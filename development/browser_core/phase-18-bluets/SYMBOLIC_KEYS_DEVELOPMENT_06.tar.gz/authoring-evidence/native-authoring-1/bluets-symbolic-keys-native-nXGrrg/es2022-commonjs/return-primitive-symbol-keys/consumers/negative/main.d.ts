export declare function result(key: keyof symbol): "toString" | "valueOf";
