export declare function result<E>(key: keyof unknown, consume: (key: never) => void): void;
