import {result} from "./main";
result(true, () => {});
