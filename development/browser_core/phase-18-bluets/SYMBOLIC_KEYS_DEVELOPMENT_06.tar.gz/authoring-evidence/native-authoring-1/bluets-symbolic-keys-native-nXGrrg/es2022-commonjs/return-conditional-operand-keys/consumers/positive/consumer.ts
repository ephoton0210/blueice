import {result} from "./main";
const accepted: "x" = result<true, {x: number}, {y: string}>("x");
