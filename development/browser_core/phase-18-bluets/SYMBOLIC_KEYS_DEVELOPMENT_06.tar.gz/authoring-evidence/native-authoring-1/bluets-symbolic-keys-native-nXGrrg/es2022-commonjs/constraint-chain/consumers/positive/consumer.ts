import {result} from "./main";
result<{x: number}, "x", "x">("x", () => {});
