import {result} from "./main";
const accepted: keyof number[] = result<number>("length");
