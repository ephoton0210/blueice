import {result} from "./main";
result<{x: number}, {y: string}>("x", () => {});
