export declare function result<E, F, K extends keyof E & keyof F>(key: K, consume: (key: keyof E) => void): void;
