import {result} from "./main";
result<{x: number}, {x: number; y: string}, "x">("x", () => {});
