import {result} from "./main";
const accepted: keyof [number, string] = result<number, string>("1");
