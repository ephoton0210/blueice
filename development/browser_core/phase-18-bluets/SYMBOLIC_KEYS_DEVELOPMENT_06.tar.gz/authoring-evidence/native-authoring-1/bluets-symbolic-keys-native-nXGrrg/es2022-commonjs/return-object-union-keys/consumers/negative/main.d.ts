export declare function result<E, F>(key: keyof (E | F)): keyof E & keyof F;
