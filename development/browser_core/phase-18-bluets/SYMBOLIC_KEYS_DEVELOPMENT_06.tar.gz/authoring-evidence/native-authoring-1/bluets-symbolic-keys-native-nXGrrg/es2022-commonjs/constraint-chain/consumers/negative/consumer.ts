import {result} from "./main";
result<{x: number}, "x", "y">("y", () => {});
