export declare function result(key: keyof unknown, consume: (key: any) => void): void;
