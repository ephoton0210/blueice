import {result} from "./main";
declare const key: never; result(key, () => {});
