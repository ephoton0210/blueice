export declare function result<E extends F, F extends G, G, K extends keyof G>(key: K, consume: (key: keyof E) => void): void;
