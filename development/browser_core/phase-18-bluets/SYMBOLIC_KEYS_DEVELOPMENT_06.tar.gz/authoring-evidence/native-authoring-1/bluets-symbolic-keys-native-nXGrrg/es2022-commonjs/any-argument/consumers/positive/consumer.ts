import {result} from "./main";
result<{x: number}>(true, key => { const accepted: "x" = key; });
