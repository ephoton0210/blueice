import {result} from "./main";
result<number>("x");
