type PropertyKey = boolean;
export declare function result(key: PropertyKey): boolean;
export {};
