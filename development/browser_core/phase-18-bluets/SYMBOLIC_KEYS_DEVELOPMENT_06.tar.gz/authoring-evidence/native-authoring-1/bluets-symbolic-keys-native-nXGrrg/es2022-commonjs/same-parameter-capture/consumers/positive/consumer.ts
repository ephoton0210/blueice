import {result} from "./main";
result<{x: number}>(key => { const accepted: "x" = key; })<"x">("x");
