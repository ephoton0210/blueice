import {result} from "./main";
result<number>("absent");
