export declare function result(key: symbol, consume: (key: keyof any) => void): void;
