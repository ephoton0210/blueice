# P0-C design decisions to finalize after P0-B acceptance

This is a design investigation, not production implementation or completed C.
P0-B's backend remains frozen until its full same-source acceptance and commit.

## Evidence and important corrections

The initial44 Native cases, five actual CLI declaration-byte cases, eight actual
CLI diagnostic-byte cases and16 explicit-intrinsic cases are retained separately.
Rust17.0 Unicode mappings match both current Node runtimes on all1,112,064 isolated
scalars. These facts eliminate the need to guess operation behavior or Unicode
versions; they do not prove generic type-operator or arbitrary UTF-16 correctness.

TypeScript5.9.3 accepts correctly named one-parameter source declarations such as
`type Uppercase<T> = intrinsic`. It does not require a string constraint on those
source aliases. It also accepts source NoInfer with one parameter and
BuiltinIteratorReturn with no parameters. Fake names and wrong arities get2795.
Thus an embedded-only lowering policy is not a sufficient implementation of the
new package's owner/intrinsic syntax. Intrinsics are pure type operations. Support
Native-valid declarations without granting runtime bindings; retain normal owner
bodies and reject invalid declarations with the complete Native diagnostics.

The pinned Native source validates intrinsic alias names/arities in
`checkTypeAliasDeclaration`; `getTypeAliasInstantiation` dispatches the marker
using the defining symbol. This is more precise than treating every Uppercase
spelling as an operation, or treating every source intrinsic keyword as invalid.
Imported renaming must retain the defining operation and symbol identity.

## Proposed shared type model

1. Add an explicit string-mapping operation with kind, defining intrinsic identity
   and operand. General string/any/generic/index/template inputs must retain a
   symbolic operation. Same-operation/same-symbol repetition is idempotent;
   mixed operations retain their order. Preserve alias presentation separately.
2. Give string literals a UTF-16 semantic value distinct from their source or
   generated presentation. A plain Rust String cannot represent lone surrogate
   values, while storing only replacement text changes semantic identity.
   Prefer a dedicated string-literal value type and shared codec. Migrate string
   literal creation/inspection consistently; keep numeric/boolean literal paths
   distinct. Check every old `Type::Literal` consumer and wildcard traversal.
3. Preserve raw source-literal presentation when required by Native declarations.
   Render inferred/mapped values through the pinned Native printer/UTF-8 writer
   contract. Native API callbacks may contain lone surrogate units while actual
   declaration files contain U+FFFD. Retain semantic units before serialization.
4. Decode escapes and pair/unpaired surrogates once in a shared UTF-16 codec.
   Uppercase/Lowercase transform full valid scalar runs while retaining malformed
   units and contextual sigma behavior. Capitalize/Uncapitalize transform only
   the first code unit, so a leading surrogate of a supplementary scalar stays
   unchanged. Do not use first-Rust-char conversion for the latter operations.
5. Thread symbolic operations through operator traversal, inference/dependencies,
   scoped substitution, variance, canonical identities, relations, template/key
   mapping, diagnostic presentation and declaration emission. Reuse the existing
   bounded work and demand machinery. No unknown/any fallback on exhaustion.
6. Attach validated type operations to definitions. Ordinary local/imported owner
   aliases remain their declared structures; type/value namespaces remain
   separate. Define valid source-intrinsic lowering alongside trusted library
   lowering, with Native name/arity diagnostics and NoInfer/iterator regressions.

## Acceptance inputs to author before production changes

The complete matrix must cover all four operations across the selected strict
and loose-null target/module/library profiles. Do not infer reference data from
BlueTS output. Include:

- Empty/literal/general strings; expansion, contextual Greek lowercasing, dotted-I,
  supplementary and paired/unpaired UTF-16, source escapes and CRLF/non-BMP spans.
- Union distribution/order/deduplication, any/unknown/never and constrained or
  unconstrained source-intrinsic operands; complete constraint/use-site errors.
- Symbolic templates and number/bigint patterns, mapped keys, intersections,
  generic calls/context/reverse inference, idempotence and operation order.
- Ordinary and explicit-intrinsic owners, module/renaming identity, invalid names
  and arities, and absence of implicit runtime bindings. Retain existing NoInfer,
  callable/receiver and NonNullable/Awaited regressions.
- Physical byte-exact declarations; both isolated consumer polarities; applicable
  syntax/runtime checks; complete primary/related diagnostics with unchanged
  UTF-16 positions. Project malformed UTF-16 diagnostic text through the actual
  Native UTF-8 writer contract, with the eight CLI probes as calibration.
- Separate owner/default-deny/work/depth controls, source modules below1,500lines,
  preservation of every old case identity/classification, and the existing full
  Native/local/maps/projects/tooling/Windows82 acceptance boundary.

Only freeze exact form/count/hash obligations after the authored Native matrix
and consumers pass independently. This document does not predeclare a narrower
passing matrix or label unimplemented Native-valid source aliases as policy
refusals. Keep broader feature rows and full parity open until their contracts
are actually satisfied.

## Existing implementation facts and integration seam

`backend/bluejs/src/native.rs::unicode_transform` already segments UTF-16 at
unpaired surrogates and transforms complete scalar runs. Its `transform_run`
uses Rust string casing for contextual sigma, alongside runtime-only Unicode
normalization and output-limit handling. `bluejs/src/string.rs::JsString` is a
lossless code-unit container, but its methods also depend on runtime values,
tokens and heap accounting. BlueTS currently has no BlueJS dependency.

Reuse the proven pure casing algorithm through a small shared language/text
module or crate if extraction is chosen. Keep VM values, normalization and host
budget error types out of the compiler dependency graph. The compiler needs
first-code-unit Capitalize/Uncapitalize in addition to full-string upper/lower.
Keep decoded semantic units distinct from source/generated printing. Existing
emitter `Type::Literal` uses include already-rendered type fragments, so a
mechanical conversion of every raw Literal string into a semantic string value
would be wrong; inspect semantic producers/consumers and renderer placeholders.

A parsed intrinsic-keyword marker with its own SourceSpan would allow exact2795
positions. Lower accepted aliases into checker definitions while retaining the
original source alias syntax for byte-exact declaration emission. Defining
symbol identity and import renaming must survive; ordinary owner bodies must
never be reinterpreted solely from their names. Existing NoInfer and iterator
behavior need regression coverage when the validated source syntax is extended.

The sixteen native-utf16-identity cases independently prove twelve rejections: high/low surrogate units must remain distinct from U+FFFD and from each other under all four mappings. The four positive cases equate escaped pairs with scalar source spelling. Physical inferred declaration bytes alone cannot prove this semantic boundary, because Native UTF-8 output can collapse malformed units to the same replacement character. Include these direct semantic controls in the authored matrix.
