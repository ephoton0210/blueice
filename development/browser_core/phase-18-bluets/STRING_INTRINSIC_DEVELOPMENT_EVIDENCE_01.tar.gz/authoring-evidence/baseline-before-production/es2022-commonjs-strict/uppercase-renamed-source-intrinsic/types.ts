export type Uppercase<T extends string> = intrinsic;
