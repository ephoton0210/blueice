import type { Uppercase as Mapping } from "./types";
export const value: Mapping<"word"> = "WORD";
