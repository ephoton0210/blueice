const Uppercase = (input: number) => input + 1;
export const value: Uppercase<"word"> = "WORD";
export const runtime = Uppercase(1);
