export type Uppercase<T extends string> = intrinsic;
export const value: Uppercase<"word"> = "WORD";
