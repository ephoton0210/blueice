type Uppercase<T> = intrinsic;
export const value: Uppercase<123> = 123;
