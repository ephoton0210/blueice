type Uppercase<T> = intrinsic;
export const value: Uppercase<{ key: number }> = { key: 1 };
