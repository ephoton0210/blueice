export const value = Uppercase("word");
