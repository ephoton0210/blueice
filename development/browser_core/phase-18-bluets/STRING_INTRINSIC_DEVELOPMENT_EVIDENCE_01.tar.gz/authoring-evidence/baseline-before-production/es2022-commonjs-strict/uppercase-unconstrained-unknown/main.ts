type Uppercase<T> = intrinsic;
export const value: Uppercase<unknown> = "anything";
