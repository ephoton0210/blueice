export declare const value: Uppercase<unknown>;
