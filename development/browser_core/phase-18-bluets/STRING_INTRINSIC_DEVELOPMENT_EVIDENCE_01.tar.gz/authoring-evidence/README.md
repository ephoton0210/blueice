# P0-C native design investigation

These are preparatory Native-only observations collected while P0-B's full
catalog runs. They are not frozen P0-C acceptance inputs, a production change,
a BlueTS pass, or permission to check P0-C before P0-B has been accepted.

`probe_native.cjs` produced 44 independent TypeScript 5.9.3 observations in
`native-design-probe.json`. The actual runtime was Node v26.7.0, Unicode 17.0,
ICU 78.3; the exact TypeScript implementation hash is recorded. The five cases
in `probe_cli_bytes.cjs` additionally invoke the actual pinned TypeScript CLI
and retain real declaration bytes, stdout/stderr and output hashes.

Confirmed facts:

- Uppercase<string>, Lowercase<string>, Capitalize<string> and
  Uncapitalize<string> reject nonconforming literals. They cannot be erased to
  ordinary string. Uppercase<any> rejects lowercase string literals while
  accepting a numeric value; it cannot simply become any or string.
- Repeating the same generic operation is idempotent, but changing operation
  order is not. A mapped generic result is not generally assignable back to T;
  reverse inference in the probe yields string. Symbolic identity must survive
  substitution, inference, assignability and exact declaration rendering.
- Uppercase/Lowercase process full strings: sharp-s expands, Greek final sigma
  depends on context, dotted-I expands and supplementary Deseret letters fold.
  Capitalize/Uncapitalize operate on the first UTF-16 code unit: a supplementary
  Deseret initial stays unchanged. Using the first Rust char would be wrong.
- Lone surrogate escapes remain distinct semantic code units. Inferred Native
  API declaration text may contain a lone surrogate; the actual CLI's UTF-8
  file writer replaces that unit with U+FFFD. The five CLI byte probes confirm
  this difference. Freeze physical declaration bytes, not the API's UTF-16
  callback string. Accepted input JSON can retain escaped source spellings.
- Literal union mismatch can be diagnostic 2820, not just 2322. Invalid generic
  operands produce complete constraint/use-site diagnostic sequences. The initial
  Fake alias receives2795; the later16-case explicit-intrinsic probe establishes
  that correctly named/parameterized SOURCE intrinsic aliases are valid Native
  syntax. Ordinary local aliases keep their own bodies. Do not generalize the
  Fake rejection into rejection of every source intrinsic declaration.
- Open template placeholders retain mapping operations, including numeric
  template patterns. Mapped-key capitalization and conditional fixed-point
  tests share the same semantics as direct utility applications.

Relevant existing paths inspected:

- `backend/bluets/src/standard_library/intrinsics.rs` attaches NoInfer only to
  trusted embedded aliases. Add trusted operation identity there; do not use
  source spelling alone to recognize owners/imports as intrinsics.
- `backend/bluets/src/parser.rs` has an explicit Type enum and raw textual
  Literal(String). `parser/type_forms.rs` and operator traversal support shared
  operations; introduce a real symbolic string-mapping operation.
- `checker/type_operators.rs`, `checker/type_operators/templates.rs`, inference
  and type-relation substitution must carry that operation with existing work
  budgets and binders. Do not expand open patterns to a loose fallback.
- `enum_eval::decode_plain_string` deliberately returns None on lone surrogates.
  Template literal helpers use that scalar decoder. A UTF-16 literal codec and
  a clear semantic/presentation boundary are prerequisites for correct strings;
  do not silently turn invalid UTF-16 into a different semantic literal.

Before production implementation:

1. Finish and commit the complete P0-B acceptance first. Its frozen backend
   must not change while Native/workspace/Windows evidence is being accepted.
2. Choose a shared string-literal semantic representation that preserves UTF-16
   units and source presentation. Determine the rendering of inferred malformed
   units separately from semantic identity, including Native CLI UTF-8 bytes.
3. Verify/pin Unicode data against the Native runtime(s); TypeScript delegates
   mappings to JavaScript string operations. Rust and Windows Node versions are
   not evidence of identical Unicode tables without an actual check.
4. Author and freeze the full four-operation matrix across required profiles:
   literals/empty/general strings, contextual Unicode/UTF-16, unions/templates,
   any/never/constraints, generic/inference/compositions, owners/imports/runtime
   authority, related diagnostics and UTF-16 spans. Use real CLI bytes for all
   declarations, then isolated positive/negative consumers and executable checks.
5. Retain owner/default-deny/resource controls separately, preserve all old case
   identities, keep source modules below 1,500 lines, and require the existing
   complete same-source Native/local/maps/projects/tooling/Windows boundary.

Verified Unicode follow-up: Rust 1.98 reports Unicode17.0. Both actual Node runtimes (local26.7.0 and Windows24.21.0) report Unicode17.0/ICU78.3. The exhaustive isolated-scalar table comparison checks1,112,064 scalar values and all3,037 Rust-changed scalars on BOTH runtimes with zero differences. See unicode-foundation-summary.json and both original reports. This does not prove contextual multi-character mappings, surrogate-unit semantics or BlueTS type operations.

Additional verified investigations: native-diagnostic-byte-probe.json retains8 real-CLI byte comparisons, all equal to the UTF-8 encoding of complete API-formatted diagnostics, including related information and UTF-16 positions. native-intrinsic-alias-probe.json retains16 Native cases: four valid source string intrinsics, four arity rejections, valid source NoInfer/BuiltinIteratorReturn, Fake rejection, renamed imports and unconstrained scalar/object/unknown behavior. This changes the proposed C design: pure type intrinsic syntax must be validated by its Native name/arity contract, while ordinary owner aliases and runtime authority stay separate. Do not carry the earlier embedded-only implementation assumption forward as an unexamined requirement.
