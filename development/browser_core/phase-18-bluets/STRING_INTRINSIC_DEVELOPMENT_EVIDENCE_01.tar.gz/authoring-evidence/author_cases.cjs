// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const fs=require('node:fs'),path=require('node:path');
const root='/private/tmp/blueice-bluets-p0c-20261112',directory=path.join(root,'backend/bluets/tests/fixtures/string_intrinsics');fs.mkdirSync(directory,{recursive:true});
const b=JSON.parse(fs.readFileSync(path.join(root,'backend/bluets/tests/fixtures/nonnullable_awaited/cases.json'))),cases=[];
const literal=JSON.stringify,utf8=value=>Buffer.from(value,'utf8').toString('utf8');
const operations=[['Uppercase','ABC','aBc','Lowercase'],['Lowercase','abc','aBc','Uppercase'],['Capitalize','Word','word','Uncapitalize'],['Uncapitalize','word','Word','Capitalize']];
const transform=(op,text)=>op==='Uppercase'?text.toUpperCase():op==='Lowercase'?text.toLowerCase():op==='Capitalize'?text.charAt(0).toUpperCase()+text.slice(1):text.charAt(0).toLowerCase()+text.slice(1);
function add(id,source,accepts,positive,negative,extra={}){if(cases.some(c=>c.id===id))throw Error('duplicate '+id);const row={id,source,accepts,...extra};if(positive!==undefined)row.consumer={positive:'import { value } from "./main";\n'+positive+'\n',negative:'import { value } from "./main";\n'+negative+'\n'};cases.push(row);}
function mapped(op,id,text,sourceLiteral){const expected=utf8(transform(op,text));add(op.toLowerCase()+'-'+id,`declare function map<T extends string>(input: T): ${op}<T>;\nexport const value = map(${sourceLiteral??literal(text)});\n`,true,`const proof: ${literal(expected)} = value;`,'const proof: number = value;');}
for(const [op,good,bad,other] of operations){
 for(const [id,text,spelling] of [
  ['empty',''],['ascii','wOrD'],['sharp-s','ßeta'],['greek-sigma','ΟΣ'],['dotted-i','İSTANBUL'],
  ['supplementary-head','𐐨word'],['paired-escape','𐐨word','"\\uD801\\uDC28word"'],
  ['lone-high-head','\ud800word'],['lone-low-head','\udc00WORD'],['malformed-middle','a\ud800\ud801\udc28z'],
  ['combining-head','\u0301Word'],['escaped-controls','a\0\n\v"\\z'],
 ])mapped(op,id,text,spelling);
 const name=op.toLowerCase();
 add(name+'-general-valid',`export const value: ${op}<string> = ${literal(good)};\n`,true,'const proof: string = value;',`const proof: typeof value = ${literal(bad)};`);
 add(name+'-general-invalid',`export const value: ${op}<string> = ${literal(bad)};\n`,false);
 add(name+'-general-inferred',`declare const input: string;\ndeclare function map<T extends string>(input: T): ${op}<T>;\nexport const value = map(input);\n`,true,`const proof: typeof value = ${literal(good)};`,`const proof: typeof value = ${literal(bad)};`);
 const word=transform(op,'word');
 add(name+'-generic-idempotence',`export function value<T extends string>(input: ${op}<${op}<T>>): ${op}<T> { return input; }\n`,true,`const proof: ${literal(word)} = value<"word">(${literal(word)});`,'value<"word">("invalid");');
 add(name+'-generic-order',`export function value<T extends string>(input: ${op}<${other}<T>>): ${other}<${op}<T>> { return input; }\n`,false);
 add(name+'-generic-return-not-identity',`export function value<T extends string>(input: T): ${op}<T> { return input; }\n`,false);
 add(name+'-generic-result-not-argument',`export function value<T extends string>(input: ${op}<T>): T { return input; }\n`,false);
 add(name+'-generic-reverse-inference',`declare function map<T extends string>(input: ${op}<T>): T;\nexport const value = map(${literal(good)});\n`,true,'const proof: string = value;','const proof: number = value;');
 add(name+'-never',`declare const input: never;\ndeclare function map<T extends string>(input: T): ${op}<T>;\nexport const value = map(input);\n`,true,'const proof: never = value;','const proof: typeof value = 1;');
 add(name+'-any-number',`export const value: ${op}<any> = 123;\n`,true,'const proof: typeof value = 123;',`const proof: typeof value = ${literal(bad)};`);
 add(name+'-any-invalid-string',`export const value: ${op}<any> = ${literal(bad)};\n`,false);
 add(name+'-unknown-constraint',`export declare const value: ${op}<unknown>;\n`,false);
 add(name+'-number-constraint',`export declare const value: ${op}<number>;\n`,false);
 add(name+'-null-constraint',`export declare const value: ${op}<null>;\n`,false,'const proof: typeof value = null;','const proof: typeof value = 1;',{acceptsByProfile:Object.fromEntries(b.profiles.map(p=>[p.id,p.id==='es5-commonjs-loose-null']))});
 add(name+'-literal-union',`declare const input: "word" | "other";\ndeclare function map<T extends string>(input: T): ${op}<T>;\nexport const value = map(input);\n`,true,`const proof: ${literal(transform(op,'word'))} | ${literal(transform(op,'other'))} = value;`,'const proof: number = value;');
 add(name+'-ordinary-local-owner',`type ${op}<T> = { owner: T };\nexport const value: ${op}<number> = { owner: 1 };\n`,true,'const proof: number = value.owner;','const proof: string = value.owner;');
 add(name+'-ordinary-imported-owner',`import type { ${op} as Owned } from "./types";\nexport const value: Owned<number> = { owner: 1 };\n`,true,'const proof: number = value.owner;','const proof: string = value.owner;',{files:{'types.ts':`export type ${op}<T> = { owner: T };\n`}});
 add(name+'-source-intrinsic',`export type ${op}<T extends string> = intrinsic;\nexport const value: ${op}<"word"> = ${literal(word)};\n`,true,`const proof: ${literal(word)} = value;`,'const proof: number = value;');
 add(name+'-renamed-source-intrinsic',`import type { ${op} as Mapping } from "./types";\nexport const value: Mapping<"word"> = ${literal(word)};\n`,true,`const proof: ${literal(word)} = value;`,'const proof: number = value;',{files:{'types.ts':`export type ${op}<T extends string> = intrinsic;\n`}});
 add(name+'-invalid-intrinsic-arity',`export type ${op}<T, U> = intrinsic;\n`,false);
 add(name+'-unconstrained-number',`type ${op}<T> = intrinsic;\nexport const value: ${op}<number> = ${literal(op==='Uppercase'?'1E+21':'1e+21')};\n`,true,`const proof: typeof value = ${literal(op==='Uppercase'?'1E+21':'1e+21')};`,'const proof: typeof value = "not-number";');
 add(name+'-unconstrained-number-literal',`type ${op}<T> = intrinsic;\nexport const value: ${op}<123> = 123;\n`,true,'const proof: 123 = value;','const proof: string = value;');
 add(name+'-unconstrained-unknown',`type ${op}<T> = intrinsic;\nexport const value: ${op}<unknown> = "anything";\n`,true,'const proof: unknown = value;','const proof: string = value;');
 add(name+'-unconstrained-object',`type ${op}<T> = intrinsic;\nexport const value: ${op}<{ key: number }> = { key: 1 };\n`,true,'const proof: number = value.key;','const proof: string = value.key;');
 add(name+'-type-value-namespaces',`const ${op} = (input: number) => input + 1;\nexport const value: ${op}<"word"> = ${literal(word)};\nexport const runtime = ${op}(1);\n`,true,`const proof: ${literal(word)} = value;`,'const proof: number = value;',{runtime:true});
 add(name+'-runtime-type-only',`export const value = ${op}("word");\n`,false);
 add(name+'-conditional-fixed-point',`type IsMapped<T extends string> = T extends ${op}<T> ? true : false;\nexport const value: [IsMapped<${literal(good)}>, IsMapped<${literal(bad)}>] = [true, false];\n`,true,'const proof: [true, false] = value;','const proof: typeof value = [false, true];');
 add(name+'-mapped-key',`type MapKeys<T> = { [K in keyof T as ${op}<string & K>]: T[K] };\ndeclare function map<T>(input: T): MapKeys<T>;\nconst mapped = map({ word: 1 });\nexport const value = mapped[${literal(word)}];\n`,true,'const proof: number = value;','const proof: string = value;');
 for(const [suffix,left,right,accepts] of [
  ['high-vs-replacement','\\uD800a','\\uFFFDa',false],['low-vs-replacement','\\uDC00a','\\uFFFDa',false],
  ['high-vs-low','\\uD800a','\\uDC00a',false],['pair-vs-scalar','\\uD801\\uDC28a','𐐨a',true],
 ])add(name+'-identity-'+suffix,`declare const input: ${op}<"${left}">;\nexport const value: ${op}<"${right}"> = input;\n`,accepts,accepts?`const proof: ${literal(transform(op,'𐐨a'))} = value;`:undefined,accepts?'const proof: number = value;':undefined);
 const prefix=op==='Uppercase'?'PRE-':op==='Lowercase'?'pre-':op==='Capitalize'?'Pre-':'pre-';
 const tail=op==='Uppercase'?'ABC':op==='Lowercase'?'abc':op==='Capitalize'?'mixed':'Mixed';
 add(name+'-open-template',`export const value: ${op}<\`pre-\${string}\`> = ${literal(prefix+tail)};\n`,true,`const proof: typeof value = ${literal(prefix+tail)};`,'const proof: typeof value = "wrong-prefix";');
 const suffix=op==='Uppercase'?'-POST':'-post';
 add(name+'-empty-head-template',`export const value: ${op}<\`\${string}-post\`> = ${literal(good+suffix)};\n`,true,`const proof: typeof value = ${literal(good+suffix)};`,`const proof: typeof value = ${literal(bad+suffix)};`);
 const numeric=op==='Uppercase'?'1E+21':'1e+21';
 add(name+'-numeric-template',`export const value: ${op}<\`\${number}\`> = ${literal(numeric)};\n`,true,`const proof: typeof value = ${literal(numeric)};`,'const proof: typeof value = "not-number";');
 add(name+'-owned-inferred-number',`type ${op}<T> = intrinsic;\ndeclare function map<T>(input: T): ${op}<T>;\ndeclare const input: number;\nexport const value = map(input);\n`,true,`const proof: typeof value = ${literal(numeric)};`,'const proof: typeof value = "not-number";');
 add(name+'-owned-inferred-string',`type ${op}<T> = intrinsic;\ndeclare function map<T>(input: T): ${op}<T>;\ndeclare const input: string;\nexport const value = map(input);\n`,true,`const proof: typeof value = ${literal(good)};`,`const proof: typeof value = ${literal(bad)};`);

}
// Additional physical-printer inputs exercise the shared literal writer once.
for(let code=0;code<32;code++)mapped('Uppercase','printer-control-'+code.toString(16).padStart(4,'0'),'a'+String.fromCharCode(code)+'z');
for(const [id,text] of [['nul-digit','a\0'+'1z'],['del','a\x7fz'],['c1','a\x85z'],['nbsp','a\xa0z'],['line-separator','a\u2028z'],['paragraph-separator','a\u2029z'],['bom','a\ufeffz'],['noncharacter-fffe','a\ufffez'],['noncharacter-ffff','a\uffffz'],['quote','a"z'],['single-quote',"a'z"],['backslash','a\\z'],['backtick','a`z'],['dollar-brace','a${z']])mapped('Uppercase','printer-'+id,text);
add('source-fake-intrinsic','export type Fake<T> = intrinsic;\n',false);
add('source-noinfer-regression','export type NoInfer<T> = intrinsic;\nexport const value: NoInfer<number> = 1;\n',true,'const proof: number = value;','const proof: string = value;');
add('source-builtin-iterator-regression','export type BuiltinIteratorReturn = intrinsic;\nexport declare const value: BuiltinIteratorReturn;\n',true,'const proof: typeof value = undefined;','const proof: typeof value = 1;');
const data={schema:1,typescript:'5.9.3',scope:'Authored P0-C candidate matrix; freeze only after independent Native source/consumer calibration. No production changes yet.',options:b.options,profiles:b.profiles,cases};
fs.writeFileSync(path.join(directory,'cases.json'),JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify({forms:cases.length,profiles:b.profiles.length,comparisons:cases.length*b.profiles.length,path:path.join(directory,'cases.json')}));
