export declare const result: (value: unknown) => number;
export declare const demanded: number;
