import { result } from "./main";
const demanded: string[] = result("a", "b");
