declare function identity<T>(value: T): T;
export declare const result: typeof identity;
export declare const demanded: number;
export {};
