import { result } from "./main";
const demanded: [number, number[]][] = result<number>(1, [2]);
