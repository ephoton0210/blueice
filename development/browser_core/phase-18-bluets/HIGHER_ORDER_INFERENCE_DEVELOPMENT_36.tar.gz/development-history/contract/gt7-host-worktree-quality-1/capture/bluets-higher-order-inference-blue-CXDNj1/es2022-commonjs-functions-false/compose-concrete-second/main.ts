declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function list<T>(value: T): T[] { return [value]; }
function size(value: unknown[]): number { return value.length; }
export const result = compose(list, size);
export const demanded: number = result("text");
