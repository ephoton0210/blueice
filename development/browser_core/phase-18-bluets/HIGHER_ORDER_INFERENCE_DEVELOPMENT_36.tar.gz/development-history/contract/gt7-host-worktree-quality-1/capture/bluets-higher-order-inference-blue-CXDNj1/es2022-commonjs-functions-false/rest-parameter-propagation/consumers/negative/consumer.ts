import { result } from "./main";
const refused: number[] = result("a", "b");
