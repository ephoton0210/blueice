declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
const provider: { map: <T>(value: T) => T[] } = { map: <T>(value: T): T[] => [value] };
export const result = lift(provider.map);
