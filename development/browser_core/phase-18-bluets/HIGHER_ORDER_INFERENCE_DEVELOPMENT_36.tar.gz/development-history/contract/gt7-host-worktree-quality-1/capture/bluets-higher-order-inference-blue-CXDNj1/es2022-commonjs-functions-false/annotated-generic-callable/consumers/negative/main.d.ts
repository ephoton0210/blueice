export declare const result: <Element>(value: Element) => {
    value: Element[];
};
export declare const demanded: {
    value: string[];
};
