"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.compose = compose; function compose(first, second){ return value => second(first(value)); }
