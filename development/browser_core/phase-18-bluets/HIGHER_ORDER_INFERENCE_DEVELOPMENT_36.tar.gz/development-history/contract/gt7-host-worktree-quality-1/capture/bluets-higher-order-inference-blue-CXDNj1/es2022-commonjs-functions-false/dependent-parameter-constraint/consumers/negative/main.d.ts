export declare const result: <T, U extends T>(left: T, right: U) => [T, U][];
