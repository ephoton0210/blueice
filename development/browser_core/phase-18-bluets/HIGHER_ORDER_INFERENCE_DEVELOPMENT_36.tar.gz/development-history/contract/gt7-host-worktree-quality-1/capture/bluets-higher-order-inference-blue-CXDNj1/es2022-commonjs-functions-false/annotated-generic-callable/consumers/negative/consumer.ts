import { result } from "./main";
const refused: { value: number[] } = result("text");
