import { result } from "./main";
const refused: { value: string[] } = result(true);
