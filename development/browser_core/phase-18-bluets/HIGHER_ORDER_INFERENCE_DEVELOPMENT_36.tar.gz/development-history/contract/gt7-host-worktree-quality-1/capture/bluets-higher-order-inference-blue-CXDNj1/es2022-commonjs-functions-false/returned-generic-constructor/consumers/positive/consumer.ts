import { result } from "./main";
const demanded: string = new result("text").value;
