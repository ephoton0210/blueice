export declare const result: <T>(value: T) => {
    value: T[];
};
export declare const demanded: {
    value: string[];
};
