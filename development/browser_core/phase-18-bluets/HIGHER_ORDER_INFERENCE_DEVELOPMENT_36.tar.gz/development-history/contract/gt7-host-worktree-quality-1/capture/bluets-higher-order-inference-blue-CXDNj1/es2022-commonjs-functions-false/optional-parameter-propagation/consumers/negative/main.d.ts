export declare const result: <T>(value?: T | undefined) => (T | undefined)[];
