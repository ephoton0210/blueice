var check = require("./main.js").result;
if (check("text")[0] !== "text" || check(2)[0] !== 2) throw new Error("lifting");
