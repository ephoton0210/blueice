import { result } from "./main";
const refused: string = result.run("text");
