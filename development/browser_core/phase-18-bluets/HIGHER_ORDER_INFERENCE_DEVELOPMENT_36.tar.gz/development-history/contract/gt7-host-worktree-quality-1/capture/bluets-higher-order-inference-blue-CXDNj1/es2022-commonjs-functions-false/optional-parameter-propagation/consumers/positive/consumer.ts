import { result } from "./main";
const demanded: (string | undefined)[] = result("text");
