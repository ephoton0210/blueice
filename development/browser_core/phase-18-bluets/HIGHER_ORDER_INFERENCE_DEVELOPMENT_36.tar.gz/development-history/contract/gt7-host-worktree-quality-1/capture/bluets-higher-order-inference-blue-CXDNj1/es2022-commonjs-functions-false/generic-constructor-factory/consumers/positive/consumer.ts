import { result } from "./main";
const demanded: string = result("text").value;
