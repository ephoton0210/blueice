declare class Box<T> {
    value: T;
    constructor(value: T);
}
export declare const result: <T>(value: T) => Box<T>;
export declare const demanded: Box<string>;
export {};
