import { result } from "./main";
const demanded: { value: string[] } = result("text");
