import { compose } from "./higher";
import { list, box } from "./factories";
export const result = compose(list, box);
export const demanded: { value: string[] } = result("text");
