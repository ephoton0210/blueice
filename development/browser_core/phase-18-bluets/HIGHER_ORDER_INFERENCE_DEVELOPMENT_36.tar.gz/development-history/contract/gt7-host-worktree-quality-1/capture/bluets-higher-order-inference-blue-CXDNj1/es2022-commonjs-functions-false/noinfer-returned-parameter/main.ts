declare function guarded<A, B>(fn: (value: A) => B): (value: NoInfer<A>) => B;
function identity<T>(value: T): T { return value; }
export const result = guarded(identity);
