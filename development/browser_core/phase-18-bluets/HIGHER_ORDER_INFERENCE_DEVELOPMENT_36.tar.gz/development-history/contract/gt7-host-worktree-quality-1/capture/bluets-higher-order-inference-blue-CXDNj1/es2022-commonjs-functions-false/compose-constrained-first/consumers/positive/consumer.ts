import { result } from "./main";
const demanded: number = result({ tag: "ok", extra: 1 }).value[0].extra;
