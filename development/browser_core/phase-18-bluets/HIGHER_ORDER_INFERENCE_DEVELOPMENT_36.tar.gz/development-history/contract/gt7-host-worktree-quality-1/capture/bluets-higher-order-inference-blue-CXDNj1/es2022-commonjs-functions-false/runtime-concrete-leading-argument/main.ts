function apply<A, B>(value: A, fn: (value: A) => B): B { return fn(value); }
function list<T>(value: T): T[] { return [value]; }
export const result = apply("text", list);
