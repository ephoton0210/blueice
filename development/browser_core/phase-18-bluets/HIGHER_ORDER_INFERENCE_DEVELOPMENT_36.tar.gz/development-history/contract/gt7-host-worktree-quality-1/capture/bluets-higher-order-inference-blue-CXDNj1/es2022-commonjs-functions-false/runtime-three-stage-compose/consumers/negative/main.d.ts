export declare const result: <T>(value: T) => {
    value: T[];
}[];
