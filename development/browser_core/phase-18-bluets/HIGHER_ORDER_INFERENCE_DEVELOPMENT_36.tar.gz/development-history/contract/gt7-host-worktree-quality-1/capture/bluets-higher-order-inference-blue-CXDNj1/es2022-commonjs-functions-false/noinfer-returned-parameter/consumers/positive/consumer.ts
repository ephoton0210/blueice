import { result } from "./main";
const demanded: string = result<string>("text");
