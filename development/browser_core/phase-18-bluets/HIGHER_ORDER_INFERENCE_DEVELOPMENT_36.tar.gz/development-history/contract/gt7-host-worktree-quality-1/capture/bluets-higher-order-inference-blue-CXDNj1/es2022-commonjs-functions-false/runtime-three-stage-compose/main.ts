function compose3<A, B, C, D>(one: (value: A) => B, two: (value: B) => C, three: (value: C) => D): (value: A) => D { return value => three(two(one(value))); }
function list<T>(value: T): T[] { return [value]; }
function box<T>(value: T): { value: T } { return { value }; }
export const result = compose3(list, box, list);
