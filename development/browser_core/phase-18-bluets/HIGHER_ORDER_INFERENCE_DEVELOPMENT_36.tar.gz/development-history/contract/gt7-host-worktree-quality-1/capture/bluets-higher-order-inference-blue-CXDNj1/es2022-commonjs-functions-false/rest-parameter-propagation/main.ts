declare function restLift<A, B>(fn: (...values: A[]) => B): (...values: A[]) => B[];
function first<T>(...values: T[]): T { return values[0]; }
export const result = restLift(first);
