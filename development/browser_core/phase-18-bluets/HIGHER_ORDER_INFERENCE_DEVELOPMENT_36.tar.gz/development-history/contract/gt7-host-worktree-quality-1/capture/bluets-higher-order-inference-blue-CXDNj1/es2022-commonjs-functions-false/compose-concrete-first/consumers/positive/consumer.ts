import { result } from "./main";
const demanded: string[] = result(1);
