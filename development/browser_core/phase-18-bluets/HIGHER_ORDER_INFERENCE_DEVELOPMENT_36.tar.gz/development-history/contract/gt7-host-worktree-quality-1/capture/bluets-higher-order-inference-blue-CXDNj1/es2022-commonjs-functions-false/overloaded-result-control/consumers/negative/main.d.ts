export declare const result: {
    (value: unknown): unknown;
    (): unknown;
};
