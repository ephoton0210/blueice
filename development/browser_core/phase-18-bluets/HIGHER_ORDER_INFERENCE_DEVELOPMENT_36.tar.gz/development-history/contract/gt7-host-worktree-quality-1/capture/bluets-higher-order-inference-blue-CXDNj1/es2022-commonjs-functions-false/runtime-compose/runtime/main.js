"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; function compose(first, second){ return value => second(first(value)); }
function list(value){ return [value]; }
function box(value){ return { value }; }
exports.result = compose(list, box);
