import { outer } from "./main";
const refused: { value: string[] } = outer("outside")(1);
