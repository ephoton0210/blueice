export declare function outer<T>(value: T): <T_1>(value: T_1) => {
    value: T_1[];
};
export declare const demanded: {
    value: number[];
};
