"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; function apply(fn, value){ return fn(value); }
function list(value){ return [value]; }
exports.result = apply(list, "text");
