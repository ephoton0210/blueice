import { result } from "./main";
const refused: number[] = result(1);
