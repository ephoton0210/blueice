declare function choose<A, B>(fn: (value: A) => B, mode: "wrap"): (value: A) => B[];
declare function choose<A, B>(fn: (value: A) => B, mode: "keep"): (value: A) => B;
function identity<T>(value: T): T { return value; }
export const result = choose(identity, "invalid");
