export declare const result: <T>(value: T) => T[];
