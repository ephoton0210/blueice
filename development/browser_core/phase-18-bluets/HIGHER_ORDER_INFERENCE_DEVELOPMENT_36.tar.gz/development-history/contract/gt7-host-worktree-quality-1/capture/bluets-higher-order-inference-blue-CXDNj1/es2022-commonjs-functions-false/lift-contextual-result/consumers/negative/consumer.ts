import { result } from "./main";
result("wrong");
