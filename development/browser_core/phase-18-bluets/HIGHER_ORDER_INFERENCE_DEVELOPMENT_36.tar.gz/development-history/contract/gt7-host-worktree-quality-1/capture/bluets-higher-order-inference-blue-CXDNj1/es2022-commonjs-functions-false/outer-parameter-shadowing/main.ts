declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function list<T>(value: T): T[] { return [value]; }
function box<T>(value: T): { value: T } { return { value }; }
export function outer<T>(value: T) { return compose(list, box); }
export const demanded: { value: number[] } = outer("outer")(1);
