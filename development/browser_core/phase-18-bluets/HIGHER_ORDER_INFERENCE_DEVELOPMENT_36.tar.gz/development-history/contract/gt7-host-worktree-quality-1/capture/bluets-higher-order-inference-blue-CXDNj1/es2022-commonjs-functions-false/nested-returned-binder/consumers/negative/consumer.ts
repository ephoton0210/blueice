import { result } from "./main";
const refused: [number, string] = result("text")[0](1);
