import { result } from "./main";
const demanded: [string, number] = result("text")[0](1);
