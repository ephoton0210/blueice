export declare const result: <T extends {
    tag: string;
}>(value: T) => {
    value: T[];
};
export declare const demanded: {
    value: {
        tag: string;
        extra: number;
    }[];
};
