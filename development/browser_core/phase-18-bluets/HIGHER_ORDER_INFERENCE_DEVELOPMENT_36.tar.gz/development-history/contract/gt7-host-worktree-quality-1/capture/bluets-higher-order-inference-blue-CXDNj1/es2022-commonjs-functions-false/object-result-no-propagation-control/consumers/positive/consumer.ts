import { result } from "./main";
const demanded: unknown = result.run("text");
