export declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
