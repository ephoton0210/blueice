import { result } from "./main";
const demanded: { value: boolean[] } = result(true);
