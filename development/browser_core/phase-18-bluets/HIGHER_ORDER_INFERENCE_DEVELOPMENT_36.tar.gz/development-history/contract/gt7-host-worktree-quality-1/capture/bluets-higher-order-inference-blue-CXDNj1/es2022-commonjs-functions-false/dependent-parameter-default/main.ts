declare function lift2<A, B, R>(fn: (left: A, right: B) => R): (left: A, right: B) => R[];
function pair<T = string, U = T[]>(left: T, right: U): [T, U] { return [left, right]; }
export const result = lift2(pair);
