declare function adapt<A, R>(ctor: new (value: A) => R): new (value: A) => R;
class Box<T> { value: T; constructor(value: T) { this.value = value; } }
export const result = adapt(Box);
