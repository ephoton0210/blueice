import { result } from "./main";
result({ extra: 1 });
