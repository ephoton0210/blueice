export function list<T>(value: T): T[] { return [value]; }
export function box<T>(value: T): { value: T } { return { value }; }
