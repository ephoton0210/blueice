export declare const result: (value: number) => string[];
export declare const demanded: string[];
