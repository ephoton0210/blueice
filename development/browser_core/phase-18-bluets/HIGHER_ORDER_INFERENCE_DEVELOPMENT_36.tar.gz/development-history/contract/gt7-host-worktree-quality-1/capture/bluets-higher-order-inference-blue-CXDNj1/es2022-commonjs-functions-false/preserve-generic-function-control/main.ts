declare function preserve<F>(fn: F): F;
function identity<T>(value: T): T { return value; }
export const result = preserve(identity);
export const demanded: number = result(1);
