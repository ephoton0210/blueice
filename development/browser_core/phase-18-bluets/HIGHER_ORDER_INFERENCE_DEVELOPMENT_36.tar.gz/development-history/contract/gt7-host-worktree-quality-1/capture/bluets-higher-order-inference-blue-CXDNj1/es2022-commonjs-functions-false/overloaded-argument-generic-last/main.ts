declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
declare function convert(value: number): number[];
declare function convert<T>(value: T): T[];
export const result = lift(convert);
