declare class Box<T> {
    value: T;
    constructor(value: T);
}
export declare const result: new <T>(value: T) => Box<T>;
export {};
