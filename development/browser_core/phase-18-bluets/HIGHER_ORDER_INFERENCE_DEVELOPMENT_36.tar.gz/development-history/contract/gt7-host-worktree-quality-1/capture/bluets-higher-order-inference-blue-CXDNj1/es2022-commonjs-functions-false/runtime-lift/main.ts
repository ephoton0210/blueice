function lift<A, B>(fn: (value: A) => B): (value: A) => B[] { return value => [fn(value)]; }
function identity<T>(value: T): T { return value; }
export const result = lift(identity);
