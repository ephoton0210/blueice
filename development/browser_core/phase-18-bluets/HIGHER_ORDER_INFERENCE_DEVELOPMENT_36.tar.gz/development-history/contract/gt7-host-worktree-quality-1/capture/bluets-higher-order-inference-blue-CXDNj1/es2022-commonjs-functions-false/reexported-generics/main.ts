declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
import { list, box } from "./bridge";
export const result = compose(list, box);
export const demanded: { value: string[] } = result("text");
