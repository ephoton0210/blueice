"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; const higher_1 = require("./higher.js");
const factories_1 = require("./factories.js");
exports.result = (0, higher_1.compose)(factories_1.list, factories_1.box);
