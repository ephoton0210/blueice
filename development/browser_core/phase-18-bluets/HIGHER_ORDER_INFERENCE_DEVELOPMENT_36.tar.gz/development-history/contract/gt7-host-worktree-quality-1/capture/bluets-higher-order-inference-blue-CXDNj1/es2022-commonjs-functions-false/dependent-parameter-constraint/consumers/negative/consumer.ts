import { result } from "./main";
result("text", 1);
