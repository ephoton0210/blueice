import { result } from "./main";
const demanded: [string, string][] = result("left", "right");
