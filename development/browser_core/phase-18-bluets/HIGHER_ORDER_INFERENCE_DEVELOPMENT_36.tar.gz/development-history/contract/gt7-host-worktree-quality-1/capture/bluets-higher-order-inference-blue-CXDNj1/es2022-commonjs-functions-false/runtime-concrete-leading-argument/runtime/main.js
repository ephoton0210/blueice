"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; function apply(value, fn){ return fn(value); }
function list(value){ return [value]; }
exports.result = apply("text", list);
