function apply<A, B>(fn: (value: A) => B, value: A): B { return fn(value); }
function list<T>(value: T): T[] { return [value]; }
export const result = apply(list, "text");
