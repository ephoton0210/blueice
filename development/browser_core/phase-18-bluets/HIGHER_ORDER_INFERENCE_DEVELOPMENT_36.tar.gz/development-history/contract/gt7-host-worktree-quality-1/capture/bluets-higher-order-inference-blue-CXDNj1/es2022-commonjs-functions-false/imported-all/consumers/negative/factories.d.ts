export declare function list<T>(value: T): T[];
export declare function box<T>(value: T): {
    value: T;
};
