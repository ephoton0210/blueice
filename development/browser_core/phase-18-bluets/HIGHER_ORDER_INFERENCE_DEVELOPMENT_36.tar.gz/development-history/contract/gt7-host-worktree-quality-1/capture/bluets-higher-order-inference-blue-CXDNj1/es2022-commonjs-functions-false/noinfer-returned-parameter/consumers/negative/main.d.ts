export declare const result: <T>(value: NoInfer<T>) => T;
