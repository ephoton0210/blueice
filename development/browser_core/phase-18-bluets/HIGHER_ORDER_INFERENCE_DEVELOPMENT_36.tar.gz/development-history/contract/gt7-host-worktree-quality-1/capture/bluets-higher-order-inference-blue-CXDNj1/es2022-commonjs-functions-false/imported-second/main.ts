declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function list<T>(value: T): T[] { return [value]; }
import { box } from "./second";
export const result = compose(list, box);
export const demanded: { value: string[] } = result("text");
