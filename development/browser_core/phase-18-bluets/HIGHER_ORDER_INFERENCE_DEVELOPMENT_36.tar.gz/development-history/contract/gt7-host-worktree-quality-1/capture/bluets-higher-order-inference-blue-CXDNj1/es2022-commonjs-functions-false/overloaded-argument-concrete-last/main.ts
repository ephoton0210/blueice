declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
declare function convert<T>(value: T): T[];
declare function convert(value: number): number[];
export const result = lift(convert);
