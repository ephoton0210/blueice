export declare const result: {
    run: (value: unknown) => unknown;
};
