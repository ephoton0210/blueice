declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
function nested<T>(value: T): <U>(other: U) => [T, U] { return other => [value, other]; }
export const result = lift(nested);
