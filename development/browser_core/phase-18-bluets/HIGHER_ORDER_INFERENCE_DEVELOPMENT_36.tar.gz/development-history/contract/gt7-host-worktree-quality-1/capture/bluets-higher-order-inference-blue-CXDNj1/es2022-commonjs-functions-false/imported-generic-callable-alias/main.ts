declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
import { mapper } from "./shapes";
export const result = lift(mapper);
