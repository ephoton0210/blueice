export declare const result: <T = string, U = T[]>(left: T, right: U) => [T, U][];
