export declare const result: <T>(...values: T[]) => T[];
