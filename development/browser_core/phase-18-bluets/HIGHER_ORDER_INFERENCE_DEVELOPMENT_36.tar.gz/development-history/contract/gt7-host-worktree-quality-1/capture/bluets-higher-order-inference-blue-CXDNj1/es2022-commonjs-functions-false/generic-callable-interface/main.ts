declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];
interface Mapper { <T>(value: T): T; }
declare const mapper: Mapper;
export const result = lift(mapper);
