import { result } from "./main";
const demanded: number[] = result(1);
