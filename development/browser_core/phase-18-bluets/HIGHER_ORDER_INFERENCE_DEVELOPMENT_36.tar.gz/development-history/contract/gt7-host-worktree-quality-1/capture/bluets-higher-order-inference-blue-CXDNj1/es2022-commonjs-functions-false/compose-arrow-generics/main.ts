declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
const first = <T>(value: T): T[] => [value];
const second = <U>(value: U): { value: U } => ({ value });
export const result = compose(first, second);
