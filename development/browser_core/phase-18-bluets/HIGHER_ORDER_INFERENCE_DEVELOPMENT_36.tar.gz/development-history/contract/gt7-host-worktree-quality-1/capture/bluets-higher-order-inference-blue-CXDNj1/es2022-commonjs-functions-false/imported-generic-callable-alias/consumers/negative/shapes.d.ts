export type Mapper = <T>(value: T) => T;
export declare const mapper: Mapper;
