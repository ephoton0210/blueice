import { outer } from "./main";
const demanded: { value: number[] } = outer("outside")(1);
const independent: { value: string[] } = outer(1)("inside");
