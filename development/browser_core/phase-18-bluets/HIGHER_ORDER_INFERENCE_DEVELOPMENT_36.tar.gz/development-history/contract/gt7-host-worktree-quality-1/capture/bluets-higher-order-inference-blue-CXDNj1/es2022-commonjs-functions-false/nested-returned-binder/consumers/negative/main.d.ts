export declare const result: <T>(value: T) => (<U>(other: U) => [T, U])[];
