declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function list<T>(value: T): T[] { return [value]; }
function text(value: number): string { return value.toString(); }
export const result = compose(text, list);
export const demanded: string[] = result(1);
