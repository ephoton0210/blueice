import { compose } from "./higher.js";
import { list, box } from "./factories.js";
export const result = compose(list, box);
