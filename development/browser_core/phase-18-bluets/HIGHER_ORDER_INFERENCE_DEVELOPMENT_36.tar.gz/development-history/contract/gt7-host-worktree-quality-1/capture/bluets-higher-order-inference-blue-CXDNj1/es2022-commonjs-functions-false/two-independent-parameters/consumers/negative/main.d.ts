export declare const result: <T, U>(left: T, right: U) => [T, U][];
