declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function tagged<T extends { tag: string }>(value: T): T[] { return [value]; }
function box<T>(value: T): { value: T } { return { value }; }
export const result = compose(tagged, box);
export const demanded: { value: { tag: string; extra: number }[] } = result({ tag: "ok", extra: 1 });
