export declare const result: <T = string>(value: T) => T[];
export declare const demanded: number[];
