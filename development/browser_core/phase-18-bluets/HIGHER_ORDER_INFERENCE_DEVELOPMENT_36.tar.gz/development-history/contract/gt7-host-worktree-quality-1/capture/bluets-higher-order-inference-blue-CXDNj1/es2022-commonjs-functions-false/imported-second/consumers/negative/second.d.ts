export declare function box<T>(value: T): {
    value: T;
};
