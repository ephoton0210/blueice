"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.list = list; exports.box = box; function list(value){ return [value]; }
function box(value){ return { value }; }
