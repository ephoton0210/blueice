export declare function list<T>(value: T): T[];
