import { result } from "./main";
const refused: string[][] = result(1);
