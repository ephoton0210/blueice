export declare const result: (value: number) => number[];
