export declare const result: <T>(value: T) => T[];
export declare const demanded: string[];
