declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function box<T>(value: T): { value: T } { return { value }; }
import { list } from "./first";
export const result = compose(list, box);
export const demanded: { value: string[] } = result("text");
