var check = require("./main.js").result;
if (check("text").value[0] !== "text" || check(2).value[0] !== 2) throw new Error("imported composition");
