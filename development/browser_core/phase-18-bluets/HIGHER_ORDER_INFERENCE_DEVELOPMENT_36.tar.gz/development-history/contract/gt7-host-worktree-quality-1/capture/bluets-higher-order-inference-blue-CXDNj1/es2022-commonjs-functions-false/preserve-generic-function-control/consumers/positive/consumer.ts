import { result } from "./main";
const demanded: string = result("text");
const independent: number = result(1);
