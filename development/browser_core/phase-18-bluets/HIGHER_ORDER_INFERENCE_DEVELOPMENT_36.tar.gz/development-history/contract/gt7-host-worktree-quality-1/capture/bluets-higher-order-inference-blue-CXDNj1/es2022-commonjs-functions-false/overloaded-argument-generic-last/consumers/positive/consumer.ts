import { result } from "./main";
const demanded: unknown[] = result(1);
