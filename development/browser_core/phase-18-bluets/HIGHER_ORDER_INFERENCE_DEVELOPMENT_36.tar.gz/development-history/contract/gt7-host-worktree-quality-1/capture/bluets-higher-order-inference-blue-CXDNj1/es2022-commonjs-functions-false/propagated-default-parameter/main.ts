declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;
function identity<T = string>(value: T): T { return value; }
function list<T>(value: T): T[] { return [value]; }
export const result = compose(identity, list);
export const demanded: number[] = result(1);
