import { result } from "./main";
result<string>(1);
