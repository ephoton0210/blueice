var check = require("./main.js").result;
if (check.length !== 1 || check[0] !== "text") throw new Error("leading argument");
