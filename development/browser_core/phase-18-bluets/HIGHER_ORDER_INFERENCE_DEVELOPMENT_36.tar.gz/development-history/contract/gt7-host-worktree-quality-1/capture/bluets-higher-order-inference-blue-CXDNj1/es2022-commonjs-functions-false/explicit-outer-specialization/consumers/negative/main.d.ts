export declare const result: (value: string) => {
    value: string[];
};
