export declare const result: (value: boolean) => {
    value: boolean[];
};
