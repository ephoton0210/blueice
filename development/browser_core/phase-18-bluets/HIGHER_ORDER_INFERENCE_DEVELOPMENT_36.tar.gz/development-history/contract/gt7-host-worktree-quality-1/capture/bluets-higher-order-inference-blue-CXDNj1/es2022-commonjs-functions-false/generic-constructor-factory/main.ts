declare function factory<A, R>(ctor: new (value: A) => R): (value: A) => R;
class Box<T> { value: T; constructor(value: T) { this.value = value; } }
export const result = factory(Box);
export const demanded: Box<string> = result("text");
