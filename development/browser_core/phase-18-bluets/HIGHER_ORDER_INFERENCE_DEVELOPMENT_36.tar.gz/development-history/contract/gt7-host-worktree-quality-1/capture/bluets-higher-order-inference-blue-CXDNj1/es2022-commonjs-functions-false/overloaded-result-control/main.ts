declare function overloaded<A, B>(fn: (value: A) => B): { (value: A): B; (): B | undefined };
function identity<T>(value: T): T { return value; }
export const result = overloaded(identity);
