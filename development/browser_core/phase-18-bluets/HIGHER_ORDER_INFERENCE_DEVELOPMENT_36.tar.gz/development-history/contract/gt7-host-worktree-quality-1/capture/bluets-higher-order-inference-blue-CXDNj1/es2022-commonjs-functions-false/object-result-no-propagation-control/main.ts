declare function container<A, B>(fn: (value: A) => B): { run: (value: A) => B };
function identity<T>(value: T): T { return value; }
export const result = container(identity);
