declare function optionalLift<A, B>(fn: (value?: A) => B): (value?: A) => B[];
function optional<T>(value?: T): T | undefined { return value; }
export const result = optionalLift(optional);
