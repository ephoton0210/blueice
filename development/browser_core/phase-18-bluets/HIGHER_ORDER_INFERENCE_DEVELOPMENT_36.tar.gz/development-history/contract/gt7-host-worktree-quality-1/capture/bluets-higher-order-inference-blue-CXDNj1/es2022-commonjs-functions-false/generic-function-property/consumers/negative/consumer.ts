import { result } from "./main";
const refused: number[][] = result("text");
