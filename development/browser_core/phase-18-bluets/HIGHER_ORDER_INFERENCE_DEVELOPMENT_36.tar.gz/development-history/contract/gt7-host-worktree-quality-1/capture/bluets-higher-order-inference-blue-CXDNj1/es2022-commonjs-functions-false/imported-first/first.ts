export function list<T>(value: T): T[] { return [value]; }
