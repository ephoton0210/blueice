"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; function lift(fn){ return value => [fn(value)]; }
function identity(value){ return value; }
exports.result = lift(identity);
