import { result } from "./main";
const refused: number = new result("text").value;
