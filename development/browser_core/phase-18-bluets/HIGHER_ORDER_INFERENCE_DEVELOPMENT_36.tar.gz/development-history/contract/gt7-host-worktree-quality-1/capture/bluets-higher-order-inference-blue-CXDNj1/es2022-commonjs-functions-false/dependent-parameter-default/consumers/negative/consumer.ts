import { result } from "./main";
const refused: [number, string[]][] = result<number>(1, [2]);
