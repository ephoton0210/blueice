"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = void 0; function compose3(one, two, three){ return value => three(two(one(value))); }
function list(value){ return [value]; }
function box(value){ return { value }; }
exports.result = compose3(list, box, list);
