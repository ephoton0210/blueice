type Infer<T> = T extends (x: infer U) => infer U ? U : "miss";
declare const value: Infer<(x: string) => "ok">;
export const result = value;
export const check: "ok" = result;
