import { result } from "./main";
const bad: typeof result = { a: "ok" };
