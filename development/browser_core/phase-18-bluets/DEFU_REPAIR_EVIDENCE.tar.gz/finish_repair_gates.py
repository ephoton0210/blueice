from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,shutil
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';root=Path('/private/tmp/bluets-next-project-20261110')
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state=read(root/'repair-acceptance.json');source=read(root/'frozen-source-preflight.json')
assert state['conclusion']=='failure' and state['stage']=='workspace'
failed=[row for row in state['steps'] if row['exit']!=0]
assert len(failed)==1 and failed[0]['label']=='workspace' and failed[0]['exit']==101
firstlog=root/failed[0]['log'];text=firstlog.read_text(errors='replace');assert sha(firstlog)==failed[0]['sha256']
pattern=r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;'
rows=re.findall(pattern,text);assert rows and all(r[4]=='0' for r in rows)
markers=list(re.finditer(r'(?m)^\s+(?:Running [^\n]+\((target/debug/deps/[^)]+)\)|Doc-tests [^\n]+)\n',text))
assert len(markers)==len(rows)
segments=[]
for i,m in enumerate(markers):
 part=text[m.end():markers[i+1].start() if i+1<len(markers) else len(text)]
 summary=re.findall(pattern,part);assert len(summary)==1
 errors=re.findall(r'error: test failed, to rerun pass `([^`]+)`',part)
 segment={'executable':m.group(1),'summary':summary[0],'command':errors[0] if errors else None}
 assert len(errors)==(1 if summary[0][0]=='FAILED' else 0)
 segments.append(segment)
replays=[s for s in segments if s['summary'][0]=='FAILED'];assert len(replays)==17
assert {s['command'] for s in replays}==set(re.findall(r'error: test failed, to rerun pass `([^`]+)`',text))
assert re.search(r'error: 17 targets failed:',text)
buildlog=root/'repair-workspace-build.log';expected=re.findall(r'Executable [^\n]*\((target/debug/deps/[^)]+)\)',buildlog.read_text());observed=[s['executable'] for s in segments if s['executable']]
assert expected and len(expected)==len(set(expected)) and len(observed)==len(expected) and set(observed)==set(expected)
assert all(s['executable'] for s in replays)
assert all(not r['bound'] for r in read(root/'socket-probe-denied.json')['results'])
assert all(r['bound'] for r in read(root/'socket-probe-allowed.json')['results'])
for name,count in [('regex-deadlines-replay.json',5),('regex-deadlines-parallel-replay.json',10)]:
 replay=read(root/name);assert replay['conclusion']=='pass' and len(replay['attempts'])==count
 for attempt in replay['attempts']:assert attempt['exit']==0 and sha(root/attempt['log'])==attempt['logSha256']
original_dir=root/'workspace-initial-attempt';original_dir.mkdir(exist_ok=True);shutil.copy2(root/'repair-acceptance.json',original_dir/'repair-acceptance.json')
target_receipt={'sourceRevision':source['sourceRevision'],'conclusion':'pass','expectedTargets':len(expected),'executedTargets':len(observed),'allCompiledTargetsExecuted':True,'completeResultGroups':len(rows),'workspaceBuildLogSha256':sha(buildlog),'fullCommandLogSha256':sha(firstlog),'originalCommandExit':101,'originalFailedTargets':[s['command'] for s in replays],'originalFailedFunctions':sum(int(r[2]) for r in rows),'note':'Every compiled target ran. All failed complete targets require successful unchanged-binary replay with local sockets permitted; no failed observation is credited. Existing ignored functions retain their classifications; complete pinned Native cohort is separately measured.'}
(root/'complete-workspace-target-selection.json').write_text(json.dumps(target_receipt,indent=2)+'\n')
state['workspaceInitialAttempt']={'conclusion':'failure','command':failed[0],'resultGroups':len(rows),'passed':sum(int(r[1]) for r in rows),'failed':sum(int(r[2]) for r in rows),'failedTargets':[s['command'] for s in replays],'ignored':sum(int(r[3]) for r in rows),'filtered':0,'scope':'Complete no-fail-fast workspace command. One RegExp wall-clock assertion and local socket permission failures; complete raw target and diagnostic observations retained.'}
state['steps']=[row for row in state['steps'] if row['exit']==0];state.update(conclusion='in_progress',stage='workspace-target-replays');state.pop('error',None);state.pop('finishedAt',None)
env=dict(os.environ,PATH=read(root/'frozen-executable-paths.json')['PATH'],CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0',BLUEICE_GE5_EXPECTED_COMPILER_SHA256=state['workspaceCompilerSha256'])
def save():(root/'repair-acceptance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,cwd=repo):
 state['stage']=label;save();log=root/('repair-'+label+'.log')
 with log.open('wb') as out:r=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':args,'cwd':str(cwd),'exit':r.returncode,'log':log.name,'sha256':sha(log)});save()
 if r.returncode:raise RuntimeError(f'{label}: exit {r.returncode}')
 return log
members=re.findall(r'"(backend/[^"]+)"',(repo/'Cargo.toml').read_text())
packages={re.search(r'(?m)^name\s*=\s*"([^"]+)"',(repo/member/'Cargo.toml').read_text()).group(1):repo/member for member in members}
try:
 save();cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
 run('source-replay-preflight',cargo+['--check-staged'])
 assert sha(repo/'target/debug/bluetsc')==state['workspaceCompilerSha256']
 replayed=[];receipt=root/'workspace-target-replays.json'
 for index,s in enumerate(replays):
  executable=repo/s['executable'];digest=sha(executable);package=re.match(r'-p (\S+)',s['command']).group(1);cwd=packages[package]
  if package=='blueice-bluejs':
   old=read(root/'regex-deadlines-replay.json');assert digest==old['testExecutableSha256'] and sha(repo/'target/debug/bluejs-regexp-worker')==old['workerSha256']
  listing=run(f'workspace-replay-{index:02d}-catalog',[str(executable),'--list'],cwd).read_text()
  names=re.findall(r'^(.+): test$',listing,re.M);assert len(names)==int(s['summary'][1])+int(s['summary'][2])+int(s['summary'][3])
  log=run(f'workspace-replay-{index:02d}',[str(executable),'--test-threads=4'],cwd)
  actual=re.findall(pattern,log.read_text(errors='replace'))
  assert actual==[('ok',str(int(s['summary'][1])+int(s['summary'][2])),'0',s['summary'][3],'0')]
  assert sha(executable)==digest and sha(repo/'target/debug/bluetsc')==state['workspaceCompilerSha256']
  replayed.append({'initialCommand':s['command'],'executable':s['executable'],'executableSha256':digest,'cwd':str(cwd),'selectedTests':names,'testThreads':4,'log':log.name,'logSha256':sha(log),'passed':int(actual[0][1]),'ignored':int(actual[0][3]),'failed':0,'filtered':0})
  receipt.write_text(json.dumps({'sourceRevision':state['sourceRevision'],'compilerSha256':state['workspaceCompilerSha256'],'requiredTargets':len(replays),'replayedTargets':replayed,'conclusion':'pass' if len(replayed)==len(replays) else 'in_progress','permissionProbe':'socket-probe-allowed.json','limitsUnchanged':True},indent=2)+'\n')
 state['workspace']={'passed':sum(int(r[1])+int(r[2]) for r in rows),'failed':0,'ignored':sum(int(r[3]) for r in rows),'filtered':0,'groups':len(rows),'collectionMode':'complete-workspace-across-unchanged-source-target-replays','initialCommandExit':101,'replayedTargets':len(replayed),'replayedTargetPasses':sum(r['passed'] for r in replayed),'retainedSuccessfulGroups':len(rows)-len(replayed),'initialFailureRetained':True,'serialCompleteRegexTargetRepeats':5,'originalFourThreadCompleteRegexTargetRepeats':10,'limitsUnchanged':True};save()
 run('fmt-check',['cargo','fmt','--all','--','--check']);run('clippy',['cargo','clippy','--workspace','--all-targets','--features','blueice-bluets/windows-symlink-tests','--','-D','warnings'])
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))+sorted((repo/'differential-testing/bluets-projects').glob('*.test.cjs'))
 run('node-tools',['node','--test',*[str(p) for p in tests]]);run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,args)
 state.update(stage='local-complete-awaiting-publication',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(conclusion='failure',error=repr(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
