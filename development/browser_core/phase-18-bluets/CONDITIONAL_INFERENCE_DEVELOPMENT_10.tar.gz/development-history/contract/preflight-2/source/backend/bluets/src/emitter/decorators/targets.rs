// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Reparse owned decorator output before applying existing class and ES5 transforms.

use super::super::{class_lowering, targets, EmittedJavaScript, Module};
use crate::compiler::{CompilerOptions, Project};
use crate::diagnostic::Diagnostic;

pub(in crate::emitter) fn lower(
    mut emitted: EmittedJavaScript,
    module: &Module,
    project: &Project,
    options: &CompilerOptions,
) -> Result<EmittedJavaScript, Diagnostic> {
    let legacy_accessors = options.experimental_decorators
        && options.target != crate::EcmaTarget::EsNext
        && module.classes().any(|class| {
            class
                .members
                .iter()
                .any(|member| member.field.as_ref().is_some_and(|field| field.accessor))
        });
    let generated_es5 = options.target == crate::EcmaTarget::Es5
        && class_lowering::has_wrapped_class_expressions(module);
    if !legacy_accessors
        && !generated_es5
        && (options.experimental_decorators
            || super::preserves_proposals(options)
            || (options.target >= crate::EcmaTarget::Es2022 && options.defines_class_fields())
            || !super::has_standard_lowering(module))
    {
        return Ok(emitted);
    }
    let owned = crate::parser::parse_emitted_module(
        &module.id,
        &emitted.javascript,
        &options.limits.parser,
    )
    .map_err(|mut errors| errors.remove(0))?;
    let mut edits = owned.edits.clone();
    class_lowering::lower_generated_class_members(&owned, options, &mut edits, module, &emitted)?;
    emitted =
        class_lowering::mapped_generated_class_edits(emitted, edits, module, &owned, options)?;
    if options.target == crate::EcmaTarget::Es5 {
        let owned = crate::parser::parse_emitted_module(
            &module.id,
            &emitted.javascript,
            &options.limits.parser,
        )
        .map_err(|mut errors| errors.remove(0))?;
        let mut owned_project = project.clone();
        owned_project
            .modules
            .insert(module.id.clone(), owned.clone());
        let mut edits = owned.edits.clone();
        let lexical = targets::es5::prepare_generated(
            &owned,
            &owned_project,
            options,
            &mut edits,
            module,
            &emitted,
        )?;
        emitted = targets::mapped_edits(emitted, edits);
        emitted = targets::es5::lower_generated(emitted, &owned, module, options, &lexical)?;
    }
    Ok(emitted)
}
