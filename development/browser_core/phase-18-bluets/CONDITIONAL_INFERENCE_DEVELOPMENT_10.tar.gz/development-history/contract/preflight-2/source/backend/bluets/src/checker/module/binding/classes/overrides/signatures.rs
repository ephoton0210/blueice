// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Inherited signatures and fixed/variadic parameter compatibility.

use super::*;

pub(super) struct InheritedMethod<'a> {
    pub(super) base_name: String,
    pub(super) parameters: &'a [Parameter],
    pub(super) return_type: Option<&'a Type>,
}

#[derive(Clone, Copy)]
pub(super) enum RestShape {
    None,
    MatchingArrays,
    DerivedCoversFixed(usize),
    BaseCoversFixed(usize),
    ShiftedArrays {
        derived_fixed: usize,
        inherited_fixed: usize,
    },
    DerivedTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        inherited_array_rest: bool,
    },
    DerivedTrailingTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        inherited_array_rest: bool,
    },
    DerivedMiddleTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        inherited_array_rest: bool,
    },
    InheritedTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        derived_array_rest: bool,
    },
    InheritedTrailingTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        derived_array_rest: bool,
    },
    InheritedMiddleTuple {
        derived_fixed: usize,
        inherited_fixed: usize,
        derived_array_rest: bool,
    },
    BothTuples {
        derived_fixed: usize,
        inherited_fixed: usize,
    },
    BothTrailingTuples {
        derived_fixed: usize,
        inherited_fixed: usize,
    },
    BothVariableTuples {
        derived_fixed: usize,
        inherited_fixed: usize,
    },
    MiddleFixedTuples {
        derived_fixed: usize,
        inherited_fixed: usize,
        derived_variable: bool,
    },
    OptionalFixedMiddleTuples,
}

pub(super) fn specialize_class_rest_parameters(
    parameters: &[Parameter],
    types: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> Result<Vec<Parameter>, TupleSpreadError> {
    let mut specialized = parameters.to_vec();
    for parameter in &mut specialized {
        if parameter.rest {
            if let Some(annotation @ (Type::Tuple(_) | Type::Named { .. })) =
                parameter.annotation.as_ref()
            {
                parameter.annotation =
                    Some(specialize_class_rest_annotation(annotation, types, budget)?);
            }
        }
    }
    Ok(specialized)
}

pub(super) struct OwnedInheritedMethod {
    pub(super) base_name: String,
    pub(super) parameters: Vec<Parameter>,
    pub(super) return_type: Option<Type>,
}

pub(super) fn nearest_inherited_method(
    declarations: &[Declaration],
    types: &BTreeMap<String, TypeDefinition>,
    values: &BTreeMap<String, Type>,
    constructors: &BTreeMap<String, ClassConstructorBinding>,
    class: &ClassDeclaration,
    group: &ClassMethodGroup,
    max_edges: usize,
) -> Option<OwnedInheritedMethod> {
    let mut base_name = class.extends_name.clone();
    let mut arguments = class.extends_arguments.clone();
    let mut visited = BTreeSet::new();
    for _ in 0..max_edges {
        let name = base_name?;
        if !visited.insert(name.clone()) {
            return None;
        }
        let base = declarations.iter().find_map(|declaration| {
            let Declaration::Class(base) = declaration else {
                return None;
            };
            (base.name == name && base.name_span.start < class.name_span.start).then_some(base)
        });
        let parameters = base
            .map(|base| base.type_parameters.as_slice())
            .or_else(|| {
                types
                    .get(&name)
                    .map(|definition| definition.parameters.as_slice())
            })?;
        let substitutions = super::super::heritage::heritage_substitutions(parameters, &arguments);
        let label = type_label(&Type::Named {
            name: name.clone(),
            arguments: arguments.clone(),
        });
        if let Some(base) = base {
            if let Some(candidate) = base.method_groups.iter().find(|candidate| {
                candidate.name == group.name && candidate.is_static == group.is_static
            }) {
                if !candidate.signature_member_indices.is_empty() {
                    return None;
                }
                let method = candidate
                    .implementation_member_index
                    .and_then(|index| base.members[index].method.as_ref())?;
                let value = if method.type_parameters.is_empty() {
                    Type::Function {
                        parameters: method.parameters.clone(),
                        result: Box::new(method.return_type.clone().unwrap_or(Type::Unknown)),
                    }
                } else {
                    Type::GenericFunction {
                        type_parameters: method.type_parameters.clone(),
                        parameters: method.parameters.clone(),
                        result: Box::new(method.return_type.clone().unwrap_or(Type::Unknown)),
                        span: method.span.clone(),
                    }
                };
                let (Type::Function { parameters, result }
                | Type::GenericFunction {
                    parameters, result, ..
                }) = substitute_type(&value, &substitutions)
                else {
                    unreachable!()
                };
                return Some(OwnedInheritedMethod {
                    base_name: label,
                    parameters,
                    return_type: method.return_type.as_ref().map(|_| *result),
                });
            }
            arguments = base
                .extends_arguments
                .iter()
                .map(|value| substitute_type(value, &substitutions))
                .collect();
            base_name = base.extends_name.clone();
            continue;
        }
        if declarations.iter().any(
            |declaration| matches!(declaration, Declaration::Class(local) if local.name == name),
        ) || !constructors.contains_key(&name)
        {
            return None;
        }
        let surface = if group.is_static {
            values.get(&name)
        } else {
            types.get(&name).and_then(|definition| {
                (definition.kind == TypeDefinitionKind::Class).then_some(&definition.value)
            })
        };
        let (Type::Record(fields) | Type::CallableRecord { fields, .. }) = surface? else {
            return None;
        };
        let mut matching = fields.iter().filter(|field| field.name == group.name);
        let field = matching.next()?;
        if matching.next().is_some() {
            return None;
        }
        let (Type::Function { parameters, result }
        | Type::GenericFunction {
            parameters, result, ..
        }) = substitute_type(&field.value, &substitutions)
        else {
            return None;
        };
        return Some(OwnedInheritedMethod {
            base_name: label,
            parameters,
            return_type: Some(*result),
        });
    }
    None
}

pub(super) fn rest_shape(derived: &[Parameter], inherited: &[Parameter]) -> Option<RestShape> {
    if let (Some((derived_rest, derived_fixed)), Some((inherited_rest, inherited_fixed))) =
        (derived.split_last(), inherited.split_last())
    {
        let middle_fixed_pair = match (
            derived_rest.annotation.as_ref(),
            inherited_rest.annotation.as_ref(),
        ) {
            (Some(Type::Tuple(derived_elements)), Some(Type::Tuple(inherited_elements))) => {
                let derived_middle = derived_elements
                    .iter()
                    .position(|element| element.rest)
                    .is_some_and(|index| index + 1 < derived_elements.len());
                let inherited_middle = inherited_elements
                    .iter()
                    .position(|element| element.rest)
                    .is_some_and(|index| index + 1 < inherited_elements.len());
                let derived_is_fixed = derived_elements.iter().all(|element| !element.rest);
                let inherited_is_fixed = inherited_elements.iter().all(|element| !element.rest);
                if (derived_middle && inherited_is_fixed) || (inherited_middle && derived_is_fixed)
                {
                    Some((
                        derived_middle,
                        derived_elements.iter().any(|element| element.optional)
                            || inherited_elements.iter().any(|element| element.optional),
                    ))
                } else {
                    None
                }
            }
            _ => None,
        };
        if let Some((derived_variable, has_optional)) = middle_fixed_pair {
            if derived_rest.rest
                && inherited_rest.rest
                && !derived_fixed
                    .iter()
                    .chain(inherited_fixed)
                    .any(|parameter| parameter.rest)
            {
                return Some(if has_optional {
                    RestShape::OptionalFixedMiddleTuples
                } else {
                    RestShape::MiddleFixedTuples {
                        derived_fixed: derived_fixed.len(),
                        inherited_fixed: inherited_fixed.len(),
                        derived_variable,
                    }
                });
            }
        }
    }
    if let (Some((derived_rest, derived_fixed)), Some((inherited_rest, inherited_fixed))) =
        (derived.split_last(), inherited.split_last())
    {
        let variable_tuples = match (
            derived_rest.annotation.as_ref(),
            inherited_rest.annotation.as_ref(),
        ) {
            (Some(Type::Tuple(derived_elements)), Some(Type::Tuple(inherited_elements))) => {
                let derived_rest_index = derived_elements.iter().position(|element| element.rest);
                let inherited_rest_index =
                    inherited_elements.iter().position(|element| element.rest);
                derived_rest_index.is_some()
                    && inherited_rest_index.is_some()
                    && (derived_rest_index.is_some_and(|index| index + 1 < derived_elements.len())
                        || inherited_rest_index
                            .is_some_and(|index| index + 1 < inherited_elements.len()))
            }
            _ => false,
        };
        if derived_rest.rest
            && inherited_rest.rest
            && !derived_fixed
                .iter()
                .chain(inherited_fixed)
                .any(|parameter| parameter.rest)
            && variable_tuples
        {
            return Some(RestShape::BothVariableTuples {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited_fixed.len(),
            });
        }
    }
    if let Some((derived_rest, derived_fixed)) = derived.split_last() {
        let derived_middle_rest = matches!(
            derived_rest.annotation.as_ref(),
            Some(Type::Tuple(elements))
                if elements.iter().position(|element| element.rest)
                    .is_some_and(|index| index + 1 < elements.len())
        );
        if derived_rest.rest
            && !derived_fixed.iter().any(|parameter| parameter.rest)
            && derived_middle_rest
        {
            let inherited_array_rest = inherited.last().is_some_and(|parameter| {
                parameter.rest && matches!(parameter.annotation.as_ref(), Some(Type::Array(_)))
            });
            if inherited.iter().any(|parameter| parameter.rest) && !inherited_array_rest {
                return None;
            }
            return Some(RestShape::DerivedMiddleTuple {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited.len() - usize::from(inherited_array_rest),
                inherited_array_rest,
            });
        }
    }
    if let Some((inherited_rest, inherited_fixed)) = inherited.split_last() {
        let inherited_middle_rest = matches!(
            inherited_rest.annotation.as_ref(),
            Some(Type::Tuple(elements))
                if elements.iter().position(|element| element.rest)
                    .is_some_and(|index| index + 1 < elements.len())
        );
        if inherited_rest.rest
            && !inherited_fixed.iter().any(|parameter| parameter.rest)
            && inherited_middle_rest
        {
            let derived_array_rest = derived.last().is_some_and(|parameter| {
                parameter.rest && matches!(parameter.annotation.as_ref(), Some(Type::Array(_)))
            });
            if derived.iter().any(|parameter| parameter.rest) && !derived_array_rest {
                return None;
            }
            return Some(RestShape::InheritedMiddleTuple {
                derived_fixed: derived.len() - usize::from(derived_array_rest),
                inherited_fixed: inherited_fixed.len(),
                derived_array_rest,
            });
        }
    }
    let inherited_variadic = inherited.iter().any(|parameter| {
        matches!(
            parameter.annotation.as_ref(),
            Some(Type::Tuple(elements))
                if elements.iter().any(|element| element.rest)
        )
    });
    if inherited_variadic
        && (!inherited.last().is_some_and(|parameter| {
            parameter.rest
                && matches!(parameter.annotation.as_ref(), Some(Type::Tuple(elements)) if elements.last().is_some_and(|element| element.rest))
        })
            || derived.last().is_some_and(|parameter| {
                parameter.rest
                    && matches!(parameter.annotation.as_ref(), Some(Type::Tuple(elements)) if !elements.last().is_some_and(|element| element.rest))
            }))
    {
        return None;
    }
    let derived_variadic = derived.iter().any(|parameter| {
        matches!(
            parameter.annotation.as_ref(),
            Some(Type::Tuple(elements))
                if elements.iter().any(|element| element.rest)
        )
    });
    if derived_variadic
        && !derived.last().is_some_and(|parameter| {
            parameter.rest
                && matches!(parameter.annotation.as_ref(), Some(Type::Tuple(elements)) if elements.last().is_some_and(|element| element.rest))
        })
    {
        return None;
    }
    let derived_has_rest = derived.iter().any(|parameter| parameter.rest);
    let inherited_has_rest = inherited.iter().any(|parameter| parameter.rest);
    if !derived_has_rest && !inherited_has_rest {
        return Some(RestShape::None);
    }
    if !derived_has_rest {
        let (inherited_rest, inherited_fixed) = inherited.split_last()?;
        if !inherited_rest.rest || inherited_fixed.iter().any(|parameter| parameter.rest) {
            return None;
        }
        return match inherited_rest.annotation.as_ref() {
            Some(Type::Array(_)) => Some(RestShape::BaseCoversFixed(inherited_fixed.len())),
            Some(Type::Tuple(elements)) if elements.last().is_some_and(|element| element.rest) => {
                Some(RestShape::InheritedTrailingTuple {
                    derived_fixed: derived.len(),
                    inherited_fixed: inherited_fixed.len(),
                    derived_array_rest: false,
                })
            }
            Some(Type::Tuple(_)) => Some(RestShape::InheritedTuple {
                derived_fixed: derived.len(),
                inherited_fixed: inherited_fixed.len(),
                derived_array_rest: false,
            }),
            _ => None,
        };
    }
    let (derived_rest, derived_fixed) = derived.split_last()?;
    if !derived_rest.rest || derived_fixed.iter().any(|parameter| parameter.rest) {
        return None;
    }
    if let Some(Type::Tuple(elements)) = derived_rest.annotation.as_ref() {
        let inherited_array_rest = inherited.last().is_some_and(|parameter| {
            parameter.rest && matches!(parameter.annotation.as_ref(), Some(Type::Array(_)))
        });
        if elements.last().is_some_and(|element| element.rest) {
            if inherited_variadic {
                let (inherited_rest, inherited_fixed) = inherited.split_last()?;
                return (inherited_rest.rest
                    && !inherited_fixed.iter().any(|parameter| parameter.rest))
                .then_some(RestShape::BothTrailingTuples {
                    derived_fixed: derived_fixed.len(),
                    inherited_fixed: inherited_fixed.len(),
                });
            }
            if inherited_has_rest && !inherited_array_rest {
                return None;
            }
            return Some(RestShape::DerivedTrailingTuple {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited.len() - usize::from(inherited_array_rest),
                inherited_array_rest,
            });
        }
        if inherited_has_rest && !inherited_array_rest {
            let (inherited_rest, inherited_fixed) = inherited.split_last()?;
            return (inherited_rest.rest
                && !inherited_fixed.iter().any(|parameter| parameter.rest)
                && matches!(inherited_rest.annotation.as_ref(), Some(Type::Tuple(_))))
            .then_some(RestShape::BothTuples {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited_fixed.len(),
            });
        }
        return Some(RestShape::DerivedTuple {
            derived_fixed: derived_fixed.len(),
            inherited_fixed: inherited.len() - usize::from(inherited_array_rest),
            inherited_array_rest,
        });
    }
    if !matches!(derived_rest.annotation.as_ref(), Some(Type::Array(_))) {
        return None;
    }
    if !inherited_has_rest && derived_fixed.len() <= inherited.len() {
        return Some(RestShape::DerivedCoversFixed(derived_fixed.len()));
    }
    let (inherited_rest, inherited_fixed) = inherited.split_last()?;
    if inherited_rest.rest
        && !inherited_fixed.iter().any(|parameter| parameter.rest)
        && matches!(inherited_rest.annotation.as_ref(), Some(Type::Tuple(_)))
    {
        return Some(if inherited_variadic {
            RestShape::InheritedTrailingTuple {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited_fixed.len(),
                derived_array_rest: true,
            }
        } else {
            RestShape::InheritedTuple {
                derived_fixed: derived_fixed.len(),
                inherited_fixed: inherited_fixed.len(),
                derived_array_rest: true,
            }
        });
    }
    if !inherited_rest.rest
        || inherited_fixed.iter().any(|parameter| parameter.rest)
        || !matches!(inherited_rest.annotation.as_ref(), Some(Type::Array(_)))
    {
        return None;
    }
    if inherited_fixed.len() == derived_fixed.len() {
        Some(RestShape::MatchingArrays)
    } else {
        Some(RestShape::ShiftedArrays {
            derived_fixed: derived_fixed.len(),
            inherited_fixed: inherited_fixed.len(),
        })
    }
}

pub(super) fn fixed_tuple_required(parameters: &[Parameter], fixed: usize) -> usize {
    let Some(Type::Tuple(elements)) = parameters
        .last()
        .and_then(|parameter| parameter.annotation.as_ref())
    else {
        unreachable!("rest shape requires a tuple annotation")
    };
    if elements.is_empty() {
        parameters[..fixed]
            .iter()
            .filter(|parameter| !parameter.optional)
            .count()
    } else {
        fixed + elements.len()
    }
}

pub(super) fn middle_tuple_required(parameters: &[Parameter], fixed: usize) -> usize {
    let Some(Type::Tuple(elements)) = parameters
        .last()
        .and_then(|parameter| parameter.annotation.as_ref())
    else {
        unreachable!("rest shape requires a tuple annotation")
    };
    fixed
        + elements
            .iter()
            .filter(|element| !element.optional && !element.rest)
            .count()
}

pub(super) fn middle_tuple_prefix(parameters: &[Parameter]) -> usize {
    let Some(Type::Tuple(elements)) = parameters
        .last()
        .and_then(|parameter| parameter.annotation.as_ref())
    else {
        unreachable!("rest shape requires a tuple annotation")
    };
    elements
        .iter()
        .position(|element| element.rest)
        .expect("middle tuple rest shape requires a rest element")
}

pub(super) fn override_parameter_type(parameter: &Parameter) -> Type {
    let annotation = parameter.annotation.clone().unwrap_or(Type::Unknown);
    if parameter.optional {
        Type::Union(vec![annotation, Type::Undefined])
    } else {
        annotation
    }
}

pub(super) fn parameter_types_compatible(
    derived: &Type,
    inherited: &Type,
    aliases: &BTreeMap<String, TypeDefinition>,
    budget: &mut TypeExpansionBudget,
) -> bool {
    is_assignable(derived, inherited, aliases, &mut HashSet::new(), budget)
        || is_assignable(inherited, derived, aliases, &mut HashSet::new(), budget)
}
