// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Object types preserve call/construct signatures alongside data members.

use super::*;

impl Parser {
    pub(super) fn parse_constructor_type(&mut self, stop: &[&str]) -> Type {
        let start = self.current().start;
        let abstract_constructor = self.consume("abstract");
        self.expect("new");
        let type_parameters = self.parse_type_parameters();
        let parameters = self.parse_parameters();
        self.expect("=>");
        let result = self.parse_type_until(stop);
        Type::CallableRecord {
            fields: Vec::new(),
            signatures: vec![TypeSignature {
                construct: true,
                abstract_constructor,
                constructor_visibility: Visibility::Public,
                constructor_arrow: true,
                type_parameters,
                parameters,
                result,
                span: SourceSpan::new(&self.id, start, self.previous().end),
            }],
        }
    }

    pub(in crate::parser) fn parse_record_type(&mut self, field_expectation: &str) -> Type {
        let mut fields = Vec::new();
        let mut signatures = Vec::new();
        let mut indices = Vec::new();
        let mut closed = false;
        while !self.at_eof() {
            if self.consume("}") {
                closed = true;
                break;
            }
            let start = self.current().start;
            let construct = self.peek("new")
                && self
                    .tokens
                    .get(self.index + 1)
                    .is_some_and(|token| token.is("(") || token.is("<"));
            if construct || self.peek("(") || self.peek("<") {
                if construct {
                    self.bump();
                }
                let type_parameters = self.parse_type_parameters();
                let Type::Function { parameters, result } =
                    self.parse_method_signature(&[";", ",", "}"])
                else {
                    unreachable!()
                };
                signatures.push(TypeSignature {
                    construct,
                    abstract_constructor: false,
                    constructor_visibility: Visibility::Public,
                    constructor_arrow: false,
                    type_parameters,
                    parameters,
                    result: *result,
                    span: SourceSpan::new(&self.id, start, self.previous().end),
                });
            } else {
                let readonly = self.consume("readonly");
                let computed = self.peek("[")
                    && self
                        .tokens
                        .get(self.index + 2)
                        .is_none_or(|token| !token.is(":"));
                if !computed && self.consume("[") {
                    let name = self.require_identifier("expected an index parameter name");
                    self.expect(":");
                    let key_start = self.current().start;
                    let key = self.parse_type_until(&["]"]);
                    let key_span = SourceSpan::new(&self.id, key_start, self.previous().end);
                    self.expect("]");
                    self.expect(":");
                    let value = self.parse_type_until(&[";", ",", "}"]);
                    indices.push(IndexSignature {
                        mapped_domain: None,
                        name,
                        key,
                        value,
                        readonly,
                        key_span,
                        span: SourceSpan::new(&self.id, start, self.previous().end),
                    });
                    self.consume(";");
                    self.consume(",");
                    continue;
                }
                let name = if computed {
                    self.bump();
                    let mut entity = self.require_identifier("expected a computed entity name");
                    while self.consume(".") {
                        entity.push('.');
                        entity.push_str(&self.require_identifier("expected an entity member"));
                    }
                    self.expect("]");
                    crate::symbol_keys::name(&self.id, &entity)
                } else {
                    self.require_property_name(field_expectation)
                };
                let optional = self.consume("?");
                let method = self.peek("(") || self.peek("<");
                let value = if method {
                    let type_parameters = self.parse_type_parameters();
                    let function = self.parse_method_signature(&[";", ",", "}"]);
                    if type_parameters.is_empty() {
                        function
                    } else {
                        let Type::Function { parameters, result } = function else {
                            unreachable!()
                        };
                        Type::GenericFunction {
                            type_parameters,
                            parameters,
                            result,
                            span: SourceSpan::new(&self.id, start, self.previous().end),
                        }
                    }
                } else {
                    self.expect(":");
                    self.parse_type_until(&[";", ",", "}"])
                };
                fields.push(TypeField {
                    accessor_write_type: None,
                    method,
                    name,
                    readonly,
                    optional,
                    value,
                    span: SourceSpan::new(&self.id, start, self.previous().end),
                });
            }
            self.consume(";");
            self.consume(",");
        }
        if !closed {
            self.expect("}");
        }
        let object = if signatures.is_empty() {
            Type::Record(fields)
        } else {
            Type::CallableRecord { fields, signatures }
        };
        if indices.is_empty() {
            object
        } else {
            Type::IndexedRecord {
                object: Box::new(object),
                indices,
            }
        }
    }
}

impl TypeSignature {
    pub(crate) fn function_type(&self) -> Type {
        Type::GenericFunction {
            type_parameters: self.type_parameters.clone(),
            parameters: self.parameters.clone(),
            result: Box::new(self.result.clone()),
            span: self.span.clone(),
        }
    }

    pub(crate) fn map_types(&self, transform: impl FnOnce(&Type) -> Type) -> Self {
        let Type::GenericFunction {
            type_parameters,
            parameters,
            result,
            ..
        } = transform(&self.function_type())
        else {
            unreachable!("signature transformation preserves callable binders")
        };
        Self {
            type_parameters,
            parameters,
            result: *result,
            ..self.clone()
        }
    }
}
