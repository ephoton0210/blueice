// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Constructor, method and static-block bodies.

use super::*;

#[derive(Clone, Copy)]
pub(super) enum ClassBodyReturnRule<'a> {
    Constructor {
        class_name: &'a str,
        instance_type: &'a Type,
        /// The base whose constructor a `super(...)` call must satisfy.
        super_class: &'a ClassDeclaration,
    },
    Method {
        return_type: Option<&'a Type>,
        allows_implicit_undefined: bool,
        setter: bool,
    },
    /// A `static { .. }` block, which cannot `return`.
    StaticBlock,
}

impl ModuleChecker<'_> {
    pub(in crate::checker::module::binding) fn check_class_constructor_bodies(
        &mut self,
        class: &ClassDeclaration,
    ) {
        let instance_type = self
            .types
            .get(&class.name)
            .filter(|definition| definition.kind == TypeDefinitionKind::Class)
            .map(|definition| definition.value.clone())
            .unwrap_or_else(|| class_instance_type(class));
        for constructor in class
            .members
            .iter()
            .filter_map(|member| member.constructor.as_ref())
        {
            let Some(body) = &constructor.body else {
                continue;
            };
            let mut scope = self.class_body_parameter_scope(&constructor.parameters);
            scope.insert("this".to_string(), class_body_this_type(class));
            if let Some(base) = self.super_scope_type(class, false) {
                scope.insert("super".to_string(), base);
            }
            hoist_local_functions(body, &mut scope);
            self.check_constructor_super_placement(class, constructor, body);
            self.constructor_readonly_fields = Some(
                class
                    .members
                    .iter()
                    .filter_map(|member| member.field.as_ref())
                    .chain(class.parameter_property_fields().iter())
                    .filter(|field| field.readonly && !field.is_static)
                    .map(|field| field.name.clone())
                    .collect(),
            );
            self.check_class_body_items(
                body,
                &scope,
                ClassBodyReturnRule::Constructor {
                    class_name: &class.name,
                    instance_type: &instance_type,
                    super_class: class,
                },
            );
            self.constructor_readonly_fields = None;
        }
    }

    pub(in crate::checker::module::binding) fn check_class_method_bodies(
        &mut self,
        class: &ClassDeclaration,
    ) {
        let constructor_side = self
            .values
            .get(&class.name)
            .cloned()
            .unwrap_or_else(|| class_constructor_side_type(class));
        let accessor_methods = class.accessor_methods();
        for method in class
            .members
            .iter()
            .filter_map(|member| member.method.as_ref())
            .chain(accessor_methods.iter())
        {
            self.with_lexical_type_scope(&method.type_parameters, |checker| {
            let accessor = class
                .members
                .iter()
                .filter_map(|member| member.accessor.as_ref())
                .find(|accessor| accessor.span == method.span);
            checker.validate_class_parameters(&method.parameters, method.body.is_some(), "method");
            let return_type = method.return_type.as_ref().filter(|return_type| {
                let before = checker.diagnostics.len();
                checker.check_type(
                    return_type,
                    method.return_type_span.as_ref().unwrap_or(&method.span),
                );
                !checker.diagnostics[before..]
                    .iter()
                    .any(|diagnostic| diagnostic.code == DiagnosticCode::UnknownType)
            });
            if let Some(return_type) = return_type {
                checker.check_predicate_signature(return_type, &method.parameters);
            }
            let runtime_return_type = return_type.map(Type::runtime_result);
            let return_type = runtime_return_type.as_ref();
            if let Some(body) = &method.body {
                let mut scope = checker.class_body_parameter_scope(&method.parameters);
                if let Some(base) = checker.super_scope_type(class, method.is_static) {
                    scope.insert("super".to_string(), base);
                }
                checker.check_method_super_placement(class, body);
                hoist_local_functions(body, &mut scope);
                scope.insert(
                    "this".to_string(),
                    if method.is_static {
                        constructor_side.clone()
                    } else {
                        class_body_this_type(class)
                    },
                );
                if method.generator || method.async_function {
                    checker.check_function_in_scope(&method.as_function(), scope);
                    return;
                }
                let allows_implicit_undefined = return_type.is_none_or(|return_type| {
                    checker.return_type_allows_implicit_undefined(return_type, &method.span)
                });
                checker.check_class_body_items(
                    body,
                    &scope,
                    ClassBodyReturnRule::Method {
                        return_type,
                        allows_implicit_undefined,
                        setter: accessor.is_some_and(|accessor| !accessor.getter),
                    },
                );
                if let Some(return_type) = return_type {
                    if !allows_implicit_undefined
                        && matches!(
                            Self::function_body_termination(body),
                            StructuredTermination::FallsThrough
                        )
                    {
                        checker.typescript_type_error(
                            &method.span,
                            format!(
                                "class method with return type `{}` can complete without returning a value",
                                type_label(return_type)
                            ),
                            DiagnosticCode::ReturnTypeMismatch,
                            if accessor.is_some_and(|accessor| accessor.getter) { 2378 } else { 2366 },
                            Vec::new(),
                        );
                    }
                }
            }
            });
        }
    }

    /// Each `static { .. }` block runs once with `this` bound to the class
    /// constructor. It is a function body that cannot `return` or `await`.
    pub(in crate::checker::module::binding) fn check_class_static_blocks(
        &mut self,
        class: &ClassDeclaration,
    ) {
        let constructor_side = self
            .values
            .get(&class.name)
            .cloned()
            .unwrap_or_else(|| class_constructor_side_type(class));
        for block in class
            .members
            .iter()
            .filter_map(|member| member.static_block.as_ref())
        {
            let mut scope = self.values.clone();
            if let Some(base) = self.super_scope_type(class, true) {
                scope.insert("super".to_string(), base);
            }
            hoist_local_functions(&block.body, &mut scope);
            scope.insert("this".to_string(), constructor_side.clone());
            let previous_async = self.async_context.replace(false);
            self.check_class_body_items(&block.body, &scope, ClassBodyReturnRule::StaticBlock);
            self.async_context = previous_async;
        }
    }

    pub(super) fn class_body_parameter_scope(
        &self,
        parameters: &[Parameter],
    ) -> BTreeMap<String, Type> {
        let mut scope = self.values.clone();
        for parameter in parameters {
            if let Some(pattern) = &parameter.pattern {
                // A destructured class parameter binds its names untyped.
                for (name, _) in pattern.names() {
                    scope.insert(name.to_string(), Type::Unknown);
                }
                continue;
            }
            let value = parameter
                .annotation
                .clone()
                .or_else(|| {
                    parameter
                        .default
                        .as_ref()
                        .map(|tokens| self.infer_expression(tokens, &scope))
                })
                .unwrap_or(Type::Unknown);
            scope.insert(parameter.name.clone(), value);
        }
        scope
    }

    pub(super) fn check_class_body_items(
        &mut self,
        items: &[FunctionBodyItem],
        scope: &BTreeMap<String, Type>,
        return_rule: ClassBodyReturnRule<'_>,
    ) {
        let mut scope = scope.clone();
        for item in items {
            match item {
                FunctionBodyItem::Variable(variable) => {
                    self.check_variable_in_scope(variable, &scope);
                    let value = variable
                        .annotation
                        .clone()
                        .unwrap_or_else(|| self.infer_expression(&variable.initializer, &scope));
                    scope.insert(variable.name.clone(), value);
                }
                FunctionBodyItem::Expression { tokens, span }
                | FunctionBodyItem::Throw { tokens, span } => {
                    self.check_direct_runtime_expression(tokens, &scope, span);
                    if let (
                        FunctionBodyItem::Expression { .. },
                        ClassBodyReturnRule::Constructor { super_class, .. },
                    ) = (item, return_rule)
                    {
                        if let Some(base) = super_class.extends_name.as_deref() {
                            self.check_super_call_arguments(
                                base,
                                super_class,
                                tokens,
                                &scope,
                                span,
                            );
                        }
                    }
                }
                FunctionBodyItem::Return { tokens, span } => {
                    if !tokens.is_empty() {
                        self.check_direct_runtime_expression(tokens, &scope, span);
                    }
                    match return_rule {
                        ClassBodyReturnRule::Constructor {
                            class_name,
                            instance_type,
                            ..
                        } if !tokens.is_empty() => {
                            let actual = self.infer_expression(tokens, &scope);
                            let primitive = Type::Union(vec![
                                Type::Null,
                                Type::Undefined,
                                Type::Boolean,
                                Type::Number,
                                Type::String,
                            ]);
                            if !self.is_assignable_bounded(&actual, &primitive, span)
                                && !self.is_assignable_bounded(&actual, instance_type, span)
                            {
                                self.assignment_error(
                                    span,
                                    format!(
                                        "constructor return type `{}` is not assignable to class `{}`",
                                        type_label(&actual),
                                        class_name
                                    ),
                                    DiagnosticCode::ReturnTypeMismatch,
                                    &actual,
                                    &Type::Named {name:class_name.to_string(),arguments:Vec::new()},
                                );
                            }
                        }
                        ClassBodyReturnRule::Method {
                            return_type: Some(return_type),
                            allows_implicit_undefined,
                            setter,
                        } => {
                            let actual = if tokens.is_empty() {
                                Type::Undefined
                            } else {
                                self.infer_in_context(tokens, &scope, return_type)
                            };
                            if (!tokens.is_empty() || !allows_implicit_undefined)
                                && !self.is_assignable_bounded(&actual, return_type, span)
                            {
                                let message = format!(
                                    "class method return type `{}` is not assignable to `{}`",
                                    type_label(&actual),
                                    type_label(return_type)
                                );
                                if setter {
                                    self.typescript_type_error(
                                        span,
                                        message,
                                        DiagnosticCode::ReturnTypeMismatch,
                                        2408,
                                        Vec::new(),
                                    );
                                } else {
                                    self.assignment_error(
                                        span,
                                        message,
                                        DiagnosticCode::ReturnTypeMismatch,
                                        &actual,
                                        return_type,
                                    );
                                }
                            }
                        }
                        ClassBodyReturnRule::StaticBlock => self.type_error(
                            span,
                            "a return statement cannot be used inside a class static block"
                                .to_string(),
                            DiagnosticCode::ReturnTypeMismatch,
                        ),
                        ClassBodyReturnRule::Constructor { .. }
                        | ClassBodyReturnRule::Method {
                            return_type: None, ..
                        } => {}
                    }
                }
                FunctionBodyItem::If(statement) => {
                    self.check_class_body_if(statement, &scope, return_rule)
                }
                FunctionBodyItem::While(statement) => {
                    self.check_direct_runtime_expression(&statement.test, &scope, &statement.span);
                    self.check_class_body_items(&statement.body, &scope, return_rule);
                }
                FunctionBodyItem::Try(statement) => {
                    self.check_class_body_items(&statement.block, &scope, return_rule);
                    if let Some(handler) = &statement.handler {
                        let catch_scope = self.catch_binding_scope(&scope, handler);
                        self.check_class_body_items(&handler.body, &catch_scope, return_rule);
                    }
                    if let Some(finalizer) = &statement.finalizer {
                        self.check_class_body_items(finalizer, &scope, return_rule);
                    }
                }
                FunctionBodyItem::Function(function) => {
                    self.check_function_in_scope(function, scope.clone());
                }
                FunctionBodyItem::TypeAlias(_) | FunctionBodyItem::Opaque(_) => {}
            }
        }
    }

    pub(super) fn check_class_body_if(
        &mut self,
        statement: &FunctionIfStatement,
        scope: &BTreeMap<String, Type>,
        return_rule: ClassBodyReturnRule<'_>,
    ) {
        self.check_direct_runtime_expression(&statement.test, scope, &statement.span);
        self.check_class_body_items(&statement.consequent, scope, return_rule);
        match &statement.alternate {
            Some(FunctionElseBranch::Braced(body)) => {
                self.check_class_body_items(body, scope, return_rule);
            }
            Some(FunctionElseBranch::ElseIf(branch)) => {
                self.check_class_body_if(branch, scope, return_rule);
            }
            None => {}
        }
    }
}
