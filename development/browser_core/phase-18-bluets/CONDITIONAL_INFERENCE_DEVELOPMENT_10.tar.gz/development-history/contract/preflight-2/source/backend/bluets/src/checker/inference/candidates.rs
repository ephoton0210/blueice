// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Candidate direction is retained until a parameter's solution is selected.
use super::*;

#[derive(Default)]
pub(super) struct Candidates {
    covariant: Vec<Type>,
    contravariant: Vec<Type>,
}

impl Candidates {
    /// Reverse mapped slots combine covariant property evidence before using
    /// contravariant-only evidence. A call's candidate-selection policy is
    /// separate from reconstruction of its individual mapped properties.
    pub(super) fn reverse(
        &self,
        aliases: &BTreeMap<String, TypeDefinition>,
        budget: &mut TypeExpansionBudget,
    ) -> Option<Type> {
        if budget.exhausted {
            return None;
        }
        if !self.covariant.is_empty() {
            // Fresh property values were widened while reading the argument.
            // Reconstruction must retain explicit literal annotations/assertions.
            return Some(super::super::type_operators::union(self.covariant.clone()));
        }
        if self.contravariant.is_empty() {
            return Some(Type::StrictUnknown);
        }
        let value = if self.contravariant.len() == 1 {
            self.contravariant[0].clone()
        } else {
            super::super::type_operators::expanded(
                &Type::Intersection(self.contravariant.clone()),
                aliases,
                &mut HashSet::new(),
                budget,
            )
        };
        (!budget.exhausted).then_some(value)
    }

    /// Constituents of one covariant union argument are one union-valued
    /// candidate, not competing independent call arguments. Contravariant
    /// constraints retain their original directed comparison.
    pub(super) fn merge_union(&mut self, other: Self) {
        if !other.covariant.is_empty() {
            self.add(&super::super::type_operators::union(other.covariant), false);
        }
        for value in other.contravariant {
            self.add(&value, true);
        }
    }

    pub(super) fn add(&mut self, value: &Type, contra: bool) {
        // An unfinished contextual parameter is not evidence for a solution.
        if matches!(value, Type::Unknown) {
            return;
        }
        let values = if contra {
            &mut self.contravariant
        } else {
            &mut self.covariant
        };
        if !values.contains(value) {
            values.push(value.clone());
        }
    }

    pub(super) fn solve(
        &self,
        preserve: bool,
        aliases: &BTreeMap<String, TypeDefinition>,
        budget: &mut TypeExpansionBudget,
    ) -> Option<Type> {
        let accepts = |actual: &Type, expected: &Type, budget: &mut TypeExpansionBudget| {
            is_assignable(actual, expected, aliases, &mut HashSet::new(), budget)
        };
        let covariant = if self.covariant.is_empty() {
            None
        } else if self
            .covariant
            .iter()
            .all(|v| matches!(v, Type::Literal(_) | Type::StringLiteral(_)))
            && self
                .covariant
                .iter()
                .all(|v| widen(v) == widen(&self.covariant[0]))
        {
            Some(if preserve {
                super::super::type_operators::union(self.covariant.clone())
            } else {
                widen(&self.covariant[0])
            })
        } else {
            Some(
                self.covariant
                    .iter()
                    .find(|candidate| {
                        self.covariant
                            .iter()
                            .all(|other| accepts(other, candidate, budget))
                    })
                    .unwrap_or(&self.covariant[0])
                    .clone(),
            )
        };
        if let Some(candidate) = covariant.as_ref() {
            if self
                .contravariant
                .iter()
                .all(|constraint| accepts(candidate, constraint, budget))
            {
                return Some(if preserve {
                    candidate.clone()
                } else {
                    widen(candidate)
                });
            }
        }
        self.contravariant
            .iter()
            .find(|candidate| {
                self.contravariant
                    .iter()
                    .all(|other| accepts(candidate, other, budget))
            })
            .or_else(|| self.contravariant.first())
            .cloned()
            .or(covariant)
    }
}
