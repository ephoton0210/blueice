// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Module declarations, function bodies, and erasure edits.

use super::runtime_syntax::*;
use super::*;

#[path = "declarations/ambient.rs"]
mod ambient;
#[path = "declarations/binding_recovery.rs"]
mod binding_recovery;
#[path = "declarations/statement_diagnostics.rs"]
mod statement_diagnostics;

impl Parser {
    pub(crate) fn new(
        id: String,
        source: String,
        tokens: Vec<Token>,
        max_type_depth: usize,
    ) -> Self {
        Self {
            id,
            source,
            // TypeScript permits adjacent generic closers without whitespace,
            // even though the JavaScript lexer initially recognizes `>>` and
            // `>>>` as shift operators.  The BlueTS parser does not parse
            // runtime expressions from this token stream (the emitter keeps
            // their original source), so present each closer independently to
            // the type grammar while retaining its exact source span.
            tokens: split_generic_closers(merge_private_names(tokens)),
            index: 0,
            declarations: Vec::new(),
            edits: Vec::new(),
            generic_call_type_arguments: BTreeMap::new(),
            nested_functions: BTreeMap::new(),
            class_expressions: BTreeMap::new(),
            type_references: Vec::new(),
            import_types: Vec::new(),
            expression_variable_types: BTreeMap::new(),
            type_assertions: BTreeMap::new(),
            diagnostics: Vec::new(),
            recovered_primitive_values: Vec::new(),
            max_type_depth,
            type_depth: 0,
            infer_depth: 0,
            parameter_property_mode: false,
            parameter_properties: Vec::new(),
            namespace_depth: 0,
            ambient_depth: 0,
            namespace_export_markers: 0,
            pending_decorators: Vec::new(),
            emitted_runtime: false,
            emitted_body_end: None,
        }
    }

    /// Merges qualified namespace references into single tokens.
    pub(crate) fn with_namespace_names(
        mut self,
        names: &super::super::namespace_names::NamespaceNames,
    ) -> Self {
        self.tokens = names.merge(std::mem::take(&mut self.tokens));
        self
    }

    pub(crate) fn parse_module(self) -> Result<Module, Vec<Diagnostic>> {
        self.parse_module_recovered()
            .map_err(|failure| failure.diagnostics)
    }

    pub(crate) fn parse_module_recovered(mut self) -> Result<Module, ParseFailure> {
        self.diagnose_unparenthesized_nullish_logical_mixing();
        self.diagnose_unparenthesized_unary_exponentiation();
        self.parse_items();
        self.validate_umd_exports();

        if self.diagnostics.is_empty() {
            self.audit_erased_function_annotations();
        }
        self.edits.sort_by_key(|edit| (edit.start, edit.end));
        let mut module = Module {
            id: self.id,
            source: self.source,
            declarations: self.declarations,
            edits: self.edits,
            generic_call_type_arguments: self.generic_call_type_arguments,
            nested_functions: self.nested_functions,
            class_expressions: self.class_expressions,
            type_references: self.type_references,
            import_types: self.import_types,
            expression_variable_types: self.expression_variable_types,
            type_assertions: self.type_assertions,
        };
        if self.diagnostics.is_empty() {
            module.bind_class_expression_captures();
            Ok(module)
        } else {
            Err(ParseFailure {
                diagnostics: self.diagnostics,
                recovered: (!self.recovered_primitive_values.is_empty()).then(|| {
                    Box::new(RecoveredSyntax {
                        module,
                        primitive_values: self.recovered_primitive_values,
                    })
                }),
            })
        }
    }

    /// Reads the decorators at the cursor.
    fn parse_decorators(&mut self) -> Vec<Decorator> {
        let mut decorators = Vec::new();
        while self.peek("@") {
            match class::decorator_at(&self.id, &self.tokens, self.index) {
                Some((decorator, next)) => {
                    self.collect_expression_type_edits(decorator.token_start, decorator.token_end);
                    decorators.push(decorator);
                    self.index = next;
                }
                None => {
                    self.error_here(
                        DiagnosticCode::ParseError,
                        "expected a decorator expression",
                    );
                    self.bump();
                }
            }
        }
        decorators
    }

    /// Parses declarations until the end of the token stream, the module's or a
    /// namespace body's.
    pub(super) fn parse_items(&mut self) {
        while !self.at_eof() {
            if self.consume(";") {
                continue;
            }
            let start = self.current().start;
            let mut decorators = self.parse_decorators();
            let exported = self.consume("export");
            if exported && self.peek("@") {
                decorators.extend(self.parse_decorators());
            }
            self.pending_decorators.clear();
            if !decorators.is_empty() {
                if self.peek("class")
                    || (self.peek("abstract")
                        && self
                            .tokens
                            .get(self.index + 1)
                            .is_some_and(|token| token.is("class")))
                {
                    self.pending_decorators = decorators;
                } else {
                    self.error_at(
                        decorators[0].span.clone(),
                        DiagnosticCode::ParseError,
                        "decorators are not valid here; they decorate a class or a class member",
                    );
                }
            }
            if exported && self.peek("as") {
                self.parse_umd_export(start);
                continue;
            }
            // `export {};` in a namespace body only says that exports are explicit.
            if self.namespace_depth > 0
                && exported
                && self.peek("{")
                && self
                    .tokens
                    .get(self.index + 1)
                    .is_some_and(|token| token.is("}"))
            {
                self.bump();
                self.bump();
                self.consume(";");
                self.namespace_export_markers += 1;
                continue;
            }
            if self.namespace_depth > 0
                && ((exported
                    && (self.peek("default")
                        || self.peek("=")
                        || self.peek("*")
                        || self.peek("{")))
                    || self.peek("import"))
            {
                self.unsupported(
                    self.current().span(&self.id),
                    "an import, `export default`, `export =`, `export *` or export list inside a namespace body is not supported",
                );
                self.skip_statement();
                continue;
            }
            if exported && self.consume("default") {
                self.parse_default_declaration(start);
                continue;
            }
            if exported && self.peek("=") {
                self.parse_export_assignment(start);
                continue;
            }
            if exported && self.peek("*") {
                self.parse_value_export(start);
                continue;
            }
            if exported && self.peek("{") {
                self.parse_value_export(start);
                continue;
            }

            if self.peek("import") {
                let equals = self
                    .tokens
                    .get(self.index + 2)
                    .is_some_and(|token| token.is("="));
                if exported && !equals {
                    self.error_here(DiagnosticCode::ParseError, "an import cannot be exported");
                }
                self.parse_import(start, exported && equals);
            } else if self.peek("type")
                && self.tokens.get(self.index + 1).is_some_and(|token| {
                    token.kind == TokenKind::Identifier
                        || matches!(token.text.as_str(), "of" | "type" | "asserts" | "is")
                        || (exported && (token.is("{") || token.is("*")))
                })
            {
                self.bump();
                if exported && (self.peek("{") || self.peek("*")) {
                    self.parse_type_export(start);
                } else {
                    self.parse_type_alias(start, exported);
                }
            } else if self.consume("interface") {
                self.parse_interface(start, exported);
            } else if self.consume("abstract") {
                let modifier = self.previous().span(&self.id);
                if self.consume("class") {
                    self.edits.push(TextEdit {
                        start: modifier.start,
                        end: self.previous().start,
                        replacement: String::new(),
                    });
                    self.parse_class(start, exported, Some(modifier));
                } else {
                    self.error_here(
                        DiagnosticCode::ParseError,
                        "expected a class after abstract",
                    );
                    self.skip_statement();
                }
            } else {
                let explicit_declare = self.consume("declare");
                if explicit_declare && self.ambient_depth > 0 {
                    self.error_at(
                        self.previous().span(&self.id),
                        DiagnosticCode::ParseError,
                        "a `declare` modifier cannot be used in an already ambient context",
                    );
                }
                let declared = explicit_declare || self.ambient_depth > 0;
                let async_start = self.consume("async");
                if (declared && self.peek("global"))
                    || (self.peek("module")
                        && self
                            .tokens
                            .get(self.index + 1)
                            .is_some_and(|token| token.kind == TokenKind::String))
                {
                    self.parse_ambient_declaration(start);
                } else if declared && !async_start && self.consume("type") {
                    self.parse_type_alias(start, exported);
                } else if self.consume("function") {
                    self.parse_function(start, exported, false, declared, async_start);
                } else if self.consume("class") {
                    if (declared && !crate::compiler::is_declaration_module(&self.id))
                        || async_start
                    {
                        self.unsupported(
                            self.previous().span(&self.id),
                            "declared and async classes are not in the first class form",
                        );
                        self.skip_statement();
                    } else {
                        self.parse_class(start, exported, None);
                    }
                } else if self.peek("const")
                    && self
                        .tokens
                        .get(self.index + 1)
                        .is_some_and(|token| token.is("enum"))
                {
                    if async_start {
                        self.unsupported(
                            self.previous().span(&self.id),
                            "an async enum is not valid",
                        );
                        self.skip_statement();
                    } else {
                        self.bump();
                        self.bump();
                        self.parse_enum(start, exported, declared, true);
                    }
                } else if self.consume("enum") {
                    if async_start {
                        self.unsupported(
                            self.previous().span(&self.id),
                            "an async enum is not valid",
                        );
                        self.skip_statement();
                    } else {
                        self.parse_enum(start, exported, declared, false);
                    }
                } else if self.peek("const") || self.peek("let") || self.peek("var") {
                    let kind = match self.current().text.as_str() {
                        "const" => VariableKind::Const,
                        "let" => VariableKind::Let,
                        "var" => VariableKind::Var,
                        _ => unreachable!("variable declaration was guarded by its keyword"),
                    };
                    self.bump();
                    self.parse_variable(start, exported, declared, kind);
                } else if (self.peek("namespace") || self.peek("module"))
                    && self
                        .tokens
                        .get(self.index + 1)
                        .is_some_and(|token| token.kind == TokenKind::Identifier)
                    && !self.newline_between(self.index, self.index + 1)
                {
                    if async_start {
                        self.unsupported(
                            self.current().span(&self.id),
                            "an async namespace is not valid",
                        );
                        self.skip_statement();
                    } else {
                        self.bump();
                        self.parse_namespace(start, exported, declared);
                    }
                } else if self.peek("namespace")
                    && self
                        .tokens
                        .get(self.index + 1)
                        .is_some_and(|token| token.is("{"))
                {
                    self.diagnose_missing_namespace_name();
                    self.skip_statement();
                } else if self.peek_any(&[
                    "namespace",
                    "module",
                    "abstract",
                    "implements",
                    "decorator",
                ]) {
                    self.unsupported(
                        self.current().span(&self.id),
                        format!(
                            "`{}` is not in the initial BlueTS matrix",
                            self.current().text
                        ),
                    );
                    self.skip_statement();
                } else if self.peek("@")
                    || (self.peek("<")
                        && self
                            .tokens
                            .get(self.index + 1)
                            .is_some_and(|token| token.kind == TokenKind::Identifier))
                {
                    self.unsupported(
                        self.current().span(&self.id),
                        "decorators and TSX/JSX are not in the initial BlueTS matrix",
                    );
                    self.skip_statement();
                } else {
                    if declared {
                        self.error_here(
                            DiagnosticCode::ParseError,
                            "`declare` must introduce a supported declaration",
                        );
                    }
                    if async_start {
                        self.error_here(
                            DiagnosticCode::ParseError,
                            "`async` must precede a function declaration in the initial matrix",
                        );
                    }
                    self.parse_raw(start);
                }
            }
        }
        self.merge_class_interfaces();
    }

    /// An interface with the name of a class in the same declaration list
    /// merges into the class's instance type.
    fn merge_class_interfaces(&mut self) {
        let mut merged: Vec<(usize, Vec<TypeField>)> = Vec::new();
        for (index, declaration) in self.declarations.iter().enumerate() {
            let Declaration::Class(class) = declaration else {
                continue;
            };
            let mut fields = Vec::new();
            for other in &self.declarations {
                let Declaration::Interface(interface) = other else {
                    continue;
                };
                if interface.name != class.name {
                    continue;
                }
                fields.extend(interface.fields.iter().cloned());
            }
            if !fields.is_empty() {
                merged.push((index, fields));
            }
        }
        for (index, fields) in merged {
            if let Declaration::Class(class) = &mut self.declarations[index] {
                class.merged_interface_fields = fields;
            }
        }
    }

    pub(super) fn parse_raw(&mut self, start: usize) {
        let raw_start = self.index;
        if self.peek("throw") {
            self.diagnose_throw_operand(raw_start);
        }
        let (end_index, next_index, end) = if let Some(end) =
            raw_boundaries::end(&self.tokens, raw_start, self.tokens.len() - 1)
        {
            if self.tokens[end].is(";") {
                (end, end + 1, self.tokens[end].end)
            } else {
                (end, end, self.tokens[end - 1].end)
            }
        } else {
            let end =
                find_balanced_delimiter(&self.tokens, self.index, self.tokens.len() - 1, &[";"]);
            (
                end,
                end + usize::from(self.tokens[end].is(";")),
                self.tokens[end].end,
            )
        };
        self.collect_statement_type_edits(raw_start, end_index);
        let assertions = self.tokens[raw_start..end_index]
            .iter()
            .filter(|token| token.is("as") || token.is("satisfies"))
            .map(|token| token.span(&self.id))
            .collect::<Vec<_>>();
        for span in assertions {
            self.unsupported(
                span,
                "TypeScript assertions outside a supported declaration are not in the initial BlueTS matrix",
            );
        }
        self.index = next_index;
        self.declarations.push(Declaration::Raw(RawDeclaration {
            tokens: self.tokens[raw_start..end_index].to_vec(),
            span: SourceSpan::new(&self.id, start, end),
        }));
    }
}

#[path = "declarations/class.rs"]
mod class;
#[path = "declarations/class_expressions.rs"]
mod class_expressions;
#[path = "declarations/default_exports.rs"]
mod default_exports;
#[path = "declarations/enums.rs"]
mod enums;
#[path = "declarations/erasure_audit.rs"]
mod erasure_audit;
#[path = "declarations/function_body.rs"]
mod function_body;
#[path = "declarations/imports_exports.rs"]
mod imports_exports;
#[path = "declarations/namespaces.rs"]
mod namespaces;
#[path = "declarations/nested_functions.rs"]
mod nested_functions;
#[path = "declarations/patterns.rs"]
mod patterns;
pub(crate) use patterns::parse_variable_pattern;
#[path = "declarations/raw_boundaries.rs"]
mod raw_boundaries;
#[path = "declarations/source_edits.rs"]
mod source_edits;
#[path = "declarations/typed_declarations.rs"]
mod typed_declarations;
