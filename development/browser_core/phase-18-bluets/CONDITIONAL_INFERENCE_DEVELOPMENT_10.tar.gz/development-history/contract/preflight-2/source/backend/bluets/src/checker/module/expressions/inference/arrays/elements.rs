// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Fresh literal elements widen in mutable arrays; regular literals retain their types.

use super::*;

impl ModuleChecker<'_> {
    pub(in crate::checker) fn inferred_fresh_variables(&self) -> BTreeSet<usize> {
        self.module
            .declarations
            .iter()
            .filter_map(|declaration| {
                let Declaration::Variable(variable) = declaration else {
                    return None;
                };
                (variable.annotation.is_none()
                    && variable.kind == crate::parser::VariableKind::Const
                    && self.fresh_array_element(
                        &variable.initializer,
                        &self.values,
                        &mut BTreeSet::new(),
                        0,
                    ))
                .then_some(variable.span.start)
            })
            .collect()
    }

    pub(in crate::checker::module) fn array_element_type(
        &self,
        tokens: &[Token],
        scope: &BTreeMap<String, Type>,
        value: Type,
    ) -> Type {
        let enum_member = match &value {
            Type::Literal(name) => Some(name),
            Type::Named { name, arguments } if arguments.is_empty() => Some(name),
            _ => None,
        };
        if let Some(name) = enum_member {
            if self
                .types
                .get(name)
                .is_some_and(|definition| definition.kind == TypeDefinitionKind::EnumMember)
            {
                let (bare, module) = name
                    .split_once('@')
                    .map_or((name.as_str(), None), |(name, module)| (name, Some(module)));
                if let Some((owner, _)) = bare.rsplit_once('.') {
                    return Type::Named {
                        name: module.map_or_else(
                            || owner.to_string(),
                            |module| format!("{owner}@{module}"),
                        ),
                        arguments: Vec::new(),
                    };
                }
            }
        }
        if self.fresh_array_element(tokens, scope, &mut BTreeSet::new(), 0) {
            return crate::checker::module::return_inference::widen(value);
        }
        value
    }

    pub(in crate::checker::module) fn fresh_array_element(
        &self,
        tokens: &[Token],
        scope: &BTreeMap<String, Type>,
        seen: &mut BTreeSet<String>,
        depth: usize,
    ) -> bool {
        if depth >= 128 {
            return false;
        }
        let tokens = strip_outer_parentheses(tokens);
        if self.fresh_return_call(tokens, scope) {
            return true;
        }
        if let [token] = tokens {
            if matches!(
                token.kind,
                TokenKind::Number | TokenKind::String | TokenKind::Template
            ) || token.is("true")
                || token.is("false")
            {
                return true;
            }
            if let Some(local) = self
                .scopes
                .as_ref()
                .and_then(|scopes| scopes.local_literal_initializer(token))
            {
                let Some(initializer) = local else {
                    return false;
                };
                let Some(first) = initializer.first() else {
                    return false;
                };
                if !seen.insert(format!("local:{}:{}", token.text, first.start)) {
                    return false;
                }
                return self.fresh_array_element(&initializer, scope, seen, depth + 1);
            }
            if let Some(fresh) = self.fresh_local_return(&token.text) {
                return fresh;
            }
            if scope.get(&token.text) != self.values.get(&token.text)
                || !seen.insert(token.text.clone())
            {
                return false;
            }
            if let Some(fresh) = self.imported_literal_freshness(&token.text) {
                return fresh;
            }
            if self.module.declarations.iter().any(|declaration| {
                matches!(declaration, Declaration::Import(import)
                    if import.bindings.iter().any(|binding| binding.local == token.text)
                        && self.project.resolved_import(&self.module.id, import)
                            .is_some_and(|resolved| resolved.ends_with(".js")))
            }) {
                return true;
            }
            return self.module.declarations.iter().any(|declaration| {
                matches!(declaration, Declaration::Variable(variable)
                    if variable.name == token.text
                        && variable.kind == crate::parser::VariableKind::Const
                        && variable.annotation.is_none()
                        && self.fresh_array_element(&variable.initializer, scope, seen, depth + 1))
            });
        }
        if let Some(fresh) = self.fresh_call_chain(tokens, scope, seen, depth) {
            return fresh;
        }
        let (arguments, signatures) = if let Some(call) = member_call_parts(tokens, |start| {
            self.module.generic_call_type_arguments.contains_key(&start)
        }) {
            if call.generic {
                return false;
            }
            let base = self.infer_expression(call.receiver, scope);
            let mut budget = TypeExpansionBudget::new(self.max_type_expansions);
            budget.checking = self.checking;
            let PropertyType::Found { value, .. } = property_type(
                &base,
                &call.member.text,
                &self.types,
                &mut HashSet::new(),
                &mut budget,
            ) else {
                return false;
            };
            let Some(signatures) = signatures::callable_signatures(&value, false) else {
                return false;
            };
            (call.arguments, signatures)
        } else {
            let Some(call) = direct_call_parts(tokens).filter(|call| !call.generic) else {
                return false;
            };
            let Some(signatures) = self
                .function_value_signatures(&call.callee.text, scope, false)
                .or_else(|| self.functions.get(&call.callee.text).cloned())
            else {
                return false;
            };
            (call.arguments, signatures)
        };
        let Some(arguments) = split_call_arguments(arguments) else {
            return false;
        };
        let Ok(actuals) = self.expanded_call_argument_types_for(&arguments, scope, &signatures)
        else {
            return false;
        };
        let Ok(Some(signature)) = self.select_function_signature(&signatures, &actuals, None)
        else {
            return false;
        };
        let Some(result_parameter) = crate::checker::inference::declared_parameter(
            &signature.return_type,
            &signature.type_parameters,
        ) else {
            return false;
        };
        if result_parameter.is_const || result_parameter.constraint.is_some() {
            return false;
        }
        signature
            .parameters
            .iter()
            .zip(&arguments)
            .any(|(parameter, argument)| {
                parameter
                    .annotation
                    .as_ref()
                    .and_then(|value| {
                        crate::checker::inference::declared_parameter(
                            value,
                            &signature.type_parameters,
                        )
                    })
                    .is_some_and(|parameter| std::ptr::eq(parameter, result_parameter))
                    && self.fresh_array_element(argument, scope, &mut seen.clone(), depth + 1)
            })
    }
}

/// Absent keys of an anonymous object-literal union are optional undefined.
/// Only literal objects use this normalization; named values retain their shape.
pub(super) fn complete_object_union(values: &mut [Type]) {
    if values.iter().any(|value| !matches!(value, Type::Record(_))) {
        return;
    }
    let mut all = Vec::new();
    for value in values.iter() {
        if let Type::Record(fields) = value {
            for field in fields {
                if !all
                    .iter()
                    .any(|known: &crate::parser::TypeField| known.name == field.name)
                {
                    all.push(field.clone());
                }
            }
        }
    }
    for value in values {
        if let Type::Record(fields) = value {
            for field in &all {
                if !fields.iter().any(|existing| existing.name == field.name) {
                    fields.push(crate::parser::TypeField {
                        optional: true,
                        readonly: false,
                        value: Type::Undefined,
                        ..field.clone()
                    });
                }
            }
        }
    }
}
