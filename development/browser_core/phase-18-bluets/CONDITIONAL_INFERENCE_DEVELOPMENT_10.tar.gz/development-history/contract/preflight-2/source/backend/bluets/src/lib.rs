// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! The standalone, host-neutral BlueTS front end.
//!
//! This crate deliberately has no dependency on BlueJS, a DOM crate, or an
//! I/O crate.  A host supplies a closed set of already-authorized module
//! records to [`compile`]; BlueTS parses, binds, checks, lowers, and emits
//! TypeScript-derived ECMAScript without acquiring files, URLs, capabilities,
//! or evaluation authority of its own.
//!
//! The initial language matrix is intentionally small and explicit.  It
//! supports typed variables and functions, interfaces, type aliases, type-only
//! imports and exports, and the primitive/record/array/tuple/union type forms
//! exercised by the public tests.  Unsupported TypeScript syntax is diagnosed
//! as `UnsupportedSyntax`; it is never passed through accidentally as
//! JavaScript.

mod authorized_loader;
mod checker;
mod checking_options;
mod compiler;
mod contracts;
mod debug_info;
mod diagnostic;
mod emitter;
mod enum_eval;
pub mod jsx;
mod namespace_analysis;
pub mod package_resolution;
mod parser;
mod performance;
pub mod remote_declarations;
pub mod standard_library;
mod strict_boundaries;
mod symbol_keys;
mod syntax;
mod type_operator_profiles;
mod utf16;

pub use authorized_loader::{
    AuthorizedModule, AuthorizedModuleLoader, AuthorizedModuleLoaderError,
    AuthorizedModuleResolution,
};
pub use checker::{CheckedModule, CheckedProject, Symbol, SymbolKind, Type};
pub use checking_options::CheckingOptions;
pub use compiler::{
    compile, is_external_library_module, CompilerLimits, CompilerOptions, EcmaTarget,
    IncrementalCompiler, IncrementalResult, JsxMode, JsxRuntimeNamespaceResolution, MapLoader,
    ModuleKind, ModuleLoader, ModuleSource, NewLine, Project, RuntimePolicy, StrictRuntimeBoundary,
};
pub use contracts::{
    Contract, ContractError, ContractPlan, ContractValue, ValidationError, ValidationLimits,
    ValidationUsage,
};
pub use debug_info::{
    source_locations_for_spans, BlueTsDebugInfo, ContractId, DebugContract, DebugSource,
    DebugSourceLocation, DebugSourcePosition, DebugSymbol, DebugType, SourceId, SymbolId, TypeId,
};
pub use diagnostic::{
    Diagnostic, DiagnosticCode, Severity, SourceSpan, TypeScriptDiagnostic, TypeScriptPosition,
    TypeScriptRelatedInformation, DIAGNOSTICS_VERSION,
};
pub use emitter::javascript_specifier as emitted_javascript_specifier;
pub use emitter::{
    BuildArtifact, BuildOutput, EmittedRuntimeBoundary, EmittedRuntimeSite, EmittedStrictModule,
    SourceMap, SourceMapLookupError, SourceMapOriginalPosition, CLASS_HELPER_V1_VERSION,
    DECORATOR_HELPER_V1_VERSION, LEGACY_DECORATOR_HELPER_V1_VERSION, TARGET_HELPER_V1_VERSION,
};
pub use enum_eval::{evaluate_enums, evaluate_enums_in, EnumValue, EvaluatedEnum, EvaluatedMember};
pub use namespace_analysis::{
    has_runtime_values, nested_spans, refuse_shadowing_of, rewrite_declaration, BodyInput,
    NamespaceExports,
};
pub use parser::{
    parse_module, AmbientDeclaration, BindingPattern, ClassAccessor, ClassConstructor,
    ClassDeclaration, ClassExpression, ClassField, ClassMemberKind, ClassMemberShell, ClassMethod,
    ClassMethodGroup, ConditionalType, Declaration, Decorator, ElementBinding, EnumDeclaration,
    EnumMember, FunctionBodyItem, FunctionCatchClause, FunctionDeclaration, FunctionElseBranch,
    FunctionIfStatement, FunctionTryStatement, FunctionWhileStatement, ImportAttribute,
    ImportAttributes, ImportDeclaration, IndexSignature, InterfaceDeclaration, IntrinsicKind,
    IntrinsicType, MappedModifier, MappedType, Module, NamespaceDeclaration, ObjectBinding,
    Parameter, ParameterProperty, ParameterPropertyInsertion, ParserLimits, RawDeclaration,
    StringMappingType, TemplateLiteralType, TupleTypeElement, TypeAliasDeclaration,
    TypeExportDeclaration, TypeParameter, TypePredicate, TypeSignature, UmdExportDeclaration,
    ValueExportBinding, ValueExportDeclaration, VariableBindingPattern, VariableDeclaration,
    VariableKind, Variance, Visibility,
};
pub use performance::CompilerPerformance;
pub use syntax::parse_jsx;
pub use syntax::{lex, Token, TokenKind};
pub use utf16::{CaseMapping, StringLiteral, Utf16String};

/// The pinned BlueTS language matrix exposed in emitted fingerprints and
/// diagnostics.  This is not a claim of complete `tsc` compatibility.
pub const LANGUAGE_VERSION: &str = "blue-ts-0.1";

/// One compilation, including checked modules and optional portable
/// JavaScript artifacts. Diagnostics and the observed graph/options
/// fingerprint remain available when errors prevent artifact emission.
#[derive(Debug, Clone)]
pub struct Compilation {
    pub project: Project,
    pub project_fingerprint: String,
    pub checked: Option<CheckedProject>,
    pub debug_info: Option<BlueTsDebugInfo>,
    pub diagnostics: Vec<Diagnostic>,
    pub output: Option<BuildOutput>,
    pub performance: CompilerPerformance,
}

impl Compilation {
    /// Returns true when parsing, resolution, binding, checking, lowering, or
    /// emission found an error.  The compiler never creates `output` in this
    /// state.
    pub fn has_errors(&self) -> bool {
        self.diagnostics
            .iter()
            .any(|diagnostic| diagnostic.severity == Severity::Error)
    }
}
