// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Publication of inferred function and class return signatures.

use super::*;
use crate::parser::ClassDeclaration;

impl ModuleChecker<'_> {
    pub(super) fn infer_module_return_signatures(&mut self) {
        // Initializers contribute closed-over value types without replacing an
        // explicit annotation. Checking those initializers remains a separate step.
        let mut scope = self.values.clone();
        for declaration in &self.module.declarations {
            if let Declaration::Variable(variable) = declaration {
                let value = variable
                    .annotation
                    .clone()
                    .unwrap_or_else(|| self.infer_variable_type(variable, &scope));
                scope.insert(variable.name.clone(), value);
            }
        }
        self.values = scope.clone();
        for declaration in &self.module.declarations {
            if let Declaration::Function(function) = declaration {
                if function.overload || function.declared {
                    continue;
                }
                let parameters = self.return_parameters(&function.parameters, &scope);
                if function.return_type.is_some() {
                    let overloaded = self.module.declarations.iter().any(|item| {
                        matches!(item, Declaration::Function(other)
                            if other.name == function.name && other.overload)
                    });
                    if !overloaded {
                        if let Some(signatures) = self.functions.get_mut(&function.name) {
                            for signature in signatures {
                                for (bound, inferred) in
                                    signature.parameters.iter_mut().zip(&parameters)
                                {
                                    // Retain canonical rest aliases and explicit
                                    // binders; only fill newly inferred defaults.
                                    if bound.annotation.is_none() {
                                        bound.annotation = inferred.annotation.clone();
                                    }
                                }
                            }
                        }
                    }
                    continue;
                }
                let result = self.inferred_function_result(function, &scope, false);
                if !self.module.declarations.iter().any(|declaration| {
                    matches!(declaration, Declaration::Function(other) if other.name == function.name && other.overload)
                }) {
                    if let Some(signatures) = self.functions.get_mut(&function.name) {
                        for signature in signatures {
                            signature.parameters = parameters.clone();
                            signature.return_type = result.clone();
                        }
                    }
                }
                self.values.insert(function.name.clone(), result.clone());
                scope.insert(function.name.clone(), result.clone());
                for symbol in &mut self.symbols {
                    if symbol.kind == SymbolKind::Function && symbol.span == function.span {
                        symbol.value_type = Some(result.clone());
                    }
                }
            }
        }
        for declaration in &self.module.declarations {
            if let Declaration::Class(class) = declaration {
                let inferred = self.class_with_inferred_returns(class);
                let instance = class_instance_type(&inferred);
                if let Some(definition) = self.types.get_mut(&class.name) {
                    definition.value = instance;
                }
                self.values.insert(
                    class.name.clone(),
                    classes::class_constructor_side_type(&inferred),
                );
            }
        }
    }

    pub(super) fn class_with_inferred_returns(
        &mut self,
        class: &ClassDeclaration,
    ) -> ClassDeclaration {
        let merged = classes::class_with_interface_heritage(
            class,
            self.module,
            &self.types,
            self.max_type_expansions,
        )
        .unwrap_or_else(|| class.clone());
        let resolved = self.class_with_resolved_heritage(&merged);
        let class = &resolved;
        self.with_class_access(class, |checker| checker.infer_class_return_types(class))
    }

    fn infer_class_return_types(&mut self, class: &ClassDeclaration) -> ClassDeclaration {
        let mut inferred = class.clone();
        for member in &mut inferred.members {
            let Some(field) = &mut member.field else {
                continue;
            };
            if field.annotation.is_none() && field.declared_type().is_none() {
                if let Some(tokens) = &field.initializer {
                    let value = self.infer_expression(tokens, &self.values);
                    if !matches!(value, Type::Unknown | Type::Any) {
                        field.annotation = Some(return_inference::widen(value));
                        self.return_inference.fields.borrow_mut().insert(
                            field.span.start,
                            field.annotation.clone().expect("inferred field"),
                        );
                    }
                }
            }
        }
        for _ in 0..class
            .members
            .len()
            .saturating_add(1)
            .min(self.max_type_expansions)
        {
            let next = self.infer_class_return_pass(&inferred);
            if next == inferred {
                break;
            }
            inferred = next;
        }
        inferred
    }

    fn infer_class_return_pass(&mut self, class: &ClassDeclaration) -> ClassDeclaration {
        let previous = self.types.get(&class.name).cloned();
        if let (Some(mut definition), Some(Type::Record(base))) = (
            previous.clone(),
            self.specialized_base_surface(class, false),
        ) {
            if let Type::Record(own) = &mut definition.value {
                for field in base {
                    if !own.iter().any(|own| own.name == field.name) {
                        own.push(field);
                    }
                }
                self.types.insert(class.name.clone(), definition);
            }
        }
        let mut inferred = class.clone();
        for member in &mut inferred.members {
            let getter = member
                .accessor
                .as_ref()
                .is_some_and(|accessor| accessor.getter);
            let (
                parameters,
                body,
                result,
                span,
                is_static,
                type_parameters,
                async_function,
                generator,
            ) = if let Some(method) = &mut member.method {
                let Some(body) = &method.body else { continue };
                (
                    &mut method.parameters,
                    body,
                    &mut method.return_type,
                    &method.span,
                    method.is_static,
                    method.type_parameters.clone(),
                    method.async_function,
                    method.generator,
                )
            } else if let Some(accessor) = &mut member.accessor {
                if !accessor.getter {
                    continue;
                }
                (
                    &mut accessor.parameters,
                    &accessor.body,
                    &mut accessor.return_type,
                    &accessor.span,
                    accessor.is_static,
                    Vec::new(),
                    false,
                    false,
                )
            } else {
                continue;
            };
            let mut scope = self.values.clone();
            scope.insert(
                "this".to_string(),
                if is_static {
                    self.values
                        .get(&class.name)
                        .cloned()
                        .unwrap_or(Type::Unknown)
                } else {
                    super::classes::class_body_this_type(class)
                },
            );
            if let Some(base) = &class.extends_name {
                scope.insert(
                    "super".to_string(),
                    Type::Named {
                        name: if is_static {
                            format!("typeof {base}")
                        } else {
                            base.clone()
                        },
                        arguments: if is_static {
                            Vec::new()
                        } else {
                            class.extends_arguments.clone()
                        },
                    },
                );
            }
            *parameters = self.return_parameters(parameters, &scope);
            if result.is_some() {
                continue;
            }
            let function = FunctionDeclaration {
                name: "<method>".to_string(),
                async_function,
                generator,
                body_open: None,
                type_parameters,
                parameters: parameters.clone(),
                return_type: None,
                body: body.clone(),
                returns: Vec::new(),
                locals: Vec::new(),
                exported: false,
                default_export: false,
                anonymous: false,
                declared: false,
                overload: false,
                span: span.clone(),
            };
            let mut value = self.inferred_function_result(&function, &scope, false);
            if getter {
                value = return_inference::getter_union(value);
            }
            let explicit_unknown = value == Type::Unknown && body.iter().any(|item| {
                let FunctionBodyItem::Return { tokens, .. } = item else { return false; };
                match tokens.as_slice() {
                    [receiver, dot, property] if receiver.is("this") && dot.is(".") => class.members.iter()
                        .filter_map(|member| member.field.as_ref())
                        .any(|field| field.name == property.text && field.annotation == Some(Type::Unknown)),
                    [name] => parameters.iter().any(|parameter| parameter.name == name.text && parameter.annotation == Some(Type::Unknown))
                        || body.iter().any(|item| matches!(item, FunctionBodyItem::Variable(variable)
                            if variable.name == name.text && variable.annotation == Some(Type::Unknown))),
                    _ => false,
                }
            });
            if value != Type::Unknown || explicit_unknown {
                if explicit_unknown {
                    self.return_inference
                        .results
                        .borrow_mut()
                        .insert(span.start, value.clone());
                }
                *result = Some(value);
            }
        }
        if let Some(previous) = previous {
            self.types.insert(class.name.clone(), previous);
        }
        let getters = inferred
            .members
            .iter()
            .filter_map(|member| member.accessor.as_ref())
            .filter(|accessor| accessor.getter)
            .map(|accessor| {
                (
                    (accessor.is_static, accessor.name.clone()),
                    accessor.return_type.clone(),
                )
            })
            .collect::<BTreeMap<_, _>>();
        for setter in inferred
            .members
            .iter_mut()
            .filter_map(|member| member.accessor.as_mut())
            .filter(|accessor| !accessor.getter)
        {
            if let Some(parameter) = setter
                .parameters
                .first_mut()
                .filter(|parameter| parameter.annotation.is_none())
            {
                if let Some(Some(value)) = getters.get(&(setter.is_static, setter.name.clone())) {
                    parameter.annotation = Some(value.clone());
                    self.return_inference
                        .parameters
                        .borrow_mut()
                        .insert(parameter.span.start, value.clone());
                }
            }
        }
        inferred
    }
}
