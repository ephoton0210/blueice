// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Record literal result inference, including referenced spread fields.

use super::*;
use crate::parser::NestedFunctionKind;

impl<'a> ModuleChecker<'a> {
    pub(super) fn infer_record(&self, tokens: &[Token], scope: &BTreeMap<String, Type>) -> Type {
        self.infer_record_in_context(tokens, scope, None)
    }

    /// An object literal whose property values are read against the property
    /// types of `expected`, where it has one of that name, so a bracketed literal
    /// there can be a tuple and a nested literal a record.
    pub(in crate::checker::module) fn infer_record_in_context(
        &self,
        tokens: &[Token],
        scope: &BTreeMap<String, Type>,
        expected: Option<&[TypeField]>,
    ) -> Type {
        let mut fields = Vec::new();
        let mut index = 1usize;
        while index < tokens.len() && !tokens[index].is("}") {
            if tokens[index].is("...") {
                let start = index + 1;
                let Some(end) = record_member_end(tokens, start) else {
                    return Type::Unknown;
                };
                if start == end {
                    return Type::Unknown;
                }
                let spread = self.infer_expression(&tokens[start..end], scope);
                let (spread, exhausted) = self.expanded_record_fields(spread);
                if exhausted
                    || (spread.is_none() && self.record_spread_inference_failure.get().is_none())
                {
                    self.record_spread_inference_failure.set(Some((
                        tokens.first().expect("record has opening brace").start,
                        tokens.last().expect("record has closing brace").end,
                        if exhausted {
                            RecordSpreadFailure::ResourceLimit
                        } else {
                            RecordSpreadFailure::UnprovenSource
                        },
                    )));
                }
                let Some(spread) = spread else {
                    return Type::Unknown;
                };
                for field in spread {
                    // Object spread creates a fresh writable property; the
                    // referenced field value retains its own readonly type.
                    insert_inferred_spread_field(&mut fields, field);
                }
                index = end + usize::from(tokens[end].is(","));
                continue;
            }
            if let Some((name, member_end, value, setter)) =
                self.nested_member(tokens, index, scope, &fields, expected)
            {
                // A setter only supplies the property type when no getter did.
                if setter {
                    if let Some(field) = fields
                        .iter_mut()
                        .find(|field: &&mut TypeField| field.name == name)
                    {
                        field.readonly = false;
                        field.accessor_write_type = Some(Box::new(value.clone()));
                    }
                }
                if !(setter && fields.iter().any(|field: &TypeField| field.name == name)) {
                    let previous_write = fields
                        .iter()
                        .find(|field| field.name == name)
                        .and_then(|field| field.accessor_write_type.clone());
                    let readonly = self
                        .module
                        .nested_functions
                        .get(&tokens[index].start)
                        .is_some_and(|f| f.kind == NestedFunctionKind::Getter)
                        && previous_write.is_none();
                    insert_inferred_record_field(
                        &mut fields,
                        TypeField {
                            accessor_write_type: setter
                                .then(|| Box::new(value.clone()))
                                .or(previous_write),
                            method: self
                                .module
                                .nested_functions
                                .get(&tokens[index].start)
                                .is_some_and(|function| {
                                    function.kind == NestedFunctionKind::Method
                                }),
                            name,
                            readonly,
                            optional: false,
                            value,
                            span: SourceSpan::new(
                                "<inferred>",
                                tokens[index].start,
                                tokens[member_end.saturating_sub(1)].end,
                            ),
                        },
                    );
                }
                index = member_end.saturating_add(1);
                continue;
            }
            let (name, name_end) = if tokens[index].is("[") {
                let Some(close) = crate::checker::scopes::targets::close(tokens, index) else {
                    return Type::Unknown;
                };
                let key = &tokens[index + 1..close];
                let key_type = self.infer_expression(key, scope);
                let name = match key_type {
                    Type::UniqueSymbol(_) => crate::symbol_keys::name(
                        &self.module.id,
                        &key.iter()
                            .map(|token| token.text.as_str())
                            .collect::<String>(),
                    ),
                    Type::Literal(text) => text.trim_matches(['\'', '"']).to_string(),
                    _ => return Type::Unknown,
                };
                (name, close)
            } else {
                (tokens[index].text.clone(), index)
            };
            let (value, value_end) = if tokens.get(name_end + 1).is_some_and(|token| token.is(":"))
            {
                let value_start = name_end + 2;
                let Some(value_end) = record_member_end(tokens, value_start) else {
                    return Type::Unknown;
                };
                let value_tokens = &tokens[value_start..value_end];
                let context = expected
                    .and_then(|fields| fields.iter().find(|field| field.name == name))
                    .map(|field| &field.value);
                (
                    match context {
                        Some(context) => {
                            let value = self.infer_in_context(value_tokens, scope, context);
                            if self.property_context_preserves_literals(context) {
                                value
                            } else {
                                self.array_element_type(value_tokens, scope, value)
                            }
                        }
                        None => self.array_element_type(
                            value_tokens,
                            scope,
                            self.infer_expression(value_tokens, scope),
                        ),
                    },
                    value_end,
                )
            } else if tokens
                .get(index + 1)
                .is_some_and(|token| token.is(",") || token.is("}"))
            {
                (
                    self.array_element_type(
                        &tokens[index..index + 1],
                        scope,
                        self.infer_expression(&tokens[index..index + 1], scope),
                    ),
                    index + 1,
                )
            } else {
                return Type::Unknown;
            };
            insert_inferred_record_field(
                &mut fields,
                TypeField {
                    accessor_write_type: None,
                    method: false,
                    name,
                    readonly: false,
                    optional: false,
                    value,
                    span: SourceSpan::new(
                        "<inferred>",
                        tokens[index].start,
                        tokens[value_end.saturating_sub(1)].end,
                    ),
                },
            );
            index = value_end.saturating_add(1);
        }
        Type::Record(fields)
    }

    fn property_context_preserves_literals(&self, context: &Type) -> bool {
        if crate::checker::type_operators::is_operator_context(context, &self.types) {
            return true;
        }
        let mut budget = TypeExpansionBudget::new(self.max_type_expansions);
        budget.checking = self.checking;
        let context = crate::checker::type_operators::expanded(
            context,
            &self.types,
            &mut HashSet::new(),
            &mut budget,
        );
        budget.exhausted
            || context.is_literal()
            || matches!(&context, Type::Union(parts) if parts.iter().any(Type::is_literal))
    }

    /// A structured method, getter or setter member starting at `index`, as
    /// its property name, the index of the `,` or `}` ending it, the type it
    /// gives the property (a function type for a method) and whether it is a
    /// setter.
    fn nested_member(
        &self,
        tokens: &[Token],
        index: usize,
        scope: &BTreeMap<String, Type>,
        fields: &[TypeField],
        expected: Option<&[TypeField]>,
    ) -> Option<(String, usize, Type, bool)> {
        let nested = self.module.nested_functions.get(&tokens[index].start)?;
        let end = record_member_end(tokens, index)?;
        let mut local = scope.clone();
        local.insert("this".into(), Type::Record(fields.to_vec()));
        let name_index = index + usize::from(nested.async_function || nested.generator);
        if nested.kind == NestedFunctionKind::Method {
            if let Some(Type::Function { parameters, result }) = expected
                .and_then(|fields| fields.iter().find(|f| f.name == tokens[name_index].text))
                .map(|field| &field.value)
            {
                for (actual, expected) in nested.parameters.iter().zip(parameters) {
                    if actual.annotation.is_none() {
                        if let Some(annotation) = &expected.annotation {
                            self.return_inference
                                .parameters
                                .borrow_mut()
                                .insert(actual.span.start, annotation.clone());
                        }
                    }
                }
                self.contextual_return(nested.span.start, result);
            }
        }
        let result = || self.inferred_nested_result(nested, &local);
        let (name, value, setter) = match nested.kind {
            NestedFunctionKind::Method => (
                // `async name(..)` starts at the `async` token.
                tokens[index + usize::from(nested.async_function || nested.generator)]
                    .text
                    .clone(),
                crate::checker::module::binding::declared_function_type(
                    &self.return_parameters(&nested.parameters, &local),
                    result(),
                    &nested.type_parameters,
                ),
                false,
            ),
            NestedFunctionKind::Getter => (tokens.get(index + 1)?.text.clone(), result(), false),
            NestedFunctionKind::Setter => (
                tokens.get(index + 1)?.text.clone(),
                nested
                    .parameters
                    .first()
                    .and_then(|parameter| parameter.annotation.clone())
                    .unwrap_or(Type::Unknown),
                true,
            ),
            _ => return None,
        };
        Some((name, end, value, setter))
    }

    pub(in crate::checker::module) fn expanded_record_fields(
        &self,
        value: Type,
    ) -> (Option<Vec<TypeField>>, bool) {
        let mut visited = HashSet::new();
        let mut budget = TypeExpansionBudget::new(self.max_type_expansions);
        let fields = self.expand_record_fields(value, &mut visited, &mut budget);
        (fields, budget.exhausted)
    }

    fn expand_record_fields(
        &self,
        value: Type,
        visited: &mut HashSet<String>,
        budget: &mut TypeExpansionBudget,
    ) -> Option<Vec<TypeField>> {
        match value {
            Type::Record(fields) | Type::CallableRecord { fields, .. } => Some(fields),
            Type::IndexedRecord { object, .. } => {
                self.expand_record_fields(*object, visited, budget)
            }
            Type::Named { .. }
            | Type::InferenceBarrier(_)
            | Type::Conditional(_)
            | Type::Mapped(_)
            | Type::KeyOf(_)
            | Type::IndexedAccess { .. } => {
                let expanded =
                    instantiate_named(&value, &self.types, visited, budget, "record spread")?;
                self.expand_record_fields(expanded, visited, budget)
            }
            Type::Union(branches) if !branches.is_empty() => {
                let branch_count = branches.len();
                let mut fields: Vec<(TypeField, usize)> = Vec::new();
                for branch in branches {
                    if !budget.consume() {
                        return None;
                    }
                    for field in self.expand_record_fields(branch, &mut visited.clone(), budget)? {
                        if let Some((existing, count)) = fields
                            .iter_mut()
                            .find(|(existing, _)| existing.name == field.name)
                        {
                            existing.value =
                                merge_conditional_branch_types(existing.value.clone(), field.value);
                            existing.optional |= field.optional;
                            *count += 1;
                        } else {
                            fields.push((field, 1));
                        }
                    }
                }
                Some(
                    fields
                        .into_iter()
                        .map(|(mut field, count)| {
                            field.optional |= count < branch_count;
                            field
                        })
                        .collect(),
                )
            }
            Type::Intersection(parts) => {
                let mut fields: Vec<TypeField> = Vec::new();
                for part in parts {
                    if !budget.consume() {
                        return None;
                    }
                    for field in self.expand_record_fields(part, &mut visited.clone(), budget)? {
                        if let Some(existing) = fields
                            .iter_mut()
                            .find(|existing| existing.name == field.name)
                        {
                            existing.optional &= field.optional;
                            existing.readonly |= field.readonly;
                            if existing.value != field.value {
                                existing.value =
                                    Type::Intersection(vec![existing.value.clone(), field.value]);
                            }
                        } else {
                            fields.push(field)
                        }
                    }
                }
                Some(fields)
            }
            _ => None,
        }
    }
}

pub(in crate::checker::module::expressions) fn record_member_end(
    tokens: &[Token],
    start: usize,
) -> Option<usize> {
    let mut depth = 0usize;
    for (index, token) in tokens.iter().enumerate().skip(start) {
        match token.text.as_str() {
            "(" | "[" | "{" => depth += 1,
            ")" | "]" | "}" if depth > 0 => depth -= 1,
            "," | "}" if depth == 0 => return Some(index),
            _ => {}
        }
    }
    None
}

fn insert_inferred_record_field(fields: &mut Vec<TypeField>, field: TypeField) {
    if let Some(existing) = fields
        .iter_mut()
        .find(|existing| existing.name == field.name)
    {
        *existing = field;
    } else {
        fields.push(field);
    }
}

fn insert_inferred_spread_field(fields: &mut Vec<TypeField>, mut field: TypeField) {
    field.readonly = false;
    field.accessor_write_type = None;
    if field.optional {
        if let Some(existing) = fields
            .iter_mut()
            .find(|existing| existing.name == field.name)
        {
            existing.value = merge_conditional_branch_types(existing.value.clone(), field.value);
            return;
        }
    }
    insert_inferred_record_field(fields, field);
}
