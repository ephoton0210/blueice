// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Ordinary type boundaries shared by decorator calls and replacements.
use blueice_bluets::{compile, CompilerOptions, MapLoader, ModuleSource};

fn accepts(source: &str) -> bool {
    !compile(
        "main.ts",
        &MapLoader::from([ModuleSource::new("main.ts", source)]),
        CompilerOptions::default(),
    )
    .has_errors()
}

#[test]
fn intersection_members_check_each_callback_receiver() {
    for receiver in ["Base", "Subject"] {
        let source = format!(
            "interface Base {{ state: string; }}
             interface Subject {{ state: string; value: number; }}
             interface Context<T> {{ kind: string; name: string; access: {{ has: (object: T) => boolean }}; }}
             declare const input: Context<Subject> & {{ name: 'value' }};
             const output: Context<{receiver}> = input;"
        );
        assert_eq!(accepts(&source), receiver == "Subject", "{source}");
    }
}

#[test]
fn constructor_relations_preserve_generic_constraints() {
    for constraint in ["string", "number"] {
        let source = format!(
            "interface Expected {{ new <T extends string>(value: T): {{ value: T }}; }}
             interface Actual {{ new <U extends {constraint}>(value: U): {{ value: U }}; }}
             declare const input: Actual;
             const output: Expected = input;"
        );
        assert_eq!(accepts(&source), constraint == "string", "{source}");
    }
}

#[test]
fn construct_signatures_have_an_implicit_prototype_without_granting_static_members() {
    let source = "interface Shape { value: number; read(): number; }
        abstract class Base { constructor(public value: number) {} abstract read(): number; }
        declare const factory: new (value: number) => Shape;
        const output: typeof Base = factory;";
    assert!(accepts(source));
    assert!(!accepts(&source.replace(
        "abstract class Base {",
        "abstract class Base { static readonly marker = 'base';"
    )));
}

#[test]
fn logical_operators_keep_only_the_returned_left_branch() {
    assert!(accepts(
        "declare const input: string | undefined;
         const output: string = input || 'fallback';"
    ));
    assert!(!accepts(
        "declare const input: string | undefined;
         const output: string = input && 'suffix';"
    ));
    assert!(!accepts(
        "declare const input: string | undefined;
         const output: string = input || undefined;"
    ));
}
