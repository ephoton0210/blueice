// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Names printed from the authorized declaration graph.
use crate::{Declaration, Project};

pub(super) fn display(name: &str, project: Option<&Project>) -> String {
    if name.starts_with("#typeparam@") {
        return crate::parser::source_type_name(name).into();
    }
    let name = crate::parser::source_type_name(name);
    if name.starts_with("import(") {
        if let Some((_, member)) = name.rsplit_once(").") {
            return member.rsplit('.').next().unwrap_or(member).into();
        }
    }
    if let Some(name) = crate::standard_library::presentation::namespace_name(name) {
        return name.into();
    }
    let Some(project) = project else {
        return name.into();
    };
    if let Some(name) = project.modules.values().find_map(|module| {
        module
            .class_expressions
            .values()
            .find(|expression| {
                expression.class.name == name
                    || format!("{}@{}", expression.class.name, module.id) == name
            })
            .and_then(|expression| expression.name.as_ref())
    }) {
        return name.clone();
    }
    if let Some((local, owner)) = name.split_once('@') {
        if project.imported_type_declaration(owner, local).is_some()
            || project.modules.get(owner).is_some_and(|module| {
                module.declarations.iter().any(|item| {
                matches!(item, Declaration::TypeAlias(alias) if alias.name == local)
                    || matches!(item, Declaration::Interface(interface) if interface.name == local)
            })
            })
        {
            return local.into();
        }
    }
    if let Some(owner) = name
        .strip_prefix("super ")
        .and_then(|owner| owner.split('@').next())
    {
        if let Some(base) = project
            .modules
            .values()
            .flat_map(|module| &module.declarations)
            .find_map(|item| match item {
                Declaration::Class(class) if class.name == owner => class.extends_name.as_ref(),
                _ => None,
            })
        {
            return display(base, Some(project));
        }
    }
    for module in project.modules.values() {
        for item in &module.declarations {
            let Declaration::Import(import) = item else {
                continue;
            };
            if let Some(binding) = import.bindings.iter().find(|binding| binding.local == name) {
                if let Some(resolved) = project
                    .resolved_import(&module.id, import)
                    .and_then(|id| project.modules.get(id))
                {
                    if resolved.declarations.iter().any(|item|matches!(item,Declaration::Class(class) if class.name==binding.imported)) {return binding.imported.clone();}
                }
            }
        }
    }
    if name.ends_with("JSX.Element") {
        return "Element".into();
    }
    if let Some((_, member)) = name.rsplit_once(".JSX.") {
        if matches!(
            member,
            "IntrinsicClassAttributes" | "LibraryManagedAttributes"
        ) {
            return member.into();
        }
    }
    if let Some((_, tail)) = name.rsplit_once('.') {
        fn found(items: &[Declaration], name: &str) -> bool {
            items.iter().any(|item| match item {
                Declaration::Class(class) => class.name == name,
                Declaration::Namespace(ns) => ns.name == name || found(&ns.body, name),
                _ => false,
            })
        }
        if project
            .modules
            .values()
            .any(|module| found(&module.declarations, tail))
        {
            return format!(
                "{}{tail}",
                if name.starts_with("typeof ") {
                    "typeof "
                } else {
                    ""
                }
            );
        }
    }
    name.into()
}
