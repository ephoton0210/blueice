// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Diagnostic type spelling is separate from stable BTS prose and checking.
use crate::parser::{Parameter, Type};
mod imports;
pub(crate) use imports::display as import_display;
mod names;
mod parameters;
mod relations;
mod signatures;
mod tuples;
pub(crate) use parameters::list as parameter_list_in;
pub(crate) use relations::detail;

pub(crate) fn render(value: &Type) -> String {
    text(value, 0, None)
}
pub(crate) fn render_in(value: &Type, project: &crate::Project) -> String {
    text(value, 0, Some(project))
}

pub(crate) fn render_exact_optional(value: &Type, project: &crate::Project) -> String {
    text_options(value, 0, Some(project), true)
}

fn field_name(field: &crate::parser::TypeField, project: Option<&crate::Project>) -> String {
    if let Some(name) = crate::symbol_keys::display(&field.name) {
        return name;
    }
    if let Some(source) = project.and_then(|p| p.source(&field.span.module)) {
        if let Some(text) = source.get(field.span.start..field.span.end) {
            let text = text.trim_start();
            if let Some(quote) = text.chars().next().filter(|c| matches!(c, '\'' | '"')) {
                if let Some(end) = text[1..].find(quote) {
                    return text[..end + 2].to_string();
                }
            }
        }
    }
    if field
        .name
        .chars()
        .enumerate()
        .all(|(i, c)| c.is_alphabetic() || matches!(c, '_' | '$') || (i > 0 && c.is_ascii_digit()))
    {
        field.name.clone()
    } else {
        serde_json::to_string(&field.name).unwrap()
    }
}

fn text(value: &Type, depth: usize, project: Option<&crate::Project>) -> String {
    text_options(value, depth, project, false)
}

fn text_options(
    value: &Type,
    depth: usize,
    project: Option<&crate::Project>,
    exact_optional: bool,
) -> String {
    if let Some(display) = crate::type_operator_profiles::diagnostic(value) {
        return display.to_string();
    }
    if depth >= 128 {
        return "...".into();
    }
    let render = |value: &Type| text_options(value, depth + 1, project, exact_optional);
    match value {
        Type::Conditional(_)
        | Type::Infer(_)
        | Type::Mapped(_)
        | Type::TemplateLiteral(_)
        | Type::Readonly(_)
        | Type::IndexedRecord { .. } => value.operator_text(render).expect("operator type"),
        Type::KeyOf(value) => format!("keyof {}", render(value)),
        Type::IndexedAccess { object, index, .. } => {
            format!("{}[{}]", render(object), render(index))
        }
        Type::Predicate(predicate) => predicate.text(render),
        Type::Literal(value) => {
            if value.starts_with('\'') && value.ends_with('\'') {
                serde_json::to_string(&value[1..value.len() - 1]).unwrap()
            } else {
                value.clone()
            }
        }
        Type::Named { name, arguments } => {
            if let Some(Type::Named { name, arguments }) =
                project.and_then(|project| imports::display(value, project))
            {
                return if arguments.is_empty() {
                    name
                } else {
                    format!(
                        "{name}<{}>",
                        arguments.iter().map(render).collect::<Vec<_>>().join(", ")
                    )
                };
            }
            if name == "Readonly"
                && arguments.len() == 1
                && matches!(&arguments[0], Type::Array(_) | Type::Tuple(_))
            {
                return format!("readonly {}", render(&arguments[0]));
            }
            if name == "ReadonlyArray" && arguments.len() == 1 {
                return format!("readonly {}", arguments[0].array_element_text(render));
            }
            let name = names::display(name, project);
            if arguments.is_empty() {
                name
            } else {
                format!(
                    "{name}<{}>",
                    arguments.iter().map(render).collect::<Vec<_>>().join(", ")
                )
            }
        }
        Type::Array(value) => value.array_element_text(render),
        Type::Tuple(values) => format!(
            "[{}]",
            values
                .iter()
                .map(|value| {
                    let label = value
                        .label
                        .as_ref()
                        .map(|name| format!("{name}{}: ", if value.optional { "?" } else { "" }))
                        .unwrap_or_default();
                    format!(
                        "{}{label}{}{}",
                        if value.rest { "..." } else { "" },
                        if value.optional
                            && value.label.is_none()
                            && matches!(value.annotation, Type::Union(_))
                        {
                            format!("({})", render(&value.annotation))
                        } else {
                            render(&value.annotation)
                        },
                        if value.optional && value.label.is_none() {
                            "?"
                        } else {
                            ""
                        }
                    )
                })
                .collect::<Vec<_>>()
                .join(", ")
        ),
        Type::CallableRecord { fields, signatures } => {
            let record_text = text_options(
                &Type::Record(fields.clone()),
                depth,
                project,
                exact_optional,
            );
            if record_text.starts_with("typeof ") {
                return record_text;
            }
            if fields.is_empty() && signatures.len() == 1 && signatures[0].constructor_arrow {
                let signature = &signatures[0];
                return format!(
                    "{}new ({}) => {}",
                    if signature.abstract_constructor {
                        "abstract "
                    } else {
                        ""
                    },
                    parameter_list_in(&signature.parameters, project),
                    render(&signature.result)
                );
            }
            let mut members = fields
                .iter()
                .map(|field| {
                    format!(
                        "{}{}{}: {};",
                        if field.readonly { "readonly " } else { "" },
                        field.name,
                        if field.optional { "?" } else { "" },
                        render(&field.value)
                    )
                })
                .collect::<Vec<_>>();
            members.extend(signatures.iter().map(|signature| {
                format!(
                    "{}({}): {};",
                    if signature.construct { "new " } else { "" },
                    parameter_list_in(&signature.parameters, project),
                    render(&signature.result)
                )
            }));
            format!("{{ {} }}", members.join(" "))
        }
        Type::Record(fields) => {
            if let Some(project) = project {
                if let Some(prototype) = fields
                    .iter()
                    .find(|field| field.name == "prototype" && field.readonly)
                {
                    fn class_at<'a>(
                        declarations: &'a [crate::Declaration],
                        span: &crate::SourceSpan,
                    ) -> Option<&'a str> {
                        declarations
                            .iter()
                            .find_map(|declaration| match declaration {
                                crate::Declaration::Class(class) if class.name_span == *span => {
                                    Some(class.name.as_str())
                                }
                                crate::Declaration::Namespace(ns) => class_at(&ns.body, span),
                                _ => None,
                            })
                    }
                    if let Some(name) = project.modules.values().find_map(|module| {
                        class_at(&module.declarations, &prototype.span).or_else(|| {
                            module
                                .class_expressions
                                .values()
                                .find(|expression| expression.class.name_span == prototype.span)
                                .and_then(|expression| expression.name.as_deref())
                        })
                    }) {
                        return format!("typeof {name}");
                    }
                }
            }
            if fields.is_empty() {
                return "{}".into();
            }
            let fields = fields.iter().map(|field| {
                let optional=field.optional && !matches!(field.value,Type::Any|Type::Unknown);
                let mut value = if optional && !exact_optional && !matches!(&field.value,Type::Union(values) if values.contains(&Type::Undefined)) {
                    let value=render(&field.value);
                    if matches!(field.value,Type::Function {..}) {format!("({value}) | undefined")} else {format!("{value} | undefined")}
                } else { render(&field.value) };
                if let Type::Function { parameters,result } = &field.value {
                    // A method signature keeps its original method syntax.
                    let source_method = project.and_then(|project|project.source(&field.span.module).or_else(||(field.span.module=="<inferred>").then(||project.modules.values().find_map(|module|module.source.get(field.span.start..field.span.end).filter(|source|source.trim_start().starts_with(&field.name)).map(|_|module.source.as_str()))).flatten())).and_then(|source|source.get(field.span.start..field.span.end)).is_some_and(|source|source.trim_start().strip_prefix(&field.name).is_some_and(|rest|rest.trim_start_matches('?').trim_start().starts_with('(')));
                    if source_method { return format!("{}{}({}): {};",field.name,if field.optional {"?"} else {""},parameters::list(parameters,project),render(result)); }
                }
                if optional && !exact_optional && matches!(field.value,Type::Union(_)) {value=render(&Type::Union(match &field.value {Type::Union(values)=>{let mut values=values.clone();if !values.contains(&Type::Undefined) {values.push(Type::Undefined)} values},_=>unreachable!()}));}
                format!("{}{}{}: {value};",if field.readonly {"readonly "} else {""},field_name(field,project),if field.optional {"?"} else {""})
            }).collect::<Vec<_>>().join(" ");
            format!("{{ {fields} }}")
        }
        Type::GenericFunction {
            type_parameters,
            parameters,
            result,
            ..
        } => {
            let generic = type_parameters
                .iter()
                .map(|p| {
                    let mut text = p.name.clone();
                    if let Some(constraint) = &p.constraint {
                        text.push_str(&format!(" extends {}", render(constraint)));
                    }
                    if let Some(default) = &p.default {
                        text.push_str(&format!(" = {}", render(default)));
                    }
                    text
                })
                .collect::<Vec<_>>()
                .join(", ");
            format!(
                "<{generic}>({}) => {}",
                parameters::list(parameters, project),
                render(result)
            )
        }
        Type::Function { parameters, result } => {
            format!(
                "({}) => {}",
                parameters::list(parameters, project),
                render(result)
            )
        }
        Type::Union(values) => {
            let literal_union = values.iter().all(|value| matches!(value, Type::Literal(_)));
            let mut values = values
                .iter()
                .map(|value| {
                    if matches!(value, Type::Function { .. }) || matches!(value, Type::CallableRecord {fields, signatures} if fields.is_empty() && signatures.len() == 1 && signatures[0].constructor_arrow) {
                        format!("({})", render(value))
                    } else {
                        render(value)
                    }
                })
                .collect::<Vec<_>>();
            if !literal_union {
                values.sort_by_key(|value| {
                    (
                        match value.as_str() {
                            "string" => 0,
                            "number" => 1,
                            "bigint" => 2,
                            "boolean" => 3,
                            "null" => 10,
                            "undefined" => 11,
                            _ => 5,
                        },
                        value.clone(),
                    )
                });
            }
            values.dedup();
            values.join(" | ")
        }
        Type::Intersection(values) => values.iter().map(render).collect::<Vec<_>>().join(" & "),
        Type::Any => "any".into(),
        Type::Unknown | Type::StrictUnknown => "unknown".into(),
        Type::BigInt => "bigint".into(),
        Type::Symbol => "symbol".into(),
        Type::UniqueSymbol(origin) => project
            .and_then(|project| {
                project.modules.values().find_map(|module| {
                    module
                        .declarations
                        .iter()
                        .find_map(|declaration| match declaration {
                            crate::Declaration::Variable(variable)
                                if variable.annotation.as_ref() == Some(value)
                                    || variable.span == *origin =>
                            {
                                Some(format!("typeof {}", variable.name))
                            }
                            _ => None,
                        })
                })
            })
            .unwrap_or_else(|| "unique symbol".into()),
        Type::ConstAssertion => "const".into(),
        Type::Never => "never".into(),
        Type::Void => "void".into(),
        Type::Null => "null".into(),
        Type::Undefined => "undefined".into(),
        Type::Boolean => "boolean".into(),
        Type::Number => "number".into(),
        Type::String => "string".into(),
    }
}

pub(crate) fn argument(actual: &Type, expected: &Type) -> String {
    match (actual, expected) {
        (Type::Literal(value), Type::Union(values))
            if !values.iter().any(|value| matches!(value, Type::Literal(_))) =>
        {
            if value.starts_with(['\'', '"']) {
                "string".into()
            } else if value.parse::<f64>().is_ok() {
                "number".into()
            } else {
                render(actual)
            }
        }
        (
            Type::Literal(value),
            Type::Number
            | Type::String
            | Type::Boolean
            | Type::Array(_)
            | Type::Record(_)
            | Type::Function { .. },
        ) => {
            if value.starts_with(['\'', '"']) {
                "string".into()
            } else if value == "true" || value == "false" {
                "boolean".into()
            } else {
                "number".into()
            }
        }
        _ => render(actual),
    }
}

pub(crate) fn argument_in(actual: &Type, expected: &Type, project: &crate::Project) -> String {
    let value = argument(actual, expected);
    if value == render(actual) {
        render_in(actual, project)
    } else {
        value
    }
}

pub(crate) fn assignment_in(actual: &Type, expected: &Type, project: &crate::Project) -> String {
    if matches!(expected, Type::String | Type::Number | Type::Boolean) {
        if let Some(Type::Union(parts)) =
            crate::standard_library::presentation::alias_value(actual, project)
        {
            if parts.iter().all(|part| matches!(part, Type::Literal(_))) {
                return assignment_in(&Type::Union(parts), expected, project);
            }
        }
    }
    if let Type::Union(parts) = actual {
        if matches!(expected, Type::String | Type::Number | Type::Boolean)
            && parts.iter().all(|part| matches!(part, Type::Literal(_)))
        {
            let mut values = parts
                .iter()
                .map(|part| argument_in(part, expected, project))
                .collect::<Vec<_>>();
            values.sort_by_key(|value| match value.as_str() {
                "string" => 0,
                "number" => 1,
                "boolean" => 2,
                _ => 3,
            });
            values.dedup();
            return values.join(" | ");
        }
    }
    if matches!(actual, Type::Literal(value) if value.starts_with(['\'', '"'])
        || value.parse::<f64>().is_ok() || matches!(value.as_str(), "true" | "false"))
    {
        argument_in(actual, expected, project)
    } else {
        // Enum member encodings retain their nominal, module-owned identity.
        render_in(actual, project)
    }
}
pub(crate) fn default_parameter(value: &Type, parameter: &Parameter) -> Type {
    if parameter.default.is_none() {
        return value.clone();
    }
    if let Type::Union(values) = value {
        let mut values = values
            .iter()
            .filter(|value| **value != Type::Undefined)
            .cloned()
            .collect::<Vec<_>>();
        if values.len() == 1 {
            values.pop().unwrap()
        } else {
            Type::Union(values)
        }
    } else {
        value.clone()
    }
}
