// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Nested object assignment failures retain the exact property and its owner.

use super::*;

impl ModuleChecker<'_> {
    pub(in crate::checker::module) fn nested_record_assignment_error(
        &mut self,
        span: &SourceSpan,
        message: &str,
        code: DiagnosticCode,
        actual: &Type,
        expected: &Type,
    ) -> bool {
        self.record_assignment_error(span, message, code, (actual, expected), 0)
    }

    pub(in crate::checker::module) fn jsx_record_assignment_error(
        &mut self,
        span: &SourceSpan,
        actual: &Type,
        expected: &Type,
    ) -> bool {
        self.record_assignment_error(
            span,
            "JSX attribute has an incompatible nested property",
            DiagnosticCode::TypeMismatch,
            (actual, expected),
            1,
        )
    }

    fn record_assignment_error(
        &mut self,
        span: &SourceSpan,
        message: &str,
        code: DiagnosticCode,
        (actual, expected): (&Type, &Type),
        initial_depth: usize,
    ) -> bool {
        let mut budget = TypeExpansionBudget::new(self.max_type_expansions);
        budget.checking = self.checking;
        let Some((actual, expected, owner, repeated_relation)) =
            self.nested_mismatch(actual, expected, span, &mut budget, initial_depth, &[])
        else {
            return false;
        };
        if budget.exhausted {
            return false;
        }
        let point = self
            .module
            .source
            .get(span.start..span.end)
            .and_then(|source| crate::syntax::lex(&self.module.id, source).ok())
            .and_then(|tokens| {
                tokens
                    .into_iter()
                    .find(|token| span.start + token.start == actual.span.start)
            })
            .map(|token| {
                SourceSpan::new(
                    &self.module.id,
                    span.start + token.start,
                    span.start + token.end,
                )
            });
        let Some(point) = point else {
            return false;
        };
        let exact_optional = self.checking.exact_optional_property_types
            && self.exact_optional_mismatch(&actual.value, &expected.value);
        self.typescript_type_error(
            &point,
            message.into(),
            code,
            if exact_optional { 2375 } else { 2322 },
            vec![
                crate::diagnostic::type_text::render_in(&actual.value, self.project),
                if exact_optional {
                    crate::diagnostic::type_text::render_exact_optional(
                        &expected.value,
                        self.project,
                    )
                } else {
                    crate::diagnostic::type_text::render_in(&expected.value, self.project)
                },
            ],
        );
        self.explain_last_type_pair(&actual.value, &expected.value);
        let origin = self
            .project
            .source(&expected.span.module)
            .and_then(|source| crate::syntax::lex(&expected.span.module, source).ok())
            .and_then(|tokens| {
                tokens.into_iter().find(|token| {
                    token.start >= expected.span.start
                        && token.end <= expected.span.end
                        && token.is(&expected.name)
                })
            })
            .map(|token| token.span(&expected.span.module))
            .unwrap_or_else(|| expected.span.clone());
        if let Some(counterpart) = self
            .diagnostics
            .last_mut()
            .and_then(|diagnostic| diagnostic.typescript.as_mut())
            .filter(|_| !repeated_relation)
        {
            counterpart.related_information.push(crate::TypeScriptRelatedInformation {
                code: 6500,
                message: format!("The expected type comes from property '{}' which is declared here on type '{}'", expected.name, crate::diagnostic::type_text::render_in(&owner, self.project)),
                span: origin,
                position: None,
            });
        }
        true
    }

    fn nested_mismatch(
        &self,
        actual: &Type,
        expected: &Type,
        span: &SourceSpan,
        budget: &mut TypeExpansionBudget,
        depth: usize,
        ancestors: &[Type],
    ) -> Option<(TypeField, TypeField, Type, bool)> {
        if depth >= 128 || !budget.consume() {
            return None;
        }
        let Type::Record(actual) = actual else {
            return None;
        };
        let shape = crate::checker::type_operators::expanded(
            expected,
            &self.types,
            &mut HashSet::new(),
            budget,
        );
        let Type::Record(fields) = &shape else {
            return None;
        };
        let repeated_relation = ancestors.contains(&shape);
        if fields
            .iter()
            .any(|field| !field.optional && !actual.iter().any(|item| item.name == field.name))
        {
            return None;
        }
        for item in actual {
            let field = fields.iter().find(|field| field.name == item.name)?;
            if is_assignable(
                &item.value,
                &field.value,
                &self.types,
                &mut HashSet::new(),
                budget,
            ) {
                continue;
            }
            if item.span.module != "<inferred>"
                || item.span.start < span.start
                || item.span.end > span.end
            {
                return None;
            }
            if self.checking.exact_optional_property_types
                && self.exact_optional_mismatch(&item.value, &field.value)
            {
                return Some((
                    item.clone(),
                    field.clone(),
                    expected.clone(),
                    repeated_relation,
                ));
            }
            let mut nested_ancestors = ancestors.to_vec();
            nested_ancestors.push(shape.clone());
            if let Some(nested) = self.nested_mismatch(
                &item.value,
                &field.value,
                span,
                budget,
                depth + 1,
                &nested_ancestors,
            ) {
                return Some(nested);
            }
            return (depth > 0).then(|| {
                (
                    item.clone(),
                    field.clone(),
                    expected.clone(),
                    repeated_relation,
                )
            });
        }
        None
    }

    fn exact_optional_mismatch(&self, actual: &Type, expected: &Type) -> bool {
        let (Type::Record(actual), Type::Record(expected)) = (actual, expected) else {
            return false;
        };
        expected.iter().any(|e| {
            e.optional && actual.iter().any(|a| {
                a.name == e.name
                    && a.value == Type::Undefined
                    && e.value != Type::Undefined
                    && !matches!(&e.value, Type::Union(parts) if parts.contains(&Type::Undefined))
            })
        })
    }
}
