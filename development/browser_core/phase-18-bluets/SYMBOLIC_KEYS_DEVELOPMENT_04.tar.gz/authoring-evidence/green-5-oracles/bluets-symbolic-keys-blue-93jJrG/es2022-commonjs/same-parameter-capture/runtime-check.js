"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = result; function result(consume) { return function(key) { consume(key); }; }

var check = module.exports.result;
var observed = ""; check(function(key) { observed = key; })("x"); if (observed !== "x") throw Error("captured key callback");
