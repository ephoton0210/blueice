"use strict"; Object.defineProperty(exports, "__esModule", { value: true }); exports.result = result; function result(key, consume) {  const local= key; consume(local); }

var check = module.exports.result;
var observed = ""; check("x", function(key) { observed = key; }); if (observed !== "x") throw Error("key callback");
