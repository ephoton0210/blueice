# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Continue one existing acceptance into verified publication and reviewable docs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

DELIVERY=Path(__file__).resolve().parent
REPO=DELIVERY.parent.parent
ROOT=DELIVERY.parent/'higher-order-inference-acceptance-20261114-r5'
STATE=DELIVERY/'state.json'
assert not STATE.exists(),'Observe the existing continuation instead of launching another'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
initial=read(ROOT/'launch-state.json')
assert initial['pid']==92647
state={'pid':os.getpid(),'conclusion':'in_progress','stage':'observing-existing-platform-acceptance',
    'observedAcceptancePid':initial['pid'],'sourceRevision':initial['sourceRevision'],
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],
    'commitPerformed':False,'pushPerformed':False}

def save():
    state['recordedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary=STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(state,indent=2)+'\n');temporary.replace(STATE)

def run(label,args):
    state['stage']=label;save();print('START',label,flush=True)
    log=DELIVERY/(label+'.log')
    with log.open('xb')as output:
        child=subprocess.Popen(args,cwd=REPO,stdout=output,stderr=subprocess.STDOUT)
        state['childPid']=child.pid;save();code=child.wait()
    state.pop('childPid',None)
    state['steps'].append({'label':label,'command':args,'exit':code,'log':log.name,'sha256':sha(log)})
    save();print('END',label,code,flush=True)
    assert code==0,label+': inspect preserved '+str(log)

try:
    save();missing=0
    while True:
        observed=read(ROOT/'launch-state.json')
        assert observed['pid']==initial['pid'] and observed['sourceRevision']==initial['sourceRevision']
        if observed['conclusion']!='in_progress':
            break
        process=subprocess.run(['ps','-p',str(initial['pid']),'-o','command='],text=True,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if process.returncode:
            missing+=1
            state['missingProcessObservations']=missing;save()
            assert missing<=5,'Observed acceptance handle missing without terminal receipt; inspect, never restart'
        else:
            assert 'higher-order-inference-acceptance-20261114-r5/launch.py'in process.stdout
            missing=0
            state['lastAcceptanceProcessVerifiedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            state['lastAcceptanceCommand']=process.stdout.strip();save()
        time.sleep(10)
    assert observed['conclusion']=='failure',observed
    assert observed['stage']=='platform-failure-observing-other-running-platform'
    assert observed['platforms']['mac']['exit']==0 and observed['platforms']['windows']['exit']==1
    assert read(ROOT/'mac-driver.json')['conclusion']=='success'
    assert read(ROOT/'windows/complete-state.json')['conclusion']=='failure'
    sys.path.insert(0,str(ROOT))
    from g_acceptance_audit import verified_platform_completion
    completion=verified_platform_completion()
    state['qualifiedPlatformCompletion']=completion;save()
    earlier=DELIVERY.parent/'higher-order-inference-delivery-20261114-r5'
    while read(earlier/'state.json')['conclusion']=='in_progress':
        time.sleep(2)
    assert read(earlier/'state.json')['conclusion']=='failure'
    assert read(earlier/'state.json')['steps']==[]
    preserved=ROOT/'earlier-delivery-continuation';preserved.mkdir()
    for path in earlier.iterdir():
        assert not path.is_symlink()
        if path.is_file():shutil.copy2(path,preserved/path.name)
    state['stage']='snapshot-publication-tools';save()
    snapshot=ROOT/'publication-start-snapshot';snapshot.mkdir()
    tool_hashes={}
    for path in sorted(ROOT.glob('*.py'))+sorted(ROOT.glob('*.cjs')):
        shutil.copy2(path,snapshot/path.name);tool_hashes[path.name]=sha(path)
    shutil.copy2(__file__,ROOT/'publication-supervision-source.py')
    (ROOT/'publication-start-manifest.json').write_text(json.dumps({
        'sourceRevision':initial['sourceRevision'],'allPlatformProcessesTerminal':True,
        'tools':tool_hashes,'supervisionSourceSha256':sha(Path(__file__)),
        'scope':'Post-acceptance publication with preserved original audit-only failure and verified platform-conditional correction; command logs live outside the immutable artifact collection.'},indent=2)+'\n')
    steps=[
        ('publish',[sys.executable,'-B',str(ROOT/'g_publish.py')]),
        ('verify-before-todo',[sys.executable,'-B',str(ROOT/'g_verify_publication.py'),'--before-todo']),
        ('finalize-docs',[sys.executable,'-B',str(ROOT/'g_finalize_docs.py')]),
        ('verify-after-todo',[sys.executable,'-B',str(ROOT/'g_verify_publication.py')]),
        ('account-check',[sys.executable,str(REPO/'development/browser_core/phase-18-bluets/tools/account_inventory_rows.py'),'--check']),
        ('status-check',[sys.executable,str(REPO/'development/browser_core/phase-18-bluets/tools/check_compatibility_status.py'),'--check']),
        ('diff-check',['git','diff','--check']),
    ]
    for label,args in steps:
        assert all(sha(ROOT/name)==digest for name,digest in tool_hashes.items())
        run(label,args)
    state.update(conclusion='success',stage='publication-verified-docs-ready-awaiting-diff-review-commit-push',
        measurementSha256=sha(REPO/'development/browser_core/phase-18-bluets/HIGHER_ORDER_INFERENCE_MEASUREMENT.json'))
except BaseException as error:
    state.update(conclusion='failure',error=repr(error));raise
finally:
    state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print(json.dumps({key:value for key,value in state.items()if key!='steps'}))
