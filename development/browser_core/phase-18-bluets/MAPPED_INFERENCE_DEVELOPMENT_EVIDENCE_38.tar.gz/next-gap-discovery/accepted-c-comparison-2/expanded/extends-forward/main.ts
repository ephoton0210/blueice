export function result<E, F extends E, K extends keyof E>(key: K, consume: (key: keyof F) => void) { consume(key); }
