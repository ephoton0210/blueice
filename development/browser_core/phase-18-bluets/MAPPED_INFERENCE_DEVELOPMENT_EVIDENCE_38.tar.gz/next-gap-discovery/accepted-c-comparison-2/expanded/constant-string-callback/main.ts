type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E>(values: Map<keyof E, List<E[keyof E]>>) {
 return {run<K extends keyof E>(key: K, event: E[K]) {
 const found = values.get(key); if (found) { return found.slice().map(handler => { handler(event); return "done"; }); }
 }};
}
