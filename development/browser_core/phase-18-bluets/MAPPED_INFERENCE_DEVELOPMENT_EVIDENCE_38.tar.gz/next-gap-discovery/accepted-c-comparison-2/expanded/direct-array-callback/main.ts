type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E>(values: List<E[keyof E]>, event: E[keyof E]) { return values.map(handler => handler(event)); }
