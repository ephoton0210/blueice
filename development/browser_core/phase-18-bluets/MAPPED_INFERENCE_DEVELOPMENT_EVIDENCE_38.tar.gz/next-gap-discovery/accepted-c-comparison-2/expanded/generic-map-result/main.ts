export function result<E, K extends keyof E>(values: Map<keyof E, number>, key: K) { return values.get(key); }
