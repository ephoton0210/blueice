export function result<E>(key: keyof unknown, consume: (key: keyof E) => void) { consume(key); }
