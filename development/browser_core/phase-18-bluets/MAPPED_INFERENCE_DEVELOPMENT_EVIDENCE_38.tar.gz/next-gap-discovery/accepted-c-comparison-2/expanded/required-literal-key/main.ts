export function result<E extends {x: number}>(consume: (key: keyof E) => void) { consume("x"); }
