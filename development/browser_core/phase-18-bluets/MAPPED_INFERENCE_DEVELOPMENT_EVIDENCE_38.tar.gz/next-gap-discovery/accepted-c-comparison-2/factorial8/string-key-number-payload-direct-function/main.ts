type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E, K extends string>(values: Map<string, List<number>>, key: K, event: number) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }
