type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E>(values: Map<keyof E, List<number>>) { return {run<K extends keyof E>(key: K, event: number) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }}; }
