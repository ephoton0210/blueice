type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E>(values: Map<string, List<number>>) { return {run<K extends string>(key: K, event: number) { const found = values.get(key); if (found) { return found.map(handler => handler(event)); } }}; }
