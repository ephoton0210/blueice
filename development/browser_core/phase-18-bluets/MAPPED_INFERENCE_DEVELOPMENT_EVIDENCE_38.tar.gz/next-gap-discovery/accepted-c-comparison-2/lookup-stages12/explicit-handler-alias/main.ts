type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<E>(values: Map<string, List<E[keyof E]>>, key: string, event: E[keyof E]) { const found = values.get(key); if (found) { const handler: Handler<E[keyof E]> = found[0]; return handler(event); } }
