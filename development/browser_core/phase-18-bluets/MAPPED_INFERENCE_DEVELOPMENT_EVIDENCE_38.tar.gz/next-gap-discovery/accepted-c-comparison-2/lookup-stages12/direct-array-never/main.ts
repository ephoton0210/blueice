type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result(values: List<never>, event: never) { return values.map(handler => handler(event)); }
