type Handler<T> = (event: T) => void;
export function result<T>(handler: Handler<T>, event: T) { return handler(event); }
