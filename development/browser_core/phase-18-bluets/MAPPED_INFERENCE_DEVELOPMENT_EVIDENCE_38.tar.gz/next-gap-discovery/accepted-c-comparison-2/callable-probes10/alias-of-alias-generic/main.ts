type Handler<T> = (event: T) => void;
type Wrapped<U> = Handler<U>;
export function result<P>(handler: Wrapped<P>, event: P) { return handler(event); }
