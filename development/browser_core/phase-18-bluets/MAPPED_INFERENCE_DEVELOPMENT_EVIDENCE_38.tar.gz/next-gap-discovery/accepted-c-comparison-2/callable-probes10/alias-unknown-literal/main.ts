type Handler<T> = (event: T) => void;
export function result(handler: Handler<unknown>, event: unknown) { return handler(event); }
