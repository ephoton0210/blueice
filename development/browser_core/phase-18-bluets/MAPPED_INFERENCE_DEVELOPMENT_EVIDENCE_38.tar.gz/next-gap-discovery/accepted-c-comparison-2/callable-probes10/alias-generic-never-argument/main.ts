type Handler<T> = (event: T) => void;
export function result<P>(handler: Handler<P>, event: P) { return handler(event as never); }
