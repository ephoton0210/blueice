type Handler<T> = (event: T) => void;
export function result<P extends Record<string, unknown>>(handler: Handler<P>, event: P) { return handler(event); }
