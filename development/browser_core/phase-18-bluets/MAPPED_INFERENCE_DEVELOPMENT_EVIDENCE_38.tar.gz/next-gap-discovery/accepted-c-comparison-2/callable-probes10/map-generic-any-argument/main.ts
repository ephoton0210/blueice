type Handler<T> = (event: T) => void;
type List<T> = Array<Handler<T>>;
export function result<P>(values: Map<string, List<P>>, key: string, event: P) { const found = values.get(key); if (found) { return found.map(handler => handler(event as any)); } }
