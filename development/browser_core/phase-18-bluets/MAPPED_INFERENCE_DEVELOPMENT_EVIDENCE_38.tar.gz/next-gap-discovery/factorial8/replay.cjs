// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path');
const {spawnSync} = require('node:child_process');
const {createHash} = require('node:crypto');
const repo = path.resolve(__dirname, '../../..'), root = __dirname;
const sha = data => createHash('sha256').update(data).digest('hex');
const read = name => JSON.parse(fs.readFileSync(name));
const referencePath = path.join(repo, 'target/mapped-callback-context-review-20261113/keyof-identity-controls/native-reference.json');
assert.equal(sha(fs.readFileSync(referencePath)), '0276415b9804b768b5c7b95e450d02ee2faeeb2bf899986c2c3c79c0d3314f7b');
const originalReference = read(referencePath);
const input = read(path.join(root, 'inputs.json'));
const reference = {...originalReference, cases:input.cases};
const originalById = new Map(originalReference.cases.map(row => ['es2022-commonjs/'+row.id,row]));
const acceptanceRoot = path.join(repo, 'target/mapped-inference-acceptance-20261113-r3');
const frozen = read(path.join(acceptanceRoot, 'frozen-source-preflight.json'));
const compiler = path.join(acceptanceRoot, 'accepted-native-cli');
const compilerSha256 = sha(fs.readFileSync(compiler));
assert.equal(compilerSha256, read(path.join(acceptanceRoot, 'native-gates.json')).nativeCompilerSha256);
const implementation = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/lib/typescript.js');
assert.equal(sha(fs.readFileSync(implementation)), reference.implementationSha256);
const ts = require(implementation);
assert.equal(ts.version, reference.typescript);
const libraryPins = read(path.join(repo, 'backend/bluets/tests/fixtures/mapped_inference/callback-context-controls.json')).libraries;
const {inventory, blueDiagnostic} = require(path.join(repo, 'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const report = {scope:'Next-gap factorial root-cause discovery only; no P0-D primary, acceptance or inventory credit.',
    sourceRevision:frozen.sourceRevision, compilerSha256, nativeReferenceSha256:sha(fs.readFileSync(referencePath)),
    implementationSha256:reference.implementationSha256, libraries:{}, cases:[], conclusion:'in_progress'};
const cache = new Map();
function diagnostic(row, cwd) {
    let file = null, position = null;
    if (row.file && row.start !== undefined) {
        const at = row.file.getLineAndCharacterOfPosition(row.start);
        file = path.relative(cwd, row.file.fileName).replaceAll('\\', '/');
        position = {line:at.line+1, column:at.character+1, length:row.length};
    }
    return {code:row.code, message:ts.flattenDiagnosticMessageText(row.messageText, '\n'),
        file, position, relatedInformation:(row.relatedInformation || []).map(item => diagnostic(item, cwd))};
}
const byId = new Map(reference.cases.map(row => [row.id,{}]));
for (const kind of ['native','blue']) {
    for (const entry of reference.cases) {
        const results = byId.get(entry.id);
        const cwd = path.join(root, entry.id, kind);
        fs.mkdirSync(cwd, {recursive:true});
        const source = path.join(cwd, 'main.ts');
        fs.writeFileSync(source, entry.source, {flag:'wx'});
        fs.writeFileSync(path.join(cwd,'tsconfig.json'), JSON.stringify({compilerOptions:{...reference.options,...entry.compilerOptions}, files:['main.ts']},null,2)+'\n', {flag:'wx'});
        let accepts, diagnostics;
        if (kind === 'native') {
            const converted = ts.convertCompilerOptionsFromJson({...reference.options,...entry.compilerOptions}, cwd);
            assert.deepEqual(converted.errors, []);
            const host = ts.createCompilerHost(converted.options), get = host.getSourceFile;
            host.getSourceFile = (file, version, ...rest) => {
                const relative = path.relative(path.dirname(implementation),file);
                if (relative.startsWith('..'+path.sep) || path.isAbsolute(relative)) return get(file,version,...rest);
                const name = path.basename(file), digest = sha(fs.readFileSync(file));
                assert.equal(digest, libraryPins[name], name);
                report.libraries[name] = digest;
                const key = file+':'+version;
                if (!cache.has(key)) cache.set(key,get(file,version,...rest));
                return cache.get(key);
            };
            const program = ts.createProgram([source], converted.options, host);
            diagnostics = ts.sortAndDeduplicateDiagnostics(ts.getPreEmitDiagnostics(program)).map(row => diagnostic(row,cwd));
            accepts = diagnostics.length === 0;
            if (accepts) program.emit();
        } else {
            const built = spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});
            fs.writeFileSync(path.join(cwd,'build.stdout'),built.stdout || '');
            fs.writeFileSync(path.join(cwd,'build.stderr'),built.stderr || '');
            if (built.error) throw built.error;
            accepts = built.status === 0;
            diagnostics = (built.stderr || '').split(/\r?\n/).filter(Boolean).map(line => ((row) => row.typescript ? blueDiagnostic(row) : {unpairedBlueDiagnostic:row})(JSON.parse(line)));
        }
        const declarations = Object.fromEntries(Object.entries(inventory(path.join(cwd,'dist'))).filter(([name]) => name.endsWith('.d.ts')));
        results[kind] = {accepts, diagnostics, declarations};
        fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(results[kind],null,2)+'\n',{flag:'wx'});

        if (kind === 'native') {
            assert.equal(results.native.accepts,entry.accepts,entry.id+': unexpected Native authoring verdict');
            const original = originalById.get(entry.id);
            if (original) for (const key of ['accepts','diagnostics','declarations']) assert.deepEqual(results.native[key],original[key],entry.id+': original Native changed');
        }
    }
    if (kind === 'native') {
        const bytes = JSON.stringify({inputSha256:sha(fs.readFileSync(path.join(root,'inputs.json'))),implementationSha256:report.implementationSha256,libraries:report.libraries,cases:reference.cases.map(entry=>({id:entry.id,source:entry.source,...byId.get(entry.id).native}))},null,2)+'\n';
        fs.writeFileSync(path.join(root,'native-reference.json'),bytes,{flag:'wx'});
        report.expandedNativeReferenceSha256=sha(bytes);
    }
}
for (const entry of reference.cases) {
    const results = byId.get(entry.id);
    report.cases.push({id:entry.id,sourceSha256:sha(entry.source),...results,
        verdictAgrees:results.native.accepts===results.blue.accepts,
        completeAgrees:JSON.stringify(results.native)===JSON.stringify(results.blue)});
}
assert.equal(sha(fs.readFileSync(compiler)),compilerSha256);
report.conclusion = 'discovery-complete';
report.completeAgreements = report.cases.filter(row => row.completeAgrees).length;
report.differences = report.cases.length-report.completeAgreements;
fs.writeFileSync(path.join(root,'observations.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({sourceRevision:report.sourceRevision, compilerSha256,
    comparisons:report.cases.length,completeAgreements:report.completeAgreements,differences:report.differences,libraries:Object.keys(report.libraries).length}));
