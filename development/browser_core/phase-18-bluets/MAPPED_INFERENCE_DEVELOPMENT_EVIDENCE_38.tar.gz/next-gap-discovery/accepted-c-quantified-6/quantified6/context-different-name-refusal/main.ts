export function result<P>(input: P) { const fn: <Q>(value: Q) => Q = value => input; return fn; }
