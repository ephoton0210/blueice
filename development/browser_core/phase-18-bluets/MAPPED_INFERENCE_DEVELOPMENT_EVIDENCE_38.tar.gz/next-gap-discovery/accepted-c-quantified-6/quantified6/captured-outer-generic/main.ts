export function result<P>(input: P) { const fn = (value: P) => value; return fn; }
