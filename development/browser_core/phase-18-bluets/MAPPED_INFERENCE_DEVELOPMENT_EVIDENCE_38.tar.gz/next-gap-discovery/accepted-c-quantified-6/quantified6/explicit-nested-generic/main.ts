export function result<P>(input: P) { const fn = <P>(value: P) => value; return fn; }
