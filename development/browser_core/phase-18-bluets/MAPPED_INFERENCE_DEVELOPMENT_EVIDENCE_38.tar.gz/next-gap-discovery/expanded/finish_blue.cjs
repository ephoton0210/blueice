// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path');
const {spawnSync} = require('node:child_process');
const {createHash} = require('node:crypto');
const repo = path.resolve(__dirname,'../../..'), root = __dirname;
const read = file => JSON.parse(fs.readFileSync(file));
const sha = data => createHash('sha256').update(data).digest('hex');
const nativePath = path.join(root,'native-reference.json'), reference = read(nativePath);
const inputs = read(path.join(root,'inputs.json'));
assert.equal(reference.inputSha256,sha(fs.readFileSync(path.join(root,'inputs.json'))));
const destination = path.join(root,'blue-replay-2'); fs.mkdirSync(destination);
const acceptanceRoot = path.join(repo,'target/mapped-inference-acceptance-20261113-r3');
const compiler = path.join(acceptanceRoot,'accepted-native-cli');
const compilerSha256 = sha(fs.readFileSync(compiler));
assert.equal(compilerSha256,read(path.join(acceptanceRoot,'native-gates.json')).nativeCompilerSha256);
const {inventory,blueDiagnostic} = require(path.join(repo,'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const report = {scope:'Expanded next-gap discovery; zero P0-D primary, acceptance or inventory credit.',
    sourceRevision:read(path.join(acceptanceRoot,'frozen-source-preflight.json')).sourceRevision,
    compilerSha256, inputSha256:reference.inputSha256, nativeReferenceSha256:sha(fs.readFileSync(nativePath)),
    implementationSha256:reference.implementationSha256, libraries:reference.libraries,
    preservedInterruptedReplay:'../replay.log', cases:[], conclusion:'in_progress'};
for (const entry of inputs.cases) {
    const expected = reference.cases.find(row=>row.id===entry.id);
    assert(expected && expected.source === entry.source);
    assert.deepEqual(Object.fromEntries(Object.entries(inventory(path.join(root,entry.id,'native/dist'))).filter(([name])=>name.endsWith('.d.ts'))),expected.declarations);
    const cwd = path.join(destination,entry.id); fs.mkdirSync(cwd);
    fs.writeFileSync(path.join(cwd,'main.ts'),entry.source,{flag:'wx'});
    fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify({compilerOptions:inputs.options,files:['main.ts']},null,2)+'\n',{flag:'wx'});
    const built = spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});
    fs.writeFileSync(path.join(cwd,'build.stdout'),built.stdout || '');
    fs.writeFileSync(path.join(cwd,'build.stderr'),built.stderr || '');
    if (built.error) throw built.error;
    const raw = (built.stderr || '').split(/\r?\n/).filter(Boolean).map(line=>JSON.parse(line));
    const diagnostics = raw.filter(row=>row.typescript).map(blueDiagnostic);
    const unpaired = raw.filter(row=>!row.typescript);
    const files = inventory(path.join(cwd,'dist'));
    const declarations = Object.fromEntries(Object.entries(files).filter(([name])=>name.endsWith('.d.ts')));
    const native = {accepts:expected.accepts,diagnostics:expected.diagnostics,declarations:expected.declarations};
    const blue = {accepts:built.status===0,diagnostics,declarations};
    const completeAgrees = !unpaired.length && JSON.stringify(native)===JSON.stringify(blue);
    const row = {id:entry.id,sourceSha256:sha(entry.source),native,blue,rawBlueDiagnostics:raw,
        diagnosticsWithoutNativeCounterpart:unpaired,verdictAgrees:native.accepts===blue.accepts,completeAgrees};
    fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx'});
    report.cases.push(row);
}
assert.equal(sha(fs.readFileSync(nativePath)),report.nativeReferenceSha256);
assert.equal(sha(fs.readFileSync(compiler)),compilerSha256);
report.completeAgreements=report.cases.filter(row=>row.completeAgrees).length;
report.verdictDifferences=report.cases.filter(row=>!row.verdictAgrees).length;
report.differences=report.cases.length-report.completeAgreements;
report.unpairedDiagnosticPrograms=report.cases.filter(row=>row.diagnosticsWithoutNativeCounterpart.length).map(row=>row.id);
report.conclusion='discovery-complete';
fs.writeFileSync(path.join(destination,'observations.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({sourceRevision:report.sourceRevision,comparisons:report.cases.length,
    completeAgreements:report.completeAgreements,differences:report.differences,verdictDifferences:report.verdictDifferences,
    unpairedDiagnosticPrograms:report.unpairedDiagnosticPrograms}));
