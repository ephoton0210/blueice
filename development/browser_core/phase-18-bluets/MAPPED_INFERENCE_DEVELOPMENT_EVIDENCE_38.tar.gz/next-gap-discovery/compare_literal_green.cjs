// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {spawnSync}=require('node:child_process'),{createHash}=require('node:crypto');
const root=__dirname,repo=path.resolve(root,'../..');
const sha=data=>createHash('sha256').update(data).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p));
const compiler=path.join(repo,'target/mapped-literal-freshness-review-20261113/green-1/green-cli');
const compilerSha256=sha(fs.readFileSync(compiler));
assert.equal(compilerSha256,'310dee4e2bf8c5f433a38d070a4aee85434fde884d072f90ad71b4442e08244e');
const {inventory,blueDiagnostic}=require(path.join(repo,'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const out=path.join(root,'literal-green-comparison60');fs.mkdirSync(out);
const oldReports=[read(path.join(root,'accepted-c-comparison-2/observations.json')),read(path.join(root,'accepted-c-quantified-6/observations.json'))];
const acceptedC=new Map(oldReports.flatMap(value=>value.cases).map(row=>[row.group+'/'+row.id,row]));
const report={candidateCompilerSha256:compilerSha256,cases:[],regressions:[],conclusion:'in_progress'};
for(const group of ['expanded','factorial8','lookup-stages12','callable-probes10','quantified6']){
 const base=path.join(root,group),input=read(path.join(base,'inputs.json'));
 const native=read(path.join(base,'native-reference.json'));
 const current=read(path.join(base,group==='expanded'?'blue-replay-2/observations.json':'observations.json'));
 for(const entry of input.cases){
  const wanted=native.cases.find(row=>row.id===entry.id),now=current.cases.find(row=>row.id===entry.id);
  const cwd=path.join(out,group,entry.id);fs.mkdirSync(cwd,{recursive:true});
  fs.writeFileSync(path.join(cwd,'main.ts'),entry.source,{flag:'wx'});
  fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify({compilerOptions:input.options,files:['main.ts']},null,2)+'\n',{flag:'wx'});
  const built=spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});
  fs.writeFileSync(path.join(cwd,'build.stdout'),built.stdout||'');fs.writeFileSync(path.join(cwd,'build.stderr'),built.stderr||'');
  if(built.error)throw built.error;
  const diagnostics=(built.stderr||'').split(/\r?\n/).filter(Boolean).map(line=>{const row=JSON.parse(line);return row.typescript?blueDiagnostic(row):{unpairedBlueDiagnostic:row};});
  const declarations=Object.fromEntries(Object.entries(inventory(path.join(cwd,'dist'))).filter(([name])=>name.endsWith('.d.ts')));
  const before={accepts:built.status===0,diagnostics,declarations};
  const expected={accepts:wanted.accepts,diagnostics:wanted.diagnostics,declarations:wanted.declarations};
  const beforeAgrees=JSON.stringify(before)===JSON.stringify(expected);
  const c=acceptedC.get(group+'/'+entry.id);assert(c);
  const verdictRegression=c.before.accepts===expected.accepts&&before.accepts!==expected.accepts;
  const declarationRegression=expected.accepts&&c.before.accepts&&JSON.stringify(c.before.declarations)===JSON.stringify(expected.declarations)&&JSON.stringify(before.declarations)!==JSON.stringify(expected.declarations);
  const completeRegression=c.beforeAgrees&&!beforeAgrees;
  const row={group,id:entry.id,acceptedC:c.before,candidate:before,native:expected,acceptedCAgrees:c.beforeAgrees,candidateAgrees:beforeAgrees,verdictRegression,declarationRegression,completeRegression};
  fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n',{flag:'wx'});
  report.cases.push(row);
  if(verdictRegression||declarationRegression||completeRegression)report.regressions.push({group,id:entry.id,verdictRegression,declarationRegression,completeRegression});
 }
}
assert.equal(sha(fs.readFileSync(compiler)),compilerSha256);
report.conclusion='comparison-complete';
fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({comparisons:report.cases.length,agreements:report.cases.filter(row=>row.candidateAgrees).length,regressions:report.regressions},null,2));
