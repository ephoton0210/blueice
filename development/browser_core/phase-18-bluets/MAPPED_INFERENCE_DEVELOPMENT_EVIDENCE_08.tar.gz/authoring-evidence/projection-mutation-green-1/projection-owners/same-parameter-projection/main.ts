export function result<T extends unknown[]>(value: T): T { return [value[0]] as unknown as T; }
