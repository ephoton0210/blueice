export function result<T>(value: unknown): T { return value as unknown as T; }
