export function result<T>(value: readonly string[]): T { return value as unknown as T; }
