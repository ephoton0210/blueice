export function result<T extends unknown[]>(value:T, protectedValue:readonly string[]):T { const projected=[value[0]]; projected[0]=protectedValue; return projected as unknown as T; }
