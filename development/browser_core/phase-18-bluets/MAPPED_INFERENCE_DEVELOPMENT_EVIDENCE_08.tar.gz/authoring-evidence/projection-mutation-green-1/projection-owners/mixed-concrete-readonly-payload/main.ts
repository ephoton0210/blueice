export function result<T extends unknown[]>(value: T, protectedValue: readonly string[]): T { return [value[0], protectedValue] as unknown as T; }
