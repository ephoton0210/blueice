export function result<T extends unknown[]>(value: T) { return <T extends unknown[]>(): T => [value[0]] as unknown as T; }
