export function result<T extends unknown[], U>(value: T): U { return [value[0]] as unknown as U; }
