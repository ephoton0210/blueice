export function result<T extends unknown[], U>(value: T): U { const projected = [value[0]]; return projected as unknown as U; }
