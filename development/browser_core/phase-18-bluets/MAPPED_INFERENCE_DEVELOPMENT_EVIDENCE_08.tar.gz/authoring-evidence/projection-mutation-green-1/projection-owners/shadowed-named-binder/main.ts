export function result<T extends unknown[]>(value: T) { function inner<T extends unknown[]>(): T { return [value[0]] as unknown as T; } return inner; }
