declare function mutate(input:unknown[], payload:readonly string[]):void;
export function result<T extends unknown[]>(value:T, protectedValue:readonly string[]):T { const projected=[value[0]]; mutate(projected, protectedValue); return projected as unknown as T; }
