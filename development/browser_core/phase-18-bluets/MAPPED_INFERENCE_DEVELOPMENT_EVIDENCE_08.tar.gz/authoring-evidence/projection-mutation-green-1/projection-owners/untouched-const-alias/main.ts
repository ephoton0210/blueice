export function result<T extends unknown[]>(value:T):T { const projected=[value[0]]; return projected as unknown as T; }
