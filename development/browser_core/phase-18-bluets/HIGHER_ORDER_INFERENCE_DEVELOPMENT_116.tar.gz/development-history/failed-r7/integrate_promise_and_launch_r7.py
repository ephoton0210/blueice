# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Integrate the verified worktree only after old-source Windows evidence is final."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

contract = Path(__file__).resolve().parent
repo = contract.parent.parent
worktree = Path('/private/tmp/blueice-bluets-p0g-promise-20261114-r1')
old = repo/'target/higher-order-inference-acceptance-20261114-r6'
new = repo/'target/higher-order-inference-acceptance-20261114-r7'
output = repo/'target/higher-order-inference-integration-20261114-r7'
output.mkdir()
shutil.copy2(__file__,output/Path(__file__).name)
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
state = {'pid':os.getpid(),'conclusion':'in_progress','stage':'observing-original-r6-Windows',
    'observedMainPid':442,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'expectedSourceRevision':'backend-tree:9f6e4f033200e519f62f3573685b6cbe04f873a3',
    'commitPerformed':False,'pushPerformed':False,'steps':[]}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = output/'state.tmp'
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(output/'state.json')

def run(label,args):
    state['stage'] = label
    save()
    log = output/(label+'.log')
    with log.open('xb') as stream:
        result = subprocess.run(args,cwd=repo,stdout=stream,stderr=subprocess.STDOUT)
    state['steps'].append({'label':label,'command':args,'exit':result.returncode,
                           'log':log.name,'sha256':sha(log)})
    save()
    assert result.returncode == 0,label

try:
    save()
    quality = contract/'promise-worktree-quality-3'
    q = read(quality/'measurement.json')
    assert q['conclusion'] == 'success' and q['stage'] == 'complete'
    assert len(q['steps']) == 7 and all(step['exit'] == 0 for step in q['steps'])
    assert read(contract/'promise-projects-preflight-1/measurement.json')['conclusion'] == 'success'
    while True:
        observed = read(old/'launch-state.json')
        assert observed['pid'] == 442
        if observed['conclusion'] != 'in_progress':
            break
        result = subprocess.run(['ps','-p','442','-o','command='],capture_output=True,text=True)
        assert result.returncode == 0 and result.stdout.strip().endswith('higher-order-inference-acceptance-20261114-r6/launch.py')
        state['lastOriginalProcessVerifiedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
        time.sleep(10)
    assert observed['conclusion'] == 'failure'
    assert observed['platforms']['mac']['exit'] == 1 and observed['platforms']['windows']['exit'] == 0
    assert read(old/'windows/complete-state.json')['conclusion'] == 'success'
    verified = read(old/'windows/windows-acceptance-verification.json')
    assert verified['conclusion'] == 'success'
    assert verified['sourceRevision'] == 'backend-tree:c746a2387175ac4df07d8a4ec91e983fb5d5ecec'
    assert verified['archiveSha256'] == sha(old/'windows-evidence.tar.gz')
    state['stage'] = 'preserving-old-terminal-outcomes'
    save()
    for name in ['launch-state.json','mac-driver.json','native-gates.json',
                 'windows/complete-state.json','windows/finalize-state.json',
                 'windows/windows-acceptance-verification.json']:
        target = output/'previous-terminal'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(old/name,target)
    previous = read(old/'frozen-source-preflight.json')
    for name,value in previous['files'].items():
        assert sha(repo/name) == value,name
    for name,value in read(old/'mac-driver.json')['driverHashes'].items():
        assert sha(old/name) == value,name
    files = read(quality/'source-manifest.json')
    assert sha(quality/'source-manifest.json') == q['sourceManifestSha256']
    assert all(sha(worktree/name) == value for name,value in files.items())
    changes = {name for name,value in files.items() if previous['files'].get(name) != value}
    expected = {'backend/bluets/src/checker/inference.rs',
        'backend/bluets/src/checker/inference/collect.rs',
        'backend/bluets/tests/higher_order_inference.rs',
        'backend/bluets/tests/fixtures/higher_order_promise_scope/cases.json',
        'backend/bluets/tests/fixtures/higher_order_promise_scope/reference.json'}
    assert changes == expected and set(previous['files']).issubset(files),changes
    state['stage'] = 'integrating-exact-verified-repair'
    state['copied'] = []
    save()
    for name in sorted(changes):
        destination = repo/name
        if destination.exists():
            backup = output/'before'/name
            backup.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(destination,backup)
        destination.parent.mkdir(parents=True,exist_ok=True)
        temporary = destination.with_name(destination.name+'.p0g-integrating')
        assert not temporary.exists()
        shutil.copy2(worktree/name,temporary)
        temporary.replace(destination)
        assert sha(destination) == files[name]
        state['copied'].append({'path':name,'sha256':files[name]})
        save()
    assert all(sha(repo/name) == value for name,value in files.items())
    phase = repo/'development/browser_core/phase-18-bluets'
    before = output/'generated-authorities-before'
    before.mkdir()
    for name in ['COMPATIBILITY_SUITES.json','COMPATIBILITY_CASES.json','COMPATIBILITY_MEASUREMENT.json',
                 'COMPATIBILITY_INVENTORY.md','TODO.md','PLAN.md']:
        shutil.copy2(phase/name,before/name)
    for name in ['COMPATIBILITY_CASES.json','COMPATIBILITY_MEASUREMENT.json']:
        assert (phase/name).read_bytes() == subprocess.check_output(
            ['git','show','HEAD:development/browser_core/phase-18-bluets/'+name],cwd=repo)
    (phase/'COMPATIBILITY_SUITES.json').write_bytes(subprocess.check_output(
        ['git','show','HEAD:development/browser_core/phase-18-bluets/COMPATIBILITY_SUITES.json'],cwd=repo))
    run('account-write',[sys.executable,str(phase/'tools/account_inventory_rows.py'),'--write'])
    run('status-write',[sys.executable,str(phase/'tools/check_compatibility_status.py'),'--write'])
    run('stage-source',['git','add','--','backend/bluets','development/browser_core/phase-18-bluets/tools'])
    tree = subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip()
    backend = subprocess.check_output(['git','rev-parse',tree+':backend'],cwd=repo,text=True).strip()
    assert 'backend-tree:'+backend == state['expectedSourceRevision']
    assert not (new/'launch-state.json').exists(),'Do not launch twice'
    shutil.copy2(__file__,new/Path(__file__).name)
    state['stage'] = 'observing-r7-complete-acceptance'
    save()
    with (output/'r7-launch.log').open('xb') as stream:
        child = subprocess.Popen([sys.executable,'-B',str(new/'launch.py')],cwd=repo,
                                 stdout=stream,stderr=subprocess.STDOUT)
        state['r7MainPid'] = child.pid
        save()
        while child.poll() is None:
            save()
            time.sleep(10)
        code = child.returncode
    state['r7Exit'] = code
    assert code == 0 and read(new/'launch-state.json')['conclusion'] == 'success'
    state.update(conclusion='success',stage='r7-acceptance-complete-awaiting-publication')
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
