# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = root.parent.parent
state_path = root / 'launch-state.json'
assert not state_path.exists(), 'Observe the existing supervisor; never restart it'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = {'pid': os.getpid(), 'conclusion': 'in_progress', 'stage': 'preflight',
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'steps': [], 'platforms': {}}
def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = state_path.with_suffix('.tmp')
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(state_path)
def run(label, args):
    state['stage'] = label
    save()
    log = root / (label + '-launch.log')
    print('START', label, flush=True)
    with log.open('xb') as stream:
        child = subprocess.Popen(args, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
        state['childPid'] = child.pid
        save()
        code = child.wait()
    state.pop('childPid', None)
    state['steps'].append({'label': label, 'command': args, 'exit': code,
                           'log': log.name, 'sha256': sha(log)})
    save()
    print('END', label, code, flush=True)
    assert code == 0, label
try:
    save()
    # Freeze verifies all seven fresh quality steps, both complete downstream
    # observations, all real projects and the independently frozen scope controls.
    run('stage-source', ['git', 'add', '--', 'backend/bluets',
                         'development/browser_core/phase-18-bluets/tools'])
    run('freeze', [sys.executable, '-B', str(root / 'freeze_source.py')])
    frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
    state['sourceRevision'] = frozen['sourceRevision']
    run('prepare-windows', [sys.executable, '-B', str(root / 'prepare_windows.py')])
    children = {}
    streams = []
    for label, script in [('mac', 'run_mac.py'), ('windows', 'complete_windows.py')]:
        log = root / (label + '-supervisor.log')
        stream = log.open('xb')
        streams.append(stream)
        child = subprocess.Popen([sys.executable, '-B', str(root / script)], cwd=repo,
                                 stdout=stream, stderr=subprocess.STDOUT)
        children[label] = child
        state['platforms'][label] = {'pid': child.pid, 'script': script, 'log': log.name}
    state['stage'] = 'running-platform-acceptance'
    save()
    while any(child.poll() is None for child in children.values()):
        for label, child in children.items():
            code = child.poll()
            if code is not None:
                state['platforms'][label]['exit'] = code
                if code:
                    state['stage'] = 'platform-failure-observing-other-running-platform'
        save()
        time.sleep(5)
    for label, child in children.items():
        state['platforms'][label]['exit'] = child.returncode
    for stream in streams:
        stream.close()
    assert all(child.returncode == 0 for child in children.values()), state['platforms']
    state.update(conclusion='success', stage='all-gates-complete-awaiting-independent-publication-audit')
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
