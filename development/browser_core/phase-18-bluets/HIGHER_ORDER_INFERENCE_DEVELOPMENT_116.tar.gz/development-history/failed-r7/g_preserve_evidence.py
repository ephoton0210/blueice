# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Snapshot complete finished source/history; never change an earlier outcome."""
from pathlib import Path
import json
import shutil
import subprocess
import hashlib
import tarfile
from g_acceptance_audit import ROOT,REPO,PHASE,read,sha,verified_platform_completion
from g_artifact_pack import write_json
from g_preserve_parent import preserve_parent


def files(directory):
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(),path
        if path.is_file() and '__pycache__' not in path.parts and not path.name.endswith('.pyc'):
            yield path


def preserve():
    verified_platform_completion()
    frozen = read(ROOT/'frozen-source-preflight.json')
    preserve_parent()
    snapshot = ROOT/'source-snapshots'
    snapshot.mkdir(exist_ok=True)
    source_rows = {}
    selected = set(frozen['files'])
    selected.update(name for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']
        if (REPO/name).is_file())
    project_paths = subprocess.check_output(['git','ls-files','-z','--',
        'differential-testing/bluets-projects'],cwd=REPO).decode().split('\0')
    selected.update(name for name in project_paths if name)
    for name in sorted(selected):
        original = REPO/name
        digest = sha(original)
        if name in frozen['files']:
            assert digest == frozen['files'][name],name
        target = snapshot/'files'/name
        target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            assert sha(target) == digest,target
        else:
            shutil.copy2(original,target)
        assert sha(target) == digest
        source_rows[name] = {'bytes':target.stat().st_size,'sha256':digest}
    write_json(snapshot/'manifest.json',{'sourceRevision':frozen['sourceRevision'],
        'allFrozenCompilerAndOracleFilesPreserved':True,'files':source_rows})
    authorities = ROOT/'authority-snapshots'
    authorities.mkdir(exist_ok=True)
    authority_rows = {}
    for name in ['COMPATIBILITY_CASES.json','COMPATIBILITY_SUITES.json','COMPATIBILITY_MEASUREMENT.json']:
        original = PHASE/name
        assert read(original)['source_revision'] == frozen['sourceRevision']
        destination = authorities/name
        if destination.exists():
            assert destination.read_bytes() == original.read_bytes()
        else:
            shutil.copy2(original,destination)
        authority_rows[name] = {'bytes':destination.stat().st_size,'sha256':sha(destination)}
    write_json(authorities/'manifest.json',{'sourceRevision':frozen['sourceRevision'],
        'files':authority_rows,'scope':'Complete accepted cases, suites and Native measurement, including every original case class.'})
    history = ROOT/'development-history'
    history.mkdir(exist_ok=True)
    old_directories = [
        ('contract',REPO/'target/higher-order-inference-contract-20261114'),
        ('discovery',REPO/'target/higher-order-inference-discovery-20261114'),
        ('failed-r1',REPO/'target/higher-order-inference-acceptance-20261114-r1'),
        ('failed-r2',REPO/'target/higher-order-inference-acceptance-20261114-r2'),
        ('failed-r3',REPO/'target/higher-order-inference-acceptance-20261114-r3'),
        ('failed-r4',REPO/'target/higher-order-inference-acceptance-20261114-r4'),
        ('failed-r5',REPO/'target/higher-order-inference-acceptance-20261114-r5'),
        ('failed-r6',REPO/'target/higher-order-inference-acceptance-20261114-r6'),
    ]
    records = {}
    for label,directory in old_directories:
        copied = {}
        for path in files(directory):
            relative = path.relative_to(directory)
            destination = history/label/relative
            destination.parent.mkdir(parents=True,exist_ok=True)
            digest = sha(path)
            if destination.exists():
                assert sha(destination) == digest,destination
            else:
                shutil.copy2(path,destination)
            assert sha(destination) == digest
            copied[relative.as_posix()] = {'bytes':path.stat().st_size,'sha256':digest}
        manifest = history/(label+'-members.json')
        write_json(manifest,copied)
        records[label] = {'original':str(directory.relative_to(REPO)),'members':len(copied),
            'manifest':manifest.relative_to(ROOT).as_posix(),'manifestSha256':sha(manifest),
            'acceptanceCredit':0}
    write_json(history/'index.json',{'sourceRevision':frozen['sourceRevision'],
        'scope':'Complete retained G development/discovery and five failed full-acceptance attempts and a terminal preflight-only launcher failure; original outcomes unchanged.',
        'history':records})
    previous = REPO/'target/conditional-inference-acceptance-20261114-r3'
    oracle = read(previous/'oracle-dependencies.json')
    archive = previous/'oracle-dependencies.tar.gz'
    assert sha(archive) == oracle['archiveSha256'] and archive.stat().st_size == oracle['archiveBytes']
    dependency_files = {}
    with tarfile.open(archive) as package:
        for member in package:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            assert member.name not in dependency_files
            dependency_files[member.name] = hashlib.sha256(package.extractfile(member).read()).hexdigest()
    assert dependency_files == oracle['files']
    installed = REPO/'target/noinfer-acceptance-20261112/oracles'
    for name,digest in dependency_files.items():
        assert sha(installed/name) == digest,name
    target = ROOT/'oracle-dependencies.tar.gz'
    if target.exists():
        assert sha(target) == oracle['archiveSha256']
    else:
        shutil.copy2(archive,target)
    write_json(ROOT/'oracle-dependencies.json',oracle)
    write_json(ROOT/'oracle-dependency-provenance.json',{'reusedFromAcceptedParent':
        'target/conditional-inference-acceptance-20261114-r3/oracle-dependencies.tar.gz',
        'archiveSha256':oracle['archiveSha256'],'allInstalledBytesIndependentlyMatch':True,
        'files':len(dependency_files),'licensesPreserved':['node_modules/typescript/LICENSE.txt',
            'node_modules/typescript/ThirdPartyNoticeText.txt','node_modules/acorn/LICENSE']})
    members = []
    with tarfile.open(ROOT/'windows-evidence.tar.gz') as package:
        for member in package:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            members.append({'path':member.name,'bytes':member.size,
                'sha256':hashlib.sha256(package.extractfile(member).read()).hexdigest()})
    assert len(members) == len({row['path'] for row in members})
    write_json(ROOT/'windows/all-archive-members.json',{'sourceRevision':frozen['sourceRevision'],
        'archiveSha256':sha(ROOT/'windows-evidence.tar.gz'),'entries':members})
    return {'sourceManifest':str((snapshot/'manifest.json').relative_to(ROOT)),
        'sourceFiles':len(source_rows),'historyIndex':str((history/'index.json').relative_to(ROOT))}


if __name__ == '__main__':
    print(json.dumps(preserve()))
