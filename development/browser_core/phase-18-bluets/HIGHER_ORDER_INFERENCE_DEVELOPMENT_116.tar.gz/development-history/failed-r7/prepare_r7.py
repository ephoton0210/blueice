# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Prepare, but never launch, final acceptance of the isolated Promise repair."""
from pathlib import Path
import json
import shutil
import subprocess

contract = Path(__file__).resolve().parent
repo = contract.parent.parent
old = repo / 'target/higher-order-inference-acceptance-20261114-r6'
root = repo / 'target/higher-order-inference-acceptance-20261114-r7'
root.mkdir()
(root / 'windows').mkdir()
names = [
    'launch.py', 'run_mac.py', 'freeze_source.py', 'prepare_windows.py',
    'upload_windows.py', 'complete_windows.py', 'finish_windows.py', 'verify_windows.py',
    'run_native_gates.py', 'measure_priority.cjs', 'run_project_gates.py',
    'run_local_gates.py', 'watch_maps.py', 'replay_original_discovery.cjs',
    'audit_symbolic_keys.py', 'audit_conditional_inference.py', 'audit_higher_order_inference.py',
    'baseline-native-durations.json', 'windows/windows-runner.cjs', 'windows/package-evidence.py',
]
for name in names:
    text = (old / name).read_text().replace('acceptance-20261114-r6', 'acceptance-20261114-r7')
    text = text.replace('p0g-r6', 'p0g-r7').replace('results-higher-order-inference-r6', 'results-higher-order-inference-r7')
    text = text.replace('1087', '1088')
    (root / name).write_text(text)
(root / 'original-discovery24').mkdir()
for name in ['inputs.json', 'native-reference.json']:
    shutil.copy2(old / 'original-discovery24' / name, root / 'original-discovery24' / name)

p = root / 'prepare_windows.py'
text = p.read_text().replace("'higher-order-inference-acceptance-20261114-r5'", "'higher-order-inference-acceptance-20261114-r6'")
text = text.replace('backend-tree:20ed07888d4b564c37e93fcbc0f0e742e99d9c41', 'backend-tree:c746a2387175ac4df07d8a4ec91e983fb5d5ecec')
text = text.replace("'/p0g-r5-source-manifest.json'", "'/p0g-r6-source-manifest.json'")
text = text.replace(".replace('p0g-r5', 'p0g-r7')", ".replace('p0g-r6', 'p0g-r7')")
text = text.replace('25 complete affected cohorts', '26 complete affected cohorts')
p.write_text(text)

# Every previously selected Windows cohort remains; G-T7 is additionally affected.
for name in ['windows/windows-runner.cjs', 'windows/package-evidence.py', 'verify_windows.py']:
    p = root / name
    text = p.read_text()
    text = text.replace("'higher_order_inference',", "'higher_order_inference', 'gt7_library_manifest',")
    text = text.replace("'higher_order_inference': 6,", "'higher_order_inference': 7, 'gt7_library_manifest': 7,")
    text = text.replace("'higher_order_inference','gt10_import_types'", "'higher_order_inference','gt7_library_manifest','gt10_import_types'")
    text = text.replace('len(cohorts) == 25', 'len(cohorts) == 26')
    text = text.replace("len(measurement['followups']) == 25", "len(measurement['followups']) == 26")
    text = text.replace('all twenty-five complete cohorts', 'all twenty-six complete cohorts')
    text = text.replace('25 complete affected cohorts', '26 complete affected cohorts')
    text = text.replace('25 complete cohorts', '26 complete cohorts')
    text = text.replace('state.followups.length === 25', 'state.followups.length === cohorts.length')
    p.write_text(text)

header = '\n'.join((old / 'freeze_source.py').read_text().splitlines()[:3]) + '\n'
(root / 'freeze_source.py').write_text(header + '''
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
contract = repo/'target/higher-order-inference-contract-20261114'
quality = contract/'promise-worktree-quality-3'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = lambda *args: subprocess.check_output(args,cwd=repo,text=True).strip()
report = read(quality/'measurement.json')
assert report['conclusion'] == 'success' and report['stage'] == 'complete'
assert [step['label'] for step in report['steps']] == [
    'library','affected-callers','call-chain-regressions','fmt','clippy','node-tools','python-tools']
for step in report['steps']:
    assert step['exit'] == 0 and sha(quality/step['log']) == step['logSha256']
assert sha(quality/'source-manifest.json') == report['sourceManifestSha256']
files = read(quality/'source-manifest.json')
for name,value in files.items():
    assert sha(repo/name) == value,name
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--',
    'backend','development/browser_core/phase-18-bluets/tools'],cwd=repo).decode().split('\\0')
assert set(filter(None,paths)) == set(files)
assert not command('git','diff','--name-only','--','backend','development/browser_core/phase-18-bluets/tools')
assert command('git','rev-parse','HEAD') == '87d53ef80beb76c77dd804b9c14f3ed2dbb8a4c5'
tree = command('git','write-tree')
backend_tree = command('git','rev-parse',tree+':backend')
assert backend_tree == '9f6e4f033200e519f62f3573685b6cbe04f873a3'
backend = sorted((name for name in files if name.startswith('backend/')),key=lambda name:name.encode())
assert len(backend) == 14117
indexed = subprocess.check_output(['git','ls-files','-z','--','backend'],cwd=repo).decode().split('\\0')[:-1]
assert set(indexed) == set(backend)
fixture = repo/'backend/bluets/tests/fixtures/higher_order_inference'
frozen = read(fixture/'FROZEN.json')
for name,value in frozen['sha256'].items():
    assert sha(fixture/name) == value,name
focused_path = contract/'promise-worktree-regressions-1/measurement.json'
focused = read(focused_path)
assert focused['conclusion'] == 'success' and focused['exit'] == 0
for name,value in focused['source'].items():
    assert files[name] == value,name
assert sha(contract/'promise-worktree-regressions-1/actual-cli') == focused['actualCompilerSha256']
summaries = re.findall(r'test result: ok\\. (\\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',
    (contract/'promise-worktree-regressions-1/tests.log').read_text())
assert summaries == ['7','7'],summaries
capture = contract/'promise-worktree-regressions-1/capture'
for role in ['native','blue']:
    reports = list(capture.glob('bluets-higher-order-inference-'+role+'-*/report.json'))
    assert len(reports) == 1
    observed = read(reports[0])
    for key,value in frozen['counts'].items():
        assert observed[key] == value,(role,key)
    if role == 'blue':
        assert observed['conclusion'] == 'success'
        assert observed['compilerSha256'] == focused['actualCompilerSha256']
for folder,receipt_name,count in [
    ('higher_order_recursive_scope','recursive-scope-red-1/pre-repair-freeze.json',16),
    ('higher_order_promise_scope','promise-scope-freeze-1/receipt.json',12)]:
    receipt = read(contract/receipt_name)
    assert receipt['beforeProductionRepair']
    for name,value in receipt.get('fixture',receipt.get('frozen',{})).items():
        assert sha(repo/'backend/bluets/tests/fixtures'/folder/name) == value
    assert len(read(repo/'backend/bluets/tests/fixtures'/folder/'reference.json')['cases']) == count
projects_path = contract/'promise-projects-preflight-1/measurement.json'
projects = read(projects_path)
assert projects['conclusion'] == 'success' and projects['sourceRevision'] == 'backend-tree:'+backend_tree
assert projects['compilerSha256'] == focused['actualCompilerSha256']
assert [step['label'] for step in projects['steps']] == ['defu','mitt','reproductions','interchange']
for step in projects['steps']:
    assert step['exit'] == 0 and sha(projects_path.parent/step['log']) == step['logSha256']
previous = repo/'target/higher-order-inference-acceptance-20261114-r6'
assert read(previous/'launch-state.json')['conclusion'] == 'failure'
assert read(previous/'mac-driver.json')['conclusion'] == 'failure'
assert read(previous/'windows/windows-acceptance-verification.json')['conclusion'] == 'success'
preserved = read(contract/'r6-gt7-failure-preservation-1/receipt.json')
assert sha(contract/'r6-gt7-failure-preservation-1/frozen-source.tar.gz') == preserved['archiveSha256']
prior = read(repo/'development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json')
assert sum(len(suite['cases']) for suite in prior['suites']) == 42716
tools = json.loads(subprocess.check_output(['node','-e',
    "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"],cwd=repo))
assert len(tools) == 618
state = {'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit':command('git','rev-parse','HEAD'),'backendTree':backend_tree,'sourceRevision':'backend-tree:'+backend_tree,
    'backendFiles':len(backend),'backendPathSetSha256':hashlib.sha256('\\0'.join(backend).encode()).hexdigest(),
    'files':files,'originalFrozenInputs':frozen['sha256'],
    'qualityMeasurementSha256':sha(quality/'measurement.json'),'qualityManifestSha256':sha(quality/'source-manifest.json'),
    'focusedCandidateMeasurementSha256':sha(focused_path),'projectPreflightSha256':sha(projects_path),
    'preflightOrigin':'isolated worktree; every compiler/oracle byte independently matches the integrated main checkout',
    'oracleToolFilesExpected':618,'expectedNativeSuites':191,'expectedNativeFunctions':1088,
    'expectedWindowsCohorts':26,'previousAssertions':42716,'addedAssertions':396,
    'recursiveScopeControls':16,'promiseScopeControls':12,'supplementaryInventoryCredit':0,
    'scope':'Finite P0-G complete same-source acceptance still required; all22 broader rows open, full parity OFF.'}
with (root/'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(state,indent=2)+'\\n')
(root/'frozen-final-oracle-tools.json').write_text(json.dumps({'sha256':tools},indent=2)+'\\n')
print(json.dumps({key:value for key,value in state.items() if key != 'files'}))
''')

for path in root.rglob('*.py'):
    compile(path.read_text(), str(path), 'exec')
for path in root.rglob('*.cjs'):
    subprocess.run(['node', '--check', str(path)], check=True)
shutil.copy2(__file__, root / Path(__file__).name)
(root / 'prepared.json').write_text(json.dumps({
    'conclusion': 'prepared-not-launched', 'runtimeDrivers': names[:17],
    'expectedSourceRevision': 'backend-tree:9f6e4f033200e519f62f3573685b6cbe04f873a3',
    'expectedNativeSuites': 191, 'expectedNativeFunctions': 1088, 'expectedWindowsCohorts': 26,
    'requirementsBeforeLaunch': ['r6 Windows terminal verification', 'isolated quality success',
                                 'exact repair integration into main', 'accepted-parent accounting coherence'],
}, indent=2) + '\n')
print(json.dumps({'prepared': str(root), 'launched': False}))
