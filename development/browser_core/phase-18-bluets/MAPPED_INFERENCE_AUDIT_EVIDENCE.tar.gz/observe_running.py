# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import json
import re
import subprocess

root = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_bytes())
native = read(root / 'accepted-native/measurement.json')
successful = [row for row in native['suites'] if row['conclusion'] == 'success']
failed = [row for row in native['suites'] if row['conclusion'] not in ['success', 'in_progress']]
active = []
assertions = []
for row in native['suites']:
    if row['conclusion'] != 'in_progress':
        continue
    log = (root / 'accepted-native' / row['log']).read_text(errors='replace')
    count = re.search(r'^running (\d+) tests?$', log, re.MULTILINE)
    passed = re.findall(r'^test (.+) \.\.\. ok$', log, re.MULTILINE)
    active.append({'harness': row['harness'], 'passed': len(passed),
                   'total': int(count[1]) if count else None})
    assertions.extend({'harness': row['harness'], 'line': line}
                      for line in log.splitlines()
                      if re.search(r'^test .* \.\.\. FAILED$|^thread .* panicked|^test result: FAILED', line))

ps = subprocess.check_output(['ps', '-axo', 'pid,ppid,pgid,etime,time,pcpu,command'], text=True)
processes = [line.split(None, 6) for line in ps.splitlines()[1:]]
group = [row for row in processes if len(row) == 7 and row[2] == '83358']
drivers = [row for row in group if row[0] == '83358'
           and row[6].endswith(root.name + '/run_native_gates.py')]
local_group = [row for row in processes if len(row) == 7 and row[2] == '84083']
supervisors = [row for row in local_group if row[0] == '84083'
               and row[6].endswith(root.name + '/after_native.py')]
stages = {name: {key: state.get(key) for key in ['stage', 'conclusion', 'pid', 'error'] if key in state}
          for name in ['native-gates', 'post-native', 'local-gates']
          if (root / (name + '.json')).exists()
          for state in [read(root / (name + '.json'))]}
if stages['native-gates']['conclusion'] == 'in_progress' and not drivers:
    raise RuntimeError('Original Native driver PID is missing; inspect terminal receipts, never restart automatically')
if stages.get('post-native', {}).get('conclusion') == 'in_progress' and not supervisors:
    raise RuntimeError('Original supervisor PID is missing; inspect terminal receipts, never restart automatically')
workspace_failures = []
workspace_progress = None
workspace_log = root / 'workspace.log'
if workspace_log.exists():
    workspace_text = workspace_log.read_text(errors='replace')
    workspace_failures = [line for line in workspace_text.splitlines()
                          if re.search(r'^test .* \.\.\. FAILED$|^thread .* panicked|^test result: FAILED', line)]
    summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', workspace_text)
    workspace_progress = {
        'passingTestLinesObserved': len(re.findall(r'^test .+ \.\.\. ok$', workspace_text, re.MULTILINE)),
        'completedResultSummaries': len(summaries),
        'passedInCompletedSummaries': sum(int(row[1]) for row in summaries),
        'failedInCompletedSummaries': sum(int(row[2]) for row in summaries),
        'scope': 'Partial log observation only; final workspace terminal result remains required.',
    }

receipt = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'classification': 'verified-wait' if drivers or supervisors else 'terminal-stage-observation',
    'sourceRevision': native['source_revision'],
    'completedNativeSuites': len(successful),
    'completedNativeFunctions': sum(row['passed'] for row in successful),
    'terminalFailures': [{'harness': row['harness'], 'log': row['log']} for row in failed],
    'activeAssertionFailures': assertions,
    'activeSuiteProgress': active,
    'stages': stages,
    'originalDriverVerifiedLive': bool(drivers),
    'originalSupervisorVerifiedLive': bool(supervisors),
    'workspaceAssertionFailures': workspace_failures,
    'workspaceProgress': workspace_progress,
    'observedProcesses': group + local_group,
    'sourceEdits': False, 'todoChecks': False, 'commits': False,
}
(root / 'verified-wait-latest.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Native', len(successful), '/ 188 suites;', receipt['completedNativeFunctions'], '/ 1071 functions')
print('Stages', json.dumps(stages))
print('Failures', json.dumps(receipt['terminalFailures']), 'active assertions', json.dumps(assertions))
print('Active suite progress', json.dumps(active))
print('Verified original driver', bool(drivers), 'live Native group processes', len(group))
print('Verified original supervisor', bool(supervisors), 'live local group processes', len(local_group))
print('Workspace assertion failures', json.dumps(workspace_failures[:8]))
if workspace_progress:
    print('Workspace partial progress', json.dumps(workspace_progress))
for row in sorted(group + local_group, key=lambda row: float(row[5]), reverse=True)[:4]:
    print(' '.join(row[:6]), row[6][:180])
