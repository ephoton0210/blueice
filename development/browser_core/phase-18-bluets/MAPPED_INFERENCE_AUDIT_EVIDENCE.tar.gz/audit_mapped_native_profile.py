# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import hashlib
import json


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(root, repo, source, gates):
    fixture = repo / 'backend/bluets/tests/fixtures/mapped_inference'
    frozen = read(fixture / 'FROZEN.json')
    for name, digest in {**frozen['sha256'], **frozen['supplementarySha256']}.items():
        assert sha(fixture / name) == digest, name
    expected = {row['id']: row for row in read(fixture / 'reference.json')['cases']}
    assert len(expected) == 404 and sum(row['accepts'] for row in expected.values()) == 358
    assert sum(len(row['declarations']) for row in expected.values()) == 366
    assert len(read(fixture / 'boundary-controls.json')['controls']) == 12
    bindings = {}
    for kind in ['native']:
        compiler = gates[kind + 'CompilerSha256']
        base = root / (kind + '-capture/mapped-inference')
        candidates = list(base.glob('bluets-mapped-inference-blue-*/report.json'))
        assert len(candidates) == 1
        path = candidates[0]
        report = read(path)
        assert report['conclusion'] == 'success' and report['sourceRevision'] == source
        assert report['compilerSha256'] == compiler and report['frozenInputs'] == frozen['sha256']
        assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 404
        assert {row['id'] for row in report['cases']} == set(expected)
        assert report['accepted'] == 358 and report['rejected'] == 46
        assert report['declarationFiles'] == report['syntax'] == 366
        assert report['consumers'] == 716 and report['runtime'] == 8
        direct = {}
        for row in report['cases']:
            wanted = expected[row['id']]
            assert all(row[key] == wanted[key] for key in ['accepts', 'diagnostics', 'declarations'])
            assert row.get('consumers') == wanted.get('consumers')
            assert row.get('runtime') == wanted.get('runtime')
            for name, text in row['declarations'].items():
                assert (path.parent / row['id'] / 'dist' / name).read_bytes() == text.encode('utf-8')
            for name, digest in row.get('javascriptSha256', {}).items():
                assert sha(path.parent / row['id'] / 'dist' / name) == digest
            ordinary_path = base / row['id'] / 'observation.json'
            ordinary = read(ordinary_path)
            assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
            assert all(ordinary[key] == wanted[key] for key in ['id', 'accepts', 'diagnostics', 'declarations'])
            direct[row['id']] = sha(ordinary_path)
        supplemental = {}
        refusals = 0
        for filename, group in [
            ('literal-preservation-controls.json', 'literal-preservation'),
            ('projection-owner-controls.json', 'projection-owners'),
            ('projection-identity-controls.json', 'projection-owners'),
            ('projection-mutation-controls.json', 'projection-owners'),
            ('callback-context-controls.json', 'callback-context'),
            ('generic-argument-controls.json', 'generic-arguments'),
        ]:
            for row in read(fixture / filename)['cases']:
                observation_path = base / group / row['id'] / 'observation.json'
                observed = read(observation_path)
                accepts = row.get('blueAccepts', row['accepts'])
                assert observed['accepts'] == accepts
                if accepts:
                    assert all(observed[key] == row[key] for key in ['id', 'diagnostics', 'declarations'])
                    for name, text in observed['declarations'].items():
                        assert (observation_path.parent / 'dist' / name).read_bytes() == text.encode('utf-8')
                else:
                    assert [item['code'] for item in observed['diagnostics']] == [2322]
                    assert observed['declarations'] == {}
                    assert not any((observation_path.parent / 'dist').rglob('*'))
                    refusals += 1
                supplemental[group + '/' + row['id']] = sha(observation_path)
        assert len(supplemental) == 33 and refusals == 10
        bindings[kind] = {'path': str(path.relative_to(root)), 'sha256': sha(path),
            'compilerSha256': compiler, 'directComparisons': 404, 'declarationFiles': 366,
            'consumers': 716, 'syntax': 366, 'executions': 8, 'separatePolicyControls': 12,
            'supplementaryObservations': 33, 'supplementaryOwnerRefusals': 10,
            'supplementaryNativeAgreements': 23, 'supplementaryInventoryCredit': 0,
            'directObservationSha256': direct, 'supplementaryObservationSha256': supplemental}
    callbacks = list((root / 'native-capture/mapped-inference').glob('native-callback-context-*/report.json'))
    assert len(callbacks) == 1
    callback = read(callbacks[0])
    fixture_callback = read(fixture / 'callback-context-controls.json')
    assert callback['conclusion'] == 'success' and callback['sourceRevision'] == source
    assert callback['inputSha256'] == sha(fixture / 'callback-context-controls.json')
    assert callback['implementationSha256'] == fixture_callback['implementationSha256']
    assert len(callback['cases']) == 4 and callback['inventoryCredit'] == 0
    assert callback['libraries']
    for name, digest in callback['libraries'].items():
        assert fixture_callback['libraries'][name] == digest
    for row, wanted in zip(callback['cases'], fixture_callback['cases']):
        assert all(row[key] == wanted[key] for key in ['id', 'accepts', 'diagnostics', 'declarations'])
    bindings['supplementaryNativeReplay'] = {'path': str(callbacks[0].relative_to(root)),
        'sha256': sha(callbacks[0]), 'observations': 4, 'inventoryCredit': 0}
    arguments = list((root / 'native-capture/mapped-inference').glob('native-generic-arguments-*/report.json'))
    assert len(arguments) == 1
    argument_report = read(arguments[0])
    argument_fixture = read(fixture / 'generic-argument-controls.json')
    assert argument_report['conclusion'] == 'success' and argument_report['sourceRevision'] == source
    assert argument_report['inputSha256'] == sha(fixture / 'generic-argument-controls.json')
    assert argument_report['implementationSha256'] == argument_fixture['implementationSha256']
    assert len(argument_report['cases']) == 12 and argument_report['inventoryCredit'] == 0
    for name, digest in argument_report['libraries'].items(): assert argument_fixture['libraries'][name] == digest
    for row, wanted in zip(argument_report['cases'], argument_fixture['cases']):
        assert all(row[key] == wanted[key] for key in ['id','accepts','diagnostics','declarations'])
        for name, text in row['declarations'].items():
            assert (arguments[0].parent / row['id'] / 'dist' / name).read_bytes() == text.encode('utf-8')
    bindings['supplementaryGenericArgumentReplay'] = {'path':str(arguments[0].relative_to(root)),
        'sha256':sha(arguments[0]), 'observations':12, 'inventoryCredit':0}
    return bindings

if __name__ == '__main__':
    root=Path(__file__).resolve().parent
    repo=root.parent.parent
    frozen=read(root/'frozen-source-preflight.json')
    gates=read(root/'native-gates.json')
    compiler=gates['nativeCompilerSha256']
    assert sha(root/'accepted-native-cli')==compiler
    rows=read(root/'accepted-native/measurement.json')['suites']
    suite=next(row for row in rows if row['harness']=='backend/bluets/tests/mapped_inference.rs')
    assert suite['conclusion']=='success' and suite['passed']==7 and suite['failed']==suite['ignored']==suite['filtered']==0
    assert sha(root/'accepted-native'/suite['log'])==suite['log_sha256']
    bindings=audit(root,repo,frozen['sourceRevision'],{'nativeCompilerSha256':compiler})
    receipt={'scope':'Native-profile mapped evidence audit only; complete catalog/workspace/Windows and publication are still required.',
        'sourceRevision':frozen['sourceRevision'],'nativeCompilerSha256':compiler,
        'conclusion':'native-profile-artifacts-verified','wholeCandidateAcceptanceCredit':False,
        'suiteLogSha256':suite['log_sha256'],'bindings':bindings}
    (root/'native-mapped-artifact-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'sourceRevision':frozen['sourceRevision'],'directComparisons':bindings['native']['directComparisons'],
        'declarationFiles':bindings['native']['declarationFiles'],'consumers':bindings['native']['consumers'],
        'syntax':bindings['native']['syntax'],'runtime':bindings['native']['executions'],
        'supplementaryObservations':bindings['native']['supplementaryObservations'],
        'ownerRefusals':bindings['native']['supplementaryOwnerRefusals'],
        'wholeCandidateAcceptanceCredit':False}))
