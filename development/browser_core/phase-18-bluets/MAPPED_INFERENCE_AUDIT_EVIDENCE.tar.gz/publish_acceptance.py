# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import json
import shutil
import subprocess
import tarfile
from audit_acceptance import audit, ROOT, REPO, PHASE, read, sha

PREFIX = 'MAPPED_INFERENCE_'
LIMIT = 95 * 1024 * 1024


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pack(path, files):
    assert not path.exists(), path
    with tarfile.open(path, 'w:gz') as output:
        for file in files:
            assert file.is_file() and not file.is_symlink(), file
            output.add(file, arcname=file.relative_to(ROOT).as_posix(), recursive=False)
    with tarfile.open(path) as output:
        members = output.getmembers()
        assert len(members) == len({member.name for member in members}) == len(files)
        assert all(member.isfile() and not Path(member.name).is_absolute()
                   and '..' not in Path(member.name).parts for member in members)


def publish_group(label, files):
    files = sorted(files)
    candidate = ROOT / (PREFIX + label + '.candidate.tar.gz')
    pack(candidate, files)
    chunks = [files]
    if candidate.stat().st_size >= LIMIT:
        # Keep every source file. Split an oversized compression group by
        # uncompressed size so even incompressible evidence stays below LIMIT.
        candidate.unlink()
        chunks, current, size = [], [], 0
        for file in files:
            length = file.stat().st_size
            assert length < 80 * 1024 * 1024, file
            if current and size + length >= 80 * 1024 * 1024:
                chunks.append(current)
                current, size = [], 0
            current.append(file)
            size += length
        if current:
            chunks.append(current)
    result = []
    for index, chunk in enumerate(chunks):
        suffix = '' if len(chunks) == 1 else '_' + str(index + 1).zfill(2)
        destination = PHASE / (PREFIX + label + suffix + '.tar.gz')
        assert not destination.exists(), destination
        if len(chunks) == 1 and candidate.exists():
            shutil.move(candidate, destination)
        else:
            pack(destination, chunk)
        assert destination.stat().st_size < LIMIT
        result.append({'path': destination.name, 'bytes': destination.stat().st_size,
                       'sha256': sha(destination),
                       'membersSha256': {file.relative_to(ROOT).as_posix(): sha(file) for file in chunk}})
        print('ARCHIVED', destination.name, destination.stat().st_size, flush=True)
    return result


def main():
    receipt = audit()
    write(ROOT / 'acceptance-audit.json', receipt)
    frozen = read(ROOT / 'frozen-source-preflight.json')
    gates = receipt['gates']
    origins = [
        ('mapped-inference-design-20261113', 'authoring-evidence'),
        ('mapped-callback-context-review-20261113', 'callback-review'),
        ('mapped-composed-budget-review-20261113', 'budget-review'),
        ('mapped-inference-acceptance-20261113-r1', 'retired-native-r1'),
        ('mapped-inference-acceptance-20261113-r2', 'retired-native-r2'),
        ('mapped-inference-acceptance-20261113-r3', 'retired-native-r3'),
        ('mapped-inference-acceptance-20261113-r4', 'retired-native-r4'),
        ('mapped-literal-freshness-review-20261113', 'literal-freshness-review'),
        ('mapped-generic-argument-review-20261113', 'generic-argument-review'),
        ('generic-key-next-discovery-20261113', 'next-gap-discovery'),
    ]
    for origin, destination in origins:
        target = ROOT / destination
        assert not target.exists(), target
        shutil.copytree(REPO / 'target' / origin, target, symlinks=True,
                        ignore=shutil.ignore_patterns('__pycache__'))
    for prior in receipt['retiredCandidates']:
        directory = ROOT / ('retired-native-' + prior['label'])
        assert sha(directory / 'candidate-retirement.json') == prior['receiptSha256']
        assert sha(directory / prior['windowsArchiveRelativePath']) == prior['windowsArchiveSha256']
    (ROOT / 'accepted-source.patch').write_bytes(subprocess.check_output([
        'git','diff','--binary','HEAD','--','backend',
        'development/browser_core/phase-18-bluets/tools'], cwd=REPO))
    groups = {name:set() for name in ['COMPILERS','NATIVE_EVIDENCE','WORKSPACE_EVIDENCE',
                                    'DEVELOPMENT_EVIDENCE','AUDIT_EVIDENCE']}
    compilers = {'accepted-native-cli','accepted-workspace-cli','baseline-cli',
                 'native-cli-snapshot','workspace-cli-snapshot',
                 'native-map-test-executable','workspace-map-test-executable'}
    native_directories = {'accepted-native','native-capture',
                          'project-defu','project-mitt','project-reproductions','project-interchange'}
    for file in ROOT.rglob('*'):
        assert not file.is_symlink(), file
        if not file.is_file() or file.name.endswith('.candidate.tar.gz'):
            continue
        relative = file.relative_to(ROOT); first = relative.parts[0]
        if first == 'windows-evidence.tar.gz':
            continue
        if len(relative.parts) == 1 and first in compilers:
            group = 'COMPILERS'
        elif first in native_directories or first.startswith('native-declaration-map') or first == 'native-map-binding.json':
            group = 'NATIVE_EVIDENCE'
        elif first == 'workspace-capture' or first.startswith('workspace-') or first == 'workspace.log':
            group = 'WORKSPACE_EVIDENCE'
        elif first == 'windows' or (len(relative.parts) == 1 and file.suffix in ['.json','.log','.py','.cjs','.patch','.md']):
            group = 'AUDIT_EVIDENCE'
        else:
            group = 'DEVELOPMENT_EVIDENCE'
        groups[group].add(file)
    artifacts = []
    for label, files in groups.items():
        assert files
        artifacts.extend(publish_group(label, files))
    destination = PHASE / (PREFIX + 'WINDOWS_EVIDENCE.tar.gz'); assert not destination.exists()
    shutil.copy2(ROOT / 'windows-evidence.tar.gz', destination)
    assert sha(destination) == receipt['windows']['archiveSha256']
    artifacts.append({'path':destination.name,'bytes':destination.stat().st_size,
                      'sha256':sha(destination),'originalWindowsArchive':True})
    assert all(row['bytes'] < LIMIT for row in artifacts)

    def reference(path):
        key = Path(path).as_posix()
        owners = [row for row in artifacts if key in row.get('membersSha256',{})]
        assert len(owners) == 1, key
        return {'archive':owners[0]['path'],'path':key,'sha256':owners[0]['membersSha256'][key]}

    utility_references = {}
    for family in ['mappedInferenceReports','stringIntrinsicReports','nonNullableAwaitedReports']:
        utility_references[family] = {kind:reference(receipt[family][kind]['path'])
                                      for kind in ['native','workspace']}
    baseline = receipt['acceptedCBaseline']
    source_prefix = 'target/mapped-inference-design-20261113/'
    baseline_raw = []
    for row in baseline['observations']:
        assert row['observation'].startswith(source_prefix)
        baseline_raw.append({'id':row['id'], 'agrees':row['agrees'],
            'observation':reference('authoring-evidence/' + row['observation'][len(source_prefix):])})
    retired = [{**prior,
        'reference':reference('retired-native-' + prior['label'] + '/candidate-retirement.json'),
        'windowsAudit':reference('retired-native-' + prior['label'] + '/windows/windows-retired-audit.json')}
        for prior in receipt['retiredCandidates']]
    artifact_manifest = {'schema':1,'sourceRevision':frozen['sourceRevision'],'artifacts':artifacts}
    write(PHASE / (PREFIX + 'ARTIFACTS.json'), artifact_manifest)
    data = {'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion':'completed-within-frozen-scope','source':frozen,'gates':gates,
        'nativeMeasurement':{'path':'COMPATIBILITY_MEASUREMENT.json',
            'sha256':sha(ROOT / 'accepted-native/measurement.json'),
            'suites':receipt['nativeSuites'],'functions':receipt['nativeFunctions']},
        'primaryForms':101,'profiles':4,'directObservations':404,'accepted':358,'rejected':46,
        'acceptedDeclarationInventories':358,'declarationFiles':366,
        'isolatedConsumers':716,'selectedEditionParses':366,'executions':8,
        'ambientOwnerControls':2,'runtimeAuthorityRefusals':2,'resourceControls':8,
        'boundaryControls':12,'boundaryControlsExcludedFromDirectDenominator':True,
        'supplementaryControls':33,'supplementaryNativeAgreements':23,
        'supplementaryOwnerRefusals':10,'supplementaryInventoryCredit':0,
        'caseInventoryAdditions':416,**utility_references,
        'supplementaryNativeReplay':reference(receipt['mappedInferenceReports']['supplementaryNativeReplay']['path']),
        'supplementaryGenericArgumentReplay':reference(receipt['mappedInferenceReports']['supplementaryGenericArgumentReplay']['path']),
        'noInferReports':{kind:{label:reference(row['path'])for label,row in values.items()}
                          for kind,values in receipt['noInferReports'].items()},
        'mapBindings':receipt['mapBindings'],
        'completeNativeRoleFamilies':receipt['completeNativeRoleFamilies'],
        'partialNativeRoleReports':receipt['partialNativeRoleReports'],
        'baseline':{'sourceRevision':baseline['sourceRevision'],
            'sourceCommit':frozen['parentCommit'],'compilerSha256':baseline['compilerSha256'],
            'observations':404,'completeAgreements':70,'differences':334,'accepted':264,
            'acceptedCMeasurementSha256':baseline['acceptedCMeasurementSha256'],
            'reference':reference('baseline-accepted-c-bridge.json'),'rawObservations':baseline_raw},
        'projects':{name:reference('project-'+name+'/report.json')
                    for name in ['defu','mitt','reproductions','interchange']},
        'windows':receipt['windows'],'casePreservation':receipt['casePreservation'],
        'modules':{'files':receipt['moduleFiles'],'maximumLines':receipt['maximumModuleLines'],
                   'audit':reference('all-source-module-size-audit.json')},
        'frozenInputs':frozen['originalFrozenInputs'],
        'supplementaryFrozenInputs':frozen['supplementaryFixtureSha256'],
        'retiredCandidates':retired,
        'repairPreflight':read(REPO / frozen['preflight'] / 'measurement.json'),
        'sourceSnapshots':reference('source-snapshots/manifest.json'),
        'broaderFeatureRowsOpen':22,'fullTypeScriptParity':False,'artifacts':artifacts}
    write(PHASE / (PREFIX + 'MEASUREMENT.json'), data)
    print('Published same-source mapped-inference evidence after complete acceptance.',flush=True)


if __name__ == '__main__':
    main()
