# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import gzip
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
previous = repo / 'target/string-intrinsics-acceptance-20261113-r2'
directory = root / 'windows'
base = 'B:/BlueIce/gm3-20261109-360d7d921'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
baseline_path = root.parent / 'mapped-inference-acceptance-20261113-r4/windows/windows-source-manifest.json'
baseline = json.loads(baseline_path.read_bytes())
assert baseline['sourceRevision'] == 'backend-tree:f9b632e822e72070c084777e2ebe7558b2ef639f'
for name, digest in frozen['files'].items():
    assert sha(repo / name) == digest, name
paths = set(baseline['files']) | set(frozen['files'])
paths.add('development/browser_core/phase-18-bluets/MAPPED_INFERENCE_FOLLOWUP.md')
files = {name: sha(repo / name) for name in sorted(paths)}
backend = sorted((name for name in files if name.startswith('backend/')), key=lambda name: name.encode())
canonical = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(canonical) == set(backend)
assert len(backend) == frozen['backendFiles']
path_hash = hashlib.sha256('\0'.join(backend).encode()).hexdigest()
assert path_hash == frozen['backendPathSetSha256']
delta = {name: digest for name, digest in files.items() if baseline['files'].get(name) != digest}
archive_path = directory / 'source-delta.tar.gz'
with archive_path.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as archive:
        for name in delta:
            archive.add(repo / name, arcname=name, recursive=False)
manifest = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision': frozen['sourceRevision'],
    'parentCommit': frozen['parentCommit'],
    'backendFiles': len(backend),
    'backendPathSetSha256': path_hash,
    'baseManifestSha256': sha(baseline_path),
    'baseManifestGuestPath': base + '/p0d-r4-source-manifest.json',
    'baseFiles': baseline['files'],
    'files': files,
    'delta': delta,
    'sourcePatchSha256': sha(archive_path),
    'runnerSha256': sha(directory / 'windows-runner.cjs'),
    'scope': 'Frozen P0-D source; original82 core,25 paths and10 complete cohorts. No old-source pass credit.',
}
manifest_path = directory / 'windows-source-manifest.json'
with manifest_path.open('x') as output:
    output.write(json.dumps(manifest, indent=2) + '\n')
compressed = directory / 'windows-source-manifest.json.gz'
compressed.write_bytes(gzip.compress(manifest_path.read_bytes(), mtime=0))
bootstrap = (previous / 'windows/bootstrap.py').read_text()
bootstrap = bootstrap.replace("sha(base / 'p0c-r1-source-manifest.json')", "sha(Path(manifest['baseManifestGuestPath']))")
bootstrap = bootstrap.replace('p0c-r2', 'p0d-r5')
bootstrap = bootstrap.replace('054d71196d3ede6315b71001651dc7a1fa35f7489f6310b85a9f851e04148ef5', sha(manifest_path))
bootstrap = bootstrap.replace('backend-tree:687190197095253ff614e93a035b4e424b5e725a', frozen['sourceRevision'])
compile(bootstrap, 'bootstrap.py', 'exec')
(directory / 'bootstrap.py').write_text(bootstrap)
destinations = [
    ('windows-source-manifest.json.gz', 'p0d-r5-source-manifest.json.gz'),
    ('source-delta.tar.gz', 'p0d-r5-source-delta.tar.gz'),
    ('windows-runner.cjs', 'p0d-r5-windows-runner.cjs'),
    ('bootstrap.py', 'p0d-r5-bootstrap.py'),
    ('package-evidence.py', 'p0d-r5-package-evidence.py'),
]
plan = {'sourceRevision': frozen['sourceRevision'], 'conclusion': 'prepared',
        'files': [{'local': str(directory / name), 'remote': base + '/' + remote,
                   'sha256': sha(directory / name), 'bytes': (directory / name).stat().st_size}
                  for name, remote in destinations]}
(directory / 'upload-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'sourceRevision': frozen['sourceRevision'], 'backendFiles': len(backend),
                  'selectedFiles': len(files), 'deltaFiles': len(delta),
                  'archiveBytes': archive_path.stat().st_size, 'manifestSha256': sha(manifest_path)}))
