# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import io
import json
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
frozen = read(root / 'frozen-source-preflight.json')
directory = root / 'windows'
measurement = read(directory / 'windows-measurement.json')
manifest_path = directory / 'windows-source-manifest.json'
manifest = read(manifest_path)
archive_path = root / 'windows-evidence.tar.gz'
archive_receipt = read(directory / 'windows-evidence-receipt.json')
assert sha(archive_path.read_bytes()) == archive_receipt['archiveSha256']
assert archive_path.stat().st_size == archive_receipt['archiveBytes']
assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
assert measurement['sourceRevision'] == manifest['sourceRevision'] == frozen['sourceRevision']
assert measurement['expectedSourceManifestSha256'] == sha(manifest_path.read_bytes())
assert measurement['verifiedSourceFiles'] == len(manifest['files'])
assert measurement['verifiedBackendFiles'] == manifest['backendFiles']
canonical = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(canonical) == {p for p in manifest['files'] if p.startswith('backend/')}
canonical.sort(key=lambda path: path.encode())
assert sha('\0'.join(canonical).encode()) == manifest['backendPathSetSha256'] == measurement['backendPathSetSha256']
for name in canonical + ['Cargo.toml', 'Cargo.lock']:
    assert sha((repo / name).read_bytes()) == manifest['files'][name], name
for name in read(root / 'frozen-final-oracle-tools.json')['sha256']:
    path = 'development/browser_core/phase-18-bluets/tools/' + name
    assert sha((repo / path).read_bytes()) == manifest['files'][path], path

def summary(text):
    rows = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;', text)
    assert rows
    status, passed, failed, ignored, filtered = rows[-1]
    assert status == 'ok' and int(failed) == int(ignored) == 0
    return {'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored), 'filtered': int(filtered)}

selection = measurement['core82Selection']
assert measurement['core82Passed'] and measurement['core82Exit'] == 0
assert len(selection['selected']) == len(set(selection['selected'])) == len(selection['passed']) == 82
assert sorted(selection['selected']) == sorted(selection['passed']) and selection['ordinarySupportFiltered'] == 6
assert len(measurement['cases']) == 25 and all(row['passed'] and row['exit'] == 0 for row in measurement['cases'])
assert len({row['id'] for row in measurement['cases']}) == 25
cohorts = measurement['followups']
assert len(cohorts) == 10 and {row['target'] for row in cohorts} == {
    'mapped_inference', 'string_intrinsics', 'gc1_object_generic_methods', 'gm2_incremental_options', 'project_config',
    'defu_prerequisites', 'callable_utilities', 'receiver_utilities', 'noinfer', 'nonnullable_awaited',
}
assert all(row['passed'] and row['exit'] == 0 for row in cohorts)
with tarfile.open(archive_path) as archive:
    members = archive.getmembers()
    names = [member.name for member in members]
    assert len(names) == len(set(names))
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names)
    assert not any(member.issym() or member.islnk() for member in members)
    compiler = archive.extractfile('accepted-windows-cli.exe').read()
    assert sha(compiler) == measurement['compiler']['sha256'] == archive_receipt['compilerSha256']
    pe = int.from_bytes(compiler[60:64], 'little')
    assert compiler[pe:pe+4] == bytes([80,69,0,0])
    assert int.from_bytes(compiler[pe+4:pe+6], 'little') == archive_receipt['compilerMachine'] == 0x8664
    patch = archive.extractfile('source-delta.tar.gz').read()
    assert sha(patch) == measurement['sourcePatchSha256'] == manifest['sourcePatchSha256']
    patched = set()
    with tarfile.open(fileobj=io.BytesIO(patch)) as sources:
        for member in sources:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            assert member.name not in patched
            patched.add(member.name)
            assert sha(sources.extractfile(member).read()) == manifest['delta'][member.name] == manifest['files'][member.name]
    assert patched == set(manifest['delta']) 
    complete_source = archive.extractfile('full-source.tar.gz').read()
    assert sha(complete_source) == archive_receipt['fullSourceArchiveSha256']
    preserved = set()
    with tarfile.open(fileobj=io.BytesIO(complete_source)) as sources:
        for member in sources:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            assert member.name not in preserved
            preserved.add(member.name)
            assert sha(sources.extractfile(member).read()) == manifest['files'][member.name], member.name
    assert preserved == set(manifest['files']) and len(preserved)
    assert set(canonical) <= preserved
    prefix = 'results-mapped-inference-r5/'
    core = archive.extractfile(prefix + 'core82.stdout').read().decode().replace('\r\n', '\n')
    assert summary(core) == {'passed': 82, 'failed': 0, 'ignored': 0, 'filtered': 6}
    passed_names = re.findall(r'^test (.+) \.\.\. ok$', core, re.MULTILINE)
    assert sorted(passed_names) == sorted(selection['selected'])
    for row in measurement['cases']:
        assert Path(row['stdout']).name == row['stdout']
        text = archive.extractfile(prefix + row['stdout']).read().decode().replace('\r\n', '\n')
        assert summary(text)['passed'] == 1
        assert re.search(r'^test ' + re.escape(row['function']) + r' \.\.\. ok$', text, re.MULTILINE)
    results = {}
    for row in cohorts:
        text = archive.extractfile(prefix + row['target'] + '.stdout').read().decode()
        results[row['target']] = summary(text)
        assert results[row['target']]['filtered'] == 0
        assert results[row['target']]['passed'] == {'mapped_inference':7,'string_intrinsics':5,'gc1_object_generic_methods':5,'gm2_incremental_options':7,'project_config':11,'defu_prerequisites':2,'callable_utilities':3,'receiver_utilities':3,'noinfer':5,'nonnullable_awaited':6}[row['target']]
    reports = {}
    for label, pattern in [('primary', '/noinfer-observations/blue-'), ('supplement', '/noinfer-observations/regressions-')]:
        found = [name for name in names if pattern in name and name.endswith('/report.json')]
        assert len(found) == 1
        report = json.loads(archive.extractfile(found[0]).read())
        assert report['sourceRevision'] == frozen['sourceRevision']
        assert report['compilerSha256'] == measurement['compiler']['sha256']
        assert report['conclusion'] == 'pass'
        reports[label] = report
    primary = reports['primary']
    assert primary['inputSha256'] == sha((repo/'backend/bluets/tests/fixtures/noinfer/cases.json').read_bytes())
    assert len(primary['cases']) == 153 and primary['declarationFiles'] == 159
    assert primary['consumers'] == 306 and primary['syntax'] == 159 and primary['runtime'] == 6
    b_reports = [name for name in names if '/nonnullable-awaited-observations/blue-' in name and name.endswith('/report.json')]
    assert len(b_reports) == 1
    b = json.loads(archive.extractfile(b_reports[0]).read())
    assert b['sourceRevision'] == frozen['sourceRevision'] and b['compilerSha256'] == measurement['compiler']['sha256']
    assert b['conclusion'] == 'pass' and len(b['cases']) == 315
    assert b['declarationFiles'] == b['syntax'] == 331 and b['consumers'] == 630 and b['runtime'] == 12
    assert set(row['id'] for row in b['cases']) == {row['id'] for file in ['reference.json', 'operator-reference.json'] for row in read(repo/'backend/bluets/tests/fixtures/nonnullable_awaited'/file)['cases'] if row['accepts']}
    c_reports = [name for name in names if '/string-intrinsics-observations/bluets-string-intrinsics-blue-' in name and name.endswith('/report.json')]
    assert len(c_reports) == 1
    c_path = c_reports[0]; c_directory = c_path.rsplit('/',1)[0]
    c = json.loads(archive.extractfile(c_path).read())
    assert c['sourceRevision'] == frozen['sourceRevision'] and c['compilerSha256'] == measurement['compiler']['sha256']
    assert c['conclusion'] == 'success' and len(c['cases']) == 980
    assert c['accepted'] == 772 and c['rejected'] == 208
    assert c['declarationFiles'] == c['syntax'] == 804 and c['consumers'] == 1544 and c['runtime'] == 16
    c_fixture = repo / 'backend/bluets/tests/fixtures/string_intrinsics'
    expected = {row['id']:row for row in read(c_fixture / 'reference.json')['cases']}
    assert len(expected) == 980 and {row['id']for row in c['cases']} == set(expected)
    assert c['frozenInputs'] == read(c_fixture / 'FROZEN.json')['sha256']
    for row in c['cases']:
        wanted = expected[row['id']]
        assert all(row[key] == wanted[key]for key in ['accepts','diagnostics','declarations'])
        assert row.get('consumers') == wanted.get('consumers') and row.get('runtime') == wanted.get('runtime')
        for name,text in row['declarations'].items():
            assert archive.extractfile(c_directory+'/'+row['id']+'/dist/'+name).read() == text.encode('utf-8')
        for name,digest in row.get('javascriptSha256',{}).items():
            assert sha(archive.extractfile(c_directory+'/'+row['id']+'/dist/'+name).read()) == digest
    contextual = read(c_fixture / 'literal-context-regressions.json')['cases']
    for row in contextual:
        path = prefix+'string-intrinsics-observations/literal-context-regressions/'+row['id']+'/observation.json'
        observed = json.loads(archive.extractfile(path).read())
        assert all(observed[key] == row[key]for key in ['id','accepts','diagnostics','declarations'])
    assert len(contextual) == 10
    d_reports = [name for name in names if '/mapped-inference-observations/bluets-mapped-inference-blue-' in name and name.endswith('/report.json')]
    assert len(d_reports) == 1
    d_path = d_reports[0]; d_directory = d_path.rsplit('/', 1)[0]
    d = json.loads(archive.extractfile(d_path).read())
    assert d['sourceRevision'] == frozen['sourceRevision'] and d['compilerSha256'] == measurement['compiler']['sha256']
    assert d['conclusion'] == 'success' and len(d['cases']) == 404
    assert d['accepted'] == 358 and d['rejected'] == 46
    assert d['declarationFiles'] == d['syntax'] == 366 and d['consumers'] == 716 and d['runtime'] == 8
    d_fixture = repo / 'backend/bluets/tests/fixtures/mapped_inference'
    expected_d = {row['id']: row for row in read(d_fixture / 'reference.json')['cases']}
    assert len(expected_d) == 404 and {row['id'] for row in d['cases']} == set(expected_d)
    assert d['frozenInputs'] == frozen['originalFrozenInputs']
    for row in d['cases']:
        wanted = expected_d[row['id']]
        assert all(row[key] == wanted[key] for key in ['accepts', 'diagnostics', 'declarations'])
        assert row.get('consumers') == wanted.get('consumers') and row.get('runtime') == wanted.get('runtime')
        ordinary = json.loads(archive.extractfile(prefix + 'mapped-inference-observations/' + row['id'] + '/observation.json').read())
        assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
        assert all(ordinary[key] == wanted[key] for key in ['id', 'accepts', 'diagnostics', 'declarations'])
        for name, text in row['declarations'].items():
            assert archive.extractfile(d_directory + '/' + row['id'] + '/dist/' + name).read() == text.encode('utf-8')
        for name, digest in row.get('javascriptSha256', {}).items():
            assert sha(archive.extractfile(d_directory + '/' + row['id'] + '/dist/' + name).read()) == digest
    d_supplement_count = d_owner_refusals = 0
    for filename, group in [('literal-preservation-controls.json', 'literal-preservation'),
                            ('projection-owner-controls.json', 'projection-owners'),
                            ('projection-identity-controls.json', 'projection-owners'),
                            ('projection-mutation-controls.json', 'projection-owners'),
                            ('callback-context-controls.json', 'callback-context'),
                            ('generic-argument-controls.json', 'generic-arguments')]:
        for row in read(d_fixture / filename)['cases']:
            location = prefix + 'mapped-inference-observations/' + group + '/' + row['id']
            observed = json.loads(archive.extractfile(location + '/observation.json').read())
            accepts = row.get('blueAccepts', row['accepts'])
            assert observed['accepts'] == accepts
            if accepts:
                assert all(observed[key] == row[key] for key in ['id', 'diagnostics', 'declarations'])
                for name, text in observed['declarations'].items():
                    assert archive.extractfile(location + '/dist/' + name).read() == text.encode('utf-8')
            else:
                assert [item['code'] for item in observed['diagnostics']] == [2322]
                assert observed['declarations'] == {}
                assert not any(name.startswith(location + '/dist/') for name in names)
                d_owner_refusals += 1
            d_supplement_count += 1
    assert d_supplement_count == 33 and d_owner_refusals == 10

    callback_reports = [name for name in names if '/mapped-inference-observations/native-callback-context-' in name and name.endswith('/report.json')]
    assert len(callback_reports) == 1
    callback = json.loads(archive.extractfile(callback_reports[0]).read())
    callback_fixture = read(d_fixture / 'callback-context-controls.json')
    assert callback['conclusion'] == 'success' and callback['sourceRevision'] == frozen['sourceRevision']
    assert callback['inputSha256'] == sha((d_fixture / 'callback-context-controls.json').read_bytes())
    assert callback['implementationSha256'] == callback_fixture['implementationSha256']
    assert len(callback['cases']) == 4 and callback['inventoryCredit'] == 0
    for name, digest in callback['libraries'].items(): assert callback_fixture['libraries'][name] == digest
    for row, expected in zip(callback['cases'], callback_fixture['cases']):
        assert all(row[key] == expected[key] for key in ['id', 'accepts', 'diagnostics', 'declarations'])

    argument_reports = [name for name in names if '/mapped-inference-observations/native-generic-arguments-' in name and name.endswith('/report.json')]
    assert len(argument_reports) == 1
    argument = json.loads(archive.extractfile(argument_reports[0]).read())
    argument_fixture = read(d_fixture / 'generic-argument-controls.json')
    assert argument['conclusion'] == 'success' and argument['sourceRevision'] == frozen['sourceRevision']
    assert argument['inputSha256'] == sha((d_fixture / 'generic-argument-controls.json').read_bytes())
    assert argument['implementationSha256'] == argument_fixture['implementationSha256']
    assert len(argument['cases']) == 12 and argument['inventoryCredit'] == 0
    for name, digest in argument['libraries'].items(): assert argument_fixture['libraries'][name] == digest
    argument_directory = argument_reports[0].rsplit('/',1)[0]
    for row, expected in zip(argument['cases'], argument_fixture['cases']):
        assert all(row[key] == expected[key] for key in ['id','accepts','diagnostics','declarations'])
        for name, text in row['declarations'].items():
            assert archive.extractfile(argument_directory+'/'+row['id']+'/dist/'+name).read() == text.encode('utf-8')

    assert archive.extractfile(prefix+'measurement.json').read() == (directory/'windows-measurement.json').read_bytes()
    assert archive.extractfile('windows-source-manifest.json').read() == manifest_path.read_bytes()
    assert sha(archive.extractfile(prefix+'accepted-windows-cli.exe').read()) == measurement['compiler']['sha256']
    supplement = reports['supplement']
    assert supplement['inputSha256'] == sha((repo / 'backend/bluets/tests/fixtures/noinfer/keyof-diagnostics.json').read_bytes())
    assert len(supplement['cases']) == 4 and all(row['agrees'] for row in supplement['cases'])

receipt = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision': frozen['sourceRevision'], 'conclusion': 'success',
    'paths': 25, 'coreOracles': 82, 'regressionCohorts': results,
    'allSelectedNamesPassedExactly': True, 'allCanonicalBackendPathsVerified': True,
    'backendFiles': len(canonical), 'selectedFiles': len(manifest['files']),
    'patchedFilesIndependentlyHashed': len(patched), 'fullSourceFilesIndependentlyHashed':len(preserved),
    'actualCompilerSha256': sha(compiler), 'actualCompilerArchiveHashMatches': True,
    'nonNullableAwaitedPrimaryComparisons': 396, 'nonNullableAwaitedSupplementaryNativeControls': 6,
    'nonNullableAwaitedDeclarationFiles': 331, 'nonNullableAwaitedConsumers': 630, 'nonNullableAwaitedSyntax': 331, 'nonNullableAwaitedExecutions': 12,
    'stringIntrinsicPrimaryComparisons':980, 'stringIntrinsicDeclarationFiles':804, 'stringIntrinsicConsumers':1544, 'stringIntrinsicSyntax':804, 'stringIntrinsicExecutions':16, 'supplementaryLiteralContextRows':10, 'supplementaryLiteralContextInventoryCredit':0,
    'mappedInferencePrimaryComparisons':404, 'mappedInferenceDeclarationFiles':366, 'mappedInferenceConsumers':716, 'mappedInferenceSyntax':366, 'mappedInferenceExecutions':8, 'mappedInferenceSupplementaryControls':33, 'mappedInferenceOwnerRefusals':10, 'mappedInferenceSupplementaryInventoryCredit':0,
    'noInferPrimaryObservations': 282, 'noInferSupplementalObservations': 4,
    'noInferDeclarationFiles': 159, 'noInferConsumers': 306, 'noInferSyntax': 159, 'noInferExecutions': 6,
    'archiveSha256': sha(archive_path.read_bytes()),
    'scope': 'Current same-source Windows x86_64 acceptance: original82 core,25 paths and10 full regression cohorts, with all canonical backend bytes, actual PE compiler and string-intrinsic/NonNullable/Awaited consumer outputs independently checked. Broader GM3 platform combinations remain open.'}
(directory / 'windows-acceptance-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
