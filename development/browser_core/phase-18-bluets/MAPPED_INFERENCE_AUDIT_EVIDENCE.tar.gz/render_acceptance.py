# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
import datetime
import re
from audit_acceptance import ROOT, PHASE, read, sha

PREFIX = 'MAPPED_INFERENCE_'


def main():
    data = read(PHASE / (PREFIX + 'MEASUREMENT.json'))
    audit = read(ROOT / 'acceptance-audit.json')
    assert data['conclusion'] == 'completed-within-frozen-scope'
    assert audit['conclusion'] == 'success' and audit['sourceRevision'] == data['source']['sourceRevision']
    for row in data['artifacts']:
        assert sha(PHASE / row['path']) == row['sha256']
    source = data['source']['sourceRevision']
    native = data['nativeMeasurement']
    workspace = data['gates']['workspace']
    date = datetime.date.today().isoformat()
    acceptance = f'''# P0-D — Reverse mapped inference and contextual array shapes

Accepted {date}, source `{source}`, against pinned TypeScript 5.9.3.
[Measurement]({PREFIX}MEASUREMENT.json), [artifacts]({PREFIX}ARTIFACTS.json)
and [discovery/repair history]({PREFIX}FOLLOWUP.md) bind this finite package.
All 22 broader feature rows remain open; full TypeScript parity remains **OFF**.

The bounded candidate collector reconstructs mapped arrays, readonly arrays,
tuples and records while preserving positional evidence, callback contexts and
literal widening. Materialized mapped signatures retain generic binders.
Runtime function/class parameters carry lexical identities; captured values are
canonicalized at their declaring scopes. Alias/interface formals stay inside
type instantiations, retaining the normal 256-expansion composed-demand budget.

A bounded projection proof requires the same parameter's real keyof identity
and either a fresh sequence or an unobserved unannotated local const initializer.
Other references, capture, write or escape invalidate that alias proof. Static
names grant no runtime authority. Configured exhaustion remains ResourceLimit
without successful output or an any/unknown fallback. Contextual binding rules,
reserved-binding recovery and exact as/satisfies continuation preserve existing
diagnostics and reject invalid emission. Declaration bytes remain exact.

| Frozen acceptance | Actual result |
| --- | --- |
| Primary programs | 101 forms × four ES5/ES2022 and CommonJS/ESNext profiles =404 complete comparisons |
| Verdicts/diagnostics | 358 accepts /46 rejects; complete primary/related diagnostics and UTF-16 positions match |
| Declarations, per actual compiler | 358 accepted inventories /366 physical declaration files |
| Isolated consumers | 716 positive/negative declaration-only Native consumers |
| Syntax/runtime | 366 selected-edition parses and eight executions |
| Separate boundaries | Two ambient owners, two runtime-authority refusals, six work and two parser-depth controls |
| Supplemental controls | 33 observations: 23 Native agreements and ten intentional owner refusals; no inventory credit |
| Complete Native catalog | {native['suites']} suites /{native['functions']} functions; zero failed, ignored or filtered |
| Complete local workspace | {workspace['passed']:,} passed; zero failed; ignored Native functions selected above |
| Complete maps | Fresh process-bound 8407×2 reports for both actual local compiler profiles; zero differences |
| Windows x86_64 | Same-source 82 core oracles, 25 paths and ten complete regression cohorts |
| Projects/tooling | defu, mitt, reproductions, interchange, formatting, warnings-denied workspace/all-target Clippy, Node/Python and accounting pass |
| Production modules | 566 Rust/declaration sources; maximum 1477 lines; none above 1500 |

Accepted C has 70/404 complete agreements, 334 differences and 264 accepts in
the expanded matrix. Its actual compiler, source binding and every raw baseline
observation are archived. The original 16 discovery programs remain unchanged.
Four independent callback controls also retain pinned Native implementation/
library replay. Twelve additional generic-argument controls preserve seven
accepted-C regressions, three positives and two contextual binder guards. Authored
parameter annotations use their declaring scope; contextual annotations keep their
own binders. Supplemental owner refusals are never Native agreements.

All 41,636 previous suite-qualified IDs and comparison/status/scope/reason classes
remain unchanged. The 404 direct and 12 policy assertions add 416, making
**N=42,052**. Assertions are neither unique programs nor language coverage.

All four retired formal candidates retain complete sources, actual Windows compilers
and raw results: R1 failed unchanged mitt with TS7006; R2 failed six G-T5
assertion-chain rows; R3 regressed seven accepted-C declarations to unknown types;
R4 widened the existing G-C1 generic-method literal result from 7 to number.
Signature-owned lexical/scoped parameter identity checks repair literal freshness
without rebinding contextual or captured parameters.
R3's complete Windows gate stays bound to its retired source. No partial pass
transfers to this source. Earlier authoring interruptions, their source and raw
receipts remain preserved; all nine final preflight steps finished before freeze.

Independent follow-ups retain broader existing gaps: unrelated/shadowed/constrained
key acceptances, key-intersection and optional-chain admission, mixed callback
unions, some callable-alias invocations and quantified negative diagnostics. The
60-case literal-freshness repair comparison retains 46 agreements and 14 differences, with no
regressions against accepted C. These discovery observations add no primary or
inventory credit. An earlier typed-index alias initializer remains open.

All actual compilers, backend sources, raw observations, consumers, maps and logs
are retained in hashed archives. Hosted CI, extra OS profiles and coverage remain
supplementary to the accepted full-local/Windows-82 boundary. P0-D is complete
within the frozen scope; broader compositions require new explicit contracts.
'''
    (PHASE / (PREFIX + 'ACCEPTANCE.md')).write_text(acceptance)
    path = PHASE / (PREFIX + 'FOLLOWUP.md')
    text = path.read_text()
    first = text.index('Status:')
    end = text.index('\nAll 22 broader feature rows', first)
    text = text[:first] + f'''Status: completed within the frozen scope. Final source `{source}` passes
[acceptance](MAPPED_INFERENCE_ACCEPTANCE.md), with complete
[measurements](MAPPED_INFERENCE_MEASUREMENT.json) and
[artifacts](MAPPED_INFERENCE_ARTIFACTS.json). The accepted-C baseline source is
`backend-tree:687190197095253ff614e93a035b4e424b5e725a`, commit
`c971f5f5c4dff02f04fa2b3199cf337b6cb71f5f`.''' + text[end:]
    text += f'''\nFinal acceptance on {date}: `{source}` passes all {native['suites']} Native suites /
{native['functions']} functions, the complete local workspace, both fresh 8407×2
map reports, projects/tooling and Windows 82 core oracles plus 25 paths and ten
full cohorts. The 404 direct comparisons and 12 policy assertions add 416,
raising N from 41,636 to 42,052 without changing previous case classes. The 33
supplemental observations add no inventory credit. All four retired candidates and
all known broader counterexamples remain preserved in the linked evidence.
'''
    path.write_text(text)
    path = PHASE / 'TODO.md'
    text = path.read_text()
    assert text == (ROOT / 'todo-before-acceptance.md').read_text(), 'Review TODO drift before completion changes'
    a = text.index('**Latest completed follow-up:**')
    b = text.index('\n## Open gaps', a)
    text = text[:a] + '''**Latest completed follow-up:** P0-D repairs shared reverse-mapped and contextual
array/tuple inference, preserving literal widening, generic identities and bounded
owner/resource behavior. [Acceptance](MAPPED_INFERENCE_ACCEPTANCE.md) binds all
Native/local/Windows gates, exact declarations, consumers, maps and projects to
its source. P0-A/P0-B/P0-C retain their dated evidence. All 22 broader rows remain
open; freeze new cross-file and generic-flow counterexamples before extending it.
''' + text[b:]
    text = text.replace('P0-A/B/C have\ncomplete source-bound acceptance; P0-D remains open.',
                        'P0-A/B/C/D have\ncomplete source-bound acceptance within their frozen contracts.')
    text = text.replace("Continue with P0-D's frozen contract.",
                        'P0-D completes that finite contract; prioritize newly frozen cross-file and generic-flow counterexamples next.')
    pattern = r'- \[ \] \*\*P0-D — Reverse mapped inference and contextual array shapes\.\*\*.*?(?=\n\nEach package needs)'
    replacement = '''- [x] **P0-D — Reverse mapped inference and contextual array shapes.** Delivered
  101 forms × four profiles =404 complete comparisons, with 358 accepts /46
  rejects, 366 exact declaration files, 716 consumers, 366 parses and eight
  executions per actual compiler. Twelve policy controls remain separate;
  33 supplemental observations include ten intentional owner refusals and add
  no inventory credit. Complete same-source Native/local/Windows, maps,
  projects and tooling pass. All 41636 earlier case classes remain unchanged;
  416 new assertions bring N to 42052. [Acceptance](MAPPED_INFERENCE_ACCEPTANCE.md) ·
  [measurement](MAPPED_INFERENCE_MEASUREMENT.json). Broader rows remain open.'''
    text, count = re.subn(pattern, replacement, text, flags=re.S)
    assert count == 1
    path.write_text(text)
    print('Rendered P0-D and checked only its finite package after complete publication.', flush=True)


if __name__ == '__main__':
    main()
