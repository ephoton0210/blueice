# P0-B preparation; production changes pending

P0-A remains in complete acceptance. Do not change its frozen production,
fixtures, oracle tools or current compiler while its pipeline is active.
Finish, document, commit and push A before starting B production changes.

The independently regenerated input/reference bytes match all four original
pre-production hashes. `combined-design-scope.json` binds both matrices,
their complete raw Native calibration, and the unchanged current-source baseline.

| Matrix | Direct observations | Accepted inventories | Declaration files | Isolated consumers | Executions | Baseline agreements |
| --- | --- | --- | --- | --- | --- | --- |
| Primary 91 forms × four profiles | 364 | 283 | 299 | 566 | 12 | 26 |
| Eight ordinary aliases × four profiles | 32 | 32 | 32 | 64 | 0 | 3 |
| Complete B scope | 396 | 315 | 331 | 630 | 12 | 29 |

The 32 ordinary controls are additional direct observations. Do not omit them
from final case accounting. Six owner/runtime and nine resource controls in
`frozen-matrix/boundary-controls.json` are separate; they still need actual
final-source public-API tests. Do not count them as direct Native agreements.

1. Provide ES5 static PromiseLike, Promise and PromiseConstructorLike foundations
   and Awaited independently of authority for the ES2015 runtime Promise value.
   Preserve owner declarations and default-denied runtime names.
2. Implement NonNullable through ordinary `T & {}` relations/normalization.
   Cover nullish unions, any, unknown, never, generic/dependent and strict-null
   profiles. The Present alias controls require shared semantics.
3. Match structural thenables through the ordinary conditional/infer machinery.
   Intersection patterns must collect bindings across all successful constraints
   atomically. Fixed callback prefixes plus inferred rest must handle absent
   positional arguments and tuple/array projections. Preserve existing receiver,
   Parameters/ConstructorParameters and NoInfer candidate boundaries.
4. Keep decreasing recursive Awaited evaluation and precise Native TS2589
   failures for demanded self/mutual cycles. Existing instantiate_named visited
   keys already include type identity and arguments; do not replace a supposed
   name-only guard. Configured work/depth exhaustion remains a separate
   ResourceLimit refusal, with no Native counterpart or emitted artifacts.
5. Preserve Native declaration identities. NonNullable and ordinary Present
   compound union operands can retain aliases/wrappers; scalar/object/unknown
   reductions differ. Explicit annotations and ordinary named diagnostic owners
   must stay intact. Do not solve this by stripping every utility/operator alias.
6. Fix actual strict-null configuration handling. The unchanged CLI currently
   rejects all 91 loose-null profile programs before checking. Native accepts
   the authored configuration. Preserve explicit option validation; do not drop
   or silently change that profile to get passing measurements.

Inspect these shared paths before production edits:

- checker/type_relations/more_types.rs: intersection normalization.
- checker/type_operators/conditional.rs: intersection infer-pattern bindings.
- checker/type_operators/conditional/functions.rs and callables.rs: fixed/rest
  signature matching and receiver preservation.
- checker/type_relations.rs and type_relations/substitution.rs: bounded named
  instantiation, recursion and demand propagation.
- checker/inference/results.rs: demanded inferred result materialization while
  preserving Native public alias surfaces.
- bin/bluetsc/tsconfig/options.rs: implicit strict-property initialization and
  explicit strictNullChecks interactions.
- standard_library files and edition selection: static ES5 definitions versus
  the ES2015 runtime constructor.

Freeze all new authored expectations before changing production. Keep both
matrix hashes unchanged. After the complete B implementation, run corresponding
focused tests followed by the complete same-source Native/local/Windows-82,
map, project, formatting/Clippy and tooling gates. Only then check B and commit
implementation with all matching measurements, followed by the authorized push.
All broader feature rows and full TypeScript parity retain their open scope.
