# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import threading
import time

root = Path(__file__).resolve().parent
repo = root.parent.parent
state = {'pid': os.getpid(), 'stage': 'starting', 'conclusion': 'in_progress',
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
project_result = {}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = root / 'pipeline-state.tmp'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(root / 'pipeline-state.json')


def projects_after_build():
    try:
        while True:
            path = root / 'native-gates.json'
            if path.exists():
                try:
                    gate = json.loads(path.read_bytes())
                except json.JSONDecodeError:
                    time.sleep(0.2)
                    continue
                if gate['conclusion'] == 'failure':
                    raise RuntimeError('Native build/gate failed before projects')
                if 'nativeCompilerSha256' in gate:
                    break
            time.sleep(1)
        with (root / 'project-driver.log').open('xb') as log:
            child = subprocess.Popen([sys.executable, str(root / 'run_project_gates.py')],
                cwd=repo, stdout=log, stderr=subprocess.STDOUT)
            project_result['pid'] = child.pid
            project_result['exit'] = child.wait()
    except Exception as error:
        project_result.update(exit=1, error=repr(error))


try:
    assert not (root / 'native-gates.json').exists()
    assert not (root / 'local-gates.json').exists()
    save()
    with (root / 'native-driver.log').open('xb') as log:
        native = subprocess.Popen([sys.executable, str(root / 'run_native_gates.py')],
            cwd=repo, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        state.update(stage='native-running', nativePid=native.pid)
        save()
        print('NATIVE_STARTED', native.pid, flush=True)
        project_thread = threading.Thread(target=projects_after_build)
        project_thread.start()
        code = native.wait()
        state['nativeExit'] = code
        save()
        if code:
            raise RuntimeError('Native driver failed: ' + str(code))
    project_thread.join()
    state['projects'] = project_result
    save()
    assert project_result['exit'] == 0, project_result
    with (root / 'local-driver.log').open('xb') as log:
        local = subprocess.Popen([sys.executable, str(root / 'run_local_gates.py')],
            cwd=repo, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        state.update(stage='local-running', localPid=local.pid)
        save()
        print('LOCAL_STARTED', local.pid, flush=True)
        code = local.wait()
    state.update(stage='terminal', localExit=code,
                 conclusion='success' if code == 0 else 'failure')
    save()
    print('LOCAL_EXIT', code, flush=True)
    raise SystemExit(code)
except Exception as error:
    state.update(conclusion='failure', error=repr(error))
    save()
    raise
