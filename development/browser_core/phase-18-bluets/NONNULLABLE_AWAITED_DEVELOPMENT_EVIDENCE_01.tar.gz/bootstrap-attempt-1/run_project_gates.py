# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime,hashlib,json,os,subprocess
repo=Path('/Users/ephoton/git/blueice-bluets');root=repo/'target/nonnullable-awaited-20261112'
frozen=json.loads((root/'frozen-source-preflight.json').read_text());native=json.loads((root/'native-gates.json').read_text());compiler=root/'accepted-native-cli'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert native['sourceRevision']==frozen['sourceRevision'] and sha(compiler)==native['nativeCompilerSha256']
for name,digest in frozen['files'].items():assert sha(repo/name)==digest,name
state={'sourceRevision':frozen['sourceRevision'],'compilerSha256':sha(compiler),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'conclusion':'in_progress'}
def save():(root/'project-gates.json').write_text(json.dumps(state,indent=2)+'\n')
env=dict(os.environ,FORCE_COLOR='0');oracle=repo/'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'
try:
 save()
 for label,script in [('defu','defu-audit.cjs'),('mitt','audit.cjs'),('reproductions','defu-reproduce.cjs'),('interchange','defu-interchange.cjs')]:
  name='project-'+label;state['stage']=name;save();log=root/(name+'.log');assert not log.exists()
  args=['node',str(repo/'differential-testing/bluets-projects'/script),'--compiler',str(compiler),'--typescript',str(oracle),'--output',str(root/name),'--source-tree',frozen['backendTree']]
  print('START',name,flush=True)
  with log.open('wb') as output:result=subprocess.run(args,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
  step={'label':name,'command':args,'exit':result.returncode,'log':log.name,'sha256':sha(log)};state['steps'].append(step);save();print('END',name,result.returncode,flush=True)
  assert result.returncode==0,step
 assert sha(compiler)==state['compilerSha256'];state.update(conclusion='success',stage='complete',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as error:state.update(conclusion='failure',error=repr(error));save();raise
