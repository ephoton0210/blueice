# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
contract = repo / 'target/higher-order-inference-contract-20261114'
quality = contract / 'regressions-6'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = lambda *args: subprocess.check_output(args, cwd=repo, text=True).strip()
checked = read(quality / 'measurement.json')
assert checked['conclusion'] == 'success' and checked['stage'] == 'complete'
assert [step['label'] for step in checked['steps']] == [
    'library','affected-callers','call-chain-regressions','fmt','clippy','node-tools','python-tools']
for step in checked['steps']:
    assert step['exit'] == 0 and sha(quality / step['log']) == step['logSha256']
assert sha(quality / 'source-manifest.json') == checked['sourceManifestSha256']
files = read(quality / 'source-manifest.json')
for name, digest in files.items():
    assert sha(repo / name) == digest, name
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard',
    '-z','--','backend','development/browser_core/phase-18-bluets/tools'],cwd=repo).decode().split('\0')
assert set(filter(None, paths)) == set(files)
assert not command('git','diff','--name-only','--','backend','development/browser_core/phase-18-bluets/tools')
parent = command('git','rev-parse','HEAD')
assert parent == '87d53ef80beb76c77dd804b9c14f3ed2dbb8a4c5'
tree = command('git','write-tree')
backend_tree = command('git','rev-parse',tree + ':backend')
backend = sorted((name for name in files if name.startswith('backend/')),key=lambda name:name.encode())
indexed = subprocess.check_output(['git','ls-files','-z','--','backend'],cwd=repo).decode().split('\0')[:-1]
assert set(backend) == set(indexed)
fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
frozen = read(fixture / 'FROZEN.json')
for name, digest in frozen['sha256'].items():
    assert sha(fixture / name) == digest, name
candidate = read(contract / 'candidate-14/measurement.json')
assert candidate['conclusion'] == 'focused-green' and candidate['completeAgreements'] == 384
assert candidate['completeDifferences'] == candidate['newDifferencesSinceBaseline'] == 0
for name, digest in candidate['source'].items():
    assert sha(repo / name) == digest, name
downstream = read(contract / 'downstream-6/measurement.json')
assert downstream['conclusion'] == 'success'
assert downstream['compilerSha256'] == candidate['actual-cliSha256']
for step in downstream['commands']:
    assert step['exit'] == 0
    assert sha(contract / 'downstream-6' / (step['label']+'.log')) == step['logSha256']
    assert step['report']['comparisons'] == 384 and step['report']['syntax'] == 424
    assert step['report']['consumers'] == 704 and step['report']['runtime'] == 48
# Supplementary controls and real projects are verified before long acceptance.
scope = read(contract / 'recursive-scope-green-2/report.json')
assert scope['conclusion'] == 'success' and scope['agreements'] == len(scope['cases']) == 16
assert scope['compilerSha256'] == candidate['actual-cliSha256']
scope_fixture = repo / 'backend/bluets/tests/fixtures/higher_order_recursive_scope'
assert scope['inputSha256'] == sha(scope_fixture / 'cases.json')
scope_reference = read(scope_fixture / 'reference.json')
assert [{"id": row['id'], **row['expected']} for row in scope['cases']] == scope_reference['cases']
projects = read(contract / 'projects-candidate14-1/measurement.json')
assert projects['conclusion'] == 'success' and projects['stage'] == 'complete'
assert projects['sourceRevision'] == 'backend-tree:' + backend_tree
assert projects['compilerSha256'] == candidate['actual-cliSha256']
defu = read(contract / 'defu-candidate14-1/report.json')
assert defu['conclusion'] == 'compatible-with-frozen-profile'
assert defu['sourceRevision'] == projects['sourceRevision'] and defu['compilerSha256'] == projects['compilerSha256']
for step in projects['steps']:
    assert step['exit'] == 0 and sha(contract / 'projects-candidate14-1' / step['log']) == step['logSha256']
prior_failure = read(contract / 'r5-project-failure-preservation-1/receipt.json')
assert prior_failure['conclusion'] == 'preserved' and prior_failure['originalFailureUnchanged']
assert sha(contract / 'r5-project-failure-preservation-1/frozen-source.tar.gz') == prior_failure['archiveSha256']
assert read(repo / 'target/higher-order-inference-acceptance-20261114-r5/launch-state.json')['conclusion'] == 'failure'
prior = read(repo / 'development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json')
assert sum(len(suite['cases']) for suite in prior['suites']) == 42716
tools = json.loads(subprocess.check_output(['node','-e',
    "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"],cwd=repo))
state = {'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit':parent,'backendTree':backend_tree,'sourceRevision':'backend-tree:'+backend_tree,
    'backendFiles':len(backend),'backendPathSetSha256':hashlib.sha256('\0'.join(backend).encode()).hexdigest(),
    'files':files,'originalFrozenInputs':frozen['sha256'],
    'qualityMeasurementSha256':sha(quality/'measurement.json'),
    'qualityManifestSha256':sha(quality/'source-manifest.json'),
    'focusedCandidateMeasurementSha256':sha(contract/'candidate-14/measurement.json'),
    'focusedDownstreamMeasurementSha256':sha(contract/'downstream-6/measurement.json'),
    'oracleToolFilesExpected':len(tools),'expectedNativeSuites':191,'expectedNativeFunctions':1087,
    'previousAssertions':42716,'addedAssertions':396,
    'recursiveScopeControls':16,'recursiveScopeMeasurementSha256':sha(contract/'recursive-scope-green-2/report.json'),
    'projectPreflightSha256':sha(contract/'projects-candidate14-1/measurement.json'),
    'r5FailurePreservationSha256':sha(contract/'r5-project-failure-preservation-1/receipt.json'),
    'scope':'P0-G frozen finite higher-order inference contract. Full same-source acceptance still required; all22 broader rows remain open.'}
with (root/'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(state,indent=2)+'\n')
(root/'frozen-final-oracle-tools.json').write_text(json.dumps({'sha256':tools},indent=2)+'\n')
print(json.dumps({key:value for key,value in state.items() if key!='files'}))
