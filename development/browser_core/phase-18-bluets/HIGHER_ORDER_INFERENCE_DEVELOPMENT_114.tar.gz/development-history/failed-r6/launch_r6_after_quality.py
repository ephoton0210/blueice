# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Observe the existing quality process, then launch r6 exactly once."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

contract = Path(__file__).resolve().parent
repo = contract.parent.parent
root = repo / 'target/higher-order-inference-acceptance-20261114-r6'
output = repo / 'target/higher-order-inference-orchestration-20261114-r6'
output.mkdir()
shutil.copy2(__file__, output / Path(__file__).name)
quality = contract / 'regressions-6/measurement.json'
quality_pid = 72458
quality_command = '/Applications/Xcode.app/Contents/Developer/Library/Frameworks/Python3.framework/Versions/3.9/Resources/Python.app/Contents/MacOS/Python -B target/higher-order-inference-contract-20261114/regressions_after_call_chains.py regressions-6'
state = {'pid': os.getpid(), 'conclusion': 'in_progress', 'stage': 'observing-existing-quality',
         'qualityPid': quality_pid, 'qualityCommand': quality_command,
         'sourceRevision': 'backend-tree:c746a2387175ac4df07d8a4ec91e983fb5d5ecec',
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'commitPerformed': False, 'pushPerformed': False}

def read(path):
    return json.loads(path.read_bytes())

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = output / 'state.tmp'
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(output / 'state.json')

def live_quality():
    result = subprocess.run(['ps', '-p', str(quality_pid), '-o', 'command='],
                            capture_output=True, text=True)
    if result.returncode == 1 and not result.stdout.strip():
        return False
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == quality_command, 'Original quality PID changed owners'
    state['lastQualityProcessVerifiedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    return True

try:
    save()
    while True:
        observed = read(quality)
        running = live_quality()
        state['observedQualityStage'] = observed['stage']
        state['observedQualityConclusion'] = observed['conclusion']
        save()
        if observed['conclusion'] != 'in_progress':
            assert observed['conclusion'] == 'success' and observed['stage'] == 'complete', observed
            if not running:
                break
        elif not running:
            raise RuntimeError('Quality process ended without a successful terminal measurement')
        time.sleep(5)
    assert len(observed['steps']) == 7 and all(step['exit'] == 0 for step in observed['steps'])
    assert not (root / 'launch-state.json').exists(), 'Do not launch twice'
    state.update(stage='launching-complete-acceptance',
                 qualityMeasurementSha256=hashlib.sha256(quality.read_bytes()).hexdigest())
    save()
    shutil.copy2(__file__, root / Path(__file__).name)
    with (output / 'acceptance-launch.log').open('xb') as stream:
        child = subprocess.Popen([sys.executable, '-B', str(root / 'launch.py')],
                                 cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
        state.update(acceptancePid=child.pid, stage='observing-complete-acceptance')
        save()
        while child.poll() is None:
            save()
            time.sleep(5)
        code = child.returncode
    state.update(acceptanceExit=code)
    assert code == 0 and read(root / 'launch-state.json')['conclusion'] == 'success'
    state.update(conclusion='success', stage='complete-acceptance-awaiting-independent-publication')
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
