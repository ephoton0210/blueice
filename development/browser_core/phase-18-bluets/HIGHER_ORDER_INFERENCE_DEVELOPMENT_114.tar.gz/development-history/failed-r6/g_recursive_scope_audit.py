# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Audit complete supplementary scope observations from physical source/products."""
from pathlib import Path
import hashlib
import json
import re
import tarfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def fixture(repo):
    directory = repo / 'backend/bluets/tests/fixtures/higher_order_recursive_scope'
    raw = (directory / 'cases.json').read_bytes()
    inputs = json.loads(raw)
    reference = json.loads((directory / 'reference.json').read_bytes())
    assert digest(raw) == reference['inputSha256']
    assert reference['typescript'] == '5.9.3' and reference['inventoryCredit'] == 0
    assert len(inputs['profiles']) == 2 and len(inputs['cases']) == 8
    expected = {row['id']: row for row in reference['cases']}
    assert len(expected) == 16 and sum(row['accepts'] for row in expected.values()) == 14
    assert sum(len(row['declarations']) for row in expected.values()) == 16
    return inputs, reference, expected


def diagnostic(value):
    value = value.get('typescript', value)
    assert isinstance(value, dict), 'Every rejection needs its complete Native counterpart'
    return {'code': value['code'], 'message': value['message'],
            'file': value['span']['module'], 'position': value['position'],
            'relatedInformation': [diagnostic(row) for row in value['relatedInformation']]}


def products(repo, prefix, names, content, build_logs=True):
    inputs, reference, expected = fixture(repo)
    names = set(names)
    records = []
    for profile in inputs['profiles']:
        for entry in inputs['cases']:
            ident = profile['id'] + '/' + entry['id']
            wanted = expected[ident]
            directory = prefix.rstrip('/') + '/' + ident
            sources = {'main.ts': entry['source'], **entry.get('files', {})}
            source_hashes = {}
            for name, text in sources.items():
                raw = content(directory + '/' + name)
                assert raw == text.encode('utf-8'), (ident, name)
                source_hashes[name] = digest(raw)
            config = content(directory + '/tsconfig.json')
            assert json.loads(config) == {
                'compilerOptions': {**inputs['options'], **profile['compilerOptions'], 'outDir': 'dist'},
                'files': list(sources),
            }, ident
            actual_names = {name[len(directory + '/dist/'):] for name in names
                            if name.startswith(directory + '/dist/') and name.endswith('.d.ts')}
            assert actual_names == set(wanted['declarations']), ident
            declarations = {}
            for name, text in wanted['declarations'].items():
                raw = content(directory + '/dist/' + name)
                assert raw == text.encode('utf-8'), (ident, name)
                declarations[name] = digest(raw)
            record = {'id': ident, 'sourceSha256': source_hashes,
                      'configSha256': digest(config), 'declarationSha256': declarations}
            if build_logs:
                stdout = content(directory + '/build.stdout')
                stderr = content(directory + '/build.stderr')
                if wanted['accepts']:
                    assert re.fullmatch(
                        rb'built [1-9][0-9]* entry point\(s\), [1-9][0-9]* module\(s\), fingerprint bts-project-[0-9a-f]{16}\r?\n',
                        stdout), ident
                else:
                    assert stdout == b'', ident
                observed = [diagnostic(json.loads(line)) for line in stderr.decode('utf-8').splitlines() if line]
                assert observed == wanted['diagnostics'], ident
                assert bool(observed) != wanted['accepts'], ident
                record.update(stdoutSha256=digest(stdout), stderrSha256=digest(stderr))
            if not wanted['accepts']:
                assert not any(name.startswith(directory + '/dist/') for name in names), ident
            records.append(record)
    assert len(records) == 16
    return {'comparisons': 16, 'accepted': 14, 'rejected': 2, 'declarationFiles': 16,
            'inventoryCredit': 0, 'products': records,
            'inputSha256': reference['inputSha256'],
            'implementationSha256': reference['implementationSha256']}


def audit(root, repo, source, gates):
    contract = repo / 'target/higher-order-inference-contract-20261114'
    report_path = contract / 'recursive-scope-green-2/report.json'
    report = json.loads(report_path.read_bytes())
    inputs, reference, expected = fixture(repo)
    assert report['conclusion'] == 'success' and report['agreements'] == len(report['cases']) == 16
    assert report['inputSha256'] == reference['inputSha256']
    assert report['implementationSha256'] == reference['implementationSha256']
    candidate = json.loads((contract / 'candidate-14/measurement.json').read_bytes())
    assert candidate['conclusion'] == 'focused-green'
    assert candidate['actual-cliSha256'] == report['compilerSha256']
    for row in report['cases']:
        assert row['agrees'] and row['expected'] == row['observed']
        assert {'id': row['id'], **row['expected']} == expected[row['id']]
    freeze_path = contract / 'recursive-scope-red-1/pre-repair-freeze.json'
    freeze = json.loads(freeze_path.read_bytes())
    assert freeze['beforeProductionRepair'] and freeze['observations'] == 16
    assert (freeze['baselineAgreements'], freeze['baselineDifferences']) == (4, 12)
    directory = repo / 'backend/bluets/tests/fixtures/higher_order_recursive_scope'
    for name, value in freeze['fixture'].items():
        assert digest((directory / name).read_bytes()) == value
    red = json.loads((contract / 'recursive-scope-red-1/report.json').read_bytes())
    assert red['agreements'] == 4 and red['compilerSha256'] == freeze['actualFailedCompilerSha256']
    assert [{'id': row['id'], **row['expected']} for row in red['cases']] == reference['cases']
    proof = {}
    for kind in ['native', 'workspace']:
        base = kind + '-capture/higher-order-inference/recursive-scope'
        names = [path.relative_to(root).as_posix() for path in (root / base).rglob('*') if path.is_file()]
        proof[kind] = products(repo, base, names, lambda name: (root / name).read_bytes())
        proof[kind]['compilerSha256'] = gates[kind + 'CompilerSha256']
    with tarfile.open(root / 'windows-evidence.tar.gz') as archive:
        names = [member.name for member in archive if member.isfile()]
        proof['windows'] = products(repo,
            'results-higher-order-inference-r6/higher-order-inference-observations/recursive-scope',
            names, lambda name: archive.extractfile(name).read())
    windows = json.loads((root / 'windows/windows-measurement.json').read_bytes())
    proof['windows']['compilerSha256'] = windows['compiler']['sha256']
    return {'sourceRevision': source, 'comparisonsPerCompiler': 16, 'inventoryCredit': 0,
            'permanentTest': 'recursive_calls_keep_closed_callback_parameters_in_their_own_scope',
            'preRepairFreeze': 'development-history/contract/recursive-scope-red-1/pre-repair-freeze.json',
            'preRepairFreezeSha256': digest(freeze_path.read_bytes()),
            'preflightReport': 'development-history/contract/recursive-scope-green-2/report.json',
            'preflightReportSha256': digest(report_path.read_bytes()), 'actualCompilerProducts': proof}
