import type { Merger, DefuFn as DefuFunction, DefuInstance } from "./types";
export declare function createDefu(merger?: Merger): DefuFunction;
export declare const defu: DefuInstance;
export default defu;
export declare const defuFn: DefuFunction;
export declare const defuArrayFn: DefuFunction;
export type { Defu } from "./types";
