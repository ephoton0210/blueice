// BlueIce authored dependency-addition probe.
export const auditTrue = true;
