"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defuArrayFn = exports.defuFn = exports.defu = void 0;
exports.createDefu = createDefu;
const _utils_1 = require("./_utils");
// Base function to apply defaults
function _defu(baseObject, defaults, namespace = ".", merger) {
    if (!(0, _utils_1.isPlainObject)(defaults)) {
        return _defu(baseObject, {}, namespace, merger);
    }
    const object = Object.assign({}, defaults);
    for (const key in baseObject) {
        if (key === "__proto__" || key === "constructor") {
            continue;
        }
        const value = baseObject[key];
        if (value === null || value === undefined) {
            continue;
        }
        if (merger && merger(object, key, value, namespace)) {
            continue;
        }
        if (Array.isArray(value) && Array.isArray(object[key])) {
            object[key] = [...value, ...object[key]];
        }
        else if ((0, _utils_1.isPlainObject)(value) && (0, _utils_1.isPlainObject)(object[key])) {
            object[key] = _defu(value, object[key], (namespace ? `${namespace}.` : "") + key.toString(), merger);
        }
        else {
            object[key] = value;
        }
    }
    return object;
}
// Create defu wrapper with optional merger and multi arg support
function createDefu(merger) {
    return (...arguments_) => 
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {});
}
// Standard version
exports.defu = createDefu();
exports.default = exports.defu;
// Custom version with function merge support
exports.defuFn = createDefu((object, key, currentValue) => {
    if (object[key] !== undefined && typeof currentValue === "function") {
        object[key] = currentValue(object[key]);
        return true;
    }
});
// Custom version with function merge support only for defined arrays
exports.defuArrayFn = createDefu((object, key, currentValue) => {
    if (Array.isArray(object[key]) && typeof currentValue === "function") {
        object[key] = currentValue(object[key]);
        return true;
    }
});
//# sourceMappingURL=defu.js.map