import defu from './dist/defu';
import type {DefuFn} from './dist/types';
const callable: DefuFn = defu.fn;
