# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
native_pid = 29671
state_path = root / 'post-native-supervisor.json'
lock = root / 'post-native-supervisor.lock'
state = {'pid': os.getpid(), 'nativePid': native_pid, 'stage': 'waiting-for-existing-native',
         'conclusion': 'in_progress', 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')


def native_running():
    result = subprocess.run(['ps', '-p', str(native_pid), '-o', 'command='],
                            capture_output=True, text=True)
    if result.returncode == 1 and not result.stdout.strip():
        return False
    assert result.returncode == 0, result.stderr
    return str(root.relative_to(root.parent.parent) / 'run_native_gates.py') in result.stdout


with lock.open('x') as file:
    file.write(str(os.getpid()) + '\n')
try:
    assert native_running(), 'Native driver must be observed live before supervising it'
    assert not (root / 'local-gates.json').exists(), 'never start a second local gate'
    save()
    print('SUPERVISING live Native driver', native_pid, flush=True)
    while native_running():
        gates = json.loads((root / 'native-gates.json').read_bytes())
        measurement = json.loads((root / 'accepted-native/measurement.json').read_bytes())
        state['nativeConclusion'] = gates['conclusion']
        state['nativePassedSuites'] = sum(row['conclusion'] == 'success' for row in measurement['suites'])
        save()
        time.sleep(5)
    gates = json.loads((root / 'native-gates.json').read_bytes())
    assert gates['conclusion'] == 'success', 'Native driver ended without full success; retain evidence and stop'
    assert not (root / 'local-gates.json').exists()
    state['stage'] = 'starting-local-gates-after-native-exit'
    save()
    log_path = root / 'local-driver.log'
    with log_path.open('xb') as log:
        process = subprocess.Popen([sys.executable, str(root / 'run_local_gates.py')],
            cwd=root.parent.parent, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        receipt = {'pid': process.pid, 'nativePid': native_pid,
                   'nativeTerminalConclusion': gates['conclusion'],
                   'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        launch = root / 'local-driver-launch.json'
        with launch.open('x') as output:
            output.write(json.dumps(receipt, indent=2) + '\n')
        state.update(stage='local-gates-running', localPid=process.pid)
        save()
        print('STARTED guarded local pipeline', process.pid, flush=True)
        code = process.wait()
    state.update(stage='local-driver-terminal', localExit=code,
                 conclusion='success' if code == 0 else 'failure')
    save()
    print('LOCAL_PIPELINE_EXIT', code, flush=True)
    raise SystemExit(code)
except Exception as error:
    state.update(conclusion='failure', error=repr(error))
    save()
    raise
