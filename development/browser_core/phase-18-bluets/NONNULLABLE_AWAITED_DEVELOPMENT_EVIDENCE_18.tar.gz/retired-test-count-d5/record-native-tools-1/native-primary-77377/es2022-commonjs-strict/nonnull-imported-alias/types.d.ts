export interface Payload {
    code: number;
}
