type Thenable = {
    then: number;
};
export declare const value: Thenable;
export {};
