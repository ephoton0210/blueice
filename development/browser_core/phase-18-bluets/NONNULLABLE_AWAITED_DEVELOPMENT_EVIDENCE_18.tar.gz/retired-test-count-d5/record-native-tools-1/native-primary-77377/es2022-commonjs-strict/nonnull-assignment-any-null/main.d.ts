export declare const value: NonNullable<any>;
