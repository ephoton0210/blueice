export declare const value: null | undefined;
