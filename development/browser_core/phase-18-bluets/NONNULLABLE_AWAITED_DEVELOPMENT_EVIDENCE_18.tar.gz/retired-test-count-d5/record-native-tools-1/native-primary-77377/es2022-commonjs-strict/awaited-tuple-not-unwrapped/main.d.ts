export declare const value: [PromiseLike<number>, string];
