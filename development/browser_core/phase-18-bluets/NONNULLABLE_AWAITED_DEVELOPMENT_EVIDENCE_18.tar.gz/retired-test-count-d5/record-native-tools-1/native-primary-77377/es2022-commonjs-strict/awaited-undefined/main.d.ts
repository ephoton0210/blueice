export declare const value: undefined;
