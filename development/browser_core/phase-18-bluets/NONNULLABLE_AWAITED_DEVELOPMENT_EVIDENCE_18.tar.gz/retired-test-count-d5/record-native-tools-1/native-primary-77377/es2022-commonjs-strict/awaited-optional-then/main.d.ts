type Thenable = {
    then?: (onfulfilled: (value: number) => void) => void;
};
export declare const value: Thenable;
export {};
