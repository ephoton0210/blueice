export declare function requireValue<T>(input: T): NonNullable<T>;
export declare const value: "ok";
