export declare const value: null;
