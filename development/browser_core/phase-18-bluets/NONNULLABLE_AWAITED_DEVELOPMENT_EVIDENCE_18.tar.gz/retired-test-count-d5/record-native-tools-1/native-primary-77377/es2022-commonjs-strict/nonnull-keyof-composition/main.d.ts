export declare const value: "a" | "b";
