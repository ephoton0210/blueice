"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.value = void 0;
exports.requireValue = requireValue;
function requireValue(input) {
    if (input == null)
        throw 0;
    return input;
}
exports.value = requireValue("ok");
