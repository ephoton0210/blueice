import type { Payload } from "./types";
export declare const value: Payload;
