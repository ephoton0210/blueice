type RequiredValues<T> = {
    [K in keyof T]: NonNullable<T[K]>;
};
export declare const value: RequiredValues<{
    x: string | null;
    y: number | undefined;
}>;
export {};
