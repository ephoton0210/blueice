export declare function unwrap<T>(value: T): Awaited<T>;
export declare const value: number;
