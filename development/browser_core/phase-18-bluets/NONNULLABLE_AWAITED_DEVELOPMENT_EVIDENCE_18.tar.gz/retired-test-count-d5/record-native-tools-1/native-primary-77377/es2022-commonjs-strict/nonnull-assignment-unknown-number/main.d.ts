export declare const value: NonNullable<unknown>;
