export declare const value: (x: number) => string;
