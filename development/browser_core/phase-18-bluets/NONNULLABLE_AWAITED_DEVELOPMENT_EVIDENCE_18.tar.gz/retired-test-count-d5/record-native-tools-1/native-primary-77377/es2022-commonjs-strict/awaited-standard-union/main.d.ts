export declare const value: string | number | null;
