export type Thenable = {
    then(onfulfilled: (value: number) => void): void;
};
