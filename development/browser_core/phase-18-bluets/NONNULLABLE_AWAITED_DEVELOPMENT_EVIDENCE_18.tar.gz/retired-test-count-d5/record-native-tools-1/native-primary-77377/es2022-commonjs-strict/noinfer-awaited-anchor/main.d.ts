export declare const value: "red";
