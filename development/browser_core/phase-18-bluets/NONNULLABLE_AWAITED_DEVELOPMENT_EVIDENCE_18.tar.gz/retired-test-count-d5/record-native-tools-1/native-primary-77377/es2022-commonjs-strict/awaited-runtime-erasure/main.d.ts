export declare function identity(value: number): Awaited<number>;
export declare const value: number;
