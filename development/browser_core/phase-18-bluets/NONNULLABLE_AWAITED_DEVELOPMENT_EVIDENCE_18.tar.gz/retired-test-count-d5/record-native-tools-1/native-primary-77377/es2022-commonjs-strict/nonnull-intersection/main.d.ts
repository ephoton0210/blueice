export declare const value: {
    x: number;
} & {
    y: string;
};
