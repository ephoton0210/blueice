"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.value = void 0;
exports.identity = identity;
function identity(value) { return value; }
exports.value = identity(7);
if (exports.value !== 7)
    throw 1;
