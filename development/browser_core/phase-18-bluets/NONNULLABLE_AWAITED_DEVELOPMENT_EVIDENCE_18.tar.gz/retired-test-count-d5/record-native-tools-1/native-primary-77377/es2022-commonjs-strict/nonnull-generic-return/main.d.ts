export declare function requireValue<T>(value: T): NonNullable<T>;
export declare const value: "ok";
