export declare const value: "ok";
