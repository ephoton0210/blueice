export declare const value: {
    code: number;
};
