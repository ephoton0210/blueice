type Present<T> = T & {};
export declare const value: Present<string | number | null | undefined>;
export {};
