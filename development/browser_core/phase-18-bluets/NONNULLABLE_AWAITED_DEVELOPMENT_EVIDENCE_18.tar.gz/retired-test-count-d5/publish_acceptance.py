# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import json
import shutil
import subprocess
import tarfile
from audit_acceptance import audit, ROOT, REPO, PHASE, read, sha

PREFIX = 'NONNULLABLE_AWAITED_'
LIMIT = 95 * 1024 * 1024


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pack(path, files):
    assert not path.exists(), path
    with tarfile.open(path, 'w:gz') as output:
        for file in files:
            assert file.is_file() and not file.is_symlink(), file
            output.add(file, arcname=file.relative_to(ROOT).as_posix(), recursive=False)
    with tarfile.open(path) as output:
        members = output.getmembers()
        assert len(members) == len({member.name for member in members}) == len(files)
        assert all(member.isfile() and not Path(member.name).is_absolute()
                   and '..' not in Path(member.name).parts for member in members)


def publish_group(label, files):
    files = sorted(files)
    candidate = ROOT / (PREFIX + label + '.candidate.tar.gz')
    pack(candidate, files)
    chunks = [files]
    if candidate.stat().st_size >= LIMIT:
        # Keep every source file. Split an oversized compression group by
        # uncompressed size so even incompressible evidence stays below LIMIT.
        candidate.unlink()
        chunks, current, size = [], [], 0
        for file in files:
            length = file.stat().st_size
            assert length < 80 * 1024 * 1024, file
            if current and size + length >= 80 * 1024 * 1024:
                chunks.append(current)
                current, size = [], 0
            current.append(file)
            size += length
        if current:
            chunks.append(current)
    result = []
    for index, chunk in enumerate(chunks):
        suffix = '' if len(chunks) == 1 else '_' + str(index + 1).zfill(2)
        destination = PHASE / (PREFIX + label + suffix + '.tar.gz')
        assert not destination.exists(), destination
        if len(chunks) == 1 and candidate.exists():
            shutil.move(candidate, destination)
        else:
            pack(destination, chunk)
        assert destination.stat().st_size < LIMIT
        result.append({'path': destination.name, 'bytes': destination.stat().st_size,
                       'sha256': sha(destination),
                       'membersSha256': {file.relative_to(ROOT).as_posix(): sha(file) for file in chunk}})
        print('ARCHIVED', destination.name, destination.stat().st_size, flush=True)
    return result


def main():
    # Refuse any accepted result until all full same-source gates have passed.
    receipt = audit()
    write(ROOT / 'acceptance-audit.json', receipt)
    frozen = read(ROOT / 'frozen-source-preflight.json')
    gates = receipt['gates']
    (ROOT / 'accepted-source.patch').write_bytes(subprocess.check_output([
        'git', 'diff', '--binary', 'HEAD', '--', 'backend',
        'development/browser_core/phase-18-bluets/tools'], cwd=REPO))
    groups = {name: set() for name in ['COMPILERS', 'NATIVE_EVIDENCE',
        'WORKSPACE_EVIDENCE', 'DEVELOPMENT_EVIDENCE', 'AUDIT_EVIDENCE']}
    compilers = {'accepted-native-cli', 'accepted-workspace-cli', 'baseline-cli',
        'native-cli-snapshot', 'workspace-cli-snapshot',
        'native-map-test-executable', 'workspace-map-test-executable'}
    native_directories = {'accepted-native', 'native-capture', 'presence-corrected',
        'project-defu', 'project-mitt', 'project-reproductions', 'project-interchange'}
    # Capture every completed source snapshot, raw observation and retired attempt.
    # Exclude only generated result archives and the separately copied Windows archive.
    for file in ROOT.rglob('*'):
        assert not file.is_symlink(), file
        if not file.is_file() or file.name.endswith('.candidate.tar.gz'):
            continue
        relative = file.relative_to(ROOT)
        first = relative.parts[0]
        if first == 'windows-evidence.tar.gz':
            continue
        if len(relative.parts) == 1 and first in compilers:
            group = 'COMPILERS'
        elif first in native_directories or first.startswith('native-declaration-map') or first == 'native-map-binding.json':
            group = 'NATIVE_EVIDENCE'
        elif first == 'workspace-capture' or first.startswith('workspace-') or first == 'workspace.log':
            group = 'WORKSPACE_EVIDENCE'
        elif first == 'windows' or (len(relative.parts) == 1 and file.suffix in ['.json', '.log', '.py', '.cjs', '.patch', '.md']):
            group = 'AUDIT_EVIDENCE'
        else:
            group = 'DEVELOPMENT_EVIDENCE'
        groups[group].add(file)
    artifacts = []
    for label, files in groups.items():
        assert files
        artifacts.extend(publish_group(label, files))
    destination = PHASE / (PREFIX + 'WINDOWS_EVIDENCE.tar.gz')
    assert not destination.exists()
    shutil.copy2(ROOT / 'windows-evidence.tar.gz', destination)
    assert sha(destination) == receipt['windows']['archiveSha256']
    artifacts.append({'path': destination.name, 'bytes': destination.stat().st_size,
                      'sha256': sha(destination), 'originalWindowsArchive': True})
    assert all(row['bytes'] < LIMIT for row in artifacts)
    def reference(path):
        key = Path(path).as_posix()
        owners = [row for row in artifacts if key in row.get('membersSha256', {})]
        assert len(owners) == 1, key
        return {'archive': owners[0]['path'], 'path': key,
                'sha256': owners[0]['membersSha256'][key]}
    references = {kind: reference(receipt['nonNullableAwaitedReports'][kind]['path'])
                  for kind in ['native', 'workspace']}
    no_infer = {kind: {label: reference(row['path'])
                      for label, row in receipt['noInferReports'][kind].items()}
                for kind in ['native', 'workspace']}
    baseline = read(ROOT / 'baseline-replay.json')
    artifact_manifest = {'schema': 1, 'sourceRevision': frozen['sourceRevision'], 'artifacts': artifacts}
    write(PHASE / (PREFIX + 'ARTIFACTS.json'), artifact_manifest)
    summary = {'schema': 1, 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion': 'completed-within-frozen-scope', 'source': frozen, 'gates': gates,
        'nativeMeasurement': {'path': 'COMPATIBILITY_MEASUREMENT.json',
            'sha256': sha(ROOT / 'accepted-native/measurement.json'),
            'suites': receipt['nativeSuites'], 'functions': receipt['nativeFunctions']},
        'primaryForms': 91, 'ordinaryOperatorForms': 8, 'profiles': 4,
        'primaryObservations': 364, 'ordinaryOperatorObservations': 32,
        'directObservations': 396, 'supplementaryNativeDemandControls': 6,
        'acceptedDeclarationInventories': 315, 'declarationFiles': 331,
        'isolatedConsumers': 630, 'selectedEditionParses': 331, 'executions': 12,
        'ownerRuntimeChecks': 6, 'originalResourceControls': 9,
        'supplementaryResourceControls': 6, 'boundaryControls': 21,
        'boundaryControlsExcludedFromDirectDenominator': True,
        'caseInventoryAdditions': 423,
        'nonNullableAwaitedReports': references, 'noInferReports': no_infer,
        'mapBindings': receipt['mapBindings'],
        'completeNativeRoleFamilies': receipt['completeNativeRoleFamilies'],
        'partialNativeRoleReports': receipt['partialNativeRoleReports'],
        'baseline': {'sourceRevision': baseline['sourceRevision'],
            'sourceCommit': baseline['sourceCommit'], 'compilerSha256': baseline['compilerSha256'],
            'observations': 396, 'completeAgreements': 29, 'accepted': 82,
            'scope': baseline['scope'], 'reference': reference('baseline-replay.json')},
        'presenceInventory': {'corrected': read(ROOT / 'presence-corrected.json'),
            'excludedFromDirectDenominator': True},
        'projects': {name: reference('project-' + name + '/report.json')
            for name in ['defu', 'mitt', 'reproductions', 'interchange']},
        'windows': receipt['windows'], 'casePreservation': receipt['casePreservation'],
        'modules': {'files': receipt['moduleFiles'], 'maximumLines': receipt['maximumModuleLines'],
            'audit': reference('all-source-module-size-audit.json')},
        'frozenInputs': read(ROOT / 'STATE.json')['frozenSha256'],
        'supplementaryFrozenInputs': read(ROOT / 'STATE.json')['supplementaryFixtureSha256'],
        'retiredNativeEvidence': receipt['retiredNativeEvidence'],
        'broaderFeatureRowsOpen': 22, 'fullTypeScriptParity': False,
        'artifacts': artifacts}
    write(PHASE / (PREFIX + 'MEASUREMENT.json'), summary)
    print('Published complete same-source NonNullable/Awaited implementation and measurements.', flush=True)


if __name__ == '__main__':
    main()
