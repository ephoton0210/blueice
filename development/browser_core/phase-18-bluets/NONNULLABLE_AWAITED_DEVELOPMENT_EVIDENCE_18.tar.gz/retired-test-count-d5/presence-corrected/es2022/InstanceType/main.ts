export type Witness = InstanceType<new (value: number) => {value: number}>;
