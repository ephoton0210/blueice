export type Witness = Readonly<{tag: string}>;
