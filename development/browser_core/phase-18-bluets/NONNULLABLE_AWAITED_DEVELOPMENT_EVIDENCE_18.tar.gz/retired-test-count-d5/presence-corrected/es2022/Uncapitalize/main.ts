export type Witness = Uncapitalize<"Word">;
