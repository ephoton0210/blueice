export type Witness = ThisParameterType<(this: {tag: string}, value: number) => string>;
