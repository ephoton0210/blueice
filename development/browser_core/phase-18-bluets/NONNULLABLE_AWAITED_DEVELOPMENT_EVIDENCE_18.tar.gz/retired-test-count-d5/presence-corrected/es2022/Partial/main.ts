export type Witness = Partial<{tag: string}>;
