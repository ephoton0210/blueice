export type Witness = OmitThisParameter<(this: {tag: string}, value: number) => string>;
