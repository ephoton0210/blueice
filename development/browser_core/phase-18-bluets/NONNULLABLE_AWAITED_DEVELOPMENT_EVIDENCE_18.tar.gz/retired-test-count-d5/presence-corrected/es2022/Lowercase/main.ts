export type Witness = Lowercase<"WORD">;
