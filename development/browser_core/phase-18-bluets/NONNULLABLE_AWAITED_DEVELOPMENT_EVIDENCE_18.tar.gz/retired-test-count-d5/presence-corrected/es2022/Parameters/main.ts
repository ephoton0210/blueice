export type Witness = Parameters<(value: number) => string>;
