export type Witness = Awaited<PromiseLike<string>>;
