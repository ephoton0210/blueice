export type Witness = Omit<{tag: string; value: number}, "value">;
