export type Witness = Extract<string | number, string>;
