export type Witness = Required<{tag?: string}>;
