export type Witness = NoInfer<string>;
