export type Witness = NonNullable<string | null | undefined>;
