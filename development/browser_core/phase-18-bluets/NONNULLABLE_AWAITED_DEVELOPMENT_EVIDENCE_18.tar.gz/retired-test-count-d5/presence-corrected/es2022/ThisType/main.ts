export type Witness = ThisType<{tag: string}>;
