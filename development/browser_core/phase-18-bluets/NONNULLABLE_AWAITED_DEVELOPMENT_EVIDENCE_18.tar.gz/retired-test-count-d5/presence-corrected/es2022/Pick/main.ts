export type Witness = Pick<{tag: string; value: number}, "tag">;
