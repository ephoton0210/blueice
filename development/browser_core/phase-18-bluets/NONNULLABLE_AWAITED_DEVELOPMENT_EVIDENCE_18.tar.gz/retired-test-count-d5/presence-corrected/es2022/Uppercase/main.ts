export type Witness = Uppercase<"word">;
