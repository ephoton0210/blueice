export type Witness = ReturnType<() => string>;
