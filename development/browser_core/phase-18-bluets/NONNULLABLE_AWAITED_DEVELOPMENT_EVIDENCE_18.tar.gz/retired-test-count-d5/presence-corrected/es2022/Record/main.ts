export type Witness = Record<"tag", string>;
