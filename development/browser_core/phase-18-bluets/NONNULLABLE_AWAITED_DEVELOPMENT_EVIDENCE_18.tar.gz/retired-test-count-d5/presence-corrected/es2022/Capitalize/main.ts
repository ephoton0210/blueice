export type Witness = Capitalize<"word">;
