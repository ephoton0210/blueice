export type Witness = ConstructorParameters<new (value: number) => {value: number}>;
