export type Witness = Exclude<string | number, number>;
