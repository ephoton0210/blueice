import type * as Surface0 from "./out/esm/factory.js";
export type Consumer0 = typeof Surface0;
import type * as Surface1 from "./out/esm/main.js";
export type Consumer1 = typeof Surface1;
export {};
