import type * as Surface0 from "./out/cjs/barrel.js";
export type Consumer0 = typeof Surface0;
import type * as Surface1 from "./out/cjs/decorators.js";
export type Consumer1 = typeof Surface1;
import type * as Surface2 from "./out/cjs/main.js";
export type Consumer2 = typeof Surface2;
export {};
