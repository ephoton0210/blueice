import type * as Surface0 from "./out/esm/barrel.js";
export type Consumer0 = typeof Surface0;
import type * as Surface1 from "./out/esm/factory.js";
export type Consumer1 = typeof Surface1;
import type * as Surface2 from "./out/esm/main.js";
export type Consumer2 = typeof Surface2;
import type * as Surface3 from "./out/esm/provider-runtime.js";
export type Consumer3 = typeof Surface3;
export {};
