import type * as Surface0 from "./out/esm/main.js";
export type Consumer0 = typeof Surface0;
export {};
