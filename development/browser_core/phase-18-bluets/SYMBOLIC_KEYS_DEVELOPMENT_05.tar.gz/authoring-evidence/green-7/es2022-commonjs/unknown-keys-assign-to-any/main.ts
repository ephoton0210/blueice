export function result(key: keyof unknown, consume: (key: any) => void) { consume(key); }
