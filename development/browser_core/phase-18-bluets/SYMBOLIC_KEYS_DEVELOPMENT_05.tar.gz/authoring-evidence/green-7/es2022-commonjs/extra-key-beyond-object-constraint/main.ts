export function result<E extends {x: number}, K extends keyof E>(key: K, consume: (key: "x") => void) { consume(key); }
