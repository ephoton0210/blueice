export function result<E, F extends E, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
