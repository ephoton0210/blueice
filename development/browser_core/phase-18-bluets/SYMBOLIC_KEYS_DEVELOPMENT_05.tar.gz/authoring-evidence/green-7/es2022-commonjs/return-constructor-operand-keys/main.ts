export function result<E>(key: keyof (new () => E)) { return key; }
