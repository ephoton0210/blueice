type PropertyKey = boolean;
export function result(key: PropertyKey) { return key; }
