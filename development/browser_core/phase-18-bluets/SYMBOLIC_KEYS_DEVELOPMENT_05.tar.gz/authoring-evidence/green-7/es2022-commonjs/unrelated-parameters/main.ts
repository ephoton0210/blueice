export function result<E, F, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
