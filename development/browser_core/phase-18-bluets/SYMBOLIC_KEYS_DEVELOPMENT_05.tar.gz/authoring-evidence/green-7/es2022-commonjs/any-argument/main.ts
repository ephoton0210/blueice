export function result<E>(key: any, consume: (key: keyof E) => void) { consume(key); }
