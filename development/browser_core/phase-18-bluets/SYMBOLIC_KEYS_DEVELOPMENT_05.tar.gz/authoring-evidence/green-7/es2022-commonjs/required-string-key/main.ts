export function result<E extends {x: number}>(key: "x", consume: (key: keyof E) => void) { consume(key); }
