export function result<E, F, G>(key: keyof ((E | F) & G)) { return key; }
