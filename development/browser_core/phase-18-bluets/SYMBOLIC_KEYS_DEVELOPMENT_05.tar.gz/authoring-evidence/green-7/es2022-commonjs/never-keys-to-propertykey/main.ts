export function result<E>(key: keyof never, consume: (key: PropertyKey) => void) { consume(key); }
