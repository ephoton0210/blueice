export function result(key: symbol, consume: (key: keyof any) => void) { consume(key); }
