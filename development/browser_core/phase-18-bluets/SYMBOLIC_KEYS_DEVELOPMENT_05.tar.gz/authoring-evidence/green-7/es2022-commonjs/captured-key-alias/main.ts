export function result<E, F>(consume: (key: keyof E) => void) { type Key = keyof F; return (key: Key) => consume(key); }
