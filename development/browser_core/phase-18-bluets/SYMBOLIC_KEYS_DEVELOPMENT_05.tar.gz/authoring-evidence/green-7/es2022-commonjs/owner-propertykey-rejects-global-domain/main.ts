type PropertyKey = boolean;
export function result(key: keyof any, consume: (key: PropertyKey) => void) { consume(key); }
