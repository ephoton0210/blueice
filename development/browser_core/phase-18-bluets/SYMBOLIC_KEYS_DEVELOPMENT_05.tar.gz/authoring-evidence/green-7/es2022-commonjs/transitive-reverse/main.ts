export function result<E, F extends E, G extends F, K extends keyof G>(key: K, consume: (key: keyof E) => void) { consume(key); }
