export function result(key: keyof never, consume: (key: symbol) => void) { consume(key); }
