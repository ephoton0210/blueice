export function result<E, K extends keyof E>(key: K, consume: (key: keyof E) => void) { consume(key); }
