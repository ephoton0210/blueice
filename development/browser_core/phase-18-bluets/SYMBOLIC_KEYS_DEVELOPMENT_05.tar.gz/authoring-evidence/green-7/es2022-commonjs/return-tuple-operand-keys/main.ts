export function result<E, F>(key: keyof [E, F]) { return key; }
