type Keys<T> = keyof T;
export function result<E, K extends Keys<E>>(key: K, consume: (key: keyof E) => void) { consume(key); }
