export function result<E, F>(key: keyof (E | F), consume: (key: keyof F) => void) { consume(key); }
