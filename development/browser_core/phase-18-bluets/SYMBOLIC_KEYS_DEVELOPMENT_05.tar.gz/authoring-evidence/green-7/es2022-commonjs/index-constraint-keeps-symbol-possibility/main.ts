export function result<E extends {[key: string]: number}>(key: keyof E, consume: (key: string | number) => void) { consume(key); }
