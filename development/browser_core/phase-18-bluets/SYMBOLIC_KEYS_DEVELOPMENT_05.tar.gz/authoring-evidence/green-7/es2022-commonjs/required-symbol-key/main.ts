declare const token: unique symbol;
export function result<E extends {[token]: number}>(key: typeof token, consume: (key: keyof E) => void) { consume(key); }
