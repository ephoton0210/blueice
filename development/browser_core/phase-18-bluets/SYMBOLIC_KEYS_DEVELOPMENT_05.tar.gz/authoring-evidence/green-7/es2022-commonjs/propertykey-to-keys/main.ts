export function result<E>(key: PropertyKey, consume: (key: keyof E) => void) { consume(key); }
