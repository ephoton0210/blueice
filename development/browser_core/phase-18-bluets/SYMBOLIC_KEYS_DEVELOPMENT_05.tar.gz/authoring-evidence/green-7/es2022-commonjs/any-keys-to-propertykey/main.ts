export function result<E>(key: keyof any, consume: (key: PropertyKey) => void) { consume(key); }
