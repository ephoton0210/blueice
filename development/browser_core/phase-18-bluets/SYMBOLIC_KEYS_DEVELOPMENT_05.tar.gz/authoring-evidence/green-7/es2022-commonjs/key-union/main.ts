export function result<E, F, K extends keyof E | keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
