type Keys<T> = keyof T;
export function result<E, F>(key: Keys<E | F>) { return key; }
