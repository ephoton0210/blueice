export function result<E, F>(key: keyof F, consume: (key: keyof E) => void) { type Key = keyof F; const local: Key = key; consume(local); }
