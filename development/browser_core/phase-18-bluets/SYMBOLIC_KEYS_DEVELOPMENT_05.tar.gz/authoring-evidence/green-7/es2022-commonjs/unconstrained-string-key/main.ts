export function result<E>(key: "x", consume: (key: keyof E) => void) { consume(key); }
