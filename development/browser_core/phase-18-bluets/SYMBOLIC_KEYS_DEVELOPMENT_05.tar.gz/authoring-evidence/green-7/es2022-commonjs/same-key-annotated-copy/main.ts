export function result<E, K extends keyof E>(key: K, consume: (key: keyof E) => void) { const local: keyof E = key; consume(local); }
