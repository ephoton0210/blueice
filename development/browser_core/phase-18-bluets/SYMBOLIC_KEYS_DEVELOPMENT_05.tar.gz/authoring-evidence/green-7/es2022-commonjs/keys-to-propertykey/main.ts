export function result<E>(key: keyof E, consume: (key: PropertyKey) => void) { consume(key); }
