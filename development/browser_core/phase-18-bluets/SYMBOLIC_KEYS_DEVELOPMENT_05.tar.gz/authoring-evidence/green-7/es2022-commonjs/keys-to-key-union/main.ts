export function result<E, F>(key: keyof E, consume: (key: keyof E | keyof F) => void) { consume(key); }
