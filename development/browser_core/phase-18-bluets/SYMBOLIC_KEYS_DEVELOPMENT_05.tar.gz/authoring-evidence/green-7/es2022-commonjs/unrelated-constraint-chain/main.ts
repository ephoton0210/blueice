export function result<E, F, K extends keyof F, L extends K>(key: L, consume: (key: keyof E) => void) { consume(key); }
