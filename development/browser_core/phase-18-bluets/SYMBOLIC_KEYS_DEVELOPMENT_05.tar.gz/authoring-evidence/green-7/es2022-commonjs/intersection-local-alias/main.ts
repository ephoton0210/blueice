export function result<E, F>(key: keyof E & keyof F, consume: (key: keyof E) => void) { type Key = keyof E & keyof F; const local: Key = key; consume(local); }
