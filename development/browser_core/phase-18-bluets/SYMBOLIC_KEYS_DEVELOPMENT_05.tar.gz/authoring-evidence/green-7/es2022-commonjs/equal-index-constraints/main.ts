export function result<E extends {[key: string]: unknown}, F extends {[key: string]: unknown}, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
