export function result<E extends F, F, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
