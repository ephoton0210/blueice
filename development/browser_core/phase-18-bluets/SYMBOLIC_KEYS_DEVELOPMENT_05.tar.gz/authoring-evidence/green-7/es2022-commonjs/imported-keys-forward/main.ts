import type {Keys} from "./keys";
export function result<E extends F, F, K extends Keys<F>>(key: K, consume: (key: Keys<E>) => void) { consume(key); }
