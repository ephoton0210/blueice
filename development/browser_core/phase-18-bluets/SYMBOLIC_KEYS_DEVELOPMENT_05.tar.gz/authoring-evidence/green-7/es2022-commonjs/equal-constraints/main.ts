export function result<E extends {x: number}, F extends {x: number}, K extends keyof F>(key: K, consume: (key: keyof E) => void) { consume(key); }
