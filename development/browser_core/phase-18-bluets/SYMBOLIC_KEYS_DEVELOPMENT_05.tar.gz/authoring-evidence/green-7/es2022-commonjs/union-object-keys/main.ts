export function result<E, F>(key: keyof (E | F), consume: (key: keyof E) => void) { consume(key); }
