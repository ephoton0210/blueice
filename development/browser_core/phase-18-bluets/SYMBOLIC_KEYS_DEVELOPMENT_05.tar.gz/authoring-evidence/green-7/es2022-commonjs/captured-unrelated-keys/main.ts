export function result<E, F>(consume: (key: keyof E) => void) { return function<K extends keyof F>(key: K) { consume(key); }; }
