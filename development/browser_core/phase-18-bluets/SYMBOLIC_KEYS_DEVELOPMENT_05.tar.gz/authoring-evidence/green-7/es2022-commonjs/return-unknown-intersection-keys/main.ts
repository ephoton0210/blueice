export function result<E>(key: keyof (E & unknown)) { return key; }
