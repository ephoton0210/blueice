export function result<E>(key: keyof unknown, consume: (key: never) => void) { consume(key); }
