export function result<E>(key: keyof E, consume: (key: keyof E) => void) { type Key = keyof E; const local: Key = key; consume(local); }
