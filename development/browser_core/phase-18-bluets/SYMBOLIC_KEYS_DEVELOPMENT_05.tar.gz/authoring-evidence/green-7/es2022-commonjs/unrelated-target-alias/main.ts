type Keys<T> = keyof T;
export function result<E, F>(key: keyof F, consume: (key: Keys<E>) => void) { consume(key); }
