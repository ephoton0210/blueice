export function result(key: keyof symbol) { return key; }
