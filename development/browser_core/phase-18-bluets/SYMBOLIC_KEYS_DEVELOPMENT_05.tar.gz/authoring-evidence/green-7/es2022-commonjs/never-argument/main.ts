export function result<E>(key: never, consume: (key: keyof E) => void) { consume(key); }
