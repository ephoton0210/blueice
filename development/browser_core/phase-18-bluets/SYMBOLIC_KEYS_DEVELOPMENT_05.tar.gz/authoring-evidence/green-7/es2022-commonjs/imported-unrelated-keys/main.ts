import type {Keys} from "./keys";
export function result<E, F>(key: Keys<F>, consume: (key: Keys<E>) => void) { consume(key); }
