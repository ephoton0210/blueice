export function result<E>(key: keyof E[]) { return key; }
