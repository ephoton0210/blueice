type Keys<T> = keyof T;
export function result<E, F>(key: Keys<E> & Keys<F>, consume: (key: Keys<E>) => void) { consume(key); }
