export function result<E>(consume: (key: keyof E) => void) { return function<K extends keyof E>(key: K) { consume(key); }; }
