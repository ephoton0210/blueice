export function result<E,F,G,H>(key: keyof ((E & F) | G)) { return key; }
