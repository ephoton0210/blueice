export function result<E,F,G,H>(key: keyof (G & (E | F))) { return key; }
