export function result<E,F,G,H>(key: keyof ((G | F) & E)) { return key; }
