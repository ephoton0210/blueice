export function result<E,F,G>(key: keyof (E | (F & G)), consume: (key: keyof ((E | F) & G)) => void) { consume(key); }
