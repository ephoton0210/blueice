export function result<E,F,G,H>(key: keyof ((E | G) & F)) { return key; }
