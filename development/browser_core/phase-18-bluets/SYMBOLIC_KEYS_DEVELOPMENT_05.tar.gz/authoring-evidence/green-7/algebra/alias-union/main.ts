type Choices<A,B> = A | B;
export function result<E,F,G,H>(key: keyof (Choices<E,F> & G)) { return key; }
