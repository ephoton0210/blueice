type Both<A,B> = A & B;
export function result<E,F,G,H>(key: keyof (Both<E,F> | G)) { return key; }
