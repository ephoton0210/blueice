interface Recursive {then(cb: (value: Recursive) => void): void;}
declare const input: Awaited<Recursive>;
export const value = input;
export const wrong: number = "bad";
