interface Recursive {then(cb: (value: Recursive) => void): void;}
declare function unwrap<T>(value: T): Awaited<T>;
declare const input: Recursive;
export const value = unwrap(input);
