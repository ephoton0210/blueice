interface Recursive {then(cb: (value: Recursive) => void): void;}
export const value = 1;
