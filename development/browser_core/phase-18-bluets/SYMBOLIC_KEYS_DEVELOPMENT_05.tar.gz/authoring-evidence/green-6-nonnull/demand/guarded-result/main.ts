interface Node {value: number; next?: Node;}
declare const input: Awaited<Node>;
export const value = input;
