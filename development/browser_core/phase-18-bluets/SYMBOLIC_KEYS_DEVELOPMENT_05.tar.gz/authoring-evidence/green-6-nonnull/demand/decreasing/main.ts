type Unwrap<T> = T extends {value: infer V} ? Unwrap<V> : T;
declare const input: Unwrap<{value: {value: number}}>;
export const value = input;
