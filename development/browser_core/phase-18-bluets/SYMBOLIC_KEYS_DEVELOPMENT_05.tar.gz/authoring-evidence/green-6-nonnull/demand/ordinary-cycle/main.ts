interface Recursive {then(cb: (value: Recursive) => void): void;}
type Unwrap<T> = T extends object & {then(cb: infer F, ...args: infer R): any} ? F extends (value: infer V, ...args: infer Q) => any ? Unwrap<V> : never : T;
declare const input: Unwrap<Recursive>;
export const value = input;
