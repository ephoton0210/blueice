type Thenable = ((input: boolean) => void) & {then(onfulfilled: (value: number) => void): void};
declare const input: Awaited<Thenable>;
export const value = input;
