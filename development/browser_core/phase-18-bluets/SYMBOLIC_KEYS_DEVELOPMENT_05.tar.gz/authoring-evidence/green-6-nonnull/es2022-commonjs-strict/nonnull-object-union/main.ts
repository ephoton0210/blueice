declare const input: NonNullable<{code: number} | null | undefined>;
export const value = input;
