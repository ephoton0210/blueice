declare const input: NonNullable<null>;
export const value = input;
