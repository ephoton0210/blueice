type Thenable = {then(onfulfilled: (value: {then(cb: (value: number) => void): void}) => void): void};
declare const input: Awaited<Thenable>;
export const value = input;
