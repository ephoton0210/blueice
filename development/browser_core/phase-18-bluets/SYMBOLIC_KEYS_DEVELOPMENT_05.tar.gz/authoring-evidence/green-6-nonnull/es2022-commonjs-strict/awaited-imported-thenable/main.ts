import type { Thenable } from "./types";
declare const input: Awaited<Thenable>;
export const value = input;
