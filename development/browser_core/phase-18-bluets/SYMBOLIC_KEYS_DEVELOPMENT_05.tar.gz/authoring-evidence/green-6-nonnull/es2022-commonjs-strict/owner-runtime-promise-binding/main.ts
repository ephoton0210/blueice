const Promise = {resolve(value: number) {return value;}};
export const value = Promise.resolve(7);
if (value !== 7) throw 1;
