export const value: NonNullable<string | null> = null;
