export const value = Promise.resolve(7);
