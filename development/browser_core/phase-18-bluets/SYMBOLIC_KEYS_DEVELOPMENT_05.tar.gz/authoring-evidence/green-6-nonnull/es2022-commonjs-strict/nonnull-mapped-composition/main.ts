type RequiredValues<T> = {[K in keyof T]: NonNullable<T[K]>};
declare const input: RequiredValues<{x: string | null; y: number | undefined}>;
export const value = input;
