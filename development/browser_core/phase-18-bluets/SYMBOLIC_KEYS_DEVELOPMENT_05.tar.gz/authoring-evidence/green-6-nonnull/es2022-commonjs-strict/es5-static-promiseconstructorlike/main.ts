export declare const value: PromiseConstructorLike;
