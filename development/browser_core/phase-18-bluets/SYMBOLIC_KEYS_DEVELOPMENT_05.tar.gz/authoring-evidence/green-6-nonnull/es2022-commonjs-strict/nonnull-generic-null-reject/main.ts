function requireValue<T>(input: T): NonNullable<T> { return null; }
export const value = requireValue(1);
