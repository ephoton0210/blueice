declare const input: Awaited<"ok">;
export const value = input;
