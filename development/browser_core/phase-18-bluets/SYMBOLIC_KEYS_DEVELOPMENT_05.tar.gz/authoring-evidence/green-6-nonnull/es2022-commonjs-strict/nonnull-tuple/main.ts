declare const input: NonNullable<[number, string] | null>;
export const value = input;
