type Thenable = {then(onfulfilled: (value: number, second: string) => void, extra: boolean): void};
declare const input: Awaited<Thenable>;
export const value = input;
