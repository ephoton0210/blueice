// 😀
type Thenable = {then(cb: (value: number) => void): void};
export const value: Awaited<Thenable> = "bad";
