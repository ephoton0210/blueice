declare const input: Awaited<unknown>;
export const value = input;
