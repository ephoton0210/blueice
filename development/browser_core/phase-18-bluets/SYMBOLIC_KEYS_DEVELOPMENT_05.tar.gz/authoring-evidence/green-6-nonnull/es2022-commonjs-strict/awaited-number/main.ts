declare const input: Awaited<number>;
export const value = input;
