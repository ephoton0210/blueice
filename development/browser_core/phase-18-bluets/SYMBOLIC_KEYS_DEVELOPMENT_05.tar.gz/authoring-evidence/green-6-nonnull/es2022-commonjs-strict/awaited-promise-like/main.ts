declare const input: Awaited<PromiseLike<number>>;
export const value = input;
