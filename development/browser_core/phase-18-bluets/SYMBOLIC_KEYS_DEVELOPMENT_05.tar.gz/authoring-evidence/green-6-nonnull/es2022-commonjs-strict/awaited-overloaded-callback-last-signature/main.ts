interface Callback {(value: number): void; (value: string): void;}
type Thenable = {then(onfulfilled: Callback): void};
declare const input: Awaited<Thenable>;
export const value = input;
