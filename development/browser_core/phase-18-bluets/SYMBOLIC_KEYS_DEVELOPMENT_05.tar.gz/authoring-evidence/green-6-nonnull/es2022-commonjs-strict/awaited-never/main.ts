declare const input: Awaited<never>;
export const value = input;
