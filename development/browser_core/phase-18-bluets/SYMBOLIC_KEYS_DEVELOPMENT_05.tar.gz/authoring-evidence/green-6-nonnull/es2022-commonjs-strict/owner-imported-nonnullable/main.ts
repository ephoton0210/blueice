import type { NonNullable } from "./types";
export const value: NonNullable<number> = {owned: 7};
