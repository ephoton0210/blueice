export type NonNullable<T> = {owned: T};
