type Thenable = {then(onfulfilled: (value: number) => void): void};
declare function accept(value: Awaited<Thenable>): void;
accept("bad");
export {};
