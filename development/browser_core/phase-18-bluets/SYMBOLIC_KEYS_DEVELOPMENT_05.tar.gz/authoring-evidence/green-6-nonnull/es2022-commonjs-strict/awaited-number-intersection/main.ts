type Thenable = {then(onfulfilled: (value: number) => void): void};
declare const input: Awaited<number & Thenable>;
export const value = input;
