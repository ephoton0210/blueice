interface Recursive {then(onfulfilled: (value: Recursive) => void): void;}
declare const input: Awaited<Recursive>;
export const value = input;
