declare const input: NonNullable<"red" | "blue" | null | undefined>;
export const value = input;
