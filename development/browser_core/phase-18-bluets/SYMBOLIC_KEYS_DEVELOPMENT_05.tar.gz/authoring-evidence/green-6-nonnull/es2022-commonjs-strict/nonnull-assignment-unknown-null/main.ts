export const value: NonNullable<unknown> = null;
