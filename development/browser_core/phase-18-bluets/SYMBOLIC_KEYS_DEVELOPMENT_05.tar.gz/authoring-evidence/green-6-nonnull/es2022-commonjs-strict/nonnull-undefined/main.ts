declare const input: NonNullable<undefined>;
export const value = input;
