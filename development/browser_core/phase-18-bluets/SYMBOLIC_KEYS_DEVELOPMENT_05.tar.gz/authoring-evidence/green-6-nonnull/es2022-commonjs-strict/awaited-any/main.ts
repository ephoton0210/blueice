declare const input: Awaited<any>;
export const value = input;
