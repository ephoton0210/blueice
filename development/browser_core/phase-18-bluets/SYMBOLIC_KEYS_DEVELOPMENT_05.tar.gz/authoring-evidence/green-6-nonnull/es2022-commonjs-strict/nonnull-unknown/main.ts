declare const input: NonNullable<unknown>;
export const value = input;
