declare const input: Awaited<Promise<number>>;
export const value = input;
