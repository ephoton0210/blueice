declare const input: NonNullable<({x: number} & {y: string}) | null>;
export const value = input;
