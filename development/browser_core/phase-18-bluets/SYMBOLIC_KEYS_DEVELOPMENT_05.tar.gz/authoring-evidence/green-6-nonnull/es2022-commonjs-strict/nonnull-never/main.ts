declare const input: NonNullable<never>;
export const value = input;
