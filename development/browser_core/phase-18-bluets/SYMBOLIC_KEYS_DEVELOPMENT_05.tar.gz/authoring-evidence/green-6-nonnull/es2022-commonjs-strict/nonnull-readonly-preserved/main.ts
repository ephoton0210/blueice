declare const value: NonNullable<{readonly x: number} | null>;
value.x = 2;
export { value };
