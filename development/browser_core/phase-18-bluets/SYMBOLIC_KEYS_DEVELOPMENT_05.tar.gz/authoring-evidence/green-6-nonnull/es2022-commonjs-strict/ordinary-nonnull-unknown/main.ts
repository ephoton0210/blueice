type Present<T> = T & {};
declare const input: Present<unknown>;
export const value = input;
