type Unwrap<T> = T extends null | undefined ? T : T extends object & {then(onfulfilled: infer F, ...args: infer Rest): any} ? F extends ((value: infer V, ...args: infer Remaining) => any) ? Unwrap<V> : never : T;
type Thenable = {then(onfulfilled: (value: number) => void): void};
declare const input: Unwrap<Thenable>;
export const value = input;
