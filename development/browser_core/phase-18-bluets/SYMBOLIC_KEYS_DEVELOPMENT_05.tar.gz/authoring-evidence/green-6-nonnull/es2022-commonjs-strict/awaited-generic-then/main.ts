type Thenable = {then<T>(onfulfilled: (value: T) => void): void};
declare const input: Awaited<Thenable>;
export const value = input;
