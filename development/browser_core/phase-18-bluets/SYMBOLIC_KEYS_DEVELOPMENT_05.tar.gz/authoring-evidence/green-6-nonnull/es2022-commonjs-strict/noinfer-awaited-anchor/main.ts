declare function choose<T extends string>(anchor: T, check: NoInfer<Awaited<PromiseLike<T>>>): T;
export const value = choose("red", "red");
