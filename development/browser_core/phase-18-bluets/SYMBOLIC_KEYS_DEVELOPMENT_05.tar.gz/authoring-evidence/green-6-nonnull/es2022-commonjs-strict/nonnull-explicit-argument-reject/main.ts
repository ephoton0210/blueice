declare function requireValue<T>(input: NonNullable<T>): T;
export const value = requireValue<string | null>(7);
