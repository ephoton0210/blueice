declare const input: NonNullable<any>;
export const value = input;
