declare const input: NonNullable<number[] | undefined>;
export const value = input;
