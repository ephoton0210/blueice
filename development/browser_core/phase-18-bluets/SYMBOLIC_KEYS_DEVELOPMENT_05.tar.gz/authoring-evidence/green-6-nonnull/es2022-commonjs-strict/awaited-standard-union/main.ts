declare const input: Awaited<PromiseLike<number> | string | null>;
export const value = input;
