type Fields = NonNullable<{a: number; b: string} | undefined>;
declare const input: keyof Fields;
export const value = input;
