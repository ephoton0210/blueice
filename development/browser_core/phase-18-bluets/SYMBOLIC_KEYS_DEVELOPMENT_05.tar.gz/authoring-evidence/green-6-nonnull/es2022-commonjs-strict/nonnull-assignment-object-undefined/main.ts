export const value: NonNullable<{x: number} | undefined> = undefined;
