type Thenable = {then(onfulfilled: (value: number) => void): void};
type Inner = Thenable; type Outer = Inner;
declare const input: Awaited<Outer>;
export const value = input;
