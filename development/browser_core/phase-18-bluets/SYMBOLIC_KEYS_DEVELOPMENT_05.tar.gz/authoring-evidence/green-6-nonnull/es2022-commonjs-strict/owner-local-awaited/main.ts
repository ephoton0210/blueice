type Awaited<T> = {owned: T};
export const value: Awaited<number> = {owned: 7};
