type Thenable = {then(onfulfilled: (...args: [number, string]) => void): void};
declare const input: Awaited<Thenable>;
export const value = input;
