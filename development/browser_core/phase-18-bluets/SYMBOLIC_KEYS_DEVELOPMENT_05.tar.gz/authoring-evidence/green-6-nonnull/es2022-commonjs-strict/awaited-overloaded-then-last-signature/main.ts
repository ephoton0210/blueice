interface Thenable {then(onfulfilled: (value: number) => void): void; then(onfulfilled: (value: string) => void): void;}
declare const input: Awaited<Thenable>;
export const value = input;
