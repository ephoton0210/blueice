interface First {then(cb: (value: Second) => void): void;}
interface Second {then(cb: (value: First) => void): void;}
declare const input: Awaited<First>;
export const value = input;
