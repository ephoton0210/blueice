declare const input: Awaited<null>;
export const value = input;
