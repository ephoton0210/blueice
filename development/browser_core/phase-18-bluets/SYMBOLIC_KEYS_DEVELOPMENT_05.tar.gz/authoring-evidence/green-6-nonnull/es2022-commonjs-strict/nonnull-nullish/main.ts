declare const input: NonNullable<null | undefined>;
export const value = input;
