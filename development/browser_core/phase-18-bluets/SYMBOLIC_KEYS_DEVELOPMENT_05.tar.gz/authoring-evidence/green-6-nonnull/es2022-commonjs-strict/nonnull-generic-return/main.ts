export declare function requireValue<T>(value: T): NonNullable<T>;
export const value = requireValue("ok");
