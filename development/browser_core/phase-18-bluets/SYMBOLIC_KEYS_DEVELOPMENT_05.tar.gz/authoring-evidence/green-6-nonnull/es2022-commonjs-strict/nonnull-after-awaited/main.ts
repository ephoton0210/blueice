declare const input: NonNullable<Awaited<PromiseLike<number | null>>>;
export const value = input;
