type Present<T> = T & {};
declare const input: Present<string | number | null | undefined>;
export const value = input;
