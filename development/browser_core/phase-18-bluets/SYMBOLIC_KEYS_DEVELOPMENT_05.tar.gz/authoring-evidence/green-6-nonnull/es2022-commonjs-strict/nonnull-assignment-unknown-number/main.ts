export const value: NonNullable<unknown> = 7;
