import type { Awaited } from "./types";
export const value: Awaited<number> = {owned: 7};
