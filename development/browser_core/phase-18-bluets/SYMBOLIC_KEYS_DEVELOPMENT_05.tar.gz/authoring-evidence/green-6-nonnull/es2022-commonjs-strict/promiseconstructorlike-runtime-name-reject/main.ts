export const value = PromiseConstructorLike;
