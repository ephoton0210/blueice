type Present<T> = T & {};
declare const input: Present<null | undefined>;
export const value = input;
