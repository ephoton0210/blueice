export const value: NonNullable<any> = null;
