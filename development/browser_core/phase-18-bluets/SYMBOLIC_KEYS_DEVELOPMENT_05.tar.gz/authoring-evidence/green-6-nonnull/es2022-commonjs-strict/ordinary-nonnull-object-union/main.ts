type Present<T> = T & {};
declare const input: Present<{code: number} | null | undefined>;
export const value = input;
