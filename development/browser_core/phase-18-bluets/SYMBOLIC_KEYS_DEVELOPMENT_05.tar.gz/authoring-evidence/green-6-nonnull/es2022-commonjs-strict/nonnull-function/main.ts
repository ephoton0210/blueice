declare const input: NonNullable<((x: number) => string) | undefined>;
export const value = input;
