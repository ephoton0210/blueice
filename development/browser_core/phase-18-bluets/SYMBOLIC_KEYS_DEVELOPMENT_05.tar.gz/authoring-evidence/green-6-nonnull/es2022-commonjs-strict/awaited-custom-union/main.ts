type Thenable = {then(onfulfilled: (value: number) => void): void};
declare const input: Awaited<Thenable | string>;
export const value = input;
