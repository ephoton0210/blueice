declare const input: Awaited<Promise<PromiseLike<number>>>;
export const value = input;
