type Thenable = {then?: (onfulfilled: (value: number) => void) => void};
declare const input: Awaited<Thenable>;
export const value = input;
