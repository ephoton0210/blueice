declare const input: Awaited<[PromiseLike<number>, string]>;
export const value = input;
