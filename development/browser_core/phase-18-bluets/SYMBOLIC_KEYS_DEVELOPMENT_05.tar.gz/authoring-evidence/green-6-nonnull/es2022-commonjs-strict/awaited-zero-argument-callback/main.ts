type Thenable = {then(onfulfilled: () => void): void};
declare const input: Awaited<Thenable>;
export const value = input;
