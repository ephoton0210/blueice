interface Box<T> {then(onfulfilled: (value: T) => void): void;}
declare const input: Awaited<Box<number>>;
export const value = input;
