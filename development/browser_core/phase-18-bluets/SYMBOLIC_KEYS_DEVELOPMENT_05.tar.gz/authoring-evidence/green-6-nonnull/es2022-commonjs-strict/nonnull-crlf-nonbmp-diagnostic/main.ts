// 😀
export const value: NonNullable<string | null> = 7;
