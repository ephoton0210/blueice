type Thenable = {then(onfulfilled: number): void};
declare const input: Awaited<Thenable>;
export const value = input;
