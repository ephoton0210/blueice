type Present<T> = T extends unknown ? NonNullable<T> : never;
declare const input: Present<string | number | null>;
export const value = input;
