export const value = new Promise<number>((resolve) => resolve(7));
