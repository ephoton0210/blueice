declare const input: Awaited<null | undefined>;
export const value = input;
