declare const input: NonNullable<string | number | null | undefined>;
export const value = input;
