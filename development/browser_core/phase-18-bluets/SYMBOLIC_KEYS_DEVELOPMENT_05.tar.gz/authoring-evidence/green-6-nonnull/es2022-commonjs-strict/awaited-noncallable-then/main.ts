type Thenable = {then: number};
declare const input: Awaited<Thenable>;
export const value = input;
