type NonNullable<T> = {owned: T};
export const value: NonNullable<number> = {owned: 7};
