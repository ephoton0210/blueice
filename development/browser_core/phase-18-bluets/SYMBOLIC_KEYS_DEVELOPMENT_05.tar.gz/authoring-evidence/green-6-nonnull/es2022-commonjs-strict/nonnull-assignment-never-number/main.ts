export const value: NonNullable<never> = 7;
