import type { Payload } from "./types";
declare const input: NonNullable<Payload | null>;
export const value = input;
