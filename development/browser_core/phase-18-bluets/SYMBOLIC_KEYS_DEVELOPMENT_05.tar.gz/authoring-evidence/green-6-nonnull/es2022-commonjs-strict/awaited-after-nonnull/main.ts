declare const input: Awaited<NonNullable<PromiseLike<number> | null>>;
export const value = input;
