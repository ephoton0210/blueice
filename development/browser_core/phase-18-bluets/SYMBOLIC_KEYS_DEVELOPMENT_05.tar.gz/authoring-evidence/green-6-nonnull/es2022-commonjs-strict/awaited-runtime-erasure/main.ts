export function identity(value: number): Awaited<number> {return value;}
export const value = identity(7);
if (value !== 7) throw 1;
