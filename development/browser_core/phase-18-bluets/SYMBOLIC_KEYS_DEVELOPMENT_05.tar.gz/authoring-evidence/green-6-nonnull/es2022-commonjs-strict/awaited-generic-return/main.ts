export declare function unwrap<T>(value: T): Awaited<T>;
declare const input: PromiseLike<number>;
export const value = unwrap(input);
