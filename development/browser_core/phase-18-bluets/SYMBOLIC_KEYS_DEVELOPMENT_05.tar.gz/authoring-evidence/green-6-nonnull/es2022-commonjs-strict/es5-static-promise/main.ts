export declare const value: Promise<number>;
