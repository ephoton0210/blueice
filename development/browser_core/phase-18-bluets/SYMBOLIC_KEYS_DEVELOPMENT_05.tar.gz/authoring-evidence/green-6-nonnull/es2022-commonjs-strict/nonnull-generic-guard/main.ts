export function requireValue<T>(input: T): NonNullable<T> {
 if (input == null) throw 0;
 return input;
}
export const value = requireValue("ok");
