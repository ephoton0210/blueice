type Thenable = {then(onfulfilled: (value: number) => void): void};
declare const input: Awaited<string & Thenable>;
export const value = input;
