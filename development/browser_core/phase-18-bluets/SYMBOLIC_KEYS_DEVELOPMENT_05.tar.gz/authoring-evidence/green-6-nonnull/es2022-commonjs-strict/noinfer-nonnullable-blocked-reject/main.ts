declare function choose<T extends string>(anchor: T, check: NoInfer<NonNullable<T | null>>): T;
export const value = choose("red", "blue");
