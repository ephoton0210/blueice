declare const input: Awaited<undefined>;
export const value = input;
