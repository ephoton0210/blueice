declare function consume<T>(callback: <U>(value: U) => T): T;
declare function value<U>(input: U): string;
export const result = consume(value);
