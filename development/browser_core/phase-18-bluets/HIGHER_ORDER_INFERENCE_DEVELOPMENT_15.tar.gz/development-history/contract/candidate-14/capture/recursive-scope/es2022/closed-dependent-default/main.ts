type Merger = <T extends object, K extends keyof T = keyof T>(object: T, key: keyof T, value: T[K]) => any;
export function recur<T>(base: T, defaults: any, merger?: Merger): T {
 const result = Object.assign({}, defaults);
 for (const key in base) { const value: unknown = base[key]; result[key] = recur(value, result[key], merger); }
 return result;
}
