declare function consume<T>(value: T, callback: <U>(input: U) => T): T;
declare function numeric<U>(input: U): number;
export const result = consume("s", numeric);
