declare function box<T>(value:T): (value:T)=>T;
export const result: string = -box("s")("t");
