export type Merger = <T extends object, K extends keyof T>(object: T, key: keyof T, value: T[K]) => any;
