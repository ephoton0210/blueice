type Merger = <Item extends object, K extends keyof Item>(object: Item, key: keyof Item, value: Item[K]) => any;
export function recur<T>(base: T, defaults: any, merger?: Merger): T {
 const result = Object.assign({}, defaults);
 for (const key in base) { const value: unknown = base[key]; result[key] = recur(value, result[key], merger); }
 return result;
}
