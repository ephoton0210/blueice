declare function box<T>(value:T): (value:T)=>T;
export const result: number = -box("s")(1);
