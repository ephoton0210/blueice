declare function box<T>(value:T): (value:T)=>T;
export const result: boolean = !box("s")("t");
