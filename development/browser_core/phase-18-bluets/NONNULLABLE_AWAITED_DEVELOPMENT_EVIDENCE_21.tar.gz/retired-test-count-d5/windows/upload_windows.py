# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import base64,datetime,hashlib,importlib.util,json
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qga_transfer',root.parent.parent/'noinfer-acceptance-20261112/recovery/qga_transfer.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
package=json.loads((root/'package.json').read_text())
base='B:\\BlueIce\\gm3-20261109-360d7d921'
state={'sourceRevision':package['sourceRevision'],'stage':'uploading','files':[],'conclusion':'in_progress'}
def save():
 state['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (root/'upload.json').write_text(json.dumps(state,indent=2)+'\n')
def upload(name,remote):
 local=root/name
 receipt={'local':name,'remote':remote,'bytes':local.stat().st_size,'sha256':hashlib.sha256(local.read_bytes()).hexdigest(),'written':0}
 state['files'].append(receipt);save()
 handle=api.call({'execute':'guest-file-open','arguments':{'path':remote,'mode':'wb'}})
 try:
  with local.open('rb') as stream:
   while True:
    chunk=stream.read(65536)
    if not chunk:break
    result=api.call({'execute':'guest-file-write','arguments':{'handle':handle,'buf-b64':base64.b64encode(chunk).decode(),'count':len(chunk)}})
    assert result['count']==len(chunk),result
    receipt['written']+=len(chunk)
    if receipt['written']%(4*1024*1024)==0:
     save();print(json.dumps({'file':name,'written':receipt['written'],'total':receipt['bytes']}),flush=True)
 finally:api.call({'execute':'guest-file-close','arguments':{'handle':handle}})
 assert receipt['written']==receipt['bytes'];receipt['complete']=True;save()
try:
 save()
 for name,remote in [('source-patch.tar.gz','p0b-source-patch.tar.gz'),('windows-source-manifest.json','p0b-source-manifest.json'),('windows-runner.cjs','p0b-windows-runner.cjs'),('apply-source.py','p0b-apply-source.py')]:upload(name,base+'\\'+remote)
 state['stage']='starting-verified-source-replay';save()
 code=(root/'start-windows.ps1').read_text();encoded=base64.b64encode(code.encode('utf-16le')).decode()
 process=api.call({'execute':'guest-exec','arguments':{'path':'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','arg':['-NoLogo','-NonInteractive','-EncodedCommand',encoded],'capture-output':True}})
 (root/'bootstrap-process.json').write_text(json.dumps(process,indent=2)+'\n')
 state.update(stage='guest-source-replay-started',guestBootstrapPid=process['pid'],conclusion='uploaded-launch-requested');save();print(json.dumps({'stage':state['stage'],'guestBootstrapPid':process['pid'],'sourceRevision':state['sourceRevision']}),flush=True)
except BaseException as error:
 state.update(conclusion='failure',error=repr(error));save();raise
