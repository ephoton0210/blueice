$ErrorActionPreference = 'Stop'
$base = 'B:\BlueIce\gm3-20261109-360d7d921'
if (@(Get-Process cargo,rustc -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Another VM build is active; source replay refused.' }
& 'C:\Program Files\Python312\python.exe' (Join-Path $base 'p0b-apply-source.py')
if ($LASTEXITCODE -ne 0) { throw 'Frozen source replay failed.' }
$runner = Join-Path $base 'p0b-windows-runner.cjs'
$job = Start-Process -FilePath 'C:\Program Files\nodejs\node.exe' -ArgumentList $runner -WorkingDirectory $base -RedirectStandardOutput (Join-Path $base 'p0b-runner.stdout') -RedirectStandardError (Join-Path $base 'p0b-runner.stderr') -PassThru
$receipt = @{marker='bluets-p0b-windows-v1';sourceRevision='backend-tree:d5f5f555ab5968685c4a3fbff1fd0cc797d6c49e';pid=[int]$job.Id;startedAt=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
[System.IO.File]::WriteAllText((Join-Path $base 'p0b-launch.json'), $receipt)
Write-Output $receipt
