# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Preserve the unchanged discovery and independently check every archive member."""
from pathlib import Path
import datetime
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
phase = repo / 'development/browser_core/phase-18-bluets'
archive = phase / 'HIGHER_ORDER_INFERENCE_DISCOVERY_EVIDENCE.tar.gz'
members_path = phase / 'HIGHER_ORDER_INFERENCE_DISCOVERY_MEMBERS.json'
measurement_path = phase / 'HIGHER_ORDER_INFERENCE_DISCOVERY.json'
assert not any(path.exists() for path in [archive, members_path, measurement_path])
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
audit = read(root / 'declaration-audit.json')
assert audit['conclusion'] == 'independently-audited-discovery'
assert audit['comparisons'] == 24 and audit['completeDifferences'] == 20
assert audit['completeAgreements'] == 4 and audit['inventoryCredit'] == 0
assert not audit['verdictCalibrationQuestions']
entries = []
files = sorted(path for path in root.rglob('*') if path.is_file())
with tarfile.open(archive, 'w:gz', compresslevel=6) as output:
    for path in files:
        assert not path.is_symlink()
        name = path.relative_to(root).as_posix()
        data = path.read_bytes()
        entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
        output.add(path, arcname=name, recursive=False)
assert archive.stat().st_size < 95 * 1024 * 1024
expected = {entry['path']: entry for entry in entries}
seen = set()
with tarfile.open(archive, 'r:gz') as source:
    for member in source:
        assert member.isfile() and member.name in expected and member.name not in seen
        data = source.extractfile(member).read()
        assert member.size == len(data) == expected[member.name]['bytes']
        assert sha(data) == expected[member.name]['sha256']
        seen.add(member.name)
assert seen == set(expected)
members = {'schema': 1, 'sourceRevision': audit['sourceRevision'], 'archive': archive.name,
           'entries': entries, 'conclusion': 'independently-verified'}
members_path.write_text(json.dumps(members, indent=2) + '\n')
measurement = dict(audit)
measurement.update(
    evidence={'path': archive.name, 'bytes': archive.stat().st_size,
              'sha256': sha(archive.read_bytes()), 'members': len(entries)},
    memberManifest={'path': members_path.name, 'sha256': sha(members_path.read_bytes())},
    acceptedBaselineEvidence={'measurement': 'CONDITIONAL_INFERENCE_MEASUREMENT.json',
        'measurementSha256': sha((phase / 'CONDITIONAL_INFERENCE_MEASUREMENT.json').read_bytes()),
        'artifactIndex': 'CONDITIONAL_INFERENCE_ARTIFACTS.json',
        'artifactIndexSha256': sha((phase / 'CONDITIONAL_INFERENCE_ARTIFACTS.json').read_bytes()),
        'scope': 'Accepted P0-F source and complete pinned oracle packages with their original licenses.'},
    publicationRecordedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
measurement_path.write_text(json.dumps(measurement, indent=2) + '\n')
print(json.dumps({'discovery': measurement_path.name, 'archive': archive.name,
                  'members': len(entries), 'bytes': archive.stat().st_size,
                  'sha256': sha(archive.read_bytes()), 'inventoryCredit': 0}))
