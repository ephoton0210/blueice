// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const {isDeepStrictEqual} = require('node:util');
const {execFileSync} = require('node:child_process');
const root = __dirname, repo = path.resolve(root, '../..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file));
const raw = read(path.join(root, 'measurement.json'));
const input = read(path.join(root, 'inputs.json'));
const {inventory} = require(path.join(repo, 'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const destination = path.join(root, 'declaration-audit.json');
assert(!fs.existsSync(destination), 'Preserve the original independent audit');
assert.equal(raw.conclusion, 'discovery-complete');
assert.equal(sha(fs.readFileSync(path.join(root, 'inputs.json'))), raw.inputSha256);
assert.equal(sha(fs.readFileSync(path.join(root, 'discover.cjs'))), raw.scriptSha256);
assert.equal(sha(fs.readFileSync(path.join(root, 'baseline-cli'))), raw.compilerSha256);
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], {cwd:repo, encoding:'utf8'}).trim(), raw.parentCommit);
assert.equal(execFileSync('git', ['status', '--porcelain=v1'], {cwd:repo, encoding:'utf8'}), '');
assert.equal(raw.cases.length, input.cases.length);
const cases = [];
for (const original of raw.cases) {
    const entry = input.cases.find(entry => entry.id === original.id);
    assert(entry);
    const row = {id:entry.id, expectedNativeAccepts:entry.expectedNativeAccepts};
    for (const kind of ['native','blue']) {
        const cwd = path.join(root, kind, entry.id);
        for (const [name, text] of Object.entries({'main.ts':entry.source, ...entry.files}))
            assert.equal(fs.readFileSync(path.join(cwd,name),'utf8'), text);
        const observation = read(path.join(cwd,'observation.json'));
        assert.deepEqual(observation, original[kind]);
        const outputs = inventory(path.join(cwd,'dist'));
        // The initial recorder incorrectly named the complete build inventory
        // "declarations". Retain that record; independently select actual .d.ts
        // files without changing their source, bytes or any diagnostic.
        assert.deepEqual(outputs, observation.declarations);
        const declarations = Object.fromEntries(Object.entries(outputs).filter(([name]) => /\.d\.(ts|mts|cts)$/.test(name)));
        const buildOnlyProducts = Object.keys(outputs).filter(name => !Object.hasOwn(declarations,name));
        row[kind] = {accepts:observation.accepts,diagnostics:observation.diagnostics,declarations};
        row[kind+'BuildOnlyProducts'] = buildOnlyProducts;
    }
    row.agrees = isDeepStrictEqual(row.native,row.blue);
    row.authoredVerdictAgrees = row.native.accepts === entry.expectedNativeAccepts;
    row.classification = row.agrees ? 'complete-agreement' :
        row.native.accepts && !row.blue.accepts ? 'incorrect-rejection' :
        !row.native.accepts && row.blue.accepts ? 'incorrect-acceptance' :
        row.native.accepts ? 'exact-declaration-difference' : 'complete-diagnostic-difference';
    cases.push(row);
}
const classifications = Object.fromEntries([...new Set(cases.map(row=>row.classification))].map(label=>[label,cases.filter(row=>row.classification===label).length]));
const data = {schema:1,parentCommit:raw.parentCommit,sourceRevision:raw.sourceRevision,compilerSha256:raw.compilerSha256,
    typescript:raw.typescript,implementationSha256:raw.implementationSha256,libraries:raw.libraries,
    inputSha256:raw.inputSha256,rawMeasurementSha256:sha(fs.readFileSync(path.join(root,'measurement.json'))),
    auditScriptSha256:sha(fs.readFileSync(__filename)),
    originalRecorderIssue:'The raw declarations property included build manifest/JavaScript outputs; those are retained and excluded only from the declaration-language comparison.',
    comparisonScope:'Complete verdict, primary/related diagnostics and UTF-16 positions, and physical declaration inventory/bytes; build-only products retained separately. No declaration normalization.',
    sourceStringsUnchanged:true,rawObservationsUnchanged:true,inventoryCredit:0,comparisons:cases.length,
    completeAgreements:cases.filter(row=>row.agrees).length,completeDifferences:cases.filter(row=>!row.agrees).length,
    classifications,verdictCalibrationQuestions:cases.filter(row=>!row.authoredVerdictAgrees).map(row=>row.id),cases,
    conclusion:'independently-audited-discovery',recordedAt:new Date().toISOString()};
assert.deepEqual(data.verdictCalibrationQuestions,[]);
fs.writeFileSync(destination,JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify({comparisons:data.comparisons,completeAgreements:data.completeAgreements,completeDifferences:data.completeDifferences,classifications,sourceStringsUnchanged:true,rawObservationsUnchanged:true}));
