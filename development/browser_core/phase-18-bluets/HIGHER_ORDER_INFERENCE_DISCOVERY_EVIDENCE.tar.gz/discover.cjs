// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const fs = require('node:fs');
const path = require('node:path');
const {spawnSync, execFileSync} = require('node:child_process');
const {isDeepStrictEqual} = require('node:util');
const root = __dirname;
const repo = path.resolve(root, '../..');
const phase = path.join(repo, 'development/browser_core/phase-18-bluets');
process.env.BLUEICE_BLUETSC_ORACLE = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc');
process.env.BLUEICE_ACORN_ORACLE = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn');
const c = require(path.join(phase, 'tools/conditional_inference/common.cjs'));
const {writeSources} = require(path.join(phase, 'tools/string_intrinsics/files.cjs'));
const {assert, sha} = c;
assert(!fs.existsSync(path.join(root, 'measurement.json')), 'Preserve every discovery attempt; use a new directory for a new run');
assert.equal(execFileSync('git', ['status', '--porcelain=v1'], {cwd:repo, encoding:'utf8'}), '');
const commit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd:repo, encoding:'utf8'}).trim();
assert.equal(commit, '87d53ef80beb76c77dd804b9c14f3ed2dbb8a4c5');
const accepted = JSON.parse(fs.readFileSync(path.join(phase, 'CONDITIONAL_INFERENCE_MEASUREMENT.json')));
const compiler = path.join(root, 'baseline-cli');
fs.copyFileSync(path.join(repo, 'target/conditional-inference-acceptance-20261114-r3/accepted-workspace-cli'), compiler);
fs.chmodSync(compiler, 0o755);
assert.equal(sha(fs.readFileSync(compiler)), accepted.gates.workspaceCompilerSha256);
const compose = 'declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;\n';
const identity = 'function identity<T>(value: T): T { return value; }\n';
const list = 'function list<T>(value: T): T[] { return [value]; }\n';
const box = 'function box<T>(value: T): { value: T } { return { value }; }\n';
const lift = 'declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];\n';
const cases = [];
function add(id, source, expectedNativeAccepts = true, files = {}) {
    cases.push({id, source, files, expectedNativeAccepts});
}
add('compose-array-box', compose + list + box + 'export const result = compose(list, box);\n');
add('compose-array-box-call', compose + list + box + 'export const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n');
add('compose-array-box-reject', compose + list + box + 'export const result = compose(list, box);\nexport const demanded: { value: number[] } = result("text");\n', false);
add('compose-arrow-generics', compose + 'const first = <T>(value: T): T[] => [value];\nconst second = <U>(value: U): { value: U } => ({ value });\nexport const result = compose(first, second);\n');
add('compose-three-stages', 'declare function compose3<A, B, C, D>(one: (value: A) => B, two: (value: B) => C, three: (value: C) => D): (value: A) => D;\n' + list + box + 'export const result = compose3(list, box, list);\nexport const demanded: { value: string[] }[] = result("text");\n');
add('compose-constrained-first', compose + 'function tagged<T extends { tag: string }>(value: T): T[] { return [value]; }\n' + box + 'export const result = compose(tagged, box);\nexport const demanded: { value: { tag: string; extra: number }[] } = result({ tag: "ok", extra: 1 });\n');
add('compose-concrete-first', compose + list + 'function text(value: number): string { return value.toString(); }\nexport const result = compose(text, list);\nexport const demanded: string[] = result(1);\n');
add('compose-concrete-second', compose + list + 'function size(value: unknown[]): number { return value.length; }\nexport const result = compose(list, size);\nexport const demanded: number = result("text");\n');
add('lift-generic-identity', lift + identity + 'export const result = lift(identity);\n');
add('lift-generic-identity-call', lift + identity + 'export const result = lift(identity);\nexport const demanded: string[] = result("text");\n');
add('lift-generic-identity-reject', lift + identity + 'export const result = lift(identity);\nexport const demanded: number[] = result("text");\n', false);
add('lift-contextual-result', lift + identity + 'export const result: (value: number) => number[] = lift(identity);\n');
add('preserve-generic-function-control', 'declare function preserve<F>(fn: F): F;\n' + identity + 'export const result = preserve(identity);\nexport const demanded: number = result(1);\n');
add('outer-parameter-shadowing', compose + list + box + 'export function outer<T>(value: T) { return compose(list, box); }\nexport const demanded: { value: number[] } = outer("outer")(1);\n');
add('imported-first', compose + box + 'import { list } from "./first";\nexport const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n', true, {'first.ts':'export ' + list});
add('imported-second', compose + list + 'import { box } from "./second";\nexport const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n', true, {'second.ts':'export ' + box});
add('imported-all', 'import { compose } from "./higher";\nimport { list, box } from "./factories";\nexport const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n', true, {'higher.ts':'export ' + compose, 'factories.ts':'export ' + list + 'export ' + box});
add('reexported-generics', compose + 'import { list, box } from "./bridge";\nexport const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n', true, {'factories.ts':'export ' + list + 'export ' + box, 'bridge.ts':'export { list, box } from "./factories";\n'});
add('annotated-generic-callable', compose + box + 'const list: <Element>(value: Element) => Element[] = value => [value];\nexport const result = compose(list, box);\nexport const demanded: { value: string[] } = result("text");\n');
add('object-result-no-propagation-control', 'declare function container<A, B>(fn: (value: A) => B): { run: (value: A) => B };\n' + identity + 'export const result = container(identity);\n');
add('object-result-rejection-control', 'declare function container<A, B>(fn: (value: A) => B): { run: (value: A) => B };\n' + identity + 'export const result = container(identity);\nexport const demanded: string = result.run("text");\n', false);
add('overloaded-result-control', 'declare function overloaded<A, B>(fn: (value: A) => B): { (value: A): B; (): B | undefined };\n' + identity + 'export const result = overloaded(identity);\n');
add('generic-constructor-factory', 'declare function factory<A, R>(ctor: new (value: A) => R): (value: A) => R;\nclass Box<T> { value: T; constructor(value: T) { this.value = value; } }\nexport const result = factory(Box);\nexport const demanded: Box<string> = result("text");\n');
add('propagated-default-parameter', compose + 'function identity<T = string>(value: T): T { return value; }\n' + list + 'export const result = compose(identity, list);\nexport const demanded: number[] = result(1);\n');
assert.equal(cases.length, 24);
assert.equal(new Set(cases.map(row => row.id)).size, 24);
const options = {target:'ES2022',module:'CommonJS',strict:true,declaration:true,emitDeclarationOnly:true,noEmitOnError:true,lib:['ES5'],types:[],outDir:'dist'};
const input = {schema:1, purpose:'Higher-order generic inference discovery; zero compatibility-inventory credit', options, cases};
fs.writeFileSync(path.join(root,'inputs.json'),JSON.stringify(input,null,2)+'\n');
const ctx = c.context();
const state = {schema:1, parentCommit:commit, sourceRevision:accepted.source.sourceRevision, compilerSha256:sha(fs.readFileSync(compiler)),
    typescript:ctx.ts.version, implementationSha256:sha(fs.readFileSync(ctx.implementation)),
    inputSha256:sha(fs.readFileSync(path.join(root,'inputs.json'))), scriptSha256:sha(fs.readFileSync(__filename)),
    startedAt:new Date().toISOString(), conclusion:'in_progress', cases:[], libraries:{}, inventoryCredit:0};
const save=()=>fs.writeFileSync(path.join(root,'measurement.json'),JSON.stringify(state,null,2)+'\n');
try {
    save();
    for(const entry of cases) {
        const pair={id:entry.id,expectedNativeAccepts:entry.expectedNativeAccepts};
        for(const kind of ['native','blue']) {
            const cwd=path.join(root,kind,entry.id);fs.mkdirSync(cwd,{recursive:true});writeSources(cwd,entry);
            const config={compilerOptions:options,files:['main.ts',...Object.keys(entry.files)]};fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify(config,null,2)+'\n');
            let observation;
            if(kind==='native') {
                const result=c.nativeProject(ctx,cwd,config);Object.assign(state.libraries,result.libraries);
                observation={accepts:result.diagnostics.length===0,diagnostics:result.diagnostics,declarations:result.outputs};
            } else {
                const result=spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});
                fs.writeFileSync(path.join(cwd,'build.stdout'),result.stdout||'');fs.writeFileSync(path.join(cwd,'build.stderr'),result.stderr||'');if(result.error)throw result.error;
                observation={accepts:result.status===0,diagnostics:(result.stderr||'').split(/\r?\n/).filter(Boolean).map(line=>c.blueDiagnostic(JSON.parse(line))),declarations:c.inventory(path.join(cwd,'dist'))};
            }
            fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(observation,null,2)+'\n');pair[kind]=observation;
        }
        pair.agrees=isDeepStrictEqual(pair.native,pair.blue);pair.authoredVerdictAgrees=pair.native.accepts===entry.expectedNativeAccepts;
        state.cases.push(pair);save();console.log(entry.id,pair.agrees?'agreement':'DIFFERENCE',pair.native.accepts,pair.blue.accepts);
    }
    assert.equal(sha(fs.readFileSync(compiler)),state.compilerSha256);
    state.comparisons=state.cases.length;state.completeAgreements=state.cases.filter(row=>row.agrees).length;state.completeDifferences=state.cases.filter(row=>!row.agrees).length;
    state.verdictCalibrationQuestions=state.cases.filter(row=>!row.authoredVerdictAgrees).map(row=>row.id);
    state.conclusion=state.verdictCalibrationQuestions.length?'discovery-complete-with-calibration-questions':'discovery-complete';state.finishedAt=new Date().toISOString();save();
    console.log(JSON.stringify({conclusion:state.conclusion,comparisons:state.comparisons,completeAgreements:state.completeAgreements,completeDifferences:state.completeDifferences,verdictCalibrationQuestions:state.verdictCalibrationQuestions}));
} catch(error) { state.conclusion='failure';state.error=String(error.stack||error);save();throw error; }
