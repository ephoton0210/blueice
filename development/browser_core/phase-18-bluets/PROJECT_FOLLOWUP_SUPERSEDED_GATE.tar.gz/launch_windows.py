from pathlib import Path
import datetime,hashlib,json,subprocess,sys,tarfile,time
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-project-gates-20261109');previous=Path('/private/tmp/bluets-gt1-gc1-gm2-20261109');baseline=Path('/private/tmp/bluets-maintenance-20261109');helper='/private/tmp/gm3_qga.py';guest=r'B:\BlueIce\gm3-20261109-360d7d921';state={'stage':'waiting-for-previous-windows-archive'}
def save():
 state['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(root/'windows-launch.json').write_text(json.dumps(state,indent=2)+'\n')
def call(*args):return subprocess.check_output([sys.executable,helper,*args])
try:
 save()
 while True:
  p=previous/'windows-watch.json'
  if p.exists():
   old=json.loads(p.read_bytes())
   if old.get('conclusion')=='failure':raise RuntimeError('Previous Windows run failed: '+str(old))
   if old.get('stage')=='windows-complete':break
  time.sleep(15)
 frozen=json.loads((root/'frozen-source.json').read_bytes());changes=subprocess.check_output(['git','diff','--name-only','HEAD','--','backend','development/browser_core/phase-18-bluets/tools/record_gc1_object_generic_methods.cjs','development/browser_core/phase-18-bluets/tools/record_gm2_incremental_options.cjs'],cwd=repo,text=True).splitlines();
 with tarfile.open(previous/'source-patch.tar.gz') as old_patch:changes=sorted(set(changes)|set(old_patch.getnames()))
 patch=root/'source-patch.tar.gz'
 with tarfile.open(patch,'w:gz') as archive:
  for name in changes:archive.add(repo/name,arcname=name,recursive=False)
 patchhash=hashlib.sha256(patch.read_bytes()).hexdigest();manifest=json.loads((baseline/'windows-source-manifest.json').read_bytes());manifest['files'].update({name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in changes});manifest.update(sourceRevision=frozen['sourceRevision'],followupPatchSha256=patchhash,scope='Complete source manifest plus the fixed follow-up backend and recorder patch; compiler source is the immutable recorded backend tree.');(root/'windows-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 prior=json.loads((previous/'windows-source-manifest.json').read_bytes());s=(previous/'windows-runner.cjs').read_text().replace('results-followups-v6','results-followups-v7').replace(prior['sourceRevision'],frozen['sourceRevision']).replace(prior['followupPatchSha256'],patchhash);(root/'windows-runner.cjs').write_text(s)
 s=(previous/'start-windows.ps1').read_text().replace(prior['followupPatchSha256'],patchhash);(root/'start-windows.ps1').write_text(s)
 s=(previous/'watch_windows.py').read_text().replace(str(previous),str(root)).replace('results-followups-v6','results-followups-v7').replace('followup-evidence-v6.tar.gz','followup-evidence-v7.tar.gz');(root/'watch_windows.py').write_text(s)
 state.update(stage='uploading-source',sourceRevision=frozen['sourceRevision'],patchSha256=patchhash,verifiedFiles=len(manifest['files']));save()
 for local,remote in [('source-patch.tar.gz','followup-patch.tar.gz'),('windows-source-manifest.json','followup-source-manifest.json'),('windows-runner.cjs','followup-runner.cjs')]:call('write',str(root/local),guest+'\\'+remote)
 (root/'windows-process.json').write_bytes(call('start',str(root/'start-windows.ps1')));state.update(stage='windows-started');save()
 subprocess.run([sys.executable,str(root/'watch_windows.py')],check=True)
 state.update(stage='complete',conclusion='success');save()
except BaseException as error:
 state.update(conclusion='failure',error=repr(error));save();raise
