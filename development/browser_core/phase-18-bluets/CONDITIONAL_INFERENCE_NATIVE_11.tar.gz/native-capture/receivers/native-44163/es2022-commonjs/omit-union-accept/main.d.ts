export declare const inferred: ((value: number) => number) | ((value: string) => string);
