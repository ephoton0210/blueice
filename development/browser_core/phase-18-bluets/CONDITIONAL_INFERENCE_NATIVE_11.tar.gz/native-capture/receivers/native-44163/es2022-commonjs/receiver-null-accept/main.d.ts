export declare const inferred: null;
