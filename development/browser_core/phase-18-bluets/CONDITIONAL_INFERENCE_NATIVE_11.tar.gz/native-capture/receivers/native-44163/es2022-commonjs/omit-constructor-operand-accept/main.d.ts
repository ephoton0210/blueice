declare class Source {
    value: number;
    constructor(value: number);
}
export declare const inferred: typeof Source;
export {};
