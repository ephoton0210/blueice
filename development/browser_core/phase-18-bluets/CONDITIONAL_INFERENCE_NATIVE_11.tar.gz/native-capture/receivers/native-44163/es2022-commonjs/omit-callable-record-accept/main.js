"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function keep(value) { return value; }
function produced(value) { return "value:" + value; }
exports.inferred = keep(produced);
