interface Source { (this: { old: number }, first: string): number; (this: { tag: string }, value: number): string; }
function keep<T>(value: T): T { return value; }
function produced(value: number): string { return "value:" + value; }
export const inferred = keep<OmitThisParameter<Source>>(produced);
