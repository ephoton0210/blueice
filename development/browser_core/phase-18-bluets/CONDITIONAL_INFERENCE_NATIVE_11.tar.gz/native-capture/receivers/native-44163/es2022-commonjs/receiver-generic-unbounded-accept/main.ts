function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<<T>(this: T, value: T) => T>>(1);
