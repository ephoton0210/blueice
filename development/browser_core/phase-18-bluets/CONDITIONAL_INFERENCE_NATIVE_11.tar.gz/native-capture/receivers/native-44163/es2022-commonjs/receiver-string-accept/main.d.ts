export declare const inferred: string;
