"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function original(value) { return this.tag + ":" + value; }
function keep(value) { return value; }
exports.inferred = keep({ tag: "ok" });
console.log(original.call(exports.inferred, 3));
