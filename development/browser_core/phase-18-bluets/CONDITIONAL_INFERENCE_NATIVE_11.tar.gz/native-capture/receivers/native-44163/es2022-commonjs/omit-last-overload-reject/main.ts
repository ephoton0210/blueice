interface Source { (this: { old: number }, first: string): number; (this: { tag: string }, value: number): string; }
function keep<T>(value: T): T { return value; }
function produced(value: string): number { return 1; }
export const inferred = keep<OmitThisParameter<Source>>(produced);
