export declare const inferred: (value: string) => string;
