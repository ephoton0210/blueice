export declare function inferred(value: OmitThisParameter<never>): never;
