type Receiver<T> = T extends (this: infer R, ...args: never) => any ? R : unknown;
type WithoutReceiver<T> = unknown extends Receiver<T> ? T : T extends (...args: infer A) => infer R ? (...args: A) => R : T;
function keep<T>(value: T): T { return value; }
function produced(value: string): number { return 1; }
export const inferred = keep<WithoutReceiver<(this: { tag: string }, value: number) => string>>(produced);
