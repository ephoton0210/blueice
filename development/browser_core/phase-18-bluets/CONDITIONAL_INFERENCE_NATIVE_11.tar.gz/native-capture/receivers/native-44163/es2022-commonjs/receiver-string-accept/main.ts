function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<(this: string, value: number) => void>>("ok");
