function keep<T>(value: T): T { return value; }
export const inferred = keep<OmitThisParameter<{ tag: string }>>({ tag: "ok" });
