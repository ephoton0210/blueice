"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
class Source {
    value;
    constructor(value) {
        this.value = value;
    }
}
function keep(value) { return value; }
exports.inferred = keep(Source);
