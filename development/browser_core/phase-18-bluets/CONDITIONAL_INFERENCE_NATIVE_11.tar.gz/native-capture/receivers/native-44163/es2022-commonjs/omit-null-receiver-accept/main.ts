function keep<T>(value: T): T { return value; }
function produced(value: number): string { return "value:" + value; }
export const inferred = keep<OmitThisParameter<(this: null, value: number) => string>>(produced);
