function keep<T>(value: T): T { return value; }
export const inferred: string = keep<OmitThisParameter<unknown>>(1);
