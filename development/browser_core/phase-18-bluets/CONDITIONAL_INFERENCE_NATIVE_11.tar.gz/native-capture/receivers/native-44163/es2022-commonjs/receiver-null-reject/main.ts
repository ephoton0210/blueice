function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<(this: null, value: number) => string>>(1);
