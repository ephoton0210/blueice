declare const console: { log(value: string): void };
function original(this: { tag: string }, value: number): string { return this.tag + ":" + value; }
function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<typeof original>>({ tag: "ok" });
console.log(original.call(inferred, 3));
