"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function keep(value) { return value; }
function produced(value, ...tail) { return "ok"; }
exports.inferred = keep(produced);
