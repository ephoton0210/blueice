function keep<T>(value: T): T { return value; }
function produced(value?: number, ...tail: string[]): string { return "ok"; }
export const inferred = keep<OmitThisParameter<(this: { tag: string }, value?: number, ...tail: string[]) => string>>(produced);
