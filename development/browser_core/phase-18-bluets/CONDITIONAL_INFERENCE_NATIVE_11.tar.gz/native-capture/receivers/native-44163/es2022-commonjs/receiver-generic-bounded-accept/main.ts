function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<<T extends { tag: string }>(this: T, value: T) => T>>({ tag: "ok" });
