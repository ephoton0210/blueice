export function inferred(value: ThisParameterType<never>): never { return value; }
