function keep<T>(value: T): T { return value; }
export const inferred = keep<OmitThisParameter<unknown>>(1);
