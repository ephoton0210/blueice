function keep<T>(value: T): T { return value; }
function produced(value: number): number { return value; }
export const inferred = keep<OmitThisParameter<<T extends string>(this: { tag: T }, value: T) => T>>(produced);
