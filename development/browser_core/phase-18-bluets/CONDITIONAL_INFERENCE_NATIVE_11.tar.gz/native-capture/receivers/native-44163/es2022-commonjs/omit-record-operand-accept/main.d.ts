export declare const inferred: {
    tag: string;
};
