function keep<T>(value: T): T { return value; }
export const inferred: string = keep<ThisParameterType<unknown>>(1);
