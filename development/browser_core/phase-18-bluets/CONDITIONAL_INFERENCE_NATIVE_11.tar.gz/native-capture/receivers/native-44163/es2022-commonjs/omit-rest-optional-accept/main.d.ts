export declare const inferred: (value?: number | undefined, ...tail: string[]) => string;
