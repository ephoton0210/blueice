export function inferred(value: number): ThisParameterType<never> { return value; }
