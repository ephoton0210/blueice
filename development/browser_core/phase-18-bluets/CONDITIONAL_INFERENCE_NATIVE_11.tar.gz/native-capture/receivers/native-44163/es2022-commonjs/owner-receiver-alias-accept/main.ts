type Receiver<T> = T extends (this: infer R, ...args: never) => any ? R : unknown;
function keep<T>(value: T): T { return value; }
export const inferred = keep<Receiver<(this: { tag: string }, value: number) => string>>({ tag: "ok" });
