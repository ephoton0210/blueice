function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<(this: { tag: string }, value?: number, ...tail: boolean[]) => void>>({ tag: "ok" });
