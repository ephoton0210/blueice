"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function original(value) { return this.tag + ":" + value; }
function keep(value) { return value; }
function produced(value) { return original.call({ tag: "bound" }, value); }
exports.inferred = keep(produced);
console.log((0, exports.inferred)(4));
