export function inferred(value: OmitThisParameter<never>): never { return value; }
