type Source = <T>(value: T) => T;
export declare const inferred: Source;
export {};
