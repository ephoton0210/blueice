function keep<T>(value: T): T { return value; }
export const inferred: string = keep<ThisParameterType<new (value: number) => { value: number }>>(1);
