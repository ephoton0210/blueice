type Source = ((this: { old: number }, first: string) => number) & ((this: { tag: string }, value: number) => string);
function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<Source>>({ tag: "ok" });
