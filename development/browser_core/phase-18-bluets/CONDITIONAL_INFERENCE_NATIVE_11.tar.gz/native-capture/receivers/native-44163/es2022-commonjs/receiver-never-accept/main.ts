export function inferred(value: ThisParameterType<(this: never, value: number) => string>): never { return value; }
