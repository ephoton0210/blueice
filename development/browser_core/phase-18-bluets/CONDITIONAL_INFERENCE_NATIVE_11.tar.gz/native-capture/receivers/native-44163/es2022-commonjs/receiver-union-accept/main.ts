type Source = ((this: string, value: number) => string) | ((this: number, value: string) => number);
function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<Source>>(1);
