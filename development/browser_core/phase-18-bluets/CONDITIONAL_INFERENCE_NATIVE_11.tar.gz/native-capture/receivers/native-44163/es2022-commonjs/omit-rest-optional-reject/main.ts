function keep<T>(value: T): T { return value; }
function produced(value: boolean): number { return 1; }
export const inferred = keep<OmitThisParameter<(this: { tag: string }, value?: number, ...tail: string[]) => string>>(produced);
