declare const console: { log(value: string): void };
function original(this: { tag: string }, value: number): string { return this.tag + ":" + value; }
function keep<T>(value: T): T { return value; }
function produced(value: number): string { return original.call({ tag: "bound" }, value); }
export const inferred = keep<OmitThisParameter<typeof original>>(produced);
console.log(inferred(4));
