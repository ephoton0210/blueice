class Source { constructor(public value: number) {} }
function keep<T>(value: T): T { return value; }
export const inferred = keep<OmitThisParameter<typeof Source>>(Source);
