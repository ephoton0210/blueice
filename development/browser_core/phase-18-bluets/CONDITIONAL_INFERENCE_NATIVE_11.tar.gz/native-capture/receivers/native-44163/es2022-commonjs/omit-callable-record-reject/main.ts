interface Source { (this: { tag: string }, value: number): string; readonly marker: number; }
function keep<T>(value: T): T { return value; }
function produced(value: string): number { return 1; }
export const inferred = keep<OmitThisParameter<Source>>(produced);
