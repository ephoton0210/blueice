export function inferred(value: number): ThisParameterType<(this: never, value: number) => string> { return value; }
