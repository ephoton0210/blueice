function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<any>>(1);
