export function inferred(value: number): OmitThisParameter<never> { return value; }
