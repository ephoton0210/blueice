export declare const inferred: string | number;
