function keep<T>(value: T): T { return value; }
function produced(value: string): number { return 1; }
export const inferred = keep<OmitThisParameter<(this: never, value: number) => string>>(produced);
