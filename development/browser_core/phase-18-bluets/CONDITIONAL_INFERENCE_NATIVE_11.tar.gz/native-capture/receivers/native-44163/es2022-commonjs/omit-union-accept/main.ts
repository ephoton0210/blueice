type Source = ((this: { tag: string }, value: number) => number) | ((this: { tag: number }, value: string) => string);
function keep<T>(value: T): T { return value; }
function produced(value: number): number { return value; }
export const inferred = keep<OmitThisParameter<Source>>(produced);
