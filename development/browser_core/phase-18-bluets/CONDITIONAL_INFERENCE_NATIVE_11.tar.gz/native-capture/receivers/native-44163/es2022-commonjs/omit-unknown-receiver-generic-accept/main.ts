type Source = <T>(this: unknown, value: T) => T;
function keep<T>(value: T): T { return value; }
function produced<T>(this: unknown, value: T): T { return value; }
export const inferred = keep<OmitThisParameter<Source>>(produced);
