interface Source { (this: { tag: string }, value: number): string; readonly marker: number; }
function keep<T>(value: T): T { return value; }
export const inferred = keep<ThisParameterType<Source>>({ tag: "ok" });
