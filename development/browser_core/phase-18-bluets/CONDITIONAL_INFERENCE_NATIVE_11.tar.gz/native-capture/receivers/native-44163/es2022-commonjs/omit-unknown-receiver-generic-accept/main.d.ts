type Source = <T>(this: unknown, value: T) => T;
export declare const inferred: Source;
export {};
