export declare function inferred(value: ThisParameterType<never>): never;
