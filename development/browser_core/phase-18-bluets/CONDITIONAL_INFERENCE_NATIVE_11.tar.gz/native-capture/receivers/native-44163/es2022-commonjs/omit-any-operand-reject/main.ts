function keep<T>(value: T): T { return value; }
export const inferred: never = keep<OmitThisParameter<any>>(1);
