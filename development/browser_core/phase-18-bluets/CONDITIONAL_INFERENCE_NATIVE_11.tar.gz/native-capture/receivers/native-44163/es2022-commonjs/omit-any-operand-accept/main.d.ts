export declare const inferred: any;
