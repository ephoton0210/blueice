type Source = <T>(this: any, value: T) => T;
export declare const inferred: Source;
export {};
