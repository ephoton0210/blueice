function keep(value) { return value; }
function produced(value) { return value; }
export const inferred = keep(produced);
