function original(value) { return this.tag + ":" + value; }
function keep(value) { return value; }
export const inferred = keep({ tag: "ok" });
console.log(original.call(inferred, 3));
