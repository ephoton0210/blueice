function keep(value) { return value; }
function produced(value, ...tail) { return "ok"; }
export const inferred = keep(produced);
