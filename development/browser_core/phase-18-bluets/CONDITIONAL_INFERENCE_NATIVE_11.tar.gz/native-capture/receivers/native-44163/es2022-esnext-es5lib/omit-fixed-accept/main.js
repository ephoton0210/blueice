function original(value) { return this.tag + ":" + value; }
function keep(value) { return value; }
function produced(value) { return original.call({ tag: "bound" }, value); }
export const inferred = keep(produced);
console.log(inferred(4));
