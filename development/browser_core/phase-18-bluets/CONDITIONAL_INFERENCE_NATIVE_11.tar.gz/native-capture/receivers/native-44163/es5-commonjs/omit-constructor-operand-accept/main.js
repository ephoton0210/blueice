"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
var Source = /** @class */ (function () {
    function Source(value) {
        this.value = value;
    }
    return Source;
}());
function keep(value) { return value; }
exports.inferred = keep(Source);
