"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function keep(value) { return value; }
function produced(value) {
    var tail = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        tail[_i - 1] = arguments[_i];
    }
    return "ok";
}
exports.inferred = keep(produced);
