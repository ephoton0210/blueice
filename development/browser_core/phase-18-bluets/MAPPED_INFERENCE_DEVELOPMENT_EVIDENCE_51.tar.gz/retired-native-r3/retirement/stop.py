# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess

root = Path(__file__).resolve().parent.parent
repo = root.parent.parent
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = read(root / 'frozen-source-preflight.json')
regression_path = repo / 'target/generic-key-next-discovery-20261113/accepted-c-comparison-2/observations.json'
comparison = read(regression_path)
assert len(comparison['regressions']) == 7
assert all(row['declarationRegression'] for row in comparison['regressions'])
assert all(sha(repo / name) == digest for name, digest in frozen['files'].items())
assert sha(root / 'accepted-native-cli') == read(root / 'native-gates.json')['nativeCompilerSha256']
assert read(root / 'windows/windows-acceptance-verification.json')['conclusion'] == 'success'


def processes():
    result = {}
    for line in subprocess.check_output(['ps', '-axo', 'pid,ppid,pgid,state,command'], text=True).splitlines()[1:]:
        parts = line.split(None, 4)
        if len(parts) == 5:
            pid, parent, group, state, command = parts
            result[int(pid)] = {'pid':int(pid), 'parent':int(parent),
                                'group':int(group), 'state':state, 'command':command}
    return result


live = processes()
driver = 71999
watcher = 72977
assert live[driver]['group'] == driver
assert live[driver]['command'].endswith(root.name + '/run_native_gates.py')
assert live[watcher]['command'].endswith(root.name + '/watch_maps.py')
assert read(root / 'post-native.json')['pid'] == 73090
for name in ['native-gates.json', 'post-native.json', 'accepted-native/measurement.json',
             'accepted-native/current.json', 'map-watch-state.json']:
    destination = root / 'retirement' / name.replace('/', '__')
    with destination.open('xb') as output:
        output.write((root / name).read_bytes())

receipt = {'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'sourceRevision':frozen['sourceRevision'],
           'conclusion':'retiring',
           'reason':'Seven independently calibrated declaration regressions against accepted C: void/void[] results become unknown/unknown[]. No whole-candidate acceptance credit.',
           'regressionObservation':str(regression_path.relative_to(repo)),
           'regressionObservationSha256':sha(regression_path),
           'regressions':comparison['regressions'],
           'allFrozenSourceFilesStillMatch':True,
           'allKnownMacProcessesTerminal':False,
           'windowsFullTestsAndArchiveAuditPassedOnRetiredSource':True,
           'windowsArchiveSha256':sha(root / 'windows-evidence.tar.gz'),
           'passCredit':False}
(root / 'candidate-retirement.json').write_text(json.dumps(receipt, indent=2) + '\n')

# This process group belongs to the verified Native driver only. Freeze it
# atomically so its scheduler and test helpers cannot create further readers.
os.killpg(driver, signal.SIGSTOP)
try:
    stopped = processes()
    group = [row for row in stopped.values() if row['group'] == driver]
    assert any(row['pid'] == driver for row in group)
    receipt['stoppedNativeProcessGroup'] = group
    for row in group:
        if row['pid'] != driver:
            try:
                os.kill(row['pid'], signal.SIGTERM)
            except ProcessLookupError:
                pass
    os.kill(watcher, signal.SIGTERM)
    receipt['signalledWatcher'] = live[watcher]
finally:
    # Resume delivery of pending termination signals. Leave the Python driver
    # alive to record its child's terminal status and unblock its supervisor.
    os.killpg(driver, signal.SIGCONT)
receipt['terminationIssuedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(root / 'candidate-retirement.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'sourceRevision':receipt['sourceRevision'], 'conclusion':'retiring',
                  'nativeGroupProcesses':len(group), 'regressions':7}), flush=True)
