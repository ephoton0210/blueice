# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Independently compare r10 driver selections and preserved failure evidence."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import re
import sys

contract=Path(__file__).resolve().parent
repo=contract.parent.parent
root=Path(sys.argv[1]).resolve()
old=repo/'target/higher-order-inference-acceptance-20261114-r9'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prepared=read(root/'prepared.json')
assert not (root/'launch-state.json').exists()
changed={'freeze_source.py','prepare_windows.py','verify_windows.py'}
drivers=prepared['runtimeDrivers']
assert len(drivers)==len(set(drivers))==17
for name in set(drivers)-changed:
    actual=(root/name).read_text().replace('acceptance-20261114-r10','acceptance-20261114-r9')
    actual=actual.replace('p0g-r10','p0g-r9').replace('results-higher-order-inference-r10','results-higher-order-inference-r9')
    assert actual==(old/name).read_text(),name
def selection(p):
    value=re.search(r'const cohorts = (\[[\s\S]*?\]);',p.read_text())
    return ast.literal_eval(value.group(1))
prior=selection(old/'windows/windows-runner.cjs')
current=selection(root/'windows/windows-runner.cjs')
assert len(prior)==26 and len(current)==len(set(current))==27
assert current==['diagnostics',*prior]
tree=ast.parse((root/'verify_windows.py').read_text())
maps=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Dict):
        try:value=ast.literal_eval(node)
        except (ValueError,TypeError):continue
        if isinstance(value,dict) and 'higher_order_inference'in value and 'nonnullable_awaited'in value:
            maps.append(value)
assert len(maps)==1
expected=maps[0]
assert set(expected)==set(current) and expected['diagnostics']==10
old_windows=read(old/'windows/windows-acceptance-verification.json')
assert all(expected[name]==old_windows['regressionCohorts'][name]['passed'] for name in prior)
source=(repo/'backend/bluets/tests/diagnostics.rs').read_text()
names=re.findall(r'#\[test\]\s*fn (\w+)\(',source)
assert len(names)==len(set(names))==10 and '#[cfg('not in source
assert 'typescript-5.9.3-diagnostics-v13'in source and 'diagnostics-v12'not in source
freeze=(root/'freeze_source.py').read_text()
assert 'diagnostics-version-worktree-quality-1'in freeze
assert 'diagnostics-version-projects-preflight-1'in freeze
assert 'test result: ok. 10 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;'in freeze
assert "'expectedWindowsCohorts':27"in freeze
win=(root/'prepare_windows.py').read_text()
assert "'higher-order-inference-acceptance-20261114-r9'"in win
assert "'/p0g-r9-source-manifest.json'"in win
assert ".replace('p0g-r9', 'p0g-r10')"in win
assert 'diagnostics-version-worktree-quality-1'in(root/'g_recursive_scope_audit.py').read_text()
assert 'sourceDifferencesSinceSupersededPreflight'in(root/'g_acceptance_audit.py').read_text()
sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('r10_history_audit',root/'g_history_audit.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
history=module.audit(repo)
assert history['conclusion']=='success'
assert history['priorWholeGateFailureEvidence']['r9']['originalFailureUnchanged']
out=root/'driver-contract-preflight-1';out.mkdir()
(out/'history-audit.json').write_text(json.dumps(history,indent=2)+'\n')
result={'conclusion':'preparation-contract-verified','acceptanceCredit':0,
    'sourceRevision':prepared['expectedSourceRevision'],
    'driverSha256':{name:sha(root/name) for name in drivers},
    'namespaceOnlyRuntimeDrivers':sorted(set(drivers)-changed),
    'adaptedRuntimeDrivers':sorted(changed),'windowsCohorts':current,
    'windowsFunctions':expected,'publicDiagnosticsFunctions':names,
    'publicDiagnosticsInventoryCredit':0,'historicalFailureAuditSha256':sha(out/'history-audit.json'),
    'windowsRunnerSha256':sha(root/'windows/windows-runner.cjs'),
    'scope':'Selection and preservation proof only; complete fresh platform execution remains mandatory.'}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['conclusion','sourceRevision','acceptanceCredit']}))
