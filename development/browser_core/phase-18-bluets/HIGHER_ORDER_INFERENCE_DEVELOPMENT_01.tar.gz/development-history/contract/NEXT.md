# P0-G implementation handoff

All Native inputs are frozen; production Rust is still unchanged from accepted
commit 87d53ef80. Do not regenerate the reference. P0-G is unchecked/uncommitted.
User authorizes commit+push only after the whole implementation and matching
complete measurements. No subagents. Keep one Mac Cargo pipeline.

Required frozen counts: 48 forms ×8 profiles =384; 352 accepts /32 rejects;
424 declarations, 704 consumers, 424 parses, 48 executions; twelve separate
policy controls. Original24 source/module strings unchanged. Native replay
and four imported-runtime positive/negative guards pass.

Paths:

- fixture: backend/bluets/tests/fixtures/higher_order_inference/
- tools: development/browser_core/phase-18-bluets/tools/higher_order_inference/
- public Rust: backend/bluets/tests/higher_order_inference.rs (four functions)
- baseline-1: 48 agreements /336 differences (116 reject,204 declaration,16 diagnostic)
- red-1: expected-red;1passed,2failed,1ignored,0filtered; all384 observations
  exactly match the independent baseline; compiled actual CLI fed688b54009ae9f...
- baseline.cjs completed session19423; red.py completed37502; no live test jobs.
- published BASELINE/RED JSON +31.2MB EVIDENCE +MEMBERS independently verify13232
  members. Native FROZEN hash a97ce8c0ece181bdee9706325e01516e3aba298f6389d013e23ec1f963b8dd25.

Concrete code facts:

- inference/collect.rs handles Function/Function and GenericFunction/GenericFunction,
  omitting ordinary-target/generic-argument matching.
- InferenceResult currently has only substitutions/rejected_constraint. Calls
  infer map-only through infer_call_substitutions; returned binders are lost.
- direct result path: module/expressions.rs::infer_function_call selects signature,
  calls function_call_substitutions, then materialize_result. Contextual path:
  module/expressions/generic_inference.rs::infer_generic_result_in_context.
- Call chains delegate to infer_function_call. Return constructors use TypeSignature.
- GenericFunction has type_parameters,parameters,result,span. TypeParameter has
  lexical name,constraint,default,span. IDs are #typeparam@module:start:name.
  substitute_type protects nested binders. Retain identity and alpha-rename output.
- Type relations parameters.rs generic_functions_assignable already instantiates
  generic source signatures against concrete target inputs/result; constrained
  propagated IDs may need source-local parameter definitions for checking.

Implementation direction (not implemented):

1. Add a bounded higher-order module used only when ordinary formal signatures
   meet generic callable/constructor actuals. Preserve old paths without such inputs.
2. Seed existing outer candidates from non-generic actuals and result context.
   Distinguish missing candidates from deliberately inferred strict unknown;
   expose inferred-parameter names in InferenceResult rather than guessing from
   final substitutions that already contain defaults.
3. For each generic actual, create a scoped fresh-parameter proposal. Collect
   input-position outer slots first, then result slots. If returned type has one
   non-generic call/construct signature, input evidence exists and proposed slots
   do not overlap existing candidates, retain the incoming binders. Otherwise
   instantiate its local parameters against the known contextual signature.
   Keep sequential evidence for the next argument. A blanket global "any earlier
   candidate disables propagation" rule is too restrictive.
4. Return introduced parameters explicitly with substitutions. At the common
   result-instantiation boundary, attach them to a Function->GenericFunction or
   the single construct signature. Carry constraints/defaults and owner IDs;
   do not propagate into ordinary object/overloaded return controls.
5. Keep original argument checks active. Source-local scoped parameter definitions
   may be needed for constrained generic assignability. Do not hide failures or
   use function spellings as special cases. Retain budget charges; default budget
   must not be increased. Repeated full inference can exhaust budget; measure
   and use incremental candidate state if necessary.
6. Separate remaining exact-output work: typeof identity/private declarations,
   outer T vs returned T_1, and inferred unknown|undefined absorption in overload
   results. Baseline sources/diagnostics are immutable. Fixing only false rejections
   leaves204 declaration and16 diagnostic differences.

Native library implementation was inspected only as a primary behavior reference;
do not translate or copy upstream source. Observable frozen controls enforce
single-callable eligibility and non-overlapping candidates. Implement independently
in Rust with the repository MPL header and modules <1500 lines.

After a first coherent change: build one focused candidate, capture actual CLI/test
bytes and per-case progress. Compare against384 frozen observations, then full
permanent Native/Blue producers+consumers+syntax+runtime. Do not commit on focused
green: require the entire Native catalog, full workspace, both8407x2maps, four
projects, Windows82/25/full affected cohorts,fmt/clippy/Node/Python/accounting,
source/artifact member verification and old42716-row preservation.

The suite/case inventory registration for the new Rust harness has not yet been
added. Add it before full acceptance (primary384 +boundary12); keep old rows intact.
Current global inventory remains42716 and full parity OFF. All22 broader rows open.
