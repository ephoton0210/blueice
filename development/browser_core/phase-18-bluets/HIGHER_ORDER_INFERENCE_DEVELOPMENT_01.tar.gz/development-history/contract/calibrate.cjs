// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const fs = require('node:fs');
const path = require('node:path');
const root = __dirname, repo = path.resolve(root, '../..');
process.env.BLUEICE_BLUETSC_ORACLE = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc');
process.env.BLUEICE_ACORN_ORACLE = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn');
const c = require(path.join(repo,'development/browser_core/phase-18-bluets/tools/higher_order_inference/common.cjs'));
const {assert,sha,fixture,read} = c;
const output = path.resolve(process.argv[2]);
assert(!fs.existsSync(output), 'Every authoring/calibration attempt must be preserved');
assert(!fs.existsSync(path.join(fixture,'FROZEN.json')));
assert(!fs.existsSync(path.join(fixture,'reference.json')), 'Do not overwrite an existing Native reference');
fs.mkdirSync(output,{recursive:true});
const inputBytes = fs.readFileSync(path.join(fixture,'cases.json')), input = JSON.parse(inputBytes);
fs.writeFileSync(path.join(output,'inputs.json'),inputBytes);
fs.copyFileSync(__filename,path.join(output,'calibrate.cjs'));
fs.copyFileSync(path.join(repo,'development/browser_core/phase-18-bluets/tools/higher_order_inference/common.cjs'),path.join(output,'common.cjs'));
const ctx = c.context(), libraries = {}, rows = [];
const state = {stage:'primary',conclusion:'in_progress',inputSha256:sha(inputBytes),startedAt:new Date().toISOString(),cases:rows};
const save=()=>fs.writeFileSync(path.join(output,'measurement.json'),JSON.stringify(state,null,2)+'\n');
try {
    save();
    for(const profile of input.profiles) for(const entry of input.cases) {
        const id = profile.id+'/'+entry.id;
        state.currentCase=id;save();
        const {cwd,options,config} = c.prepare(output,input,profile,entry);
        const native = c.nativeProject(ctx,cwd,config);
        Object.assign(libraries,native.libraries);
        const accepts = native.diagnostics.length===0;
        const row = {id,accepts,diagnostics:native.diagnostics,
            declarations:Object.fromEntries(Object.entries(native.outputs).filter(([name])=>/\.d\.(ts|mts|cts)$/.test(name))),
            authoredVerdictAgrees:accepts===(entry.nativeExpectedAcceptsByProfile?.[profile.id]??entry.nativeExpectedAccepts)};
        rows.push(row);save();
        fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n');
        if(accepts) Object.assign(row,c.downstream(ctx,cwd,profile,entry,options,native.outputs));
        else assert.deepEqual(native.outputs,{},id+': Native rejected source published artifacts');
        fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n');
        save();
        if(rows.length%24===0)console.log('NATIVE',rows.length,'/384',id);
    }
    const reference={schema:1,typescript:ctx.ts.version,implementationSha256:sha(fs.readFileSync(ctx.implementation)),libraries,
        inputSha256:sha(inputBytes),...c.counts(rows),verdictCalibrationQuestions:rows.filter(row=>!row.authoredVerdictAgrees).map(row=>row.id),cases:rows};
    fs.writeFileSync(path.join(output,'reference.json'),JSON.stringify(reference,null,2)+'\n');
    assert.deepEqual(reference.verdictCalibrationQuestions,[],'Resolve every Native authoring question before freezing');
    assert.equal(reference.comparisons,384);assert.equal(reference.runtime,48);
    state.stage='boundaries';save();
    const boundaryBytes=fs.readFileSync(path.join(fixture,'boundary-controls.json'));
    fs.writeFileSync(path.join(output,'boundary-controls.json'),boundaryBytes);
    const boundaries=JSON.parse(boundaryBytes),controls=[];
    for(const entry of boundaries.controls) {
        const profile={id:'boundaries',compilerOptions:{target:'ES2022',module:'CommonJS'}};
        const files=entry.declaration?{'ambient.d.ts':entry.declaration+'\n'}:{};
        const {cwd,config}=c.prepare(output,input,profile,{...entry,files});
        const native=c.nativeProject(ctx,cwd,config);
        controls.push({id:entry.id,accepts:native.diagnostics.length===0,diagnostics:native.diagnostics});
        fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(controls.at(-1),null,2)+'\n');
    }
    assert.equal(controls.filter(row=>row.accepts).length,10);assert.equal(controls.filter(row=>!row.accepts).length,2);
    const boundaryReference={typescript:ctx.ts.version,implementationSha256:reference.implementationSha256,inputSha256:sha(boundaryBytes),controls,directAgreementCredit:0};
    fs.writeFileSync(path.join(output,'boundary-reference.json'),JSON.stringify(boundaryReference,null,2)+'\n');
    assert.equal(sha(fs.readFileSync(path.join(fixture,'cases.json'))),sha(inputBytes));
    fs.copyFileSync(path.join(output,'reference.json'),path.join(fixture,'reference.json'));
    fs.copyFileSync(path.join(output,'boundary-reference.json'),path.join(fixture,'boundary-reference.json'));
    state.stage='calibrated-awaiting-independent-replay';state.conclusion='success';state.counts=c.counts(rows);state.finishedAt=new Date().toISOString();save();
    console.log(JSON.stringify({output,conclusion:'success',...state.counts}));
}catch(error){state.conclusion='failure';state.error=String(error.stack||error);state.finishedAt=new Date().toISOString();save();throw error;}
