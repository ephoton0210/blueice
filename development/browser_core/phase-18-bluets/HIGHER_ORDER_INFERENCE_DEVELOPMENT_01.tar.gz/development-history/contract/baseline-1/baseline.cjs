// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const fs=require('node:fs'),path=require('node:path');
const {spawnSync,execFileSync}=require('node:child_process');
const {isDeepStrictEqual}=require('node:util');
const root=__dirname,repo=path.resolve(root,'../..');
process.env.BLUEICE_BLUETSC_ORACLE=path.join(repo,'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc');
process.env.BLUEICE_ACORN_ORACLE=path.join(repo,'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn');
const c=require(path.join(repo,'development/browser_core/phase-18-bluets/tools/higher_order_inference/common.cjs'));
const {assert,fixture,sha,read}=c;
const output=path.join(root,'baseline-1');assert(!fs.existsSync(output));fs.mkdirSync(output);
const input=read(path.join(fixture,'cases.json')),reference=read(path.join(fixture,'reference.json'));
const accepted=read(path.join(repo,'development/browser_core/phase-18-bluets/CONDITIONAL_INFERENCE_MEASUREMENT.json'));
const compiler=path.join(output,'baseline-cli');fs.copyFileSync(path.join(repo,'target/conditional-inference-acceptance-20261114-r3/accepted-workspace-cli'),compiler);fs.chmodSync(compiler,0o755);
assert.equal(sha(fs.readFileSync(compiler)),accepted.gates.workspaceCompilerSha256);
for(const name of ['FROZEN.json','cases.json','reference.json','boundary-controls.json','boundary-reference.json'])fs.copyFileSync(path.join(fixture,name),path.join(output,name));
fs.copyFileSync(__filename,path.join(output,'baseline.cjs'));
const ctx=c.context();c.authorities(ctx);
const expected=new Map(reference.cases.map(row=>[row.id,row]));
const state={schema:1,parentCommit:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),
    sourceRevision:accepted.source.sourceRevision,compilerSha256:sha(fs.readFileSync(compiler)),
    frozenSha256:sha(fs.readFileSync(path.join(fixture,'FROZEN.json'))),
    comparisonScope:'Complete verdict, diagnostics/UTF-16 positions and actual declaration inventory/bytes. Baseline consumers, syntax and execution are not acceptance evidence.',
    inventoryCredit:0,conclusion:'in_progress',startedAt:new Date().toISOString(),cases:[]};
const save=()=>fs.writeFileSync(path.join(output,'measurement.json'),JSON.stringify(state,null,2)+'\n');
try {
    save();
    for(const profile of input.profiles)for(const entry of input.cases) {
        const id=profile.id+'/'+entry.id,wanted=expected.get(id);
        const {cwd}=c.prepare(output,input,profile,entry);
        const result=spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});
        fs.writeFileSync(path.join(cwd,'build.stdout'),result.stdout||'');fs.writeFileSync(path.join(cwd,'build.stderr'),result.stderr||'');if(result.error)throw result.error;
        const outputs=c.inventory(path.join(cwd,'dist'));
        const observed={accepts:result.status===0,diagnostics:(result.stderr||'').split(/\r?\n/).filter(Boolean).map(line=>c.blueDiagnostic(JSON.parse(line))),
            declarations:Object.fromEntries(Object.entries(outputs).filter(([name])=>/\.d\.(ts|mts|cts)$/.test(name)))};
        const native={accepts:wanted.accepts,diagnostics:wanted.diagnostics,declarations:wanted.declarations};
        const rejectedOutput=!wanted.accepts&&Object.keys(outputs).length!==0;
        const row={id,...observed,agrees:isDeepStrictEqual(observed,native)&&!rejectedOutput,publishedOnRejectedNativeInput:rejectedOutput,
            classification:isDeepStrictEqual(observed,native)&&!rejectedOutput?'complete-agreement':wanted.accepts&&!observed.accepts?'incorrect-rejection':!wanted.accepts&&observed.accepts?'incorrect-acceptance':wanted.accepts?'exact-declaration-difference':'complete-diagnostic-difference'};
        fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n');state.cases.push(row);save();
        if(state.cases.length%48===0)console.log('BASELINE',state.cases.length,'/384');
    }
    c.authorities(ctx);assert.equal(sha(fs.readFileSync(compiler)),state.compilerSha256);assert.equal(state.cases.length,384);
    const labels=[...new Set(state.cases.map(row=>row.classification))];
    Object.assign(state,{conclusion:'measured-baseline',comparisons:state.cases.length,completeAgreements:state.cases.filter(row=>row.agrees).length,
        completeDifferences:state.cases.filter(row=>!row.agrees).length,classifications:Object.fromEntries(labels.map(label=>[label,state.cases.filter(row=>row.classification===label).length])),
        rejectedInputsPublishedArtifacts:state.cases.filter(row=>row.publishedOnRejectedNativeInput).length,finishedAt:new Date().toISOString()});save();
    console.log(JSON.stringify({conclusion:state.conclusion,comparisons:state.comparisons,completeAgreements:state.completeAgreements,completeDifferences:state.completeDifferences,classifications:state.classifications,rejectedInputsPublishedArtifacts:state.rejectedInputsPublishedArtifacts}));
}catch(error){state.conclusion='failure';state.error=String(error.stack||error);save();throw error;}
