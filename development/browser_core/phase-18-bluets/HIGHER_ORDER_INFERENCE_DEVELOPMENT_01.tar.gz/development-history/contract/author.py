# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
repo = root.parent.parent
fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
assert not (fixture / 'FROZEN.json').exists()
fixture.mkdir(parents=True, exist_ok=True)
original_path = repo / 'target/higher-order-inference-discovery-20261114/inputs.json'
original = json.loads(original_path.read_bytes())
cases = []
compose = 'declare function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C;\n'
identity = 'function identity<T>(value: T): T { return value; }\n'
listing = 'function list<T>(value: T): T[] { return [value]; }\n'
box = 'function box<T>(value: T): { value: T } { return { value }; }\n'
lift = 'declare function lift<A, B>(fn: (value: A) => B): (value: A) => B[];\n'
lift2 = 'declare function lift2<A, B, R>(fn: (left: A, right: B) => R): (left: A, right: B) => R[];\n'


def consumers(expression, good, bad, symbol='result'):
    prefix = 'import { ' + symbol + ' } from "./main";\n'
    return {'positive': prefix + 'const demanded: ' + good + ' = ' + expression + ';\n',
            'negative': prefix + 'const refused: ' + bad + ' = ' + expression + ';\n'}


for entry in original['cases']:
    row = {'id': entry['id'], 'source': entry['source'], 'files': entry['files'],
           'nativeExpectedAccepts': entry['expectedNativeAccepts'],
           'origin': 'unchanged-discovery-24',
           'question': 'Retain the complete original higher-order inference observation.'}
    row['consumerSources'] = consumers('result("text")', '{ value: string[] }', '{ value: number[] }')
    name = row['id']
    if name.startswith('lift-generic') or name == 'propagated-default-parameter':
        row['consumerSources'] = consumers('result("text")', 'string[]', 'number[]')
    if name == 'compose-three-stages':
        row['consumerSources'] = consumers('result("text")', '{ value: string[] }[]', '{ value: number[] }[]')
    if name == 'compose-constrained-first':
        row['consumerSources'] = consumers('result({ tag: "ok", extra: 1 }).value[0].extra', 'number', 'string')
        row['consumerSources']['negative'] = 'import { result } from "./main";\nresult({ extra: 1 });\n'
    if name == 'compose-concrete-first':
        row['consumerSources'] = consumers('result(1)', 'string[]', 'number[]')
    if name == 'compose-concrete-second':
        row['consumerSources'] = consumers('result("text")', 'number', 'string')
    if name == 'lift-contextual-result':
        row['consumerSources'] = consumers('result(1)', 'number[]', 'string[]')
        row['consumerSources']['negative'] = 'import { result } from "./main";\nresult("wrong");\n'
    if name == 'preserve-generic-function-control':
        row['consumerSources'] = consumers('result("text")', 'string', 'number')
        row['consumerSources']['positive'] += 'const independent: number = result(1);\n'
    if name == 'outer-parameter-shadowing':
        row['consumerSources'] = consumers('outer("outside")(1)', '{ value: number[] }', '{ value: string[] }', 'outer')
        row['consumerSources']['positive'] += 'const independent: { value: string[] } = outer(1)("inside");\n'
    if name.startswith('object-result-'):
        row['consumerSources'] = consumers('result.run("text")', 'unknown', 'string')
    if name == 'overloaded-result-control':
        row['consumerSources'] = consumers('result()', 'unknown', 'string')
    if name == 'generic-constructor-factory':
        row['consumerSources'] = consumers('result("text").value', 'string', 'number')
    cases.append(row)


def add(name, source, expression, good, bad, *, files=None, accepts=True, runtime=None):
    row = {'id': name, 'source': source, 'files': files or {},
           'nativeExpectedAccepts': accepts, 'origin': 'expanded-authored-form',
           'question': name.replace('-', ' '),
           'consumerSources': consumers(expression, good, bad)}
    if runtime is not None:
        row['runtime'] = runtime
    cases.append(row)


add('rest-parameter-propagation', 'declare function restLift<A, B>(fn: (...values: A[]) => B): (...values: A[]) => B[];\nfunction first<T>(...values: T[]): T { return values[0]; }\nexport const result = restLift(first);\n', 'result("a", "b")', 'string[]', 'number[]')
add('optional-parameter-propagation', 'declare function optionalLift<A, B>(fn: (value?: A) => B): (value?: A) => B[];\nfunction optional<T>(value?: T): T | undefined { return value; }\nexport const result = optionalLift(optional);\n', 'result("text")', '(string | undefined)[]', 'number[]')
add('two-independent-parameters', lift2 + 'function pair<T, U>(left: T, right: U): [T, U] { return [left, right]; }\nexport const result = lift2(pair);\n', 'result("text", 1)', '[string, number][]', '[number, string][]')
add('dependent-parameter-constraint', lift2 + 'function pair<T, U extends T>(left: T, right: U): [T, U] { return [left, right]; }\nexport const result = lift2(pair);\n', 'result("left", "right")', '[string, string][]', '[number, number][]')
cases[-1]['consumerSources']['negative'] = 'import { result } from "./main";\nresult("text", 1);\n'
add('dependent-parameter-default', lift2 + 'function pair<T = string, U = T[]>(left: T, right: U): [T, U] { return [left, right]; }\nexport const result = lift2(pair);\n', 'result<number>(1, [2])', '[number, number[]][]', '[number, string[]][]')
add('nested-returned-binder', lift + 'function nested<T>(value: T): <U>(other: U) => [T, U] { return other => [value, other]; }\nexport const result = lift(nested);\n', 'result("text")[0](1)', '[string, number]', '[number, string]')
add('generic-function-property', lift + 'const provider: { map: <T>(value: T) => T[] } = { map: <T>(value: T): T[] => [value] };\nexport const result = lift(provider.map);\n', 'result("text")', 'string[][]', 'number[][]')
add('generic-method-value', lift + 'const provider = { map<T>(value: T): T[] { return [value]; } };\nexport const result = lift(provider.map);\n', 'result("text")', 'string[][]', 'number[][]')
add('generic-callable-interface', lift + 'interface Mapper { <T>(value: T): T; }\ndeclare const mapper: Mapper;\nexport const result = lift(mapper);\n', 'result("text")', 'string[]', 'number[]')
add('imported-generic-callable-alias', lift + 'import { mapper } from "./shapes";\nexport const result = lift(mapper);\n', 'result("text")', 'string[]', 'number[]', files={'shapes.ts': 'export type Mapper = <T>(value: T) => T;\nexport declare const mapper: Mapper;\n'})
add('runtime-concrete-leading-argument', 'function apply<A, B>(value: A, fn: (value: A) => B): B { return fn(value); }\n' + listing + 'export const result = apply("text", list);\n', 'result', 'string[]', 'number[]', runtime='if (check.length !== 1 || check[0] !== "text") throw new Error("leading argument");\n')
add('runtime-concrete-trailing-argument', 'function apply<A, B>(fn: (value: A) => B, value: A): B { return fn(value); }\n' + listing + 'export const result = apply(list, "text");\n', 'result', 'string[]', 'number[]', runtime='if (check.length !== 1 || check[0] !== "text") throw new Error("trailing argument");\n')
add('noinfer-returned-parameter', 'declare function guarded<A, B>(fn: (value: A) => B): (value: NoInfer<A>) => B;\n' + identity + 'export const result = guarded(identity);\n', 'result<string>("text")', 'string', 'number')
cases[-1]['consumerSources']['negative'] = 'import { result } from "./main";\nresult<string>(1);\n'
add('explicit-outer-specialization', compose + listing + box + 'export const result = compose<string, string[], { value: string[] }>(list, box);\n', 'result("text")', '{ value: string[] }', '{ value: number[] }')
add('returned-context-specialization', compose + listing + box + 'export const result: (value: boolean) => { value: boolean[] } = compose(list, box);\n', 'result(true)', '{ value: boolean[] }', '{ value: string[] }')
add('overloaded-argument-concrete-last', lift + 'declare function convert<T>(value: T): T[];\ndeclare function convert(value: number): number[];\nexport const result = lift(convert);\n', 'result(1)', 'number[][]', 'string[][]')
add('overloaded-argument-generic-last', lift + 'declare function convert(value: number): number[];\ndeclare function convert<T>(value: T): T[];\nexport const result = lift(convert);\n', 'result(1)', 'unknown[]', 'string[]')
choose = 'declare function choose<A, B>(fn: (value: A) => B, mode: "wrap"): (value: A) => B[];\ndeclare function choose<A, B>(fn: (value: A) => B, mode: "keep"): (value: A) => B;\n'
add('overload-candidate-isolation', choose + identity + 'export const result = choose(identity, "wrap");\n', 'result("text")', 'string[]', 'number[]')
add('overload-no-match-rejection', choose + identity + 'export const result = choose(identity, "invalid");\n', 'result("text")', 'string[]', 'number[]', accepts=False)
add('returned-generic-constructor', 'declare function adapt<A, R>(ctor: new (value: A) => R): new (value: A) => R;\nclass Box<T> { value: T; constructor(value: T) { this.value = value; } }\nexport const result = adapt(Box);\n', 'new result("text").value', 'string', 'number')
compose_impl = 'function compose<A, B, C>(first: (value: A) => B, second: (value: B) => C): (value: A) => C { return value => second(first(value)); }\n'
add('runtime-compose', compose_impl + listing + box + 'export const result = compose(list, box);\n', 'result("text")', '{ value: string[] }', '{ value: number[] }', runtime='if (check("text").value[0] !== "text" || check(2).value[0] !== 2) throw new Error("composition");\n')
add('runtime-lift', 'function lift<A, B>(fn: (value: A) => B): (value: A) => B[] { return value => [fn(value)]; }\n' + identity + 'export const result = lift(identity);\n', 'result("text")', 'string[]', 'number[]', runtime='if (check("text")[0] !== "text" || check(2)[0] !== 2) throw new Error("lifting");\n')
add('runtime-imported-compose', 'import { compose } from "./higher.js";\nimport { list, box } from "./factories.js";\nexport const result = compose(list, box);\n', 'result("text")', '{ value: string[] }', '{ value: number[] }', files={'higher.ts': 'export ' + compose_impl, 'factories.ts': 'export ' + listing + 'export ' + box}, runtime='if (check("text").value[0] !== "text" || check(2).value[0] !== 2) throw new Error("imported composition");\n')
add('runtime-three-stage-compose', 'function compose3<A, B, C, D>(one: (value: A) => B, two: (value: B) => C, three: (value: C) => D): (value: A) => D { return value => three(two(one(value))); }\n' + listing + box + 'export const result = compose3(list, box, list);\n', 'result("text")', '{ value: string[] }[]', '{ value: number[] }[]', runtime='if (check("text")[0].value[0] !== "text" || check(2)[0].value[0] !== 2) throw new Error("three stages");\n')
assert len(cases) == len({row['id'] for row in cases}) == 48
assert sum('runtime' in row for row in cases) == 6
for entry in original['cases']:
    row = next(row for row in cases if row['id'] == entry['id'])
    assert row['source'] == entry['source'] and row['files'] == entry['files']
profiles = [{'id': target.lower() + '-' + module.lower() + '-functions-' + str(strict).lower(),
             'compilerOptions': {'target': target, 'module': module, 'strictFunctionTypes': strict}}
            for target in ['ES5', 'ES2022'] for module in ['CommonJS', 'ESNext'] for strict in [True, False]]
data = {'schema': 1, 'scope': 'Authored higher-order contract; Native calibration required before freezing or implementation.',
        'originalDiscoveryInputSha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
        'options': {'strict': True, 'target': 'ES2022', 'module': 'CommonJS', 'lib': ['ES5'], 'types': [],
                    'declaration': True, 'noEmitOnError': True, 'skipLibCheck': True, 'outDir': 'dist'},
        'profiles': profiles, 'cases': cases}
destination = fixture / 'cases.json'
if destination.exists():
    previous = destination.read_bytes()
    (root / ('cases-before-' + hashlib.sha256(previous).hexdigest() + '.json')).write_bytes(previous)
destination.write_text(json.dumps(data, indent=2) + '\n')
controls = []
for name in ['compose-array-box', 'lift-generic-identity', 'compose-constrained-first']:
    row = next(row for row in cases if row['id'] == name)
    for limit in [0, 1]:
        controls.append({'id': name + '-work-' + str(limit), 'kind': 'resource-limit',
                         'source': row['source'], 'limited': {'max_type_expansions': limit}})
for limit in [0, 1]:
    controls.append({'id': 'returned-generic-parser-' + str(limit), 'kind': 'resource-limit',
                     'source': 'type Handler = <T>(value: T) => <U>(other: U) => [T, U];\ndeclare const value: Handler;\nexport const result = value;\n',
                     'limited': {'parser.max_type_depth': limit}})
for name, declaration, source in [
    ('ExternalIdentity', 'type ExternalIdentity = <T>(value: T) => T;',
     'export const result: ExternalIdentity = <T>(value: T): T => value;\n'),
    ('ExternalFactory', 'type ExternalFactory = new <T>(value: T) => { value: T };',
     'declare const factory: ExternalFactory;\nexport const result = factory;\n'),
]:
    controls.append({'id': 'ambient-' + name, 'kind': 'ambient-owner', 'declaration': declaration, 'source': source})
    controls.append({'id': 'runtime-' + name, 'kind': 'runtime-authority', 'declaration': declaration, 'source': name + '("wrong");\n'})
assert len(controls) == 12
(fixture / 'boundary-controls.json').write_text(json.dumps({'schema': 1, 'scope': 'Separate policy controls; zero direct Native agreement credit.', 'controls': controls}, indent=2) + '\n')
print(json.dumps({'forms': len(cases), 'profiles': len(profiles), 'primaryComparisons': 384,
                  'unchangedOriginalPrograms': 24, 'runtimeForms': 6, 'boundaryControls': len(controls)}))
