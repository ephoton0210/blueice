// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Discovery preserves raw diagnostics and declarations before any repair.
const assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path');
const {createHash} = require('node:crypto');
const {spawnSync, execFileSync} = require('node:child_process');
const {isDeepStrictEqual} = require('node:util');
const root = __dirname, repo = path.resolve(root, '../..');
const implementation = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/lib/typescript.js');
const ts = require(implementation);
const {inventory, writeSources, blueDiagnostic} = require(path.join(repo,
    'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const compiler = path.join(repo, 'target/symbolic-keys-acceptance-20261113-r1/accepted-workspace-cli');
const sha = data => createHash('sha256').update(data).digest('hex');
const inputPath = path.join(root, 'cases.json');
const input = JSON.parse(fs.readFileSync(inputPath));
const inputSha256 = sha(fs.readFileSync(inputPath));
assert.equal(ts.version, '5.9.3');
assert.equal(sha(fs.readFileSync(implementation)), '3ae902c92cc44dace175c0e69e13a4b0899f6983c6121d76b9ab8dd5795e7675');
assert.equal(sha(fs.readFileSync(compiler)), '683cc89a0417661178c05b7bfd2a0abab19e0088616562fc30744a3fe28576f6');
const save = (name, value) => fs.writeFileSync(path.join(root, name), JSON.stringify(value, null, 2) + '\n', {flag: 'wx'});

function prepare(kind, entry) {
    const cwd = path.join(root, kind, entry.id);
    fs.mkdirSync(cwd, {recursive: true});
    writeSources(cwd, entry);
    const config = {compilerOptions: input.options, files: ['main.ts', ...Object.keys(entry.files)]};
    fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify(config, null, 2) + '\n', {flag: 'wx'});
    return {cwd, config};
}

function diagnostic(value, cwd) {
    let file = null, position = null;
    if (value.file && value.start !== undefined) {
        const at = value.file.getLineAndCharacterOfPosition(value.start);
        file = path.relative(cwd, value.file.fileName).replaceAll('\\', '/');
        position = {line: at.line + 1, column: at.character + 1, length: value.length};
    }
    return {code: value.code, message: ts.flattenDiagnosticMessageText(value.messageText, '\n'),
        file, position, relatedInformation: (value.relatedInformation || []).map(row => diagnostic(row, cwd))};
}

function products(cwd, accepts, diagnostics) {
    const outputs = inventory(path.join(cwd, 'dist'));
    return {accepts, diagnostics,
        declarations: Object.fromEntries(Object.entries(outputs).filter(([name]) => name.endsWith('.d.ts'))),
        outputsSha256: Object.fromEntries(Object.entries(outputs).map(([name, text]) => [name, sha(text)])),
        publishedOnRejectedInput: !accepts && Object.keys(outputs).length > 0};
}

const native = [], libraries = new Map();
for (const entry of input.cases) {
    const {cwd, config} = prepare('native', entry);
    const parsed = ts.parseJsonConfigFileContent(config, ts.sys, cwd);
    assert.equal(parsed.errors.length, 0);
    const program = ts.createProgram(parsed.fileNames, parsed.options);
    const before = ts.getPreEmitDiagnostics(program);
    const emitted = program.emit();
    const diagnostics = ts.sortAndDeduplicateDiagnostics([...before, ...emitted.diagnostics])
        .map(row => diagnostic(row, cwd));
    for (const source of program.getSourceFiles()) {
        if (source.fileName.startsWith(path.dirname(implementation)) && source.isDeclarationFile)
            libraries.set(path.basename(source.fileName), sha(fs.readFileSync(source.fileName)));
    }
    const accepts = !diagnostics.length;
    native.push({id: entry.id, ...products(cwd, accepts, diagnostics),
        authoringVerdictAgrees: accepts === entry.nativeExpectedAccepts});
}
const binding = {typescript: ts.version, implementationSha256: sha(fs.readFileSync(implementation)),
    compilerSha256: sha(fs.readFileSync(compiler)), inputSha256,
    parentCommit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: repo, encoding: 'utf8'}).trim(),
    sourceRevision: 'backend-tree:' + execFileSync('git', ['rev-parse', 'HEAD:backend'], {cwd: repo, encoding: 'utf8'}).trim(),
    libraries: Object.fromEntries(libraries), inventoryCredit: 0};
save('native.json', {...binding, cases: native});

const rows = [];
for (const entry of input.cases) {
    const {cwd} = prepare('blue', entry);
    const result = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'],
        {cwd, encoding: 'utf8', timeout: 120000});
    if (result.error) throw result.error;
    fs.writeFileSync(path.join(cwd, 'build.stdout'), result.stdout);
    fs.writeFileSync(path.join(cwd, 'build.stderr'), result.stderr);
    const diagnostics = result.stderr.trim() ? result.stderr.trim().split('\n').map(line => {
        const value = JSON.parse(line);
        try { return blueDiagnostic(value); }
        catch { return {missingNativeCounterpart: true, raw: value}; }
    }) : [];
    const actual = products(cwd, result.status === 0, diagnostics);
    const wanted = native.find(row => row.id === entry.id);
    const comparable = row => ({accepts: row.accepts, diagnostics: row.diagnostics, declarations: row.declarations});
    const agrees = isDeepStrictEqual(comparable(wanted), comparable(actual));
    rows.push({id: entry.id, question: entry.question, agrees, native: wanted, blue: actual});
    console.log(agrees ? 'AGREE' : 'DIFFER', entry.id, 'Native=' + wanted.accepts, 'Blue=' + actual.accepts);
}
assert.equal(sha(fs.readFileSync(inputPath)), inputSha256);
save('report.json', {...binding, authoringErrors: native.filter(row => !row.authoringVerdictAgrees).map(row => row.id),
    comparisons: rows.length, completeAgreements: rows.filter(row => row.agrees).length,
    completeDifferences: rows.filter(row => !row.agrees).length, cases: rows});
