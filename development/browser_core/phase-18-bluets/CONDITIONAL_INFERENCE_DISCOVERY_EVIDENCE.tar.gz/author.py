# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Author conditional-inference discovery inputs before either compiler runs."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
cases = []


def add(name, definition, operand, expected, check=None, verdict=True, files=None):
    source = definition + '\n' + f'declare const value: Infer<{operand}>;\n'
    source += 'export const result = value;\n'
    if check is not None:
        source += f'export const check: {check} = result;\n'
    cases.append({'id': name, 'source': source, 'files': files or {},
                  'nativeExpectedAccepts': verdict, 'question': expected})


covariant = 'type Infer<T> = T extends { a: infer U; b: infer U } ? U : "miss";'
contravariant = 'type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";'
mixed = 'type Infer<T> = T extends (x: infer U) => infer U ? U : "miss";'
argument = 'type Infer<T> = T extends (x: infer U) => void ? U : "miss";'

add('covariant-union-control', covariant, '{ a: string; b: number }',
    'Covariant candidates form a union.', 'string | number')
add('contravariant-disjoint', contravariant,
    '{ a: (x: string) => void; b: (x: number) => void }',
    'Contravariant disjoint candidates intersect to never.', 'never')
add('contravariant-related-literals', contravariant,
    '{ a: (x: "a" | "b") => void; b: (x: "b" | "c") => void }',
    'Contravariant overlapping candidates retain their shared literal.', '"b"')
add('contravariant-record-intersection', contravariant,
    '{ a: (x: { a: string }) => void; b: (x: { b: number }) => void }',
    'Both record obligations survive contravariant inference.', '{ a: string; b: number }')
add('contravariant-reject-union', contravariant,
    '{ a: (x: string) => void; b: (x: number) => void }',
    'A never candidate cannot admit an ordinary string.', None)
cases[-1]['source'] += 'export const rejected: typeof result = "wrong";\n'
cases[-1]['nativeExpectedAccepts'] = False
add('mixed-covariance-precedence', mixed, '(x: string) => "ok"',
    'Covariant evidence takes precedence over contravariant evidence.', '"ok"')
add('mixed-incompatible-rejection-branch', mixed, '(x: "narrow") => string',
    'An inferred covariant result must still satisfy the contravariant position.', '"miss"')
add('double-contravariance',
    'type Infer<T> = T extends (f: (x: infer U) => void) => void ? U : "miss";',
    '(f: (x: "ok") => void) => void',
    'Nested parameter positions flip variance twice.', '"ok"')
add('function-zero-arguments', argument, '() => void',
    'A function may ignore a required caller argument; missing inference is unknown.')
add('function-zero-arguments-reject-literal', argument, '() => void',
    'An uninferred unknown result cannot be treated as the false-branch literal.', '"miss"', False)
add('function-optional-position',
    'type Infer<T> = T extends (x?: infer U) => void ? U : "miss";',
    '() => void', 'Missing optional function positions contribute no evidence.')
add('function-constrained-missing',
    'type Infer<T> = T extends (x: infer U extends string) => void ? U : "miss";',
    '() => void', 'Missing candidates use a declared infer constraint.', 'string')
add('function-return-control',
    'type Infer<T> = T extends (...args: any[]) => infer U ? U : "miss";',
    '(x: number) => "ok"', 'Ordinary covariant return inference remains unchanged.', '"ok"')
add('overload-last-signature-control', argument,
    '{ (x: "first"): void; (x: "last"): void }',
    'Conditional function inference uses the final overload.', '"last"')
add('readonly-array',
    'type Infer<T> = T extends readonly (infer U)[] ? U : "miss";',
    'readonly string[]', 'Readonly array patterns infer their element.', 'string')
add('tuple-prefix-control',
    'type Infer<T> = T extends [infer H, ...infer R] ? [H, R] : "miss";',
    '[string, number, boolean]', 'Existing head/rest matching remains unchanged.', '[string, [number, boolean]]')
add('tuple-suffix-rest',
    'type Infer<T> = T extends [...infer R, infer L] ? [R, L] : "miss";',
    '[string, number, boolean]', 'A variadic prefix must retain its trailing fixed element.', '[[string, number], boolean]')
add('tuple-optional-empty',
    'type Infer<T> = T extends [(infer H)?, ...infer R] ? [H, R] : "miss";',
    '[]', 'Optional tuple slots may be absent.')
add('conditional-any', 'type Infer<T> = T extends string ? 1 : 2;',
    'any', 'Any retains both possible conditional branches.', '1 | 2')
add('conditional-never-control', 'type Infer<T> = T extends string ? 1 : 2;',
    'never', 'A naked never check distributes to never.', 'never')
add('non-distributive-union-control',
    'type Infer<T> = [T] extends [string] ? 1 : 2;',
    'string | number', 'Tuple wrappers prevent distributivity.', '2')
add('constrained-covariant-union',
    'type Infer<T> = T extends { a: infer U extends string; b: infer U extends string } ? U : "miss";',
    '{ a: "a"; b: "b" }', 'Covariant constrained candidates retain a union.', '"a" | "b"')
add('cross-file-contravariance',
    'import type { Infer } from "./types";',
    '{ a: (x: string) => void; b: (x: number) => void }',
    'Imported generic aliases retain contravariant candidate directions.', 'never',
    files={'types.ts': 'export ' + contravariant + '\n'})
add('aliased-candidate-positions',
    'type Callback<X> = (value: X) => void;\n'
    'type Infer<T> = T extends { a: Callback<infer U>; b: Callback<infer U> } ? U : "miss";',
    '{ a: Callback<string>; b: Callback<number> }',
    'Alias expansion preserves the parameter variance of infer occurrences.', 'never')

payload = {'schema': 1, 'scope': 'Discovery only; no inventory or acceptance credit.',
           'options': {'strict': True, 'target': 'ES2022', 'module': 'CommonJS',
                       'lib': ['ES5'], 'types': [], 'declaration': True,
                       'noEmitOnError': True, 'skipLibCheck': True, 'outDir': 'dist'},
           'cases': cases}
destination = root / 'cases.json'
with destination.open('x') as output:
    json.dump(payload, output, indent=2)
    output.write('\n')
print(f'Authored {len(cases)} independent discovery programs.')
