# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import base64
import datetime
import hashlib
import importlib.util
import json

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qga', root.parent / 'noinfer-acceptance-20261112/recovery/qga_transfer.py')
qga = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qga)
plan = json.loads((root / 'windows/upload-plan.json').read_bytes())
state_path = root / 'windows/upload-state.json'
assert not state_path.exists(), 'Inspect the recorded upload/guest process before any retry'
state = {'conclusion': 'in_progress', 'files': [], 'sourceRevision': plan['sourceRevision']}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')


try:
    save()
    for item in plan['files']:
        content = Path(item['local']).read_bytes()
        assert hashlib.sha256(content).hexdigest() == item['sha256']
        handle = qga.call({'execute': 'guest-file-open', 'arguments': {'path': item['remote'], 'mode': 'wb'}})
        try:
            for offset in range(0, len(content), 65536):
                data = content[offset:offset + 65536]
                result = qga.call({'execute': 'guest-file-write', 'arguments': {
                    'handle': handle, 'buf-b64': base64.b64encode(data).decode(),
                }})
                assert result['count'] == len(data)
        finally:
            qga.call({'execute': 'guest-file-close', 'arguments': {'handle': handle}})
        state['files'].append(item)
        save()
        print('UPLOADED', Path(item['local']).name, len(content), flush=True)
    state.update(stage='launching-bootstrap')
    save()
    process = qga.call({'execute': 'guest-exec', 'arguments': {
        'path': 'C:\\Program Files\\Python312\\python.exe',
        'arg': ['-B', 'B:/BlueIce/gm3-20261109-360d7d921/p0f-r2-bootstrap.py'],
        'capture-output': True,
    }})
    (root / 'windows/launch.json').write_text(json.dumps({'process': process}, indent=2) + '\n')
    state.update(stage='bootstrap-launched', conclusion='success', process=process)
    save()
    print(json.dumps(state), flush=True)
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    save()
    raise
