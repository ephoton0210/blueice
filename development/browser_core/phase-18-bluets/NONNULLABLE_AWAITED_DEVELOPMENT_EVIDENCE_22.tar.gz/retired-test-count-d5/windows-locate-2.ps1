$ErrorActionPreference = 'Stop'
$root = 'B:\BlueIce\gm3-20261109-360d7d921'
$drive = Get-PSDrive -Name B -ErrorAction SilentlyContinue
$tools = @{}
foreach ($name in @('cargo','rustc','node','python')) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if ($command) { $tools[$name] = $command.Source }
}
$observation = [PSCustomObject]@{
    marker = 'bluets-p0b-locate-20261112-2'
    observedAt = [DateTime]::UtcNow.ToString('o')
    computer = $env:COMPUTERNAME
    architecture = $env:PROCESSOR_ARCHITECTURE
    root = $root
    rootExists = (Test-Path -LiteralPath $root -PathType Container)
    freeGiB = $(if ($drive) { [math]::Round($drive.Free / 1GB, 2) } else { $null })
    entries = @($(if (Test-Path -LiteralPath $root) { Get-ChildItem -LiteralPath $root -Name | Select-Object -First 18 }))
    tools = $tools
    buildProcesses = @(Get-Process cargo,rustc -ErrorAction SilentlyContinue | Select-Object Id,ProcessName)
} | ConvertTo-Json -Depth 5 -Compress

[System.IO.File]::WriteAllText('C:\Windows\Temp\bluets-p0b-locate-20261112-2.json', $observation)
Write-Output $observation
