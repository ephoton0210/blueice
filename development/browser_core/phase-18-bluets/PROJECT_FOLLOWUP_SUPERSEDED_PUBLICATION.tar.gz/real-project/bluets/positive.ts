import mitt from './dist/index';
const emitter = mitt<{count: number; ready: undefined}>();
emitter.on('count', value => { const count: number = value; });
emitter.emit('count', 42); emitter.emit('ready');
