import mitt from './dist/index';
const emitter = mitt<{count: number}>();
emitter.emit('count', 'wrong');
