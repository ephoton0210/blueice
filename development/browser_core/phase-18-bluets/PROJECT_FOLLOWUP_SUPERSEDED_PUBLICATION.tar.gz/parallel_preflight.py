from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import os,subprocess,json,hashlib,datetime,time
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-config-gates-20261109/parallel-preflight');root.mkdir(exist_ok=True)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','--','backend'],cwd=repo,text=True).splitlines()+['development/browser_core/phase-18-bluets/tools/record_gc1_object_generic_methods.cjs','development/browser_core/phase-18-bluets/tools/record_gm2_incremental_options.cjs']
def snapshot():return {p:sha(repo/p) for p in paths if (repo/p).is_file()}
before=snapshot();(root/'worktree-source-manifest.json').write_text(json.dumps(before,indent=2)+'\n')
state={'conclusion':'in_progress','stage':'build','scope':'All ordinary BlueTS and BlueJS integration harnesses except ge5_*; compatibility_inventory is deferred until complete Native measurements are generated, and remains part of the required unfiltered workspace gate.','suiteJobs':4,'suites':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():(root/'measurement.json').write_text(json.dumps(state,indent=2)+'\n')
save()
args=['cargo','test','-p','blueice-bluets','-p','blueice-bluets-bluejs','--tests','--no-run','--locked','--offline','--message-format=json']
with (root/'build.stdout').open('wb') as out,(root/'build.stderr').open('wb') as err:p=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=err)
state['build']={'command':args,'exit':p.returncode};save();assert p.returncode==0
binaries=[]
for line in (root/'build.stdout').read_text().splitlines():
 try:d=json.loads(line)
 except json.JSONDecodeError:continue
 if d.get('reason')=='compiler-artifact' and d.get('executable') and d.get('profile',{}).get('test') and 'test' in d['target']['kind']:
  name=d['target']['name']
  if name.startswith('ge5_') or name=='compatibility_inventory':continue
  binaries.append((name,d['executable']))
assert binaries and len(binaries)==len(set(p for _,p in binaries))
state.update(stage='tests',total=len(binaries),compilerSha256=sha(repo/'target/debug/bluetsc'));save()
def run(item):
 name,binary=item;start=time.monotonic();log=root/(name+'-'+hashlib.sha256(binary.encode()).hexdigest()[:8]+'.log')
 with log.open('wb') as out:p=subprocess.run([binary],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 return {'target':name,'executable':binary,'binarySha256':sha(Path(binary)),'exit':p.returncode,'log':log.name,'logSha256':sha(log),'seconds':round(time.monotonic()-start,3)}
with ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(run,item) for item in binaries]
 for future in as_completed(futures):state['suites'].append(future.result());save()
state['sourcesUnchanged']=before==snapshot();state['compilerUnchanged']=state['compilerSha256']==sha(repo/'target/debug/bluetsc');state['conclusion']='success' if state['sourcesUnchanged'] and state['compilerUnchanged'] and all(s['exit']==0 for s in state['suites']) else 'failure';state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['stage']='complete';save();raise SystemExit(0 if state['conclusion']=='success' else 1)
