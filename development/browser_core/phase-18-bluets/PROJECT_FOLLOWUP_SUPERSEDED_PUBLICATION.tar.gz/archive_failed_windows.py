from pathlib import Path
import json,subprocess,time,hashlib,datetime
root=Path('/private/tmp/bluets-config-gates-20261109');helper='/private/tmp/gm3_qga.py';base=r'B:\BlueIce\gm3-20261109-360d7d921';state={'stage':'waiting-for-windows-process'}
def save():state['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(root/'windows-watch.json').write_text(json.dumps(state,indent=2)+'\n')
def command(*args):return subprocess.check_output(['python3',helper,*args])
def wait(pid):
 while True:
  r=json.loads(command('poll',str(pid)))
  if r.get('exited'):return r
  time.sleep(20)
r=json.loads((root/'windows-measurement.json').read_text())
try:
 save()
 script="$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)\n$base='"+base+"'\n"
 script+="$state=Get-Content \"$base\\results-followups-v8\\measurement.json\" -Raw | ConvertFrom-Json\nCopy-Item $state.compiler.path \"$base\\followup-bluetsc.exe\"\n& tar.exe -czf \"$base\\followup-evidence-v8.tar.gz\" -C $base results-followups-v8 followup-runner.cjs followup-source-manifest.json followup-patch.tar.gz followup-bluetsc.exe\nif ($LASTEXITCODE -ne 0) {throw 'Evidence archive failed'}\n@{sha256=(Get-FileHash \"$base\\followup-evidence-v8.tar.gz\" -Algorithm SHA256).Hash.ToLower();bytes=(Get-Item \"$base\\followup-evidence-v8.tar.gz\").Length} | ConvertTo-Json -Compress\n"
 (root/'archive-windows.ps1').write_text(script);state['stage']='archiving-windows-evidence';save();archive_pid=json.loads(command('start',str(root/'archive-windows.ps1')))['pid'];receipt=wait(archive_pid);assert receipt['exitcode']==0,receipt;meta=json.loads(receipt['out-data']);(root/'windows-archive-receipt.json').write_text(json.dumps(meta,indent=2)+'\n')
 state['stage']='downloading-windows-archive';save();remote_script="""import subprocess,json,base64,sys
vm='omnisolve-winui-automation'
def call(name,args):
 r=subprocess.run(['virsh','qemu-agent-command',vm,'--timeout','30',json.dumps({'execute':name,'arguments':args})],capture_output=True,text=True,check=True);v=json.loads(r.stdout)
 if 'error' in v:raise RuntimeError(v['error'])
 return v['return']
h=call('guest-file-open',{'path':REMOTE,'mode':'rb'})
try:
 while True:
  r=call('guest-file-read',{'handle':h,'count':49152});sys.stdout.buffer.write(base64.b64decode(r.get('buf-b64','')));sys.stdout.buffer.flush()
  if r.get('eof'):break
finally:call('guest-file-close',{'handle':h})
""".replace('REMOTE',repr(base+r'\followup-evidence-v8.tar.gz'))
 archive=root/'windows-evidence.tar.gz'
 with archive.open('wb') as out:p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','pb60g.bravotekcorp.cc','python3','-u','-'],input=remote_script.encode(),stdout=out,stderr=subprocess.PIPE)
 assert p.returncode==0,p.stderr.decode();assert archive.stat().st_size==meta['bytes'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==meta['sha256']
 state.update(stage='windows-complete',conclusion=r['conclusion'],namedPassed=25,corePassed=82,verifiedSourceFiles=14619,archive=archive.name,archiveSha256=meta['sha256'],archiveBytes=meta['bytes']);save();print('Failed Windows candidate archived with its passing82core/25path results and extra Unicode-fixture failures',flush=True)
except BaseException as e:state.update(conclusion='failure',error=repr(e));save();raise
