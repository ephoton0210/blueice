from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-config-gates-20261109');captured={};statefile=root/'map-watch-state.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():statefile.write_text(json.dumps({'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captured':captured},indent=2)+'\n')
def bind(label,pid,executable):
 cli=repo/'target/debug/bluetsc';destination=root/(label+'-cli-snapshot');shutil.copy2(cli,destination);r={'sourceRevision':'backend-tree:295c886fbcc06ebecad8b087fbf5b31034836963','label':label,'pid':pid,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilerSha256':sha(destination),'compilerSnapshot':str(destination),'testExecutable':executable,'testExecutableSha256':sha(Path(executable)) if executable else None,'reportPath':str(Path(os.environ['TMPDIR'])/f'bluets-ge5-declaration-report-{pid}.json'),'scope':'Observed running G-E5 source-maps suite; final report/test terminal still pending'};r['reportNotBeforeEpoch']=time.time()-2;captured[label]=r;save()
while True:
 if 'native' not in captured:
  p=root/'native/current.json'
  if p.exists():
   r=json.loads(p.read_bytes())
   for row in r.get('active',[]):
    if row['harness']=='backend/bluets/tests/ge5_source_maps.rs':
     pid=row['pid'];lines=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True).strip();executable=lines.split()[0] if lines else None;bind('native',pid,executable);assert captured['native']['compilerSha256']==json.loads((root/'acceptance.json').read_bytes())['nativeCompilerSha256']
 if 'workspace' not in captured:
  p=root/'acceptance.json'
  if p.exists() and json.loads(p.read_bytes())['stage']=='workspace':
   rows=subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()
   for line in rows:
    a=line.split(None,1)
    if len(a)==2 and a[1].startswith(str(repo/'target/debug/deps/ge5_source_maps-')):bind('workspace',int(a[0]),a[1].split()[0])
 for label,r in captured.items():
  if r.get('verified'):continue
  p=Path(r['reportPath'])
  if p.exists():
   if p.stat().st_mtime < r['reportNotBeforeEpoch']:continue
   try:v=json.loads(p.read_bytes())
   except json.JSONDecodeError:continue
   assert v['configurations']==8407 and v['buildsPerConfiguration']==2 and not v['differences'],(label,v)
   out=root/(label+'-declaration-map-report.json');out.write_bytes(p.read_bytes());r.update(verified=True,reportFreshSinceBinding=True,reportModifiedEpoch=p.stat().st_mtime,reportSha256=sha(out),retainedReport=str(out),scope='Process-bound complete8407x2 declaration/JavaScript metadata/bounds report; final whole-suite/gates are recorded separately');(root/(label+'-map-binding.json')).write_text(json.dumps(r,indent=2)+'\n');save();print('Bound complete8407x2',label,flush=True)
 if len(captured)==2 and all(r.get('verified') for r in captured.values()):print('COMPLETE map report bindings',flush=True);break
 save();time.sleep(5)
