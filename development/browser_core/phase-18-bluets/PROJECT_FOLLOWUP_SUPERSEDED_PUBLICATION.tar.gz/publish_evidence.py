from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,tarfile
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';root=Path('/private/tmp/bluets-config-gates-20261109')
def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
frozen=read(root/'frozen-source.json');acceptance=read(root/'acceptance.json');native=read(root/'native/measurement.json');windows=read(root/'windows-measurement.json');winwatch=read(root/'windows-watch.json');project=read(root/'real-project/report.json')
assert acceptance['conclusion']=='success' and native['conclusion']=='success'
assert len(native['suites'])==181 and all(s['failed']==s['ignored']==s['filtered']==0 for s in native['suites'])
assert native['source_revision']==windows['sourceRevision']==project['sourceRevision']==frozen['sourceRevision']
assert windows['conclusion']==winwatch['conclusion']=='success' and windows['core82Passed']
assert len(windows['cases'])==25 and all(c['passed'] for c in windows['cases'])
assert len(windows['followups'])==3 and all(c['passed'] for c in windows['followups'])
assert windows['verifiedSourceFiles']==14619
assert project['compatible'] and project['declarations']['equal']
assert acceptance['workspace']['failed']==acceptance['workspace']['filtered']==0
maps={}
for role in ['native','workspace']:
 binding=read(root/(role+'-map-binding.json'));report=read(root/(role+'-declaration-map-report.json'))
 assert binding['sourceRevision']==frozen['sourceRevision'] and binding['verified'] and binding['reportFreshSinceBinding']
 assert report['configurations']==8407 and report['buildsPerConfiguration']==2 and not report['differences']
 assert binding['compilerSha256']==acceptance[role+'CompilerSha256']
 maps[role]={'binding':binding,'report':report}
index_tree=subprocess.check_output(['git','write-tree'],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','rev-parse',index_tree+':backend'],cwd=repo,text=True).strip()==frozen['backendTree']
# Keep complete source-bound compiler bytes, raw logs and maps. The Windows
# archive is separate to keep each repository artifact below GitHub's limit.
local_archive=root/'local-evidence.tar.gz'
exclude={'local-evidence.tar.gz','windows-evidence.tar.gz','baseline-cases.json','prior-attempts.tar.gz','superseded-gate.tar.gz'}
with tarfile.open(local_archive,'w:gz') as archive:
 for path in sorted(root.iterdir()):
  if path.name not in exclude:archive.add(path,arcname=path.name,recursive=True)
assert local_archive.stat().st_size < 95*1024*1024
windows_archive=root/'windows-evidence.tar.gz';assert sha(windows_archive)==winwatch['archiveSha256']
artifacts=[]
for source,name,scope in [(local_archive,'PROJECT_FOLLOWUP_LOCAL_EVIDENCE.tar.gz','Complete local gates, actual compiler bytes, original-project audit, raw reports and source bindings'),(windows_archive,'PROJECT_FOLLOWUP_WINDOWS_EVIDENCE.tar.gz','Windows source proof, 25 path tests, 82 selected core oracles, new regression cohorts and actual compiler bytes')]:
 destination=phase/name;shutil.copyfile(source,destination);artifacts.append({'path':name,'sha256':sha(destination),'bytes':destination.stat().st_size,'scope':scope})
# Earlier attempts are retained, never republished as the accepted source.
attempts=[Path('/private/tmp/bluets-followups-20261109'),Path('/private/tmp/bluets-followups-final-20261109'),Path('/private/tmp/bluets-followups-acceptance-20261109'),Path('/private/tmp/bluets-followups-release-20261109'),Path('/private/tmp/bluets-project-validation-20261109')]
attempts.append(Path('/private/tmp/bluets-gt1-gc1-gm2-20261109'))
attempt_archive=root/'prior-attempts.tar.gz'
if not attempt_archive.exists():
 with tarfile.open(attempt_archive,'w:gz') as archive:
  for attempt in attempts:
   for name in ['frozen-source.json','acceptance.json','acceptance-runner.log','source-patch.tar.gz','native','real-project','windows-measurement.json','windows-watch.json','windows-launch.json','windows-evidence.tar.gz','diagnostic-presentation.log','missing-state-proof.log','marker-state.log','local-origins.log']:
    path=attempt/name
    if path.exists():archive.add(path,arcname=attempt.name+'/'+name,recursive=True)
assert attempt_archive.stat().st_size < 95*1024*1024
name='PROJECT_FOLLOWUP_PRIOR_ATTEMPTS.tar.gz';shutil.copyfile(attempt_archive,phase/name);artifacts.append({'path':name,'sha256':sha(phase/name),'bytes':(phase/name).stat().st_size,'scope':'Historical failed, superseded and earlier-source results; no whole-gate acceptance is credited from these attempts'})
# Retain the seventh failed gate separately to keep every archive below the limit.
superseded=root/'superseded-gate.tar.gz'
with tarfile.open(superseded,'w:gz') as archive:
 for path in sorted(Path('/private/tmp/bluets-project-gates-20261109').iterdir()):
  if path.name not in {'prior-attempts.tar.gz','local-evidence.tar.gz'}:archive.add(path,arcname=path.name,recursive=True)
assert superseded.stat().st_size < 95*1024*1024
name='PROJECT_FOLLOWUP_SUPERSEDED_GATE.tar.gz';shutil.copyfile(superseded,phase/name);artifacts.append({'path':name,'sha256':sha(phase/name),'bytes':(phase/name).stat().st_size,'scope':'Earlier source72db: project configuration regression failed; the pending safe-home comparison was cancelled after that failure. No complete acceptance is credited.'})
cases=read(phase/'COMPATIBILITY_CASES.json');summary={'schema':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'conclusion':'complete-within-frozen-scope','source':frozen,'native':native,'localWorkspace':acceptance['workspace'],'localCommands':acceptance['steps'],'compilerSha256':{'native':acceptance['nativeCompilerSha256'],'workspace':acceptance['workspaceCompilerSha256'],'windows':windows['compiler']['sha256']},'project':project,'caseCounts':cases['counts'],'previousCaseIdentitiesPreserved':39426,'addedNativePrograms':71,'addedOwnerControlFamilies':14,'newMatrices':{'genericMethodsPrograms':53,'incrementalConfigurations':18,'readonlyOwnerFamilies':3,'incrementalOwnerFamilies':11},'sourceMapGates':maps,'windows':{k:v for k,v in windows.items() if k not in ['patchedSourceFiles']},'windowsSourceManifestSha256':sha(root/'windows-source-manifest.json'),'productionModules':read(root/'production-modules.json'),'fullTypeScriptParity':False,'limits':['The complete unchanged mitt project is measured under its frozen CommonJS/ES2022 strict profile.','Single-source Native interchange is finite. Native -p reconstructs its library graph from source-only exported metadata; transitive Native state triggers an owner-current rebuild and no Native warm no-op is claimed.','Unverifiable source-map markers and profiles outside Native interchange use owned state.','Broader unmeasured combinations remain open; no hosted CI or arm64 requirement is added.']}
dump(phase/'PROJECT_FOLLOWUP_MEASUREMENT.json',summary);dump(phase/'PROJECT_FOLLOWUP_ARTIFACTS.json',{'schema':1,'sourceRevision':frozen['sourceRevision'],'artifacts':artifacts});print(json.dumps({'sourceRevision':frozen['sourceRevision'],'nativeSuites':len(native['suites']),'nativeFunctions':sum(s['passed'] for s in native['suites']),'workspace':acceptance['workspace'],'cases':cases['counts'],'archives':artifacts},indent=2))
