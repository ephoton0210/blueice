from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time,sys
repo=Path('/Users/ephoton/git/blueice-bluets');phase=repo/'development/browser_core/phase-18-bluets';root=Path('/private/tmp/bluets-config-gates-20261109');frozen=json.loads((root/'frozen-source.json').read_text());revision=frozen['sourceRevision']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0')
state={'stage':'waiting-for-focused-regressions','sourceRevision':revision,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'conclusion':'in_progress'}
def save(): (root/'acceptance.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label;save();log=root/(label+'.log')
 with log.open('wb') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'label':label,'command':args,'exit':r.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
 if r.returncode: raise RuntimeError(f'{label}: exit {r.returncode}')
 return log
try:
 save()
 cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
 run('suite-write',cargo+['--write',revision]);run('source-check',cargo+['--check-staged'])
 run('native-build',['cargo','test','-p','blueice-bluets','-p','blueice-bluets-bluejs','--no-run','--locked','--offline'])
 run('config-preflight',['cargo','test','-p','blueice-bluets','--test','project_config','--test','gm2_incremental_options','--locked','--offline','--','--include-ignored'])
 cli=repo/'target/debug/bluetsc';state['nativeCompilerSha256']=hashlib.sha256(cli.read_bytes()).hexdigest();(root/'native-cli').write_bytes(cli.read_bytes());(root/'native-cli').chmod(0o755);save();env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['nativeCompilerSha256']
 run('real-project',['node',str(repo/'differential-testing/bluets-projects/audit.cjs'),'--compiler',str(root/'native-cli'),'--typescript',env['BLUEICE_BLUETSC_ORACLE'],'--output',str(root/'real-project'),'--source-tree',frozen['backendTree']])
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json')]:env[name]=str(root/'native-capture'/suffix)
 run('native',['node',str(phase/'tools/measure_compatibility_cases.cjs'),'--output-dir',str(root/'native'),'--staged-source','--jobs','4'])
 measurement=json.loads((root/'native/measurement.json').read_text());assert measurement['conclusion']=='success' and len(measurement['suites'])==181
 assert all(s['failed']==s['ignored']==s['filtered']==0 for s in measurement['suites']);state['native']={'suites':len(measurement['suites']),'functions':sum(s['passed'] for s in measurement['suites']),'failed':0,'ignored':0,'filtered':0};save()
 previous=json.loads((root/'baseline-cases.json').read_text())
 run('cases-write',cargo+['--write-cases',revision,str(root/'native/measurement.json')])
 current=json.loads((phase/'COMPATIBILITY_CASES.json').read_text())
 def cases(d):return {(s['harness'],c['id']):{k:c.get(k) for k in ['comparison','status','scope','reason']} for s in d['suites'] for c in s['cases']}
 before=cases(previous);after=cases(current);assert all(after.get(k)==v for k,v in before.items());assert len(after)-len(before)==85
 run('suite-labels',cargo+['--write',revision]);run('account-write',['python3',str(phase/'tools/account_inventory_rows.py'),'--write']);run('status-write',['python3',str(phase/'tools/check_compatibility_status.py'),'--write'])
 del env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']
 run('workspace-build',['cargo','test','--workspace','--no-run','--locked','--offline'])
 state['workspaceCompilerSha256']=hashlib.sha256(cli.read_bytes()).hexdigest();(root/'workspace-cli').write_bytes(cli.read_bytes());save()
 env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256']
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json')]:
  dest=root/'workspace-capture'/suffix;dest.parent.mkdir(parents=True,exist_ok=True)
  if name.endswith('DIRECTORY'):dest.mkdir(exist_ok=True)
  env[name]=str(dest)
 log=run('workspace',['cargo','test','--workspace','--no-fail-fast','--locked','--offline']);text=log.read_text(errors='replace');rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',text);assert rows and all(r[0]=='ok' and r[2]==r[4]=='0' for r in rows);state['workspace']={'passed':sum(int(r[1]) for r in rows),'failed':0,'ignored':sum(int(r[3]) for r in rows),'filtered':0,'groups':len(rows)};save()
 run('fmt-check',['cargo','fmt','--all','--','--check']);run('clippy',['cargo','clippy','--workspace','--all-targets','--features','blueice-bluets/windows-symlink-tests','--','-D','warnings'])
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))
 run('node-tools',['node','--test',*[str(p) for p in tests]]);run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,args)
 state['stage']='local-complete-awaiting-windows-and-publication';state['conclusion']='success';state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as e:
 state['conclusion']='failure';state['error']=repr(e);state['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();raise
