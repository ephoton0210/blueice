$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$base='B:\BlueIce\gm3-20261109-360d7d921'
if ((Get-FileHash "$base\followup-patch.tar.gz" -Algorithm SHA256).Hash -ne '0f8cb8a5351437ba833f350c8f05244920378c12d2a15e5e3a7772511299b1c8') {throw 'Follow-up patch mismatch'}
& tar.exe -xzf "$base\followup-patch.tar.gz" -C "$base\source"
if ($LASTEXITCODE -ne 0) {throw 'Patch extraction failed'}
& node.exe "$base\followup-runner.cjs"
if ($LASTEXITCODE -ne 0) {throw 'Windows follow-up verification failed'}
