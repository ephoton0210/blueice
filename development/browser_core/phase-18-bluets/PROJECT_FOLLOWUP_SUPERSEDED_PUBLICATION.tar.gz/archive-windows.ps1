$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$base='B:\BlueIce\gm3-20261109-360d7d921'
$state=Get-Content "$base\results-followups-v8\measurement.json" -Raw | ConvertFrom-Json
Copy-Item $state.compiler.path "$base\followup-bluetsc.exe"
& tar.exe -czf "$base\followup-evidence-v8.tar.gz" -C $base results-followups-v8 followup-runner.cjs followup-source-manifest.json followup-patch.tar.gz followup-bluetsc.exe
if ($LASTEXITCODE -ne 0) {throw 'Evidence archive failed'}
@{sha256=(Get-FileHash "$base\followup-evidence-v8.tar.gz" -Algorithm SHA256).Hash.ToLower();bytes=(Get-Item "$base\followup-evidence-v8.tar.gz").Length} | ConvertTo-Json -Compress
