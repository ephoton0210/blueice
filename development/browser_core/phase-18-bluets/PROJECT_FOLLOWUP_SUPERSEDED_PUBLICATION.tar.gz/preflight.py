from pathlib import Path
import os,subprocess,json,datetime,hashlib
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/private/tmp/bluets-config-gates-20261109')
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='4',BLUEICE_BLUETSC_ORACLE='/private/tmp/gm3-oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/private/tmp/gm3-oracles/node_modules/acorn/bin/acorn')
state={'conclusion':'in_progress','steps':[]}
for package,directory in [('blueice-bluets','bluets'),('blueice-bluets-bluejs','bluets-bluejs')]:
 names=sorted(p.stem for p in (repo/'backend'/directory/'tests').glob('*.rs') if not p.stem.startswith('ge5_'))
 args=['cargo','test','-p',package,'--locked','--offline','--no-fail-fast']
 for name in names:args.extend(['--test',name])
 log=root/(directory+'-ordinary-preflight.log');state['current']=package;(root/'preflight.json').write_text(json.dumps(state,indent=2)+'\n')
 with log.open('wb') as out:p=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 state['steps'].append({'package':package,'command':args,'exit':p.returncode,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 if p.returncode:state['conclusion']='failure';break
else:state['conclusion']='success'
(root/'preflight.json').write_text(json.dumps(state,indent=2)+'\n')
raise SystemExit(0 if state['conclusion']=='success' else 1)
