import { answer } from '../lib/value';
export function value(): number { return answer; }
