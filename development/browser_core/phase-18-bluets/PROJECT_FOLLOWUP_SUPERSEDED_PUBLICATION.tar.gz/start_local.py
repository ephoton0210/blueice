from pathlib import Path
import json,subprocess,time
root=Path('/private/tmp/bluets-config-gates-20261109')
while True:
 try:m=json.loads((root/'parallel-preflight-final/measurement.json').read_text())
 except json.JSONDecodeError:time.sleep(1);continue
 if m['conclusion']!='in_progress':break
 time.sleep(5)
assert m['conclusion']=='success' and m['sourcesUnchanged'] and m['compilerUnchanged']
assert len(m['suites'])==m['total']==191 and all(s['exit']==0 for s in m['suites'])
raise SystemExit(subprocess.run(['python3',str(root/'run_acceptance.py')]).returncode)
