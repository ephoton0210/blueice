// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Initial legacy behavior retained only long enough to measure the regression.
const path = require('node:path');
module.exports = function virtualCompilerHost(ts, host, entries) {
    const sources = new Map(entries), directories = new Set([...sources.keys()].map(path.dirname));
    const exists = host.fileExists.bind(host), readFile = host.readFile.bind(host);
    const directoryExists = host.directoryExists.bind(host), read = host.getSourceFile.bind(host);
    host.fileExists = file => sources.has(file) || exists(file);
    host.readFile = file => sources.get(file) ?? readFile(file);
    host.directoryExists = file => directories.has(file) || directoryExists(file);
    host.getSourceFile = (file, version, ...args) => sources.has(file)
        ? ts.createSourceFile(file, sources.get(file), version, true) : read(file, version, ...args);
    return host;
};
