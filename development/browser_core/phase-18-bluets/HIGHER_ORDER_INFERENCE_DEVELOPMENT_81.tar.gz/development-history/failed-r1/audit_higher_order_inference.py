# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Inspect source-bound P0-G reports against independently hashed physical products."""
import hashlib
import json


def audit_products(repo, source, compiler, base, names, content, require_native):
    fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
    digest = lambda data: hashlib.sha256(data).hexdigest()
    read = lambda name: json.loads(content(name))
    frozen = json.loads((fixture/'FROZEN.json').read_bytes())
    reference = json.loads((fixture/'reference.json').read_bytes())
    for name, wanted in frozen['sha256'].items():
        assert digest((fixture/name).read_bytes()) == wanted, name
    expected = {row['id']:row for row in reference['cases']}
    assert len(expected) == 384 and sum(row['accepts'] for row in expected.values()) == 352
    assert len(json.loads((fixture/'boundary-controls.json').read_bytes())['controls']) == 12
    base = base.rstrip('/')+'/'
    names = set(names)

    def reports(label):
        return sorted(name for name in names
            if name.startswith(base+'bluets-higher-order-inference-'+label+'-')
            and name.count('/') == base.count('/')+1 and name.endswith('/report.json'))

    found = reports('blue')
    assert len(found) == 1, found
    report_name = found[0]
    report = read(report_name)
    assert report['conclusion'] == 'success' and report['sourceRevision'] == source
    assert report['compilerSha256'] == compiler and report['frozenInputs'] == frozen['sha256']
    assert report['implementationSha256'] == reference['implementationSha256']
    assert report['libraries'] == reference['libraries']
    counts = {'comparisons':384,'accepted':352,'rejected':32,'declarationFiles':424,
        'consumers':704,'syntax':424,'runtime':48}
    assert all(report[key] == value for key,value in counts.items())
    assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 384
    assert {row['id'] for row in report['cases']} == set(expected)
    ordinary_hashes = {}
    for row in report['cases']:
        wanted = expected[row['id']]
        assert all(row[key] == wanted[key] for key in ['accepts','diagnostics','declarations'])
        assert row.get('consumers') == wanted.get('consumers')
        assert row.get('runtime') == wanted.get('runtime')
        location = report_name.rsplit('/',1)[0]+'/'+row['id']
        assert read(location+'/observation.json') == row
        for name,text in row['declarations'].items():
            assert content(location+'/dist/'+name) == text.encode('utf-8')
        for name,wanted_hash in row.get('javascriptSha256',{}).items():
            assert digest(content(location+'/dist/'+name)) == wanted_hash
        if not row['accepts']:
            assert not any(name.startswith(location+'/dist/') for name in names)
        ordinary_name = base+row['id']+'/observation.json'
        ordinary = read(ordinary_name)
        assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
        assert all(ordinary[key] == wanted[key] for key in ['id','accepts','diagnostics','declarations'])
        ordinary_hashes[row['id']] = digest(content(ordinary_name))

    found = reports('emission-controls')
    assert len(found) == 1, found
    emission_name = found[0]
    emission = read(emission_name)
    assert emission['conclusion'] == 'success' and emission['compilerSha256'] == compiler
    assert emission['implementationSha256'] == reference['implementationSha256']
    assert emission['inventoryCredit'] == emission['differences'] == 0
    assert emission['comparisons'] == len(emission['cases']) == 8
    tool = repo/'development/browser_core/phase-18-bluets/tools/higher_order_inference/emission_controls.cjs'
    assert emission['toolSha256'] == digest(tool.read_bytes())
    for row in emission['cases']:
        assert row['agrees'] and row['blueDeclarations'] == row['nativeDeclarations']
        assert row['blueRuntime']['runtime'] == row['nativeRuntime']['runtime']
        assert row['blueRuntime']['runtime']['exit'] == 0
        for mode in ['native','blue']:
            location = emission_name.rsplit('/',1)[0]+'/'+mode+'/'+row['id']
            for name,text in row[mode+'Declarations'].items():
                assert content(location+'/dist/'+name) == text.encode('utf-8')
            for name,wanted_hash in row[mode+'Runtime']['javascriptSha256'].items():
                assert digest(content(location+'/dist/'+name)) == wanted_hash
            assert read(location+'/runtime.json') == row[mode+'Runtime']['runtime']
        location = emission_name.rsplit('/',1)[0]
        assert content(location+'/native/'+row['id']+'/main.ts') == content(location+'/blue/'+row['id']+'/main.ts')

    native_report = None
    if require_native:
        found = reports('native')
        assert len(found) == 1 and read(found[0]) == reference
        location = found[0].rsplit('/',1)[0]
        for row in reference['cases']:
            project = location+'/'+row['id']
            assert read(project+'/observation.json') == row
            for name,text in row['declarations'].items():
                assert content(project+'/dist/'+name) == text.encode('utf-8')
            for name,wanted_hash in row.get('javascriptSha256',{}).items():
                assert digest(content(project+'/dist/'+name)) == wanted_hash
            if not row['accepts']:
                assert not any(name.startswith(project+'/dist/') for name in names)
        assert read(location+'/boundaries-report.json') == json.loads((fixture/'boundary-reference.json').read_bytes())
        native_report = {'path':found[0],'sha256':digest(content(found[0]))}
    return {'primaryReport':report_name,'primaryReportSha256':digest(content(report_name)),
        'compilerSha256':compiler,**counts,'separatePolicyControls':12,
        'ordinaryObservationsSha256':ordinary_hashes,'nativeReport':native_report,
        'supplementaryEmissionControls':{'path':emission_name,'sha256':digest(content(emission_name)),
            'comparisons':8,'differences':0,'inventoryCredit':0}}
