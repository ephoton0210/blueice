# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path, PurePosixPath
import ctypes, datetime, hashlib, json, os, tarfile, time
from ctypes import wintypes

base = Path('B:/BlueIce/gm3-20261109-360d7d921')
results = base / 'results-conditional-inference-r3'
source = base / 'p0c-authoring-preflight-1/source'
manifest_path = base / 'p0f-r3-source-manifest.json'
manifest = json.loads(manifest_path.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
state_path = base / 'p0f-r3-evidence-state.json'
assert not state_path.exists(), 'Inspect the existing evidence job before any retry'
state = {'pid':os.getpid(), 'stage':'verify-existing-test-process', 'conclusion':'in_progress',
         'sourceRevision':manifest['sourceRevision'],
         'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = state_path.with_suffix('.tmp'); p.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
    p.replace(state_path)

class ProcessEntry(ctypes.Structure):
    _fields_ = [('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('pid',wintypes.DWORD),
                ('heap',ctypes.c_size_t),('module',wintypes.DWORD),('threads',wintypes.DWORD),
                ('parent',wintypes.DWORD),('priority',wintypes.LONG),('flags',wintypes.DWORD),
                ('name',wintypes.WCHAR * 260)]

def existing_node(pid, parent):
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD,wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = [wintypes.HANDLE,ctypes.POINTER(ProcessEntry)]
    kernel.Process32NextW.argtypes = [wintypes.HANDLE,ctypes.POINTER(ProcessEntry)]
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.CreateToolhelp32Snapshot(2,0)
    assert handle and handle != ctypes.c_void_p(-1).value
    try:
        entry = ProcessEntry(); entry.dwSize = ctypes.sizeof(entry)
        current = kernel.Process32FirstW(handle,ctypes.byref(entry))
        while current:
            if entry.pid == pid:
                return entry.parent == parent and entry.name.lower() == 'node.exe'
            current = kernel.Process32NextW(handle,ctypes.byref(entry))
        return False
    finally:
        kernel.CloseHandle(handle)

try:
    save(); assert manifest['sourceRevision'].startswith('backend-tree:')
    bootstrap = read(base / 'p0f-r3-bootstrap/measurement.json')
    while True:
        measurement = read(results / 'measurement.json')
        if measurement['conclusion'] != 'in_progress':
            break
        if not existing_node(bootstrap['nodePid'],bootstrap['pid']):
            measurement = read(results / 'measurement.json')
            assert measurement['conclusion'] != 'in_progress', 'Known Node process ended without terminal evidence; do not restart'
            break
        state.update(stage='waiting-existing-tests', nodePid=bootstrap['nodePid'],
                     nodeParentPid=bootstrap['pid'], nodeIdentityVerifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(); time.sleep(10)
    assert measurement['conclusion'] == 'success' and measurement['stage'] == 'complete'
    assert measurement['sourceRevision'] == manifest['sourceRevision']
    assert measurement['expectedSourceManifestSha256'] == sha(manifest_path)
    assert measurement['verifiedSourceFiles'] == len(manifest['files'])
    assert measurement['verifiedBackendFiles'] == manifest['backendFiles']
    assert measurement['core82Exit'] == 0 and measurement['core82Passed']
    assert measurement['virtualHostRegressionExit'] == 0 and measurement['virtualHostRegressionsPassed']
    assert len(measurement['cases']) == 25 and all(r['passed'] and r['exit'] == 0 for r in measurement['cases'])
    assert len(measurement['followups']) == 16 and all(r['passed'] and r['exit'] == 0 for r in measurement['followups'])
    assert {r['target'] for r in measurement['followups']} == {'conditional_inference','gt2_inference','gt3_operators','gt5_compositions','jsx_checker_matrix','symbolic_keys','mapped_inference','string_intrinsics','gc1_object_generic_methods',
        'gm2_incremental_options','project_config','defu_prerequisites','callable_utilities',
        'receiver_utilities','noinfer','nonnullable_awaited'}
    selection = measurement['core82Selection']
    assert len(set(selection['selected'])) == len(selection['passed']) == 82
    assert sorted(selection['selected']) == sorted(selection['passed'])
    assert measurement['recovery']['preservedCohorts'] == 16 and measurement['recovery']['preservedPathCases'] == 7
    compiler = results / 'accepted-windows-cli.exe'
    assert sha(compiler) == measurement['compiler']['sha256'] == sha(Path(measurement['compiler']['path']))
    image = compiler.read_bytes(); pe = int.from_bytes(image[60:64],'little')
    assert image[pe:pe+4] == b'PE\x00\x00' and int.from_bytes(image[pe+4:pe+6],'little') == 0x8664
    state['stage'] = 'verifying-and-archiving-complete-source'; save()
    full_source = base / 'p0f-r3-full-source.tar.gz'; assert not full_source.exists()
    with tarfile.open(full_source,'w:gz') as archive:
        for name,digest in manifest['files'].items():
            relative = PurePosixPath(name); file = source / name
            assert not relative.is_absolute() and '..' not in relative.parts
            assert file.is_file() and not file.is_symlink() and sha(file) == digest, name
            archive.add(file,arcname=name,recursive=False)
    assert sha(base / 'p0f-r3-source-delta.tar.gz') == manifest['sourcePatchSha256']
    state['stage'] = 'archiving-complete-results-and-compiler'; save()
    destination = base / 'p0f-r3-windows-evidence.tar.gz'; assert not destination.exists()
    with tarfile.open(destination,'w:gz') as archive:
        for file in sorted(results.rglob('*')):
            assert not file.is_symlink(), file
            if file.is_file():
                archive.add(file,arcname=file.relative_to(base).as_posix(),recursive=False)
        for file,name in [(compiler,'accepted-windows-cli.exe'),(full_source,'full-source.tar.gz'),
            (base / 'p0f-r3-source-delta.tar.gz','source-delta.tar.gz'),(manifest_path,'windows-source-manifest.json'),
            (base / 'p0f-r3-windows-runner.cjs','windows-runner.cjs'),(base / 'p0f-r3-bootstrap.py','bootstrap.py')]:
            archive.add(file,arcname=name,recursive=False)
        for file,name in [(base / 'p0f-r3-continue-paths.cjs','continue-paths.cjs'),
                          (base / 'p0f-r3-bootstrap/runner.stderr','interrupted-runner.stderr')]:
            archive.add(file,arcname=name,recursive=False)
    for name,digest in manifest['files'].items():
        assert sha(source / name) == digest, name
    assert sha(compiler) == measurement['compiler']['sha256']
    receipt = {'sourceRevision':manifest['sourceRevision'], 'conclusion':'success',
        'archive':str(destination), 'archiveBytes':destination.stat().st_size, 'archiveSha256':sha(destination),
        'fullSourceArchiveSha256':sha(full_source), 'fullSourceFiles':len(manifest['files']),
        'compilerSha256':sha(compiler), 'compilerMachine':0x8664,
        'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (base / 'p0f-r3-windows-evidence.json').write_text(json.dumps(receipt,indent=2) + '\n',encoding='utf-8')
    state.update(stage='complete',conclusion='success',receipt=receipt); save()
    print(json.dumps(receipt),flush=True)
except BaseException as error:
    state.update(conclusion='failure',error=repr(error)); save(); raise
