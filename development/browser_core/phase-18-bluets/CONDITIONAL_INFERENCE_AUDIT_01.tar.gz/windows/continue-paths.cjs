// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const crypto = require('node:crypto'), assert = require('node:assert/strict');
const base = 'B:/BlueIce/gm3-20261109-360d7d921';
const source = path.join(base, 'p0c-authoring-preflight-1/source');
const out = path.join(base, 'results-conditional-inference-r3'); assert(fs.existsSync(out));
const hash = p => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const manifestPath = path.join(base, 'p0f-r3-source-manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath));
const env = {...process.env, CARGO_INCREMENTAL: '0', CARGO_BUILD_JOBS: '2',
    CARGO_PROFILE_DEV_DEBUG: '0', CARGO_PROFILE_TEST_DEBUG: '0', RUST_TEST_THREADS: '4',
    CARGO_HOME: 'B:/BlueIce/cache/cargo', CARGO_TARGET_DIR: path.join(base, 'target'),
    TEMP: path.join(base, 'temp'), TMP: path.join(base, 'temp'), FORCE_COLOR: '0',
    BLUEICE_BLUETSC_ORACLE: path.join(base, 'oracles/node_modules/.bin/tsc.cmd'),
    BLUEICE_ACORN_ORACLE: path.join(base, 'oracles/node_modules/.bin/acorn.cmd'),
    BLUEICE_DEFU_NATIVE_OBSERVATIONS: path.join(out, 'defu-native-raw')};
for (const key of Object.keys(env)) if (key.startsWith('BLUEICE_WRITE_') || key.startsWith('BLUETS_')) delete env[key];
const previousBytes = fs.readFileSync(path.join(out, 'measurement.json'));
const interruptedBytes = fs.readFileSync(path.join(out, 'measurement.tmp'));
const previous = JSON.parse(previousBytes), interrupted = JSON.parse(interruptedBytes);
assert.equal(previous.conclusion, 'in_progress');
assert.equal(interrupted.conclusion, 'failure');
assert.match(interrupted.error, /EPERM: operation not permitted, rename/);
assert.equal(interrupted.followups.length, 16); assert.equal(interrupted.cases.length, 7);
fs.writeFileSync(path.join(out, 'measurement.before-recovery.json'), previousBytes, {flag:'wx'});
fs.writeFileSync(path.join(out, 'measurement.interrupted.json'), interruptedBytes, {flag:'wx'});
const state = {...interrupted, pid:process.pid, conclusion:'in_progress', stage:'verify-resume',
    recovery:{originalRunnerPid:interrupted.pid, originalError:interrupted.error,
        originalLedgerSha256:hash(path.join(out,'measurement.before-recovery.json')),
        interruptedLedgerSha256:hash(path.join(out,'measurement.interrupted.json')),
        originalRunnerSha256:hash(path.join(base,'p0f-r3-windows-runner.cjs')),
        continuationSha256:hash(__filename), preservedCohorts:16, preservedPathCases:7,
        startedAt:new Date().toISOString()}};
delete state.error; delete state.finishedAt;

const save = () => {
    const temporary = path.join(out, 'measurement.tmp');
    fs.writeFileSync(temporary, JSON.stringify(state, null, 2) + '\n');
    for (let attempt=0;;attempt++) {
        try {fs.renameSync(temporary,path.join(out,'measurement.json')); break;}
        catch(error) {
            if (!['EPERM','EACCES','EBUSY'].includes(error.code) || attempt>=199) throw error;
            Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,20);
        }
    }
};
let compiler;
function compilerCheck() {
    if (compiler) {
        assert.equal(hash(compiler.path), compiler.sha256);
        assert.equal(hash(path.join(out, 'accepted-windows-cli.exe')), compiler.sha256);
    }
}
function run(program, args, label) {
    compilerCheck();
    state.stage = label; state.command = [program, ...args]; save();
    const stdout = fs.openSync(path.join(out, label + '.stdout'), 'wx');
    const stderr = fs.openSync(path.join(out, label + '.stderr'), 'wx');
    try {
        const child = cp.spawnSync(program, args, {cwd: source, env, stdio: ['ignore', stdout, stderr]});
        if (child.error) throw child.error;
        compilerCheck(); return child.status;
    } finally {fs.closeSync(stdout); fs.closeSync(stderr);}
}
try {
    save();
    const backend = Object.keys(manifest.files).filter(name => name.startsWith('backend/'))
        .sort((a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b)));
    assert.equal(backend.length, manifest.backendFiles);
    assert.equal(crypto.createHash('sha256').update(backend.join('\0')).digest('hex'), manifest.backendPathSetSha256);
    for (const [name, digest] of Object.entries(manifest.files)) assert.equal(hash(path.join(source, name)), digest, name);
    state.verifiedSourceFiles = Object.keys(manifest.files).length;
    state.verifiedBackendFiles = backend.length; state.backendPathSetSha256 = manifest.backendPathSetSha256;
    state.rustc = cp.execFileSync('rustc', ['--version'], {env, encoding: 'utf8'}).trim();
    state.cargo = cp.execFileSync('cargo', ['--version'], {env, encoding: 'utf8'}).trim();
    state.node = process.version;
    const matrix = JSON.parse(fs.readFileSync(path.join(source, 'development/browser_core/phase-18-bluets/GM3_FROZEN_MATRIX.json')));
    const cohorts = ['gt2_inference', 'gt3_operators', 'gt5_compositions', 'jsx_checker_matrix', 'conditional_inference', 'symbolic_keys', 'mapped_inference', 'string_intrinsics', 'gc1_object_generic_methods', 'gm2_incremental_options', 'project_config',
        'defu_prerequisites', 'callable_utilities', 'receiver_utilities', 'noinfer', 'nonnullable_awaited'];
    const targets = [...new Set([...matrix.cases.map(row => path.basename(row.source, '.rs')), 'typescript_oracle', ...cohorts])].sort();
    assert.equal(state.buildExit,0);
    const binaries = {};
    for (const line of fs.readFileSync(path.join(out, 'build.stdout'), 'utf8').split(/\r?\n/)) {
        let message; try {message = JSON.parse(line);} catch {continue;}
        if (message.reason !== 'compiler-artifact' || !message.executable) continue;
        if (message.profile.test) binaries[message.target.name] = message.executable;
        else if (message.target.name === 'bluetsc') compiler = {path: message.executable, sha256: hash(message.executable)};
    }
    assert(compiler); assert.equal(compiler.sha256,state.compiler.sha256); state.compiler=compiler; compilerCheck();
    env.BLUEICE_GE5_EXPECTED_COMPILER_SHA256 = compiler.sha256;
    for (const [stem, capture] of [['CALLABLE_UTILITIES', 'callable'], ['RECEIVER_UTILITIES', 'receiver'],
        ['NOINFER', 'noinfer'], ['NONNULLABLE_AWAITED', 'nonnullable-awaited'], ['STRING_INTRINSICS', 'string-intrinsics'], ['MAPPED_INFERENCE', 'mapped-inference'], ['SYMBOLIC_KEYS', 'symbolic-keys'], ['CONDITIONAL_INFERENCE', 'conditional-inference']]) {
        env['BLUEICE_' + stem + '_OBSERVATIONS'] = path.join(out, capture + '-observations');
        env['BLUEICE_' + stem + '_EXPECTED_COMPILER_SHA256'] = compiler.sha256;
    }
    env.BLUEICE_CALLABLE_SOURCE_REVISION = env.BLUEICE_RECEIVER_SOURCE_REVISION =
        env.BLUEICE_NOINFER_SOURCE_REVISION = env.BLUEICE_NONNULLABLE_AWAITED_SOURCE_REVISION =
        env.BLUEICE_STRING_INTRINSICS_SOURCE_REVISION = env.BLUEICE_MAPPED_INFERENCE_SOURCE_REVISION = env.BLUEICE_SYMBOLIC_KEYS_SOURCE_REVISION = env.BLUEICE_CONDITIONAL_INFERENCE_SOURCE_REVISION = manifest.sourceRevision;
    assert.equal(state.virtualHostRegressionExit,0); assert(state.virtualHostRegressionsPassed);
    for (const target of cohorts) {
        const row=state.followups.find(row=>row.target===target); assert(row && row.passed && row.exit===0);
        assert.equal(hash(binaries[target]),row.binarySha256);
        const log=fs.readFileSync(path.join(out,target+'.stdout'),'utf8');
        assert(/0 failed; 0 ignored;.*0 filtered out/.test(log));
    }
    const completedPaths=state.cases.length;
    for (const [index, row] of matrix.cases.entries()) {
        const target = path.basename(row.source, '.rs');
        const name = row.kind === 'oracle-row' ? 'pinned_rebuild_matrix' : row.name.split('::')[1];
        const label = String(index).padStart(2, '0') + '-' + target;
        if(index<completedPaths) {
            const passed=state.cases[index]; assert.equal(passed.id,row.name); assert.equal(passed.function,name);
            assert(passed.passed && passed.exit===0); assert.equal(hash(binaries[target]),passed.binarySha256);
            const log=fs.readFileSync(path.join(out,passed.stdout),'utf8');
            assert(/1 passed; 0 failed; 0 ignored;/.test(log));
            assert(log.includes('test '+name+' ... ok'));
            continue;
        }
        const exit = run(binaries[target], ['--exact', name, '--include-ignored', '--nocapture'], label);
        const text = fs.readFileSync(path.join(out, label + '.stdout'), 'utf8');
        state.cases.push({id: row.name, function: name, exit, passed: exit === 0 && /1 passed; 0 failed; 0 ignored;/.test(text),
            stdout: label + '.stdout', stderr: label + '.stderr', binarySha256: hash(binaries[target])}); save();
    }
    state.core82Exit = run(binaries.typescript_oracle, ['--ignored', '--nocapture'], 'core82');
    const text = fs.readFileSync(path.join(out, 'core82.stdout'), 'utf8');
    const ignored = cp.execFileSync(binaries.typescript_oracle, ['--list', '--ignored'], {env, encoding: 'utf8'});
    const all = cp.execFileSync(binaries.typescript_oracle, ['--list'], {env, encoding: 'utf8'});
    fs.writeFileSync(path.join(out, 'core82-ignored-catalog.txt'), ignored); fs.writeFileSync(path.join(out, 'core82-all-catalog.txt'), all);
    const selected = [...ignored.matchAll(/^(.+): test\r?$/gm)].map(match => match[1]).sort();
    const passed = [...text.matchAll(/^test (.+) \.\.\. ok\r?$/gm)].map(match => match[1]).sort();
    state.core82Selection = {selected, passed, ordinarySupportFiltered: 6};
    state.core82Passed = state.core82Exit === 0 && /82 passed; 0 failed; 0 ignored;.*6 filtered out/.test(text)
        && selected.length === 82 && JSON.stringify(selected) === JSON.stringify(passed)
        && [...all.matchAll(/^(.+): test\r?$/gm)].length === 88;
    for (const [name, digest] of Object.entries(manifest.files)) assert.equal(hash(path.join(source, name)), digest, name);
    compilerCheck();
    state.conclusion = state.followups.length === 16 && state.followups.every(row => row.passed)
        && state.cases.length === 25 && state.cases.every(row => row.passed) && state.core82Passed ? 'success' : 'failure';
    state.stage = 'complete'; state.finishedAt = new Date().toISOString(); state.recovery.completedAt=state.finishedAt; save();
    process.exitCode = state.conclusion === 'success' ? 0 : 1;
} catch (error) {
    state.error = error.stack; state.conclusion = 'failure'; state.finishedAt = new Date().toISOString(); save(); process.exitCode = 1;
}
