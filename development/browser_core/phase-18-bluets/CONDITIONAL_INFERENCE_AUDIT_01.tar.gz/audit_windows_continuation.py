# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Check that infrastructure recovery retains every earlier passed test."""
import hashlib
import json
import tarfile


def audit(root):
    read=lambda p:json.loads(p.read_bytes())
    digest=lambda data:hashlib.sha256(data).hexdigest()
    final=read(root/'windows/windows-measurement.json')
    old=read(root/'windows/interrupted-measurement.tmp.json')
    assert old['conclusion']=='failure'and 'EPERM: operation not permitted, rename' in old['error']
    assert final['conclusion']=='success'and final['sourceRevision']==old['sourceRevision']
    assert final['compiler']==old['compiler']
    assert final['followups']==old['followups']and len(final['followups'])==16
    assert final['cases'][:7]==old['cases']and len(final['cases'])==25
    assert all(row['passed']and row['exit']==0 for row in final['cases']+final['followups'])
    assert final['core82Passed']and final['core82Exit']==0
    recovery=final['recovery']
    assert recovery['preservedCohorts']==16 and recovery['preservedPathCases']==7
    assert recovery['interruptedLedgerSha256']==digest((root/'windows/interrupted-measurement.tmp.json').read_bytes())
    assert recovery['originalRunnerSha256']==digest((root/'windows/windows-runner.cjs').read_bytes())
    assert recovery['continuationSha256']==digest((root/'windows/continue-paths.cjs').read_bytes())
    with tarfile.open(root/'windows-evidence.tar.gz')as archive:
        prefix='results-conditional-inference-r3/'
        before=archive.extractfile(prefix+'measurement.before-recovery.json').read()
        interrupted=archive.extractfile(prefix+'measurement.interrupted.json').read()
        assert digest(before)==recovery['originalLedgerSha256']
        assert digest(interrupted)==recovery['interruptedLedgerSha256']
        assert json.loads(interrupted)==old
        assert archive.extractfile('continue-paths.cjs').read()==(root/'windows/continue-paths.cjs').read_bytes()
        error=archive.extractfile('interrupted-runner.stderr').read().decode()
        assert 'EPERM: operation not permitted, rename' in error
    return {'sourceRevision':final['sourceRevision'],'conclusion':'success',
            'originalRunnerExitWasInfrastructureFailure':True,
            'all16EarlierCohortsUnchanged':True,'all7EarlierPathResultsUnchanged':True,
            'newPathCases':18,'coreOracles':82,'compilerSha256':final['compiler']['sha256'],
            'continuationSha256':recovery['continuationSha256'],
            'interruptedLedgerSha256':recovery['interruptedLedgerSha256'],
            'scope':'Same frozen compiler/source/tools; complete results combine validated earlier passes with only the remaining executions.'}
