# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,shutil
repo=Path('/Users/ephoton/git/blueice-bluets')
phase=repo/'development/browser_core/phase-18-bluets'
root=Path('/Users/ephoton/git/blueice-bluets/target/conditional-inference-acceptance-20261114-r3')
frozen=json.loads((root/'frozen-source-preflight.json').read_text())
revision=frozen['sourceRevision']
cli=repo/'target/debug/bluetsc'
cargo=['cargo','run','-p','blueice-bluets','--example','compatibility_inventory','--locked','--offline','--']
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',BLUEICE_BLUETSC_ORACLE='/Users/ephoton/git/blueice-bluets/target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc',BLUEICE_ACORN_ORACLE='/Users/ephoton/git/blueice-bluets/target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn',FORCE_COLOR='0')
for key in list(env):
 if key.startswith('BLUEICE_WRITE_') or key.startswith('BLUETS_'): del env[key]
state={'sourceRevision':revision,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':'starting','conclusion':'in_progress','steps':[]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():(root/'local-gates.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args):
 state['stage']=label;save();log=root/(label+'.log');print('START',label,flush=True)
 with log.open('wb') as out:r=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True);state['steps'].append({'label':label,'command':args,'exit':r.returncode,'log':log.name,'sha256':sha(log)});save()
 if r.returncode:raise RuntimeError(f'{label}: exit {r.returncode}')
 return log

def captures(kind):
 base=root/(kind+'-capture')
 for name,suffix in [('BLUEICE_GC3_REPORT_DIRECTORY','gc3'),('BLUEICE_GE5_ROLE_REPORT_DIRECTORY','roles'),('BLUEICE_GE5_ROLE_OBSERVATION_DIRECTORY','observations'),('BLUEICE_GE5_ADJACENT_OBSERVATION_DIRECTORY','adjacent'),('BLUEICE_GE5_NODE_ROLE_REPORT','node-roles.json'),('BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS','callables'),('BLUEICE_RECEIVER_UTILITIES_OBSERVATIONS','receivers'),('BLUEICE_NOINFER_OBSERVATIONS','noinfer'),('BLUEICE_NONNULLABLE_AWAITED_OBSERVATIONS','nonnullable-awaited'),('BLUEICE_STRING_INTRINSICS_OBSERVATIONS','string-intrinsics'),('BLUEICE_MAPPED_INFERENCE_OBSERVATIONS','mapped-inference'),('BLUEICE_SYMBOLIC_KEYS_OBSERVATIONS','symbolic-keys'),('BLUEICE_CONDITIONAL_INFERENCE_OBSERVATIONS','conditional-inference')]:
  dest=base/suffix;dest.parent.mkdir(parents=True,exist_ok=True)
  if name.endswith('DIRECTORY') or name.endswith('OBSERVATIONS'):dest.mkdir(exist_ok=True)
  env[name]=str(dest)
 env['BLUEICE_CALLABLE_SOURCE_REVISION']=env['BLUEICE_RECEIVER_SOURCE_REVISION']=env['BLUEICE_NOINFER_SOURCE_REVISION']=env['BLUEICE_NONNULLABLE_AWAITED_SOURCE_REVISION']=env['BLUEICE_STRING_INTRINSICS_SOURCE_REVISION']=env['BLUEICE_MAPPED_INFERENCE_SOURCE_REVISION']=env['BLUEICE_SYMBOLIC_KEYS_SOURCE_REVISION']=env['BLUEICE_CONDITIONAL_INFERENCE_SOURCE_REVISION']=revision
try:
 gates=json.loads((root/'native-gates.json').read_text());assert gates['conclusion']=='success' and gates['sourceRevision']==revision
 assert len(gates['steps'])==5 and gates['steps'][-1]['label']=='native' and gates['steps'][-1]['exit']==0
 m=json.loads((root/'accepted-native/measurement.json').read_text());catalog=json.loads((phase/'COMPATIBILITY_SUITES.json').read_text());assert m['conclusion']=='success' and len(m['suites'])==len(catalog['suites'])==190
 assert m['source_revision']==revision and all(s['failed']==s['ignored']==s['filtered']==0 for s in m['suites'])
 assert sha(root/'accepted-native-cli')==gates['nativeCompilerSha256']==m['compilerSha256']
 assert sum(s['passed'] for s in m['suites'])==1081
 state['nativeCompilerSha256']=gates['nativeCompilerSha256'];state['native']={'suites':190,'functions':sum(s['passed'] for s in m['suites']),'failed':0,'ignored':0,'filtered':0};save()
 env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=gates['nativeCompilerSha256'];captures('projects')
 projects=json.loads((root/'project-gates.json').read_text());assert projects['conclusion']=='success' and projects['sourceRevision']==revision and projects['compilerSha256']==gates['nativeCompilerSha256']
 assert [step['label'] for step in projects['steps']]==['project-defu','project-mitt','project-reproductions','project-interchange']
 for step in projects['steps']:
  assert step['exit']==0 and sha(root/step['log'])==step['sha256']
 state['projects']=projects;save()
 run('cases-write',cargo+['--write-cases',revision,str(root/'accepted-native/measurement.json')]);previous=json.loads((root/'baseline-cases.json').read_text());current=json.loads((phase/'COMPATIBILITY_CASES.json').read_text())
 def cases(d):return {(s['harness'],c['id']):{k:c.get(k) for k in ['comparison','status','scope','reason']} for s in d['suites'] for c in s['cases']}
 before=cases(previous);after=cases(current);assert all(after.get(k)==v for k,v in before.items());assert len(after)-len(before)==396;assert all(h=='backend/bluets/tests/conditional_inference.rs' for h,i in set(after)-set(before));state['casePreservation']={'previous':len(before),'current':len(after),'added':396,'allOldCasesUnchanged':True};save()
 run('suite-labels',cargo+['--write',revision]);run('account-write',['python3',str(phase/'tools/account_inventory_rows.py'),'--write']);run('status-write',['python3',str(phase/'tools/check_compatibility_status.py'),'--write'])
 del env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256'];env['RUST_TEST_THREADS']='4';captures('workspace');run('workspace-build',['cargo','test','--workspace','--no-run','--locked','--offline']);state['workspaceCompilerSha256']=sha(cli);shutil.copy2(cli,root/'accepted-workspace-cli');save();env['BLUEICE_GE5_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256'];env['BLUEICE_NONNULLABLE_AWAITED_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256'];env['BLUEICE_STRING_INTRINSICS_EXPECTED_COMPILER_SHA256']=env['BLUEICE_MAPPED_INFERENCE_EXPECTED_COMPILER_SHA256']=env['BLUEICE_SYMBOLIC_KEYS_EXPECTED_COMPILER_SHA256']=env['BLUEICE_CONDITIONAL_INFERENCE_EXPECTED_COMPILER_SHA256']=state['workspaceCompilerSha256']
 log=run('workspace',['cargo','test','--workspace','--no-fail-fast','--locked','--offline']);rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',log.read_text(errors='replace'));assert rows and all(r[0]=='ok' and r[2]==r[4]=='0' for r in rows);state['workspace']={'passed':sum(int(r[1]) for r in rows),'failed':0,'ignored':sum(int(r[3]) for r in rows),'filtered':0,'groups':len(rows)};save()
 for family,script,variable in [('callable','verify_callable_utilities.cjs','BLUEICE_CALLABLE_UTILITIES_COMPILER'),('receiver','verify_receiver_utilities.cjs','BLUEICE_RECEIVER_UTILITIES_COMPILER'),('noinfer','verify_noinfer.cjs','BLUEICE_NOINFER_COMPILER'),('nonnullable-awaited','verify_nonnullable_awaited.cjs','BLUEICE_NONNULLABLE_AWAITED_COMPILER'),('string-intrinsics','verify_string_intrinsics.cjs','BLUEICE_STRING_INTRINSICS_COMPILER'),('mapped-inference','verify_mapped_inference.cjs','BLUEICE_MAPPED_INFERENCE_COMPILER'),('symbolic-keys','verify_symbolic_keys.cjs','BLUEICE_SYMBOLIC_KEYS_COMPILER'),('conditional-inference','verify_conditional_inference.cjs','BLUEICE_CONDITIONAL_INFERENCE_COMPILER')]:
  env[variable]=str(root/'accepted-workspace-cli')
  run('workspace-'+family+'-oracles',['node',str(phase/'tools'/script)])
 run('workspace-noinfer-regressions',['node',str(phase/'tools/verify_noinfer_regressions.cjs')])
 run('fmt-check',['cargo','fmt','--all','--','--check']);run('clippy',['cargo','clippy','--workspace','--all-targets','--features','blueice-bluets/windows-symlink-tests','--','-D','warnings'])
 tests=sorted((phase/'tools').glob('*.test.cjs'))+sorted((repo/'backend/bluets/tests/fixtures/oracle_support').glob('*.test.cjs'))+sorted((repo/'differential-testing/bluets-projects').glob('*.test.cjs'));run('node-tools',['node','--test',*[str(p) for p in tests]]);run('python-tools',['python3','-m','unittest','discover','-s',str(phase/'tools'),'-p','test_*.py'])
 for label,args in [('source-final',cargo+['--check-staged']),('cases-final',cargo+['--check-cases-staged']),('account-final',['python3',str(phase/'tools/account_inventory_rows.py'),'--check']),('status-final',['python3',str(phase/'tools/check_compatibility_status.py'),'--check'])]:run(label,args)
 state.update(stage='local-complete-awaiting-windows-and-publication',conclusion='success',finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except BaseException as e:state.update(conclusion='failure',error=repr(e),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
