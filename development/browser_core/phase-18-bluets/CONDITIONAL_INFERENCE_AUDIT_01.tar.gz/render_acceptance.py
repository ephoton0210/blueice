# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Close only the finite P0-F item after independent publication verification."""
import re
from audit_acceptance import ROOT, PHASE, read


def main():
    proof = read(ROOT / 'publication-before-todo-verification.json')
    data = read(PHASE / 'CONDITIONAL_INFERENCE_MEASUREMENT.json')
    source = data['source']['sourceRevision']
    assert proof['conclusion'] == 'success' and proof['sourceRevision'] == source
    assert proof['todoExpectedOpen'] and data['conclusion'] == 'completed-within-frozen-scope'
    workspace = data['gates']['workspace']
    document = f'''# P0-F — Conditional infer candidates and complete matching

Accepted within the frozen P0-F contract. Compiler/oracle source:
`{source}`. The source manifest also binds every oracle tool byte; a backend
revision alone does not identify an oracle-tool revision.

Conditional inference collects covariant and contravariant evidence separately,
validates the completed pattern, retains method/alias variance and uses constraints
or unknown when a position supplies no candidate. Readonly/optional/variadic tuple
matching preserves fixed endpoints. Concrete any checks retain both possible
branches. Conditions without infer parameters use one complete assignability
relation, avoiding repeated expansion under the original work budget.

The unchanged original 24 programs pass with both actual Mac compiler profiles
and their original explicit ES5 library. The expanded contract fixes 48 forms
across eight ES5/ES2022 × CommonJS/ESNext × strictFunctionTypes true/false profiles.
Every complete diagnostic, UTF-16 position and physical declaration byte matches
pinned TypeScript 5.9.3. No declaration sorting or newline normalization is used.

| Acceptance requirement | Verified result |
| --- | --- |
| Primary matrix | 384 comparisons: 360 accepted, 24 rejected |
| Exact declarations | 368 files per actual compiler |
| Isolated declaration consumers | 720 positive/negative programs per actual compiler |
| Selected-edition syntax / execution | 368 parses /48 executions per actual compiler |
| Separate owner/runtime/resource controls | 12; excluded from direct-agreement credit |
| Alias identity supplement | 24 comparisons /24 parses; zero inventory credit |
| Complete Native catalog | 190 suites /1081 functions; zero failed, ignored or filtered |
| Complete local workspace | {workspace['passed']} passed; {workspace['failed']} failed; {workspace['ignored']} ignored, with the complete Native catalog selected separately |
| Declaration/JavaScript maps | 8407 configurations ×2 builds for each actual Mac compiler profile; zero differences |
| Real projects | defu, mitt, reproductions and interchange gates pass |
| Windows x86_64 | Same-source 82 core oracles, 25 paths and 16 complete regression cohorts |
| Native virtual host regression | Six checks of imported declarations, exact output and rejection across POSIX/Windows path forms; also verified on Windows |
| Tooling | Format, warnings-denied workspace/all-target Clippy, Node/Python and accounting checks pass |
| Module size | 576 production Rust/declaration files; maximum {data['modules']['maximumLines']} lines |

The accepted-E baseline retains all 384 physical observations: 144 complete
agreements and 240 complete differences, including sixteen Native-rejected inputs
that incorrectly published BlueTSC output. The test-first public-boundary red run
independently reproduces every baseline observation. Frozen Native results were
never replaced with BlueTSC output.

All 42320 earlier suite-qualified assertion IDs and their comparison/status/scope/
reason classes remain unchanged. The 384 primary observations and twelve separate
controls add 396 assertions, producing N=42716. The alias supplement, original
24-program replay and virtual-host regression add no denominator credit.

Earlier compile, callable-erasure, Awaited and resource failures are preserved
with their original sources and logs. The first formal candidate failed G-T3
resource checks and Windows library metadata collection. The second passed the
complete Windows P0-F cohort but exposed virtual-path lookup in an older G-T2
oracle; its Mac run was deliberately stopped after that independent gate failed.
A shared virtual host fixes the affected G-T2/G-T3/G-T5/key-profile tools and
keeps declaration bytes intact. A later Windows ledger rename returned EPERM
after sixteen complete cohorts and seven path cases had passed. The continuation
preserves both interrupted ledgers, rechecks every source and executable hash,
validates completed logs and runs only the remaining eighteen paths plus82 core
oracles. The original launcher failure remains visible; no passed test is dropped.
Before the local gate started, a tuple-key typo in its environment assignment was
reproduced and repaired. The original script and hash manifest, exact one-line
change and successful subprocess check are retained in the measurement's
orchestration-amendment reference. Product and oracle sources stayed frozen.
The first local evidence audit also found its frozen-tool manifest had not yet
been materialized because of driver ordering. All611 hashes were verified against
the earlier immutable source manifest before re-running the unchanged independent
auditor against the same received Windows archive. No Windows test was repeated.
All earlier failed candidates receive zero final acceptance credit. The development-history index records the unavailable original
preflight-3 executable explicitly; its sources/logs and separate traced diagnostic
executable remain preserved.

[Measurement](CONDITIONAL_INFERENCE_MEASUREMENT.json),
[artifact index](CONDITIONAL_INFERENCE_ARTIFACTS.json),
[contract/history](CONDITIONAL_INFERENCE_FOLLOWUP.md) and
[reproduction guide](CONDITIONAL_INFERENCE_REPRODUCTION.md) retain the source
bindings, original compilers, complete products, raw logs and pinned oracle
packages with their licenses. Bounded archives and separately hashed member
manifests were independently inspected. Rejected inputs publish no output.

Only finite P0-F is complete. All 22 broader G-* rows remain open and full
TypeScript parity remains OFF. The user-approved full-local/Windows-82 boundary
is unchanged; hosted CI and other platform combinations are supplementary.
'''
    (PHASE / 'CONDITIONAL_INFERENCE_ACCEPTANCE.md').write_text(document)
    todo_path = PHASE / 'TODO.md'
    todo = todo_path.read_text()
    accepted = '''- [x] **P0-F — Conditional infer candidates and complete matching.** Delivered
  48 forms ×eight profiles =384 complete comparisons: 360 accepts /24 rejects,
  368 exact declarations, 720 isolated consumers, 368 parses and 48 executions
  per actual compiler. Twelve policy controls remain separate; 24 alias identity
  controls and the original 24-program replay add zero inventory credit.
  Complete same-source Native/local/Windows, maps, projects and tooling pass.
  All 42320 prior assertion IDs/classes remain unchanged; 396 additions bring
  N to 42716. [Acceptance](CONDITIONAL_INFERENCE_ACCEPTANCE.md) ·
  [measurement](CONDITIONAL_INFERENCE_MEASUREMENT.json). Broader rows remain open.'''
    todo, changed = re.subn(r'- \[ \] \*\*P0-F —.*?(?=\n\nEach package)', accepted, todo, flags=re.S)
    assert changed == 1
    latest = '''**Latest completed follow-up:** P0-F repairs conditional inference candidate
variance, completed-pattern checks, missing positions and tuple matching.
[Acceptance](CONDITIONAL_INFERENCE_ACCEPTANCE.md) binds complete
Native/local/Windows, maps, projects and tooling to the frozen source and oracle
tools. Earlier packages retain their dated evidence. All 22 broader rows remain
open; their remaining scope needs separate frozen contracts and measurements.'''
    todo, changed = re.subn(r'\*\*Latest completed follow-up:\*\*.*?(?=\n\n## Open gaps)', latest, todo, flags=re.S)
    assert changed == 1
    todo = todo.replace('P0-A/B/C/D have\ncomplete source-bound acceptance within their frozen contracts.',
                        'P0-A/B/C/D/E/F have\ncomplete source-bound acceptance within their frozen contracts.', 1)
    todo_path.write_text(todo)
    path = PHASE / 'CONDITIONAL_INFERENCE_FOLLOWUP.md'
    history = path.read_text()
    assert history.startswith('# P0-F') and 'Status: open;' in history
    history = history.replace('Status: open; implementation and regression validation are in progress.',
        'Status: accepted within the frozen P0-F scope. See [complete acceptance](CONDITIONAL_INFERENCE_ACCEPTANCE.md); earlier checkpoints below retain their historical scope.', 1)
    history += '\n\n## Final acceptance\n\nThe complete same-source Native/local/Windows, map, project and tooling gates\npass. The [measurement](CONDITIONAL_INFERENCE_MEASUREMENT.json) binds every\naccepted result to actual compiler bytes and the final oracle-tool manifest.\nEarlier failed or canceled attempts remain separate. Only P0-F is checked;\nall 22 broader rows remain open and full TypeScript parity remains OFF.\n'
    path.write_text(history)
    (PHASE / 'CONDITIONAL_INFERENCE_REPRODUCTION.md').write_text((ROOT / 'reproduction-draft.md').read_text())
    print('Marked only P0-F after complete published-evidence verification.')


if __name__ == '__main__':
    main()
