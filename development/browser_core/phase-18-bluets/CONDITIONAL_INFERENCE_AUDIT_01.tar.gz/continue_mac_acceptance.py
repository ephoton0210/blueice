# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""One Mac Cargo pipeline plus one separately supervised Windows target."""
from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, sys, time

root = Path(__file__).resolve().parent
repo = root.parent.parent
preflight_path = repo / 'target/conditional-inference-contract-20261114/quality-4/measurement.json'
state_path = root / 'acceptance-mac-continuation.json'
assert not state_path.exists(), 'Inspect the existing acceptance process before retry'
state = {'pid': os.getpid(), 'stage': 'verify-existing-quality', 'conclusion': 'in_progress', 'steps': []}
sidecars = {}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temp = state_path.with_suffix('.tmp'); temp.write_text(json.dumps(state, indent=2) + '\n'); temp.replace(state_path)


def source_check():
    frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == frozen['parentCommit']
    for name, digest in frozen['files'].items():
        assert sha(repo / name) == digest, name


def run(label, script):
    state['stage'] = label; save()
    log = root / (label + '-driver.log')
    print('START', label, flush=True)
    with log.open('xb') as output:
        child = subprocess.Popen([sys.executable, '-B', str(root / script)], cwd=repo, stdout=output, stderr=subprocess.STDOUT)
        state['childPid'] = child.pid; save(); code = child.wait()
    state['steps'].append({'label': label, 'exit': code, 'log': log.name, 'sha256': sha(log)})
    state.pop('childPid', None); save(); print('END', label, code, flush=True)
    assert code == 0, (label, code)


def sidecar(label, script):
    log = (root / (label + '-driver.log')).open('xb')
    child = subprocess.Popen([sys.executable, '-B', str(root / script)], cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    log.close(); sidecars[label] = child
    state.setdefault('sidecars', {})[label] = {'pid': child.pid, 'script': script}; save()


try:
    save()
    original = json.loads((root / 'acceptance-driver.json').read_bytes())
    assert original['conclusion'] == 'failure' and original['stage'] == 'windows'
    state['sourceRevision'] = original['sourceRevision']; save(); source_check()
    failed_recovery = json.loads((root / 'acceptance-recovery.json').read_bytes())
    assert failed_recovery['conclusion'] == 'failure' and not failed_recovery['steps']
    receiver = json.loads((root / 'windows/finalize-state.json').read_bytes())
    assert receiver['conclusion'] == 'failure' and receiver['stage'] == 'independent-audit'
    assert 'frozen-final-oracle-tools.json' in receiver['error']
    verification = json.loads((root / 'windows/windows-acceptance-verification.json').read_bytes())
    assert verification['conclusion'] == 'success' and verification['sourceRevision'] == state['sourceRevision']
    state['windowsVerificationSha256'] = sha(root / 'windows/windows-acceptance-verification.json'); save()
    source_check()
    sidecar('maps', 'watch_maps.py')
    sidecar('original-workspace', 'replay_workspace_for_mac_continuation.py')
    for label, script in [('native', 'run_native_gates.py'), ('projects', 'run_project_gates.py'), ('local', 'run_local_gates.py')]:
        source_check(); run(label, script)
        if label == 'projects':
            state['stage'] = 'original-native-profile'; save()
            dependencies = repo / 'target/noinfer-acceptance-20261112/oracles/node_modules'
            environment = dict(os.environ,
                BLUEICE_BLUETSC_ORACLE=str(dependencies / 'typescript/bin/tsc'),
                BLUEICE_ACORN_ORACLE=str(dependencies / 'acorn/bin/acorn'))
            log = root / 'original-discovery24-native.log'
            with log.open('xb') as output:
                child = subprocess.Popen(['node', str(root / 'replay_original_discovery.cjs'), 'native'],
                    cwd=repo, env=environment, stdout=output, stderr=subprocess.STDOUT)
                state['childPid'] = child.pid; save(); code = child.wait()
            state['steps'].append({'label': 'original-native-profile', 'exit': code,
                                  'log': log.name, 'sha256': sha(log)})
            state.pop('childPid', None); save()
            assert code == 0, 'Original 24-program profile replay failed'

    state['stage'] = 'waiting-sidecars'; save()
    for label, child in sidecars.items():
        code = child.wait(); state['sidecars'][label]['exit'] = code; save()
        assert code == 0, (label, code)
    source_check()
    state.update(stage='all-gates-complete-awaiting-publication-audit', conclusion='success'); save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error)); save()
    if 'maps' in sidecars and sidecars['maps'].poll() is None:
        sidecars['maps'].terminate(); state['sidecars']['maps']['exit'] = sidecars['maps'].wait(); save()
    raise
