# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Continue only remaining Windows cases after a verified ledger-write failure."""
from pathlib import Path
import base64, datetime, hashlib, importlib.util, json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('qga',root.parent/'noinfer-acceptance-20261112/recovery/qga_transfer.py')
qga=importlib.util.module_from_spec(spec);spec.loader.exec_module(qga)
base='B:/BlueIce/gm3-20261109-360d7d921/'
state_path=root/'windows/recovery-state.json';assert not state_path.exists()
state={'pid':os.getpid(),'conclusion':'in_progress','stage':'verify-interruption'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 state['recordedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=state_path.with_suffix('.tmp');p.write_text(json.dumps(state,indent=2)+'\n');p.replace(state_path)
def upload(local,remote):
 data=local.read_bytes();handle=qga.call({'execute':'guest-file-open','arguments':{'path':remote,'mode':'wb'}})
 try:
  for offset in range(0,len(data),65536):
   block=data[offset:offset+65536];r=qga.call({'execute':'guest-file-write','arguments':{'handle':handle,'buf-b64':base64.b64encode(block).decode()}});assert r['count']==len(block)
 finally:qga.call({'execute':'guest-file-close','arguments':{'handle':handle}})
def wait(pid,label):
 while True:
  r=qga.call({'execute':'guest-exec-status','arguments':{'pid':pid}})
  state.update(stage='waiting-'+label,lastGuestStatus=r);save()
  if r.get('exited'):
   for key in ['out-data','err-data']:
    if key in r:r[key]=base64.b64decode(r[key]).decode('utf-8-sig',errors='replace')
   (root/'windows'/('recovery-'+label+'-terminal.json')).write_text(json.dumps(r,indent=2)+'\n');assert r['exitcode']==0,r;return
  time.sleep(10)
try:
 save();old=json.loads((root/'windows/interrupted-measurement.tmp.json').read_bytes())
 assert old['conclusion']=='failure'and len(old['followups'])==16 and len(old['cases'])==7
 assert 'EPERM: operation not permitted, rename' in old['error']
 for name,remote in [('continue-paths.cjs','p0f-r3-continue-paths.cjs'),('package-recovered-evidence.py','p0f-r3-package-recovered-evidence.py')]:upload(root/'windows'/name,base+remote)
 code="import subprocess,sys;sys.exit(subprocess.call(['node',"+repr(base+'p0f-r3-continue-paths.cjs')+"]))"
 process=qga.call({'execute':'guest-exec','arguments':{'path':'C:\\Program Files\\Python312\\python.exe','arg':['-c',code],'capture-output':True}})
 state.update(stage='continuation-launched',continuationPid=process['pid']);save()
 (root/'windows/continuation-process.json').write_text(json.dumps(process,indent=2)+'\n');wait(process['pid'],'continuation')
 qga.download(base+'results-conditional-inference-r3/measurement.json',root/'windows/recovered-measurement.json')
 measured=json.loads((root/'windows/recovered-measurement.json').read_bytes());assert measured['conclusion']=='success'
 state['stage']='packaging-existing-results';save()
 process=qga.call({'execute':'guest-exec','arguments':{'path':'C:\\Program Files\\Python312\\python.exe','arg':['-B',base+'p0f-r3-package-recovered-evidence.py'],'capture-output':True}})
 (root/'windows/package-process.json').write_text(json.dumps({'process':process},indent=2)+'\n')
 state.update(stage='receiving-evidence',packagePid=process['pid']);save()
 with(root/'windows/recovered-finish.log').open('xb')as log:
  child=subprocess.Popen([sys.executable,'-B',str(root/'finish_windows.py')],stdout=log,stderr=subprocess.STDOUT);state['receiverPid']=child.pid;save();code=child.wait()
 assert code==0,(root/'windows/recovered-finish.log').read_text()[-3000:]
 state.update(conclusion='success',stage='complete');save()
except BaseException as error:state.update(conclusion='failure',error=repr(error));save();raise
