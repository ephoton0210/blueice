# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Replay the original profile when the immutable workspace compiler is ready."""
from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, time

root = Path(__file__).resolve().parent
repo = root.parent.parent
state_path = root / 'original-discovery24/workspace-supervisor.json'
assert not state_path.exists(), 'Inspect the existing watcher before retry'
state = {'pid': os.getpid(), 'stage': 'waiting-workspace-compiler', 'conclusion': 'in_progress'}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state_path.write_text(json.dumps(state, indent=2) + '\n')


try:
    save()
    while True:
        try:
            master = json.loads((root / 'acceptance-recovery.json').read_bytes())
            local_path = root / 'local-gates.json'
            local = json.loads(local_path.read_bytes()) if local_path.exists() else {}
        except json.JSONDecodeError:
            time.sleep(1)
            continue
        assert master['conclusion'] != 'failure', master.get('error')
        compiler = root / 'accepted-workspace-cli'
        if local.get('workspaceCompilerSha256') and compiler.exists():
            digest = hashlib.sha256(compiler.read_bytes()).hexdigest()
            assert digest == local['workspaceCompilerSha256']
            break
        process = subprocess.run(['ps', '-p', str(master['pid']), '-o', 'command='],
                                 capture_output=True, text=True)
        assert process.returncode == 0, 'Acceptance process is no longer live; do not restart it'
        arguments = shlex.split(process.stdout.strip())
        assert arguments and Path(arguments[-1]).name == 'recover_acceptance.py'
        state.update(masterPid=master['pid'], masterProcessVerifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(); time.sleep(10)
    state.update(stage='replaying-original-profile', compilerSha256=digest); save()
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('BLUETS_', 'BLUEICE_WRITE_'))}
    dependencies = repo / 'target/noinfer-acceptance-20261112/oracles/node_modules'
    env['BLUEICE_BLUETSC_ORACLE'] = str(dependencies / 'typescript/bin/tsc')
    env['BLUEICE_ACORN_ORACLE'] = str(dependencies / 'acorn/bin/acorn')
    with (root / 'original-discovery24-workspace.log').open('xb') as output:
        child = subprocess.Popen(['node', str(root / 'replay_original_discovery.cjs'), 'workspace'],
                                 cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
        state['childPid'] = child.pid; save(); code = child.wait()
    assert code == 0, 'Inspect the original-profile replay; never replace the frozen reference'
    report = json.loads((root / 'original-discovery24/replay-workspace/report.json').read_bytes())
    assert report['conclusion'] == 'success' and report['compilerSha256'] == digest
    state.update(stage='complete', conclusion='success', comparisons=len(report['cases'])); save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error)); save(); raise
