# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Publish P0-F only after its complete same-source acceptance audit."""
from pathlib import Path
import datetime
import json
import shutil
import subprocess
from artifact_pack import PREFIX, LIMIT, publish_group, write_json
from audit_acceptance import audit, ROOT, REPO, PHASE, read, sha


def preserve_audit():
    result = audit()
    path = ROOT / 'acceptance-audit.json'
    if path.exists():
        previous = read(path)
        assert {k: v for k, v in previous.items() if k != 'recordedAt'} == {
            k: v for k, v in result.items() if k != 'recordedAt'}
        return previous
    write_json(path, result)
    return result


def original_discovery(receipt):
    bindings = {}
    for kind in ['native', 'workspace']:
        path = ROOT / 'original-discovery24' / ('replay-' + kind) / 'report.json'
        report = read(path)
        assert report['conclusion'] == 'success' and report['inventoryCredit'] == 0
        assert report['sourceRevision'] == receipt['sourceRevision']
        assert report['compilerSha256'] == receipt['gates'][kind + 'CompilerSha256']
        assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 24
        assert len(report['libraries']) == 3
        assert all(row['agrees'] and not row['publishedOnRejectedNativeInput'] for row in report['cases'])
        bindings[kind] = {'path': str(path.relative_to(ROOT)), 'sha256': sha(path),
                          'comparisons': 24, 'libraries': 3, 'inventoryCredit': 0}
    return bindings


def main():
    supervisor = read(ROOT / 'acceptance-mac-continuation.json')
    assert supervisor['conclusion'] == 'success'
    assert supervisor['stage'] == 'all-gates-complete-awaiting-publication-audit'
    receipt = preserve_audit()
    original = original_discovery(receipt)
    frozen = read(ROOT / 'frozen-source-preflight.json')
    gates = receipt['gates']
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--',
        'backend', 'development/browser_core/phase-18-bluets/tools'], cwd=REPO)
    patch_path = ROOT / 'accepted-source.patch'
    if patch_path.exists():
        assert patch_path.read_bytes() == patch
    else:
        patch_path.write_bytes(patch)

    groups = {label: [] for label in ['COMPILERS', 'NATIVE', 'WORKSPACE', 'DEVELOPMENT', 'AUDIT']}
    compiler_names = {'accepted-native-cli', 'accepted-workspace-cli', 'baseline-cli',
        'native-cli-snapshot', 'workspace-cli-snapshot',
        'native-map-test-executable', 'workspace-map-test-executable'}
    native_names = {'accepted-native', 'native-capture', 'project-defu', 'project-mitt',
                    'project-reproductions', 'project-interchange'}
    for file in sorted(ROOT.rglob('*')):
        assert not file.is_symlink(), file
        if not file.is_file() or '__pycache__' in file.parts or file.name.endswith('.pyc'):
            continue
        relative = file.relative_to(ROOT)
        first = relative.parts[0]
        if first == 'windows-evidence.tar.gz':
            continue
        if len(relative.parts) == 1 and first in compiler_names:
            group = 'COMPILERS'
        elif first in native_names or first.startswith('native-declaration-map') or first == 'native-map-binding.json':
            group = 'NATIVE'
        elif first == 'workspace-capture' or first.startswith('workspace-') or first == 'workspace.log':
            group = 'WORKSPACE'
        elif first == 'windows' or len(relative.parts) == 1:
            group = 'AUDIT'
        else:
            group = 'DEVELOPMENT'
        groups[group].append(file)
    artifacts = []
    for label, files in groups.items():
        assert files, label
        artifacts.extend(publish_group(ROOT, PHASE, frozen['sourceRevision'], label, files))
    windows_path = PHASE / (PREFIX + 'WINDOWS_EVIDENCE.tar.gz')
    if not windows_path.exists():
        shutil.copy2(ROOT / 'windows-evidence.tar.gz', windows_path)
    assert sha(windows_path) == receipt['windows']['archiveSha256']
    assert windows_path.stat().st_size < LIMIT
    artifacts.append({'path': windows_path.name, 'bytes': windows_path.stat().st_size,
        'sha256': sha(windows_path), 'originalWindowsArchive': True})
    owners = {}
    for artifact in artifacts:
        for part in artifact.get('memberManifests', []):
            assert sha(PHASE / part['path']) == part['sha256']
            for row in read(PHASE / part['path'])['entries']:
                assert row['path'] not in owners
                owners[row['path']] = {'archive': artifact['path'], 'path': row['path'], 'sha256': row['sha256']}

    def reference(name):
        return owners[Path(name).as_posix()]

    artifact_index = {'schema': 2, 'sourceRevision': frozen['sourceRevision'],
        'scope': 'Complete source-bound evidence; per-file members are in separately hashed manifests.',
        'artifacts': artifacts}
    index_reference = write_json(PHASE / (PREFIX + 'ARTIFACTS.json'), artifact_index)
    source = {key: value for key, value in frozen.items() if key != 'files'}
    source['manifest'] = reference('frozen-source-preflight.json')
    utility_reports = {family: {kind: reference(receipt[family][kind]['path'])
        for kind in ['native', 'workspace']} for family in [
            'mappedInferenceReports', 'stringIntrinsicReports', 'nonNullableAwaitedReports']}
    symbolic_reports = {kind: {**values,
        'primaryReport': reference(values['primaryReport']),
        'supplementaryReports': {mode: reference(row['path'])
            for mode, row in values['supplementaryReports'].items()}}
        for kind, values in receipt['symbolicKeysReports'].items()}
    conditional_reports = {kind: {**values,
        'primaryReport': reference(values['primaryReport']),
        'supplementaryReports': {mode: reference(row['path'])
            for mode, row in values['supplementaryReports'].items()}}
        for kind, values in receipt['conditionalInferenceReports'].items()}
    pre_repair = {}
    for name in ['CONDITIONAL_INFERENCE_DISCOVERY.json', 'CONDITIONAL_INFERENCE_DISCOVERY_EVIDENCE.tar.gz',
                 'CONDITIONAL_INFERENCE_BASELINE.json', 'CONDITIONAL_INFERENCE_BASELINE_EVIDENCE.tar.gz',
                 'CONDITIONAL_INFERENCE_BASELINE_MEMBERS.json', 'CONDITIONAL_INFERENCE_RED.json',
                 'CONDITIONAL_INFERENCE_RED_EVIDENCE.tar.gz', 'CONDITIONAL_INFERENCE_RED_MEMBERS.json']:
        file = PHASE / name
        pre_repair[name] = {'path': name, 'bytes': file.stat().st_size, 'sha256': sha(file)}
    baseline = receipt['acceptedEBaseline']
    data = {'schema': 2, 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'conclusion': 'completed-within-frozen-scope', 'source': source, 'gates': gates,
        'nativeMeasurement': {'path': 'COMPATIBILITY_MEASUREMENT.json',
            'sha256': sha(ROOT / 'accepted-native/measurement.json'),
            'suites': receipt['nativeSuites'], 'functions': receipt['nativeFunctions']},
        'primaryForms': 48, 'profiles': 8, 'directObservations': 384,
        'accepted': 360, 'rejected': 24, 'declarationFiles': 368,
        'isolatedConsumers': 720, 'selectedEditionParses': 368, 'executions': 48,
        'boundaryControls': 12, 'boundaryControlsExcludedFromDirectDenominator': True,
        'supplementaryControls': 24, 'supplementaryAccepted': 24, 'supplementaryRejected': 0,
        'supplementarySyntax': 24, 'supplementaryInventoryCredit': 0,
        'caseInventoryAdditions': 396, 'symbolicKeysReports': symbolic_reports,
        'conditionalInferenceReports': conditional_reports, 'preRepairEvidence': pre_repair,
        'originalDiscovery24': {kind: {**row, 'reference': reference(row['path'])}
            for kind, row in original.items()}, **utility_reports,
        'noInferReports': {kind: {label: reference(row['path']) for label, row in values.items()}
            for kind, values in receipt['noInferReports'].items()},
        'mapBindings': receipt['mapBindings'],
        'completeNativeRoleFamilies': receipt['completeNativeRoleFamilies'],
        'partialNativeRoleReports': receipt['partialNativeRoleReports'],
        'baseline': {**baseline, 'reference': reference(baseline['report'])},
        'projects': {name: reference('project-' + name + '/report.json')
            for name in ['defu', 'mitt', 'reproductions', 'interchange']},
        'windows': receipt['windows'], 'windowsContinuation':receipt['windowsContinuation'], 'casePreservation': receipt['casePreservation'],
        'orchestrationAmendment': reference('orchestration-amendments/receipt.json'),
        'toolManifestOrderRepair': reference('orchestration-amendments/tool-manifest-order.json'),
        'modules': {'files': receipt['moduleFiles'], 'maximumLines': receipt['maximumModuleLines'],
            'audit': reference('all-source-module-size-audit.json')},
        'frozenInputs': frozen['originalFrozenInputs'],
        'supplementaryFrozenInputs': frozen['supplementaryFixtureSha256'],
        'repairPreflight': read(REPO / frozen['preflight'] / 'measurement.json'),
        'sourceSnapshots': reference('source-snapshots/manifest.json'),
        'quality': read(ROOT.parent / 'conditional-inference-contract-20261114/quality-4/measurement.json'),
        'preflightFormattingEquivalence': read(ROOT.parent / 'conditional-inference-contract-20261114/quality-3/format-equivalence.json'),
        'developmentHistory': reference('development-history/index.json'),
        'oracleDependencies': reference('oracle-dependencies.json'),
        'broaderFeatureRowsOpen': 22, 'fullTypeScriptParity': False,
        'artifactIndex': index_reference}
    write_json(PHASE / (PREFIX + 'MEASUREMENT.json'), data)
    print('Published complete P0-F implementation evidence with bounded member manifests.', flush=True)


if __name__ == '__main__':
    main()
