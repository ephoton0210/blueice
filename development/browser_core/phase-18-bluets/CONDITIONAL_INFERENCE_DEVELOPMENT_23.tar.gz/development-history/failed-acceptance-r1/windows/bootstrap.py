# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path, PurePosixPath
import ctypes, datetime, gzip, hashlib, json, os, subprocess, tarfile
from ctypes import wintypes

base = Path('B:/BlueIce/gm3-20261109-360d7d921')
source = base / 'p0c-authoring-preflight-1/source'
root = base / 'p0f-r1-bootstrap'
root.mkdir()
state = {'pid': os.getpid(), 'stage': 'starting', 'conclusion': 'in_progress',
         'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = root / 'measurement.tmp'; p.write_text(json.dumps(state, indent=2) + '\n', encoding='utf-8')
    p.replace(root / 'measurement.json')

class ProcessEntry(ctypes.Structure):
    _fields_ = [('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD), ('pid', wintypes.DWORD),
                ('heap', ctypes.c_size_t), ('module', wintypes.DWORD), ('threads', wintypes.DWORD),
                ('parent', wintypes.DWORD), ('priority', wintypes.LONG), ('flags', wintypes.DWORD),
                ('name', wintypes.WCHAR * 260)]

def active_builds():
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)]
    kernel.Process32NextW.argtypes = kernel.Process32FirstW.argtypes
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = kernel.CreateToolhelp32Snapshot(2, 0)
    assert handle and handle != ctypes.c_void_p(-1).value
    try:
        found = []; entry = ProcessEntry(); entry.dwSize = ctypes.sizeof(entry)
        current = kernel.Process32FirstW(handle, ctypes.byref(entry))
        while current:
            if entry.name.lower() in ['cargo.exe', 'rustc.exe']:
                found.append({'pid': entry.pid, 'name': entry.name})
            current = kernel.Process32NextW(handle, ctypes.byref(entry))
        return found
    finally:
        kernel.CloseHandle(handle)

try:
    save(); assert not active_builds(), 'Another Windows Cargo/rustc pipeline is active'
    data = gzip.decompress((base / 'p0f-r1-source-manifest.json.gz').read_bytes())
    assert hashlib.sha256(data).hexdigest() == 'd567035b2355dfd7b502c2c47ed04370c5d5ca8cade937d95b99de17264ee342'
    manifest = json.loads(data)
    assert sha(Path(manifest['baseManifestGuestPath'])) == manifest['baseManifestSha256']
    assert manifest['sourceRevision'] == 'backend-tree:e6c4831c72322340382f8e28cb3589a6a5639a75'
    state.update(stage='verify-old-source', sourceRevision=manifest['sourceRevision'],
                 manifestSha256=hashlib.sha256(data).hexdigest()); save()
    for name, digest in manifest['baseFiles'].items():
        assert sha(source / name) == digest, name
    archive = base / 'p0f-r1-source-delta.tar.gz'
    assert sha(archive) == manifest['sourcePatchSha256']
    with tarfile.open(archive) as package:
        entries = package.getmembers()
        assert len(entries) == len(manifest['delta'])
        assert {entry.name for entry in entries} == set(manifest['delta'])
        for entry in entries:
            relative = PurePosixPath(entry.name)
            assert entry.isfile() and not relative.is_absolute() and '..' not in relative.parts
            target = source / entry.name; target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(package.extractfile(entry).read())
    for name, digest in manifest['files'].items():
        assert sha(source / name) == digest, name
    (base / 'p0f-r1-source-manifest.json').write_bytes(data)
    state.update(stage='launching-node', verifiedFiles=len(manifest['files']),
                 verifiedBackendFiles=manifest['backendFiles']); save()
    assert sha(base / 'p0f-r1-windows-runner.cjs') == manifest['runnerSha256']
    assert not active_builds(), 'Another Windows Cargo/rustc pipeline appeared before launch'
    with (root / 'runner.stdout').open('wb') as out, (root / 'runner.stderr').open('wb') as err:
        child = subprocess.Popen(['node', str(base / 'p0f-r1-windows-runner.cjs')], cwd=source, stdout=out, stderr=err)
        state.update(stage='node-running', nodePid=child.pid); save(); code = child.wait()
    state.update(stage='complete', nodeExit=code, conclusion='success' if code == 0 else 'failure',
                 finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(); print(json.dumps(state), flush=True)
except BaseException as error:
    state.update(conclusion='failure', error=repr(error), finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(); raise
