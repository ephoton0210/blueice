# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Preserve the terminal failed Windows candidate without acceptance credit."""
from pathlib import Path
import datetime
import hashlib
import json
import tarfile

base = Path('B:/BlueIce/gm3-20261109-360d7d921')
source = base / 'p0c-authoring-preflight-1/source'
results = base / 'results-conditional-inference-r1'
manifest_path = base / 'p0f-r1-source-manifest.json'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = read(manifest_path)
measured = read(results / 'measurement.json')
bootstrap = read(base / 'p0f-r1-bootstrap/measurement.json')
assert measured['conclusion'] == bootstrap['conclusion'] == 'failure'
assert bootstrap['nodeExit'] == 1 and measured['sourceRevision'] == manifest['sourceRevision']
compiler = results / 'accepted-windows-cli.exe'
assert sha(compiler) == measured['compiler']['sha256']
complete_source = base / 'p0f-r1-failure-source.tar.gz'
assert not complete_source.exists()
with tarfile.open(complete_source, 'w:gz') as archive:
    for name, digest in manifest['files'].items():
        path = source / name
        assert path.is_file() and not path.is_symlink() and sha(path) == digest, name
        archive.add(path, arcname=name, recursive=False)
package = base / 'p0f-r1-failure-evidence.tar.gz'
assert not package.exists()
with tarfile.open(package, 'w:gz') as archive:
    for file in sorted(results.rglob('*')):
        assert not file.is_symlink(), file
        if file.is_file():
            archive.add(file, arcname=file.relative_to(base).as_posix(), recursive=False)
    for file, name in [(complete_source, 'full-source.tar.gz'),
                       (compiler, 'actual-windows-cli.exe'),
                       (manifest_path, 'windows-source-manifest.json'),
                       (base / 'p0f-r1-windows-runner.cjs', 'windows-runner.cjs')]:
        archive.add(file, arcname=name, recursive=False)
assert sha(compiler) == measured['compiler']['sha256']
receipt = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'sourceRevision': manifest['sourceRevision'], 'acceptanceConclusion': 'failure',
           'archive': str(package), 'archiveBytes': package.stat().st_size,
           'archiveSha256': sha(package), 'fullSourceSha256': sha(complete_source),
           'fullSourceFiles': len(manifest['files']), 'compilerSha256': sha(compiler),
           'scope': 'Terminal failed candidate and all partial products; zero acceptance credit.'}
(base / 'p0f-r1-failure-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt), flush=True)
