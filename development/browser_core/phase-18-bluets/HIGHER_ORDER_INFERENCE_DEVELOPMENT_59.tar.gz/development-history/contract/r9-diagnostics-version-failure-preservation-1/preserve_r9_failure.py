# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Preserve the genuine r9 workspace version-assertion failure before repair."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import tarfile

repo = Path('/Users/ephoton/git/blueice-bluets')
root = repo/'target/higher-order-inference-acceptance-20261114-r9'
out = Path(__file__).resolve().parent/'r9-diagnostics-version-failure-preservation-1'
out.mkdir()
read = lambda p: json.loads(p.read_bytes())
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

frozen = read(root/'frozen-source-preflight.json')
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip() == frozen['parentCommit']
text = (root/'workspace.log').read_text()
start = text.index('Running tests/diagnostics.rs')
end = text.index('Running tests/diagnostics_matrix.rs', start)
failure = text[start:end]
assert 'test result: FAILED. 9 passed; 1 failed;' in failure
assert 'typescript-5.9.3-diagnostics-v13' in failure
assert 'typescript-5.9.3-diagnostics-v12' in failure
(out/'original-diagnostics-failure.log').write_text(failure)
files = dict(frozen['files'])
for name in ['Cargo.toml','Cargo.lock','LICENSE']:
    files[name] = sha(repo/name)
assert len(files) == 14738
for name, digest in files.items():
    assert sha(repo/name) == digest, name
drivers = read(root/'mac-driver.json')['driverHashes']
assert len(drivers) == 17
assert all(sha(root/name) == digest for name,digest in drivers.items())
archive = out/'frozen-source.tar.gz'
with tarfile.open(archive,'w:gz') as package:
    for name in sorted(files):
        package.add(repo/name,arcname=name,recursive=False)
with tarfile.open(archive,'r|gz') as package:
    verified = {item.name:hashlib.sha256(package.extractfile(item).read()).hexdigest()
                for item in package if item.isfile()}
assert verified == files
native = read(root/'native-gates.json')
local = read(root/'local-gates.json')
assert native['conclusion'] == 'success'
assert sha(root/'accepted-native-cli') == native['nativeCompilerSha256']
assert sha(root/'accepted-workspace-cli') == local['workspaceCompilerSha256']
products = {}
for original,name in [
    (root/'accepted-native-cli','actual-native-cli'),
    (root/'accepted-workspace-cli','actual-workspace-cli'),
    (repo/'target/debug/deps/diagnostics-8b3d3f17e552bd1a','actual-failed-diagnostics-test'),
]:
    assert original.is_file()
    shutil.copy2(original,out/name)
    products[name] = {'bytes':(out/name).stat().st_size,'sha256':sha(out/name)}
    assert products[name]['sha256'] == sha(original)
for name in ['launch-state.json','mac-driver.json','native-gates.json','project-gates.json',
             'local-gates.json','workspace.log','map-watch-state.json',
             'windows/complete-state.json','windows/windows-acceptance-verification.json']:
    target = out/'observed'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,target)
win = read(root/'windows/windows-acceptance-verification.json')
assert win['conclusion'] == 'success' and sha(root/'windows-evidence.tar.gz') == win['archiveSha256']
receipt = {'conclusion':'source-preserved-before-test-repair',
    'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision':frozen['sourceRevision'],'sourceFiles':len(files),'files':files,
    'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),
    'products':products,'frozenRuntimeDrivers':drivers,
    'failedTest':'checked_errors_preserve_bts_identity_and_expose_a_typescript_counterpart',
    'failureLogSha256':sha(out/'original-diagnostics-failure.log'),
    'observedStatesArePartial':True,'originalWorkspaceFailureUnchanged':True,
    'windowsArchiveSha256':win['archiveSha256'],'wholeAcceptanceCredit':0}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copy2(__file__,out/Path(__file__).name)
print(json.dumps({k:v for k,v in receipt.items() if k not in ['files','frozenRuntimeDrivers','products']}))
