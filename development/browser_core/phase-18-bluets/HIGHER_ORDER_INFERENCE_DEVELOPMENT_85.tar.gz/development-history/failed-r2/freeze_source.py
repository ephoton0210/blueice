# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
contract = repo / 'target/higher-order-inference-contract-20261114'
quality = contract / 'regressions-2'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command = lambda *args: subprocess.check_output(args, cwd=repo, text=True).strip()
checked = read(quality / 'measurement.json')
assert checked['conclusion'] == 'success' and checked['stage'] == 'complete'
assert [step['label'] for step in checked['steps']] == [
    'library','affected-callers','fmt','clippy','node-tools','python-tools']
for step in checked['steps']:
    assert step['exit'] == 0 and sha(quality / step['log']) == step['logSha256']
assert sha(quality / 'source-manifest.json') == checked['sourceManifestSha256']
files = read(quality / 'source-manifest.json')
for name, digest in files.items():
    assert sha(repo / name) == digest, name
paths = subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard',
    '-z','--','backend','development/browser_core/phase-18-bluets/tools'],cwd=repo).decode().split('\0')
assert set(filter(None, paths)) == set(files)
assert not command('git','diff','--name-only','--','backend','development/browser_core/phase-18-bluets/tools')
parent = command('git','rev-parse','HEAD')
assert parent == '87d53ef80beb76c77dd804b9c14f3ed2dbb8a4c5'
tree = command('git','write-tree')
backend_tree = command('git','rev-parse',tree + ':backend')
backend = sorted((name for name in files if name.startswith('backend/')),key=lambda name:name.encode())
indexed = subprocess.check_output(['git','ls-files','-z','--','backend'],cwd=repo).decode().split('\0')[:-1]
assert set(backend) == set(indexed)
fixture = repo / 'backend/bluets/tests/fixtures/higher_order_inference'
frozen = read(fixture / 'FROZEN.json')
for name, digest in frozen['sha256'].items():
    assert sha(fixture / name) == digest, name
candidate = read(contract / 'candidate-9/measurement.json')
assert candidate['conclusion'] == 'focused-green' and candidate['completeAgreements'] == 384
assert candidate['completeDifferences'] == candidate['newDifferencesSinceBaseline'] == 0
for name, digest in candidate['source'].items():
    assert sha(repo / name) == digest, name
downstream = read(contract / 'downstream-4/measurement.json')
assert downstream['conclusion'] == 'success'
assert downstream['compilerSha256'] == candidate['actual-cliSha256']
for step in downstream['commands']:
    assert step['exit'] == 0
    assert sha(contract / 'downstream-4' / (step['label']+'.log')) == step['logSha256']
    assert step['report']['comparisons'] == 384 and step['report']['syntax'] == 424
    assert step['report']['consumers'] == 704 and step['report']['runtime'] == 48
prior = read(repo / 'development/browser_core/phase-18-bluets/COMPATIBILITY_CASES.json')
assert sum(len(suite['cases']) for suite in prior['suites']) == 42716
tools = json.loads(subprocess.check_output(['node','-e',
    "process.stdout.write(JSON.stringify(require('./development/browser_core/phase-18-bluets/tools/measure_compatibility_cases.cjs').toolHashes()))"],cwd=repo))
state = {'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parentCommit':parent,'backendTree':backend_tree,'sourceRevision':'backend-tree:'+backend_tree,
    'backendFiles':len(backend),'backendPathSetSha256':hashlib.sha256('\0'.join(backend).encode()).hexdigest(),
    'files':files,'originalFrozenInputs':frozen['sha256'],
    'qualityMeasurementSha256':sha(quality/'measurement.json'),
    'qualityManifestSha256':sha(quality/'source-manifest.json'),
    'focusedCandidateMeasurementSha256':sha(contract/'candidate-9/measurement.json'),
    'focusedDownstreamMeasurementSha256':sha(contract/'downstream-4/measurement.json'),
    'oracleToolFilesExpected':len(tools),'expectedNativeSuites':191,'expectedNativeFunctions':1085,
    'previousAssertions':42716,'addedAssertions':396,
    'scope':'P0-G frozen finite higher-order inference contract. Full same-source acceptance still required; all22 broader rows remain open.'}
with (root/'frozen-source-preflight.json').open('x') as output:
    output.write(json.dumps(state,indent=2)+'\n')
(root/'frozen-final-oracle-tools.json').write_text(json.dumps({'sha256':tools},indent=2)+'\n')
print(json.dumps({key:value for key,value in state.items() if key!='files'}))
