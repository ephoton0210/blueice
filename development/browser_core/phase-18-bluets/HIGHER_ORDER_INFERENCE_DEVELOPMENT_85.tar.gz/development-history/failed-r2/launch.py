# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Wait on the existing preflight, then supervise one Mac and one Windows run."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = root.parent.parent
quality = repo/'target/higher-order-inference-contract-20261114/regressions-2'
state_path = root/'launch-state.json'
assert not state_path.exists(), 'Inspect the existing supervisor instead of restarting'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_bytes())
state = {'pid':os.getpid(),'conclusion':'in_progress','stage':'waiting-existing-preflight',
    'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[],'platforms':{}}

def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    temporary = state_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(state_path)

def matching_quality_processes():
    found = []
    for line in subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines():
        columns = line.strip().split(None,1)
        if len(columns) != 2:
            continue
        try:
            args = shlex.split(columns[1])
        except ValueError:
            continue
        if (args and Path(args[0]).name.lower().startswith('python') and len(args) >= 3
                and args[-1] == 'regressions-2' and Path(args[-2]).name == 'regressions.py'
                and 'higher-order-inference-contract-20261114' in args[-2]):
            found.append({'pid':int(columns[0]),'command':columns[1]})
    return found

def run(label,args):
    state['stage'] = label
    save()
    log = root/(label+'-launch.log')
    with log.open('xb') as output:
        child = subprocess.Popen(args,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
        state['childPid'] = child.pid
        save()
        code = child.wait()
    state['steps'].append({'label':label,'command':args,'exit':code,'log':log.name,'sha256':sha(log)})
    state.pop('childPid',None)
    save()
    assert code == 0,label

children = {}
try:
    save()
    known_quality = None
    while True:
        measured = read(quality/'measurement.json')
        if measured['conclusion'] != 'in_progress':
            break
        matches = matching_quality_processes()
        if not matches:
            measured = read(quality/'measurement.json')
            assert measured['conclusion'] != 'in_progress','Known preflight missing without terminal receipt; do not restart'
            break
        assert len(matches) == 1,matches
        if known_quality is not None:
            assert matches[0] == known_quality,'Preflight identity changed'
        known_quality = matches[0]
        state.update(preflightProcess=known_quality,
            preflightProcessVerifiedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        time.sleep(10)
    assert measured['conclusion'] == 'success' and measured['stage'] == 'complete'
    state['preflightMeasurementSha256'] = sha(quality/'measurement.json')
    interrupted = read(repo/'target/higher-order-inference-acceptance-20261114-r1/windows/cancellation-1/interrupted-evidence-audit.json')
    assert interrupted['acceptanceCredit'] == 0 and interrupted['recordedOwnedProcessesVerifiedAbsent']
    assert interrupted['sourceFilesIndependentlyVerified'] == 14818
    run('stage-source',['git','add','--','backend/bluets','development/browser_core/phase-18-bluets/tools'])
    run('freeze',[sys.executable,'-B',str(root/'freeze_source.py')])
    frozen = read(root/'frozen-source-preflight.json')
    state['sourceRevision'] = frozen['sourceRevision']
    save()
    run('prepare-windows',[sys.executable,'-B',str(root/'prepare_windows.py')])
    for label,script in [('mac','run_mac.py'),('windows','complete_windows.py')]:
        log = root/(label+'-supervisor.log')
        with log.open('xb') as output:
            child = subprocess.Popen([sys.executable,'-B',str(root/script)],cwd=repo,
                stdout=output,stderr=subprocess.STDOUT)
        children[label] = child
        state['platforms'][label] = {'pid':child.pid,'script':script,'log':log.name}
        save()
    while True:
        state['stage'] = 'running-platform-acceptance'
        for label,child in children.items():
            code = child.poll()
            if code is not None:
                state['platforms'][label]['exit'] = code
                if code:
                    state['stage'] = 'platform-failure-observing-other-running-platform'
        save()
        if all(child.poll() is not None for child in children.values()):
            break
        time.sleep(10)
    assert all(child.returncode == 0 for child in children.values()),state['platforms']
    state.update(conclusion='success',stage='all-gates-complete-awaiting-independent-publication-audit',
        commitPerformed=False,pushPerformed=False)
except BaseException as error:
    state.update(conclusion='failure',error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state))
