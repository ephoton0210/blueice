type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";
declare const value: Infer<{ a: (x: string) => void; b: (x: number) => void }>;
export const result = value;
export const check: never = result;
