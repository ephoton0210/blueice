type Callback<X> = (value: X) => void;
type Infer<T> = T extends { a: Callback<infer U>; b: Callback<infer U> } ? U : "miss";
declare const value: Infer<{ a: Callback<string>; b: Callback<number> }>;
export const result = value;
export const check: never = result;
