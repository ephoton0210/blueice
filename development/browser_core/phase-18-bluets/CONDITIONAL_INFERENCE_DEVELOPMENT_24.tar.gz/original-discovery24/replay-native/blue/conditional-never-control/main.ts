type Infer<T> = T extends string ? 1 : 2;
declare const value: Infer<never>;
export const result = value;
export const check: never = result;
