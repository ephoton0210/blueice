type Infer<T> = T extends (x: infer U) => void ? U : "miss";
declare const value: Infer<() => void>;
export const result = value;
