export type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";
