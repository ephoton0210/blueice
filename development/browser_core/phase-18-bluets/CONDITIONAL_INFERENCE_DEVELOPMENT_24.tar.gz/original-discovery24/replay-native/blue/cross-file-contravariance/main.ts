import type { Infer } from "./types";
declare const value: Infer<{ a: (x: string) => void; b: (x: number) => void }>;
export const result = value;
export const check: never = result;
