type Infer<T> = T extends (x: infer U) => infer U ? U : "miss";
declare const value: Infer<(x: "narrow") => string>;
export const result = value;
export const check: "miss" = result;
