type Infer<T> = T extends { a: infer U extends string; b: infer U extends string } ? U : "miss";
declare const value: Infer<{ a: "a"; b: "b" }>;
export const result = value;
export const check: "a" | "b" = result;
