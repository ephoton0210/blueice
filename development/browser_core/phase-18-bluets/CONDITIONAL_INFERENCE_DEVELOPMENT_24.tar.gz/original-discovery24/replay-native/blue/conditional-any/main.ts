type Infer<T> = T extends string ? 1 : 2;
declare const value: Infer<any>;
export const result = value;
export const check: 1 | 2 = result;
