type Infer<T> = T extends [infer H, ...infer R] ? [H, R] : "miss";
declare const value: Infer<[string, number, boolean]>;
export const result = value;
export const check: [string, [number, boolean]] = result;
