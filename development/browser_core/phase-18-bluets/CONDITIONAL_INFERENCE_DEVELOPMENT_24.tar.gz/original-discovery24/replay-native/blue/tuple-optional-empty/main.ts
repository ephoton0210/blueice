type Infer<T> = T extends [(infer H)?, ...infer R] ? [H, R] : "miss";
declare const value: Infer<[]>;
export const result = value;
