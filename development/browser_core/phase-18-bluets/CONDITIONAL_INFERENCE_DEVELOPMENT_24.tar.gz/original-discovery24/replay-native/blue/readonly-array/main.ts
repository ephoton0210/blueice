type Infer<T> = T extends readonly (infer U)[] ? U : "miss";
declare const value: Infer<readonly string[]>;
export const result = value;
export const check: string = result;
