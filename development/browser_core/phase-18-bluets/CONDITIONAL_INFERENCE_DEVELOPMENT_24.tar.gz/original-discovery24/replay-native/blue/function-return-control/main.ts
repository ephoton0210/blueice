type Infer<T> = T extends (...args: any[]) => infer U ? U : "miss";
declare const value: Infer<(x: number) => "ok">;
export const result = value;
export const check: "ok" = result;
