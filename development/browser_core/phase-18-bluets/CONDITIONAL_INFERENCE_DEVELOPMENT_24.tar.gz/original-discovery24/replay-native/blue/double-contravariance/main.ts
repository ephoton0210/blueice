type Infer<T> = T extends (f: (x: infer U) => void) => void ? U : "miss";
declare const value: Infer<(f: (x: "ok") => void) => void>;
export const result = value;
export const check: "ok" = result;
