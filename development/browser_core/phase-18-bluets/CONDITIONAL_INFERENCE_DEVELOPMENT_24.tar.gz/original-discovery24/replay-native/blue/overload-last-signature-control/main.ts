type Infer<T> = T extends (x: infer U) => void ? U : "miss";
declare const value: Infer<{ (x: "first"): void; (x: "last"): void }>;
export const result = value;
export const check: "last" = result;
