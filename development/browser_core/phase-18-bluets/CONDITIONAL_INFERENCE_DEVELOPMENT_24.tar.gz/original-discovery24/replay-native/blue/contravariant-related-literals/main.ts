type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";
declare const value: Infer<{ a: (x: "a" | "b") => void; b: (x: "b" | "c") => void }>;
export const result = value;
export const check: "b" = result;
