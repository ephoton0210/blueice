type Infer<T> = T extends (x: infer U extends string) => void ? U : "miss";
declare const value: Infer<() => void>;
export const result = value;
export const check: string = result;
