type Infer<T> = [T] extends [string] ? 1 : 2;
declare const value: Infer<string | number>;
export const result = value;
export const check: 2 = result;
