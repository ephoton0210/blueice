# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
repo=Path('/Users/ephoton/git/blueice-bluets');root=Path('/Users/ephoton/git/blueice-bluets/target/conditional-inference-acceptance-20261114-r3');captured={};statefile=root/'map-watch-state.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():statefile.write_text(json.dumps({'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captured':captured},indent=2)+'\n')
def read(path):
 try: return json.loads(path.read_bytes())
 except (FileNotFoundError, json.JSONDecodeError): return None

def bind(label,pid,executable):
 assert subprocess.check_output(['ps','-p',str(pid),'-o','comm='],text=True).strip().startswith(str(repo/'target/debug/deps/ge5_source_maps-'))
 cli=repo/'target/debug/bluetsc';destination=root/(label+'-cli-snapshot');shutil.copy2(cli,destination);r={'sourceRevision':json.loads((root/'frozen-source-preflight.json').read_text())['sourceRevision'],'label':label,'pid':pid,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilerSha256':sha(destination),'compilerSnapshot':str(destination),'testExecutable':executable,'testExecutableSha256':sha(Path(executable)) if executable else None,'reportPath':str(Path(os.environ['TMPDIR'])/f'bluets-ge5-declaration-report-{pid}.json'),'scope':'Observed running G-E5 source-maps suite; final report/test terminal still pending'};r['reportNotBeforeEpoch']=time.time()-2
 if executable:
  binary_copy=root/(label+'-map-test-executable');shutil.copy2(executable,binary_copy);assert sha(binary_copy)==r['testExecutableSha256'];r['testExecutableSnapshot']=str(binary_copy)
 captured[label]=r;save();print('BOUND running maps suite',label,pid,flush=True)
while True:
 if 'native' not in captured:
  p=root/'accepted-native/current.json'
  if p.exists():
   r=read(p) or {}
   for row in r.get('active',[]):
    if row['harness']=='backend/bluets/tests/ge5_source_maps.rs':
     pid=row['pid'];lines=subprocess.check_output(['ps','-p',str(pid),'-o','command='],text=True).strip();executable=lines.split()[0] if lines else None;bind('native',pid,executable);assert captured['native']['compilerSha256']==json.loads((root/'native-gates.json').read_bytes())['nativeCompilerSha256']
 if 'workspace' not in captured:
  p=root/'local-gates.json'
  if p.exists() and (read(p) or {}).get('stage')=='workspace':
   rows=subprocess.check_output(['ps','-axo','pid,command'],text=True).splitlines()
   for line in rows:
    a=line.split(None,1)
    if len(a)==2 and a[1].startswith(str(repo/'target/debug/deps/ge5_source_maps-')):bind('workspace',int(a[0]),a[1].split()[0])
 for label,r in captured.items():
  if r.get('verified'):continue
  p=Path(r['reportPath'])
  if p.exists():
   if p.stat().st_mtime < r['reportNotBeforeEpoch']:continue
   try:v=json.loads(p.read_bytes())
   except json.JSONDecodeError:continue
   assert v['configurations']==8407 and v['buildsPerConfiguration']==2 and not v['differences'],(label,v)
   out=root/(label+'-declaration-map-report.json');out.write_bytes(p.read_bytes());r.update(verified=True,reportFreshSinceBinding=True,reportModifiedEpoch=p.stat().st_mtime,reportSha256=sha(out),retainedReport=str(out),scope='Process-bound complete8407x2 declaration/JavaScript metadata/bounds report; final whole-suite/gates are recorded separately');(root/(label+'-map-binding.json')).write_text(json.dumps(r,indent=2)+'\n');save();print('Bound complete8407x2',label,flush=True)
 if len(captured)==2 and all(r.get('verified') for r in captured.values()):print('COMPLETE map report bindings',flush=True);break
 save();time.sleep(5)
