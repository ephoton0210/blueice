# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime, gzip, hashlib, json, subprocess, tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
previous = root.parent / 'conditional-inference-acceptance-20261114-r2'
directory = root / 'windows'
base = 'B:/BlueIce/gm3-20261109-360d7d921'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((root / 'frozen-source-preflight.json').read_bytes())
baseline_path = previous / 'windows/windows-source-manifest.json'
baseline = json.loads(baseline_path.read_bytes())
assert baseline['sourceRevision'] == 'backend-tree:57ea386c3d0864ab228846f55cf39d3a3d3f5e66'
for name, digest in frozen['files'].items():
    assert sha(repo / name) == digest, name
paths = set(baseline['files']) | set(frozen['files'])
paths.add('development/browser_core/phase-18-bluets/CONDITIONAL_INFERENCE_FOLLOWUP.md')
files = {name: sha(repo / name) for name in sorted(paths)}
backend = sorted((name for name in files if name.startswith('backend/')), key=lambda name: name.encode())
canonical = subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend'], cwd=repo).decode().split('\0')[:-1]
assert set(canonical) == set(backend) and len(backend) == frozen['backendFiles']
path_hash = hashlib.sha256('\0'.join(backend).encode()).hexdigest()
assert path_hash == frozen['backendPathSetSha256']
delta = {name: digest for name, digest in files.items() if baseline['files'].get(name) != digest}
archive_path = directory / 'source-delta.tar.gz'
with archive_path.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as archive:
        for name in delta:
            archive.add(repo / name, arcname=name, recursive=False)
manifest = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceRevision': frozen['sourceRevision'], 'parentCommit': frozen['parentCommit'],
    'backendFiles': len(backend), 'backendPathSetSha256': path_hash,
    'baseManifestSha256': sha(baseline_path),
    'baseManifestGuestPath': base + '/p0f-r2-source-manifest.json',
    'baseFiles': baseline['files'], 'files': files, 'delta': delta,
    'sourcePatchSha256': sha(archive_path), 'runnerSha256': sha(directory / 'windows-runner.cjs'),
    'scope': 'Frozen P0-F source: original82 core,25 paths and16 full cohorts. No old-source pass credit.',
}
manifest_path = directory / 'windows-source-manifest.json'
with manifest_path.open('x') as output:
    output.write(json.dumps(manifest, indent=2) + '\n')
(directory / 'windows-source-manifest.json.gz').write_bytes(gzip.compress(manifest_path.read_bytes(), mtime=0))
bootstrap = (previous / 'windows/bootstrap.py').read_text().replace('p0f-r2', 'p0f-r3')
bootstrap = bootstrap.replace(sha(baseline_path), sha(manifest_path))
bootstrap = bootstrap.replace(baseline['sourceRevision'], frozen['sourceRevision'])
compile(bootstrap, 'bootstrap.py', 'exec')
(directory / 'bootstrap.py').write_text(bootstrap)
destinations = [(name, 'p0f-r3-' + remote) for name, remote in [
    ('windows-source-manifest.json.gz', 'source-manifest.json.gz'),
    ('source-delta.tar.gz', 'source-delta.tar.gz'),
    ('windows-runner.cjs', 'windows-runner.cjs'), ('bootstrap.py', 'bootstrap.py'),
    ('package-evidence.py', 'package-evidence.py')]]
plan = {'sourceRevision': frozen['sourceRevision'], 'conclusion': 'prepared',
        'files': [{'local': str(directory / name), 'remote': base + '/' + remote,
                   'sha256': sha(directory / name), 'bytes': (directory / name).stat().st_size}
                  for name, remote in destinations]}
(directory / 'upload-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'sourceRevision': frozen['sourceRevision'], 'backendFiles': len(backend),
                  'selectedFiles': len(files), 'deltaFiles': len(delta),
                  'archiveBytes': archive_path.stat().st_size, 'manifestSha256': sha(manifest_path)}))
