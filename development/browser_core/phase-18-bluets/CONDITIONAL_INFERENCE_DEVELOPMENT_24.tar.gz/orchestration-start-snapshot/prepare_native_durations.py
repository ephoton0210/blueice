# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Make future scheduling hints from the measured seconds, without defaults."""
from pathlib import Path
import argparse
import json
import math


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('measurement', type=Path)
    parser.add_argument('output', type=Path)
    options = parser.parse_args()
    report = json.loads(options.measurement.read_bytes())
    assert report['conclusion'] == 'success'
    durations = {}
    for suite in report['suites']:
        assert suite['conclusion'] == 'success' and suite['harness'] not in durations
        seconds = suite['seconds']
        assert isinstance(seconds, (float, int)) and math.isfinite(seconds) and seconds >= 0
        durations[suite['harness']] = seconds * 1000
    assert durations and any(value > 0 for value in durations.values())
    with options.output.open('x') as output:
        output.write(json.dumps(durations, indent=2) + '\n')
    print(json.dumps({'suites': len(durations), 'longestMilliseconds': max(durations.values()),
        'output': str(options.output), 'scope': 'Future scheduling only; never replace a running measurement input.'}))


if __name__ == '__main__':
    main()
