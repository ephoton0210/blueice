# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Inspect P0-F source-bound reports and their actual archived products."""
import hashlib
import json


def audit_products(repo, source, compiler, base, names, content, require_native):
    fixture = repo / 'backend/bluets/tests/fixtures/conditional_inference'
    digest = lambda data: hashlib.sha256(data).hexdigest()
    read = lambda name: json.loads(content(name))
    frozen = json.loads((fixture / 'FROZEN.json').read_bytes())
    extra = json.loads((fixture / 'ALIAS_CONTROLS_FROZEN.json').read_bytes())
    reference = json.loads((fixture / 'reference.json').read_bytes())
    supplement = json.loads((fixture / 'alias-controls.json').read_bytes())
    for name, expected_hash in {**frozen['sha256'], **extra['sha256']}.items():
        assert digest((fixture / name).read_bytes()) == expected_hash, name
    expected = {row['id']: row for row in reference['cases']}
    assert len(expected) == 384 and sum(row['accepts'] for row in expected.values()) == 360
    assert len(json.loads((fixture / 'boundary-controls.json').read_bytes())['controls']) == 12
    aliases = {row['id']: row['expected'] for row in supplement['cases']}
    assert len(aliases) == 24 and supplement['inventoryCredit'] == 0
    base = base.rstrip('/') + '/'
    names = set(names)

    def reports(label):
        return sorted(name for name in names
                      if name.startswith(base + 'bluets-conditional-inference-' + label + '-')
                      and name.count('/') == base.count('/') + 1
                      and name.endswith('/report.json'))

    found = reports('blue')
    assert len(found) == 1, found
    report_name = found[0]
    report = read(report_name)
    assert report['conclusion'] == 'success' and report['sourceRevision'] == source
    assert report['compilerSha256'] == compiler and report['frozenInputs'] == frozen['sha256']
    assert report['implementationSha256'] == reference['implementationSha256']
    assert report['libraries'] == reference['libraries']
    for key, expected_count in [('comparisons', 384), ('accepted', 360), ('rejected', 24),
                                ('declarationFiles', 368), ('consumers', 720),
                                ('syntax', 368), ('runtime', 48)]:
        assert report[key] == expected_count, (key, report[key])
    assert report['supplementary'] == {'comparisons': 24, 'syntax': 24, 'inventoryCredit': 0}
    assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 384
    assert {row['id'] for row in report['cases']} == set(expected)
    direct_hashes = {}
    for row in report['cases']:
        wanted = expected[row['id']]
        assert all(row[key] == wanted[key] for key in ['accepts', 'diagnostics', 'declarations'])
        assert row.get('consumers') == wanted.get('consumers')
        assert row.get('runtime') == wanted.get('runtime')
        location = report_name.rsplit('/', 1)[0] + '/' + row['id']
        assert read(location + '/observation.json') == row
        for name, text in row['declarations'].items():
            assert content(location + '/dist/' + name) == text.encode('utf-8')
        for name, expected_hash in row.get('javascriptSha256', {}).items():
            assert digest(content(location + '/dist/' + name)) == expected_hash
        if not row['accepts']:
            assert not any(name.startswith(location + '/dist/') for name in names)
        ordinary_name = base + row['id'] + '/observation.json'
        ordinary = read(ordinary_name)
        assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
        assert all(ordinary[key] == wanted[key]
                   for key in ['id', 'accepts', 'diagnostics', 'declarations'])
        direct_hashes[row['id']] = digest(content(ordinary_name))

    alias_reports = {}
    for mode in ['native', 'blue'] if require_native else ['blue']:
        found = reports('alias-' + mode)
        assert len(found) == 1, found
        name = found[0]
        observed = read(name)
        assert observed['mode'] == mode and observed['conclusion'] == 'success'
        assert observed['sourceRevision'] == source and observed['inventoryCredit'] == 0
        assert observed['compilerSha256'] == (compiler if mode == 'blue' else None)
        assert observed['inputSha256'] == digest((fixture / 'alias-controls.json').read_bytes())
        assert observed['implementationSha256'] == frozen['implementationSha256']
        assert observed['comparisons'] == observed['syntax'] == 24
        assert len(observed['cases']) == len({row['id'] for row in observed['cases']}) == 24
        assert {row['id'] for row in observed['cases']} == set(aliases)
        for row in observed['cases']:
            assert row['agrees'] and row['observed'] == aliases[row['id']]
            location = name.rsplit('/', 1)[0] + '/' + row['id']
            for output, text in row['observed']['declarations'].items():
                assert content(location + '/dist/' + output) == text.encode('utf-8')
            for output, expected_hash in row['javascriptSha256'].items():
                assert digest(content(location + '/dist/' + output)) == expected_hash
        alias_reports[mode] = {'path': name, 'sha256': digest(content(name))}

    for ident, wanted in aliases.items():
        ordinary = read(base + 'alias-controls/' + ident + '/observation.json')
        assert ordinary['agrees'] and ordinary['observed'] == wanted
        assert ordinary['inventoryCredit'] == 0
    if require_native:
        found = reports('native')
        assert len(found) == 1 and read(found[0]) == reference
    return {'primaryReport': report_name, 'primaryReportSha256': digest(content(report_name)),
            'compilerSha256': compiler, 'comparisons': 384, 'declarationFiles': 368,
            'consumers': 720, 'syntax': 368, 'runtime': 48, 'separatePolicyControls': 12,
            'supplementaryComparisons': 24, 'supplementarySyntax': 24,
            'supplementaryInventoryCredit': 0, 'ordinaryObservationsSha256': direct_hashes,
            'supplementaryReports': alias_reports}


def audit(root, repo, source, gates):
    bases = [root / (kind + '-capture/conditional-inference') for kind in ['native', 'workspace']]
    names = [file.relative_to(root).as_posix()
             for base in bases for file in base.rglob('*') if file.is_file()]
    content = lambda name: (root / name).read_bytes()
    return {kind: audit_products(repo, source, gates[kind + 'CompilerSha256'],
            kind + '-capture/conditional-inference', names, content, kind == 'native')
            for kind in ['native', 'workspace']}
