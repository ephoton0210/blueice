# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Independently inspect exact P0-E reports and their physical products."""
from pathlib import Path
import hashlib
import json


def audit_products(repo, source, compiler, base, names, content, require_native):
    fixture = repo / 'backend/bluets/tests/fixtures/symbolic_keys'
    digest = lambda data: hashlib.sha256(data).hexdigest()
    read = lambda name: json.loads(content(name))
    frozen = json.loads((fixture / 'FROZEN.json').read_bytes())
    reference = json.loads((fixture / 'reference.json').read_bytes())
    supplement = json.loads((fixture / 'algebra-controls.json').read_bytes())
    for name, expected_hash in {**frozen['sha256'], **frozen['supplementarySha256']}.items():
        assert digest((fixture / name).read_bytes()) == expected_hash, name
    expected = {row['id']: row for row in reference['cases']}
    assert len(expected) == 256 and sum(row['accepts'] for row in expected.values()) == 172
    assert len(json.loads((fixture / 'boundary-controls.json').read_bytes())['controls']) == 12
    algebra = {row['id']: row['expected'] for row in supplement['cases']}
    assert len(algebra) == 16
    base = base.rstrip('/') + '/'

    def reports(label):
        return [name for name in names if name.startswith(base + 'bluets-symbolic-keys-' + label + '-')
                and name.count('/') == base.count('/') + 1 and name.endswith('/report.json')]

    found = reports('blue')
    assert len(found) == 1, found
    report_name = found[0]
    report = read(report_name)
    assert report['conclusion'] == 'success' and report['sourceRevision'] == source
    assert report['compilerSha256'] == compiler and report['frozenInputs'] == frozen['sha256']
    assert report['implementationSha256'] == reference['implementationSha256']
    assert report['libraries'] == reference['libraries']
    for key, expected_count in [('comparisons', 256), ('accepted', 172), ('rejected', 84),
                                ('declarationFiles', 176), ('consumers', 344), ('syntax', 176), ('runtime', 24)]:
        assert report[key] == expected_count, (key, report[key])
    assert report['supplementary'] == {'comparisons': 16, 'syntax': 15, 'inventoryCredit': 0}
    assert len(report['cases']) == len({row['id'] for row in report['cases']}) == 256
    assert {row['id'] for row in report['cases']} == set(expected)
    direct_hashes = {}
    for row in report['cases']:
        wanted = expected[row['id']]
        assert all(row[key] == wanted[key] for key in ['accepts', 'diagnostics', 'declarations'])
        assert row.get('consumers') == wanted.get('consumers')
        assert row.get('runtime') == wanted.get('runtime')
        location = report_name.rsplit('/', 1)[0] + '/' + row['id']
        for name, text in row['declarations'].items():
            assert content(location + '/dist/' + name) == text.encode('utf-8')
        for name, expected_hash in row.get('javascriptSha256', {}).items():
            assert digest(content(location + '/dist/' + name)) == expected_hash
        if not row['accepts']:
            assert not any(name.startswith(location + '/dist/') for name in names)
        ordinary_name = base + row['id'] + '/observation.json'
        ordinary = read(ordinary_name)
        assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
        assert all(ordinary[key] == wanted[key] for key in ['id', 'accepts', 'diagnostics', 'declarations'])
        direct_hashes[row['id']] = digest(content(ordinary_name))

    algebra_reports = {}
    for mode in ['native', 'blue'] if require_native else ['blue']:
        found = reports('algebra-' + mode)
        assert len(found) == 1, found
        name = found[0]
        observed = read(name)
        assert observed['mode'] == mode and observed['conclusion'] == 'success'
        assert observed['sourceRevision'] == source and observed['inventoryCredit'] == 0
        assert observed['compilerSha256'] == (compiler if mode == 'blue' else None)
        assert observed['inputSha256'] == digest((fixture / 'algebra-controls.json').read_bytes())
        assert observed['implementationSha256'] == supplement['implementationSha256']
        assert observed['libraries'] == supplement['libraries']
        assert (observed['accepted'], observed['rejected'], observed['syntax']) == (15, 1, 15)
        assert len(observed['cases']) == len({row['id'] for row in observed['cases']}) == 16
        assert {row['id'] for row in observed['cases']} == set(algebra)
        for row in observed['cases']:
            assert row['agrees'] and not row['publishedOnRejectedNativeInput']
            assert row['observed'] == algebra[row['id']]
            location = name.rsplit('/', 1)[0] + '/' + row['id']
            for output, text in row['observed']['declarations'].items():
                assert content(location + '/dist/' + output) == text.encode('utf-8')
            for output, expected_hash in row['javascriptSha256'].items():
                assert digest(content(location + '/dist/' + output)) == expected_hash
            if not row['observed']['accepts']:
                assert not any(path.startswith(location + '/dist/') for path in names)
        algebra_reports[mode] = {'path': name, 'sha256': digest(content(name))}

    for ident, wanted in algebra.items():
        name = base + 'algebra/' + ident + '/observation.json'
        ordinary = read(name)
        assert ordinary['agrees'] and not ordinary['publishedOnRejectedNativeInput']
        assert ordinary['observed'] == wanted
    if require_native:
        found = reports('native')
        assert len(found) == 1
        replay = read(found[0])
        assert {k: v for k, v in replay.items() if k != 'node'} == {
            k: v for k, v in reference.items() if k != 'node'}
    return {'primaryReport': report_name, 'primaryReportSha256': digest(content(report_name)),
            'compilerSha256': compiler, 'comparisons': 256, 'declarationFiles': 176,
            'consumers': 344, 'syntax': 176, 'runtime': 24, 'separatePolicyControls': 12,
            'supplementaryComparisons': 16, 'supplementarySyntax': 15,
            'supplementaryInventoryCredit': 0, 'ordinaryObservationsSha256': direct_hashes,
            'supplementaryReports': algebra_reports}


def audit(root, repo, source, gates):
    names = [path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()]
    content = lambda name: (root / name).read_bytes()
    return {kind: audit_products(repo, source, gates[kind + 'CompilerSha256'],
        kind + '-capture/symbolic-keys', names, content, kind == 'native')
        for kind in ['native', 'workspace']}
