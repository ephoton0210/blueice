# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""One Cargo pipeline and fixed staged source for prior-package regressions."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
OUT = ROOT / 'preflight-3'
OUT.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
run_text = lambda *args: subprocess.check_output(args, cwd=REPO, text=True).strip()
tree = run_text('git', 'write-tree')
backend = run_text('git', 'rev-parse', tree + ':backend')
revision = 'backend-tree:' + backend
assert not run_text('git', 'diff', '--name-only', '--', 'backend')
paths = sorted(set(subprocess.check_output(['git', 'ls-files', '-z', '--', 'backend',
    'development/browser_core/phase-18-bluets/tools'], cwd=REPO).decode().split('\0')) - {''})
expected = {name: sha(REPO / name) for name in paths}
(OUT / 'source-manifest.json').write_text(json.dumps({'sourceRevision': revision,
    'expectedFiles': expected}, indent=2) + '\n')
state = {'sourceRevision': revision, 'parentCommit': run_text('git', 'rev-parse', 'HEAD'),
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
    'driverSha256': sha(Path(__file__)), 'sourceManifestSha256': sha(OUT / 'source-manifest.json'),
    'steps': [], 'conclusion': 'in_progress', 'stage': 'starting'}
save = lambda: (OUT / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
    CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_TEST_THREADS='1', FORCE_COLOR='0')
if env.get('CARGO_TARGET_DIR'):
    assert Path(env['CARGO_TARGET_DIR']).resolve() == REPO / 'target'
for key in list(env):
    if key.startswith('BLUEICE_WRITE_') or key.startswith('BLUETS_'):
        del env[key]
oracle = REPO / 'target/noinfer-acceptance-20261112/oracles/node_modules'
env['BLUEICE_BLUETSC_ORACLE'] = str(oracle / 'typescript/bin/tsc')
env['BLUEICE_ACORN_ORACLE'] = str(oracle / 'acorn/bin/acorn')
for family in ['SYMBOLIC_KEYS', 'MAPPED_INFERENCE', 'STRING_INTRINSICS', 'NONNULLABLE_AWAITED', 'NOINFER']:
    directory = OUT / family.lower()
    directory.mkdir()
    env['BLUEICE_' + family + '_OBSERVATIONS'] = str(directory)
    env['BLUEICE_' + family + '_SOURCE_REVISION'] = revision
steps = [
    ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--features',
                'blueice-bluets/windows-symlink-tests', '--', '-D', 'warnings']),
    ('build', ['cargo', 'build', '--workspace', '--all-targets', '--locked', '--offline']),
    ('library', ['cargo', 'test', '-p', 'blueice-bluets', '--lib', '--locked', '--offline']),
]
for suite in ['gc1_object_generic_methods', 'symbolic_keys', 'noinfer', 'nonnullable_awaited',
              'string_intrinsics', 'mapped_inference', 'jsx_checker_matrix', 'gt5_compositions']:
    steps.append((suite, ['cargo', 'test', '-p', 'blueice-bluets', '--test', suite,
                         '--locked', '--offline', '--', '--include-ignored']))
try:
    save()
    for label, command in steps:
        state['stage'] = label
        save()
        log = OUT / (label + '.log')
        print('START', label, flush=True)
        with log.open('wb') as output:
            child = subprocess.Popen(command, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
            state['childPid'] = child.pid
            save()
            code = child.wait()
        state['steps'].append({'label': label, 'command': command, 'exit': code,
            'log': log.name, 'sha256': sha(log)})
        state.pop('childPid', None)
        save()
        print('END', label, code, flush=True)
        if code:
            raise RuntimeError(label + ': exit ' + str(code))
    for name, digest in expected.items():
        assert sha(REPO / name) == digest, name
    assert run_text('git', 'rev-parse', run_text('git', 'write-tree') + ':backend') == backend
    shutil.copy2(REPO / 'target/debug/bluetsc', OUT / 'accepted-cli')
    state.update(conclusion='success', stage='complete', compilerSha256=sha(OUT / 'accepted-cli'))
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    raise
finally:
    state['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
