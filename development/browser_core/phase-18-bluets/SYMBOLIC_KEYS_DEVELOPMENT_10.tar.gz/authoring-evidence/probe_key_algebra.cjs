// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Independent supplementary discovery; no primary/inventory completion credit.
const {spawnSync}=require('node:child_process');
const {isDeepStrictEqual}=require('node:util');
const c=require('../../development/browser_core/phase-18-bluets/tools/symbolic_keys/common.cjs');
const {fs,path,assert,sha}=c;
const root=path.join(__dirname,'algebra-probes-1');fs.mkdirSync(root);
const compiler=path.join(__dirname,'green-5-cli');
const ctx=c.context(), cache=new Map(), libraries={};
const options={strict:true,target:'ES2022',module:'CommonJS',lib:['ES5'],declaration:true,noEmitOnError:true,outDir:'dist'};
const pairs=[['left','(E | F) & G'],['right','G & (E | F)'],['separate','(E & G) | (F & G)'],
    ['dual','(E | F) & (G | H)'],['nested','((E | F) & G) | H'],['inverse','(E & F) | G'],
    ['mixed','(E | F) | (G & H)'],['last','(E & F) & (G | H)'],['other','(E | G) & F'],
    ['alternate','(G | F) & E'],['union-three','E | F | G'],['intersection-three','E & F & G']];
const cases=pairs.map(([id,expression])=>({id,source:`export function result<E,F,G,H>(key: keyof (${expression})) { return key; }\n`}));
cases.push({id:'alias-union',source:'type Choices<A,B> = A | B;\nexport function result<E,F,G,H>(key: keyof (Choices<E,F> & G)) { return key; }\n'});
cases.push({id:'alias-intersection',source:'type Both<A,B> = A & B;\nexport function result<E,F,G,H>(key: keyof (Both<E,F> | G)) { return key; }\n'});
for(const [id,sourceType,targetType]of[
    ['distinct-shapes-reject','(E | F) & G','E | (F & G)'],
    ['distinct-shapes-accept','E | (F & G)','(E | F) & G'],
])cases.push({id,source:`export function result<E,F,G>(key: keyof (${sourceType}), consume: (key: keyof (${targetType})) => void) { consume(key); }\n`});
const input={options,cases};fs.writeFileSync(path.join(root,'inputs.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'});
function prepare(role,entry){const cwd=path.join(root,role,entry.id);fs.mkdirSync(cwd,{recursive:true});fs.writeFileSync(path.join(cwd,'main.ts'),entry.source);fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify({compilerOptions:options,files:['main.ts']},null,2)+'\n');return cwd;}
const reference=[];
for(const entry of cases){
    const cwd=prepare('native',entry),converted=ctx.ts.convertCompilerOptionsFromJson(options,cwd);
    const host=ctx.ts.createCompilerHost(converted.options),get=host.getSourceFile;
    host.getSourceFile=(file,version,...rest)=>{const relative=path.relative(path.dirname(ctx.implementation),file);if(relative.startsWith('..'+path.sep)||path.isAbsolute(relative))return get(file,version,...rest);const key=file+':'+version;if(!cache.has(key))cache.set(key,get(file,version,...rest));libraries[path.basename(file)]=sha(fs.readFileSync(file));return cache.get(key);};
    const program=ctx.ts.createProgram([path.join(cwd,'main.ts')],converted.options,host);
    const diagnostics=ctx.ts.sortAndDeduplicateDiagnostics(ctx.ts.getPreEmitDiagnostics(program)).map(d=>c.diagnostic(ctx.ts,d,cwd));
    if(!diagnostics.length)program.emit();
    const declarations=Object.fromEntries(Object.entries(c.inventory(path.join(cwd,'dist'))).filter(([name])=>name.endsWith('.d.ts')));
    const row={id:entry.id,accepts:!diagnostics.length,diagnostics,declarations};reference.push(row);fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n');
}
fs.writeFileSync(path.join(root,'native-reference.json'),JSON.stringify({implementationSha256:sha(fs.readFileSync(ctx.implementation)),libraries,cases:reference},null,2)+'\n',{flag:'wx'});
const results=[];
for(const entry of cases){
    const cwd=prepare('blue',entry),built=spawnSync(compiler,['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8',timeout:120000});if(built.error)throw built.error;
    fs.writeFileSync(path.join(cwd,'build.stdout'),built.stdout||'');fs.writeFileSync(path.join(cwd,'build.stderr'),built.stderr||'');
    const diagnostics=built.stderr.split(/\r?\n/).filter(Boolean).map(line=>{const raw=JSON.parse(line);try{return c.blueDiagnostic(raw);}catch{return{missingNativeCounterpart:raw};}});
    const declarations=Object.fromEntries(Object.entries(c.inventory(path.join(cwd,'dist'))).filter(([name])=>name.endsWith('.d.ts')));
    const row={id:entry.id,accepts:built.status===0,diagnostics,declarations};
    fs.writeFileSync(path.join(cwd,'observation.json'),JSON.stringify(row,null,2)+'\n');
    const native=reference.find(r=>r.id===row.id);results.push({id:row.id,agrees:isDeepStrictEqual(row,native),observed:row,native});
}
const report={scope:'Independent algebra/shape discovery; zero P0-E primary or inventory credit.',compilerSha256:sha(fs.readFileSync(compiler)),inputSha256:sha(fs.readFileSync(path.join(root,'inputs.json'))),cases:results,agreements:results.filter(r=>r.agrees).length,differences:results.filter(r=>!r.agrees).length};
assert.equal(results.length,16);fs.writeFileSync(path.join(root,'report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({cases:results.length,agreements:report.agreements,differences:report.differences,compilerSha256:report.compilerSha256}));
