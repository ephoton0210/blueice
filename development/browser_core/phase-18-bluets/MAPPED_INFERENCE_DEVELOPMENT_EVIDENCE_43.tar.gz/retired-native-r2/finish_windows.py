# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import base64
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('qga_transfer', root.parent / 'noinfer-acceptance-20261112/recovery/qga_transfer.py')
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)
base = 'B:\\BlueIce\\gm3-20261109-360d7d921\\'
pid = json.loads((root / 'windows/package-process.json').read_bytes())['process']['pid']
assert not (root / 'windows/finalize-state.json').exists(), 'Inspect the existing receiver before retry'
state = {'pid': os.getpid(), 'guestPackagingPid': pid, 'stage': 'waiting-existing-package',
         'conclusion': 'in_progress', 'observations': [], 'downloadAttempts':0}


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (root / 'windows/finalize-state.json').write_text(json.dumps(state, indent=2) + '\n')


def receive(remote, destination):
    destination = Path(destination)
    assert not destination.exists(), destination
    state['downloadAttempts'] = state.get('downloadAttempts',0) + 1
    temporary = destination.with_name(destination.name + '.transfer-' + str(state['downloadAttempts']))
    save()
    api.download(remote, temporary)
    temporary.replace(destination)


try:
    save()
    print('Observing existing packaging job', pid, flush=True)
    while True:
        try:
            value = api.call({'execute': 'guest-exec-status', 'arguments': {'pid': pid}})
        except Exception as error:
            state['observations'].append({'error': repr(error), 'at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
            save()
            # A persistent terminal receipt remains valid if QGA has already
            # consumed the direct-child status. Never rerun the guest job.
            try:
                destination = root / 'windows/windows-evidence-receipt.json'
                if not destination.exists():
                    receive(base + 'p0d-r2-windows-evidence.json', destination)
                receipt = json.loads(destination.read_bytes())
                assert receipt['conclusion'] == 'success'
                break
            except Exception:
                time.sleep(15)
                continue
        if value.get('exited'):
            for key in ['out-data', 'err-data']:
                if key in value:
                    value[key] = base64.b64decode(value[key]).decode('utf-8-sig', errors='replace')
            (root / 'windows/package-terminal.json').write_text(json.dumps(value, indent=2) + '\n')
            assert value['exitcode'] == 0, value
            receive(base + 'p0d-r2-windows-evidence.json', root / 'windows/windows-evidence-receipt.json')
            break
        state['lastGuestStatus'] = value
        save()
        time.sleep(15)
    receipt = json.loads((root / 'windows/windows-evidence-receipt.json').read_bytes())
    state['stage'] = 'receiving-terminal-measurement'
    save()
    receive(base + 'results-mapped-inference-r2\\measurement.json', root / 'windows/windows-measurement.json')
    state['stage'] = 'receiving-archive'
    save()
    destination = root / 'windows-evidence.tar.gz'
    receive(receipt['archive'], destination)
    assert destination.stat().st_size == receipt['archiveBytes']
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == receipt['archiveSha256']
    state['stage'] = 'independent-audit'
    save()
    with (root / 'windows/verify-windows.log').open('xb') as log:
        result = subprocess.run([sys.executable, '-B', str(root / 'verify_windows.py')],
            cwd=root.parent.parent, stdout=log, stderr=subprocess.STDOUT,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
    assert result.returncode == 0, (root / 'windows/verify-windows.log').read_text()[-2500:]
    state.update(stage='complete', conclusion='success')
    save()
    print('Windows new-source archive and independent acceptance audit passed.', flush=True)
except Exception as error:
    state.update(conclusion='failure', error=repr(error))
    save()
    raise
