# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""Expand the unchanged discovery with authored consumers and runtime forms."""
from pathlib import Path
import copy
import hashlib
import json

root = Path(__file__).resolve().parent
original_path = root.parent / 'conditional-infer-discovery-20261114/cases.json'
original = json.loads(original_path.read_text())
cases = copy.deepcopy(original['cases'])


def consumer(entry, expected, positives, negative):
    entry['consumerSources'] = {
        'positive': 'import { result } from "./main";\n'
        + f'const output: {expected} = result;\n'
        + ''.join(f'const input{i}: typeof result = {value};\n'
                  for i, value in enumerate(positives)),
        'negative': 'import { result } from "./main";\n' + negative + '\n',
    }


specifications = {
    'covariant-union-control': ('string | number', ['"ok"', '2'], 'const bad: typeof result = true;'),
    'contravariant-disjoint': ('never', [], 'const bad: typeof result = "wrong";'),
    'contravariant-related-literals': ('"b"', ['"b"'], 'const bad: typeof result = "a";'),
    'contravariant-record-intersection': ('{ a: string; b: number }', ['{ a: "ok", b: 2 }'], 'const bad: typeof result = { a: "ok" };'),
    'contravariant-reject-union': ('never', [], 'const bad: typeof result = "wrong";'),
    'mixed-covariance-precedence': ('"ok"', ['"ok"'], 'const bad: typeof result = "wrong";'),
    'mixed-incompatible-rejection-branch': ('"miss"', ['"miss"'], 'const bad: typeof result = "wrong";'),
    'double-contravariance': ('"ok"', ['"ok"'], 'const bad: typeof result = "wrong";'),
    'function-zero-arguments': ('unknown', ['{ any: true }'], 'const bad: string = result;'),
    'function-zero-arguments-reject-literal': ('unknown', ['42'], 'const bad: string = result;'),
    'function-optional-position': ('unknown', ['{ any: true }'], 'const bad: string = result;'),
    'function-constrained-missing': ('string', ['"ok"'], 'const bad: typeof result = 42;'),
    'function-return-control': ('"ok"', ['"ok"'], 'const bad: typeof result = "wrong";'),
    'overload-last-signature-control': ('"last"', ['"last"'], 'const bad: typeof result = "first";'),
    'readonly-array': ('string', ['"ok"'], 'const bad: typeof result = 42;'),
    'tuple-prefix-control': ('[string, [number, boolean]]', ['["ok", [2, true]]'], 'const bad: typeof result = ["ok", ["wrong", true]];'),
    'tuple-suffix-rest': ('[[string, number], boolean]', ['[["ok", 2], true]'], 'const bad: typeof result = [["ok", "wrong"], true];'),
    'tuple-optional-empty': ('[unknown, unknown[]]', ['[42, []]'], 'const bad: typeof result = [];'),
    'conditional-any': ('1 | 2', ['1', '2'], 'const bad: typeof result = 3;'),
    'conditional-never-control': ('never', [], 'const bad: typeof result = 1;'),
    'non-distributive-union-control': ('2', ['2'], 'const bad: typeof result = 1;'),
    'constrained-covariant-union': ('"a" | "b"', ['"a"', '"b"'], 'const bad: typeof result = "c";'),
    'cross-file-contravariance': ('never', [], 'const bad: typeof result = "wrong";'),
    'aliased-candidate-positions': ('never', [], 'const bad: typeof result = "wrong";'),
}
for entry in cases:
    entry['origin'] = 'unchanged-discovery-24'
    consumer(entry, *specifications[entry['id']])


def add(name, definition, operand, expected, positives, negative, runtime_value=None):
    source = definition + '\n'
    if runtime_value is None:
        source += f'declare const value: Infer<{operand}>;\nexport const result = value;\n'
        source += f'export const check: {expected} = result;\n'
    else:
        source += 'function identity<T>(value: T): T { return value; }\n'
        source += f'export const result = identity<Infer<{operand}>>({runtime_value});\n'
    entry = {'id': name, 'source': source, 'files': {},
             'nativeExpectedAccepts': True, 'origin': 'expanded-before-repair'}
    consumer(entry, expected, positives, negative)
    if runtime_value is not None:
        entry['runtime'] = f'if (JSON.stringify(check) !== JSON.stringify({runtime_value})) throw new Error("unexpected runtime value");'
    cases.append(entry)


contra = 'type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void } ? U : "miss";'
co = 'type Infer<T> = T extends { a: infer U; b: infer U } ? U : "miss";'
mixed = 'type Infer<T> = T extends (x: infer U) => infer U ? U : "miss";'
readonly = 'type Infer<T> = T extends readonly (infer U)[] ? U : "miss";'
suffix = 'type Infer<T> = T extends [...infer R, infer L] ? [R, L] : "miss";'

add('contravariant-identical-control', contra, '{ a: (x: string) => void; b: (x: string) => void }',
    'string', ['"ok"'], 'const bad: typeof result = 42;')
add('contravariant-three-observations',
    'type Infer<T> = T extends { a: (x: infer U) => void; b: (x: infer U) => void; c: (x: infer U) => void } ? U : "miss";',
    '{ a: (x: "a" | "b") => void; b: (x: "b" | "c") => void; c: (x: "b" | "d") => void }',
    '"b"', ['"b"'], 'const bad: typeof result = "a";')
add('method-bivariant-candidates',
    'type Infer<T> = T extends { a(x: infer U): void; b(x: infer U): void } ? U : "miss";',
    '{ a(x: string): void; b(x: number): void }',
    'string | number', ['"ok"', '2'], 'const bad: typeof result = true;')
add('nested-double-contravariant-candidates',
    'type Infer<T> = T extends { a: (f: (x: infer U) => void) => void; b: (f: (x: infer U) => void) => void } ? U : "miss";',
    '{ a: (f: (x: string) => void) => void; b: (f: (x: number) => void) => void }',
    'string | number', ['"ok"', '2'], 'const bad: typeof result = true;')
add('covariant-array-candidates',
    'type Infer<T> = T extends { a: (infer U)[]; b: (infer U)[] } ? U : "miss";',
    '{ a: string[]; b: number[] }', 'string | number', ['"ok"', '2'], 'const bad: typeof result = true;')
add('contravariant-array-candidates',
    'type Infer<T> = T extends { a: (x: (infer U)[]) => void; b: (x: (infer U)[]) => void } ? U : "miss";',
    '{ a: (x: string[]) => void; b: (x: number[]) => void }',
    'never', [], 'const bad: typeof result = "wrong";')
add('independent-infer-positions',
    'type Infer<T> = T extends (x: infer A) => infer B ? [A, B] : "miss";',
    '(x: string) => number', '[string, number]', ['["ok", 2]'], 'const bad: typeof result = [2, "wrong"];')
add('two-missing-function-positions',
    'type Infer<T> = T extends (a: infer A, b: infer B) => void ? [A, B] : "miss";',
    '() => void', '[unknown, unknown]', ['[42, {}]'], 'const bad: typeof result = [];')
add('one-missing-function-position',
    'type Infer<T> = T extends (a: infer A, b: infer B) => void ? [A, B] : "miss";',
    '(a: string) => void', '[string, unknown]', ['["ok", {}]'], 'const bad: typeof result = [42, {}];')
add('optional-source-parameter-candidate',
    'type Infer<T> = T extends (a: infer A) => void ? A : "miss";',
    '(a?: string) => void', 'string | undefined', ['"ok"', 'undefined'], 'const bad: typeof result = 42;')
add('complete-function-rest-tuple-control',
    'type Infer<T> = T extends (...args: infer A) => void ? A : "miss";',
    '(a: string, ...tail: number[]) => void', '[a: string, ...tail: number[]]', ['["ok", 1, 2]'], 'const bad: typeof result = [42];')
add('mutable-array-to-readonly-pattern', readonly, 'string[]',
    'string', ['"ok"'], 'const bad: typeof result = 42;')
add('readonly-array-to-mutable-pattern', 'type Infer<T> = T extends (infer U)[] ? U : "miss";',
    'readonly string[]', '"miss"', ['"miss"'], 'const bad: typeof result = "wrong";')
add('readonly-tuple-pattern',
    'type Infer<T> = T extends readonly [infer A, infer B] ? [A, B] : "miss";',
    'readonly [string, number]', '[string, number]', ['["ok", 2]'], 'const bad: typeof result = [2, "wrong"];')
add('tuple-suffix-empty-control', suffix, '[]',
    '"miss"', ['"miss"'], 'const bad: typeof result = "wrong";')
add('tuple-fixed-prefix-and-suffix',
    'type Infer<T> = T extends [string, ...infer R, number] ? R : "miss";',
    '[string, boolean, number]', '[boolean]', ['[true]'], 'const bad: typeof result = ["wrong"];')
add('any-unconditional-unknown-target-control', 'type Infer<T> = T extends unknown ? 1 : 2;',
    'any', '1', ['1'], 'const bad: typeof result = 2;')
add('unknown-conditional-control', 'type Infer<T> = T extends string ? 1 : 2;',
    'unknown', '2', ['2'], 'const bad: typeof result = 1;')

add('runtime-covariant-union', co, '{ a: string; b: number }',
    'string | number', ['"ok"', '2'], 'const bad: typeof result = true;', '"ok"')
add('runtime-contravariant-literal', contra,
    '{ a: (x: "a" | "b") => void; b: (x: "b" | "c") => void }',
    '"b"', ['"b"'], 'const bad: typeof result = "a";', '"b"')
add('runtime-contravariant-record', contra,
    '{ a: (x: { a: string }) => void; b: (x: { b: number }) => void }',
    '{ a: string; b: number }', ['{ a: "ok", b: 2 }'], 'const bad: typeof result = { a: "ok" };', '{ a: "ok", b: 2 }')
add('runtime-mixed-candidate-precedence', mixed, '(x: string) => "ok"',
    '"ok"', ['"ok"'], 'const bad: typeof result = "wrong";', '"ok"')
add('runtime-readonly-element', readonly, 'readonly string[]',
    'string', ['"ok"'], 'const bad: typeof result = 42;', '"ok"')
add('runtime-variadic-suffix', suffix, '[string, number, boolean]',
    '[[string, number], boolean]', ['[["ok", 2], true]'], 'const bad: typeof result = [["ok", "wrong"], true];', '[["ok", 2], true]')

assert len(cases) == 48 and len({row['id'] for row in cases}) == 48
assert sum('runtime' in row for row in cases) == 6
assert all(cases[i]['source'] == original['cases'][i]['source'] for i in range(24))
profiles = []
for target in ['ES5', 'ES2022']:
    for module in ['CommonJS', 'ESNext']:
        for strict_function in [True, False]:
            profiles.append({'id': f'{target.lower()}-{module.lower()}-functions-{str(strict_function).lower()}',
                             'compilerOptions': {'target': target, 'module': module,
                                                 'strictFunctionTypes': strict_function}})
for entry in cases:
    if entry['id'] in ['mixed-incompatible-rejection-branch', 'aliased-candidate-positions']:
        entry['nativeExpectedAcceptsByProfile'] = {
            profile['id']: False for profile in profiles
            if not profile['compilerOptions']['strictFunctionTypes']
        }
payload = {'schema': 1, 'scope': 'Authored expanded inputs, independent of implementation and acceptance status.',
           'originalDiscoveryInputSha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
           'options': original['options'], 'profiles': profiles, 'cases': cases}
with (root / 'cases.json').open('x') as output:
    json.dump(payload, output, indent=2)
    output.write('\n')
controls = []
for name, definition, operand in [
    ('contravariant-candidates', contra, '{ a: (x: string) => void; b: (x: number) => void }'),
    ('mixed-candidates', mixed, '(x: string) => "ok"'),
    ('variadic-suffix', suffix, '[string, number, boolean]'),
]:
    source = definition + '\n' + f'declare const value: Infer<{operand}>;\nexport const result = value;\n'
    for limit in [0, 1]:
        controls.append({'id': f'{name}-work-{limit}', 'kind': 'resource-limit',
                         'source': source, 'limited': {'max_type_expansions': limit}})
for limit in [0, 1]:
    controls.append({'id': f'conditional-parser-{limit}', 'kind': 'resource-limit',
                     'source': 'type Infer<T> = T extends readonly [infer A, infer B] ? [A, B] : never;\n'
                               'export const result: Infer<readonly [string, number]> = ["ok", 2];\n',
                     'limited': {'parser.max_type_depth': limit}})
for name, declaration, annotation, value in [
    ('ExternalInfer', 'type ExternalInfer<T> = T extends { value: infer U } ? U : never;',
     'ExternalInfer<{ value: string }>', '"ok"'),
    ('ExternalPair', 'type ExternalPair<T> = T extends [infer A, infer B] ? [A, B] : never;',
     'ExternalPair<[string, number]>', '["ok", 2]'),
]:
    controls.append({'id': f'ambient-{name}', 'kind': 'ambient-owner',
                     'declaration': declaration,
                     'source': f'export const result: {annotation} = {value};\n'})
    controls.append({'id': f'runtime-{name}', 'kind': 'runtime-authority',
                     'declaration': declaration, 'source': f'{name}("wrong");\n'})
assert len(controls) == 12
with (root / 'boundary-controls.json').open('x') as output:
    json.dump({'schema': 1, 'scope': 'Separate policy controls; zero direct Native agreement credit.',
               'controls': controls}, output, indent=2)
    output.write('\n')
print(f'Authored {len(cases)} forms across {len(profiles)} profiles before production changes.')
