// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

// Measure complete diagnostics/declarations without granting acceptance credit.
const fs = require('node:fs'), path = require('node:path');
const assert = require('node:assert/strict');
const {isDeepStrictEqual} = require('node:util');
const {createHash} = require('node:crypto');
const {spawnSync} = require('node:child_process');
const root = __dirname, repo = path.resolve(root, '../..');
const fixture = path.join(repo, 'backend/bluets/tests/fixtures/conditional_inference');
const {inventory, writeSources, blueDiagnostic} = require(path.join(repo,
    'development/browser_core/phase-18-bluets/tools/string_intrinsics/files.cjs'));
const sha = data => createHash('sha256').update(data).digest('hex');
const frozen = JSON.parse(fs.readFileSync(path.join(fixture, 'FROZEN.json')));
for (const [name, digest] of Object.entries(frozen.sha256))
    assert.equal(sha(fs.readFileSync(path.join(fixture, name))), digest);
const input = JSON.parse(fs.readFileSync(path.join(fixture, 'cases.json')));
const reference = JSON.parse(fs.readFileSync(path.join(fixture, 'reference.json')));
const expected = new Map(reference.cases.map(row => [row.id, row]));
const compiler = path.join(repo, 'target/symbolic-keys-acceptance-20261113-r1/accepted-workspace-cli');
assert.equal(sha(fs.readFileSync(compiler)), frozen.productionBaseline.compilerSha256);
const output = path.join(root, 'accepted-e-expanded-baseline');
fs.mkdirSync(output);
fs.copyFileSync(__filename, path.join(output, 'baseline.cjs'));
for (const name of ['FROZEN.json', ...Object.keys(frozen.sha256)])
    fs.copyFileSync(path.join(fixture, name), path.join(output, name));
const rows = [];
for (const profile of input.profiles) {
    for (const entry of input.cases) {
        const id = profile.id + '/' + entry.id, cwd = path.join(output, id);
        fs.mkdirSync(cwd, {recursive: true});
        writeSources(cwd, entry);
        fs.writeFileSync(path.join(cwd, 'tsconfig.json'), JSON.stringify({
            compilerOptions: {...input.options, ...profile.compilerOptions},
            files: ['main.ts', ...Object.keys(entry.files)],
        }, null, 2) + '\n');
        const built = spawnSync(compiler, ['build', '--config', 'tsconfig.json', '--diagnostics-json'],
            {cwd, encoding: 'utf8', timeout: 120000});
        if (built.error) throw built.error;
        fs.writeFileSync(path.join(cwd, 'build.stdout'), built.stdout);
        fs.writeFileSync(path.join(cwd, 'build.stderr'), built.stderr);
        const diagnostics = built.stderr.trim() ? built.stderr.trim().split('\n').map(line => {
            try { return blueDiagnostic(JSON.parse(line)); }
            catch { return {missingNativeCounterpart: true, text: line}; }
        }) : [];
        const outputs = inventory(path.join(cwd, 'dist'));
        const observed = {accepts: built.status === 0, diagnostics,
            declarations: Object.fromEntries(Object.entries(outputs).filter(([name]) => name.endsWith('.d.ts')))};
        const native = expected.get(id);
        const wanted = {accepts: native.accepts, diagnostics: native.diagnostics, declarations: native.declarations};
        const row = {id, agrees: isDeepStrictEqual(observed, wanted), observed,
            exit: built.status, signal: built.signal,
            outputsSha256: Object.fromEntries(Object.entries(outputs).map(([name, text]) => [name, sha(text)])),
            publishedOnRejectedNativeInput: !native.accepts && Object.keys(outputs).length > 0};
        rows.push(row);
        fs.writeFileSync(path.join(cwd, 'observation.json'), JSON.stringify(row, null, 2) + '\n');
        if (rows.length % 48 === 0) console.log('BASELINE', rows.length, '/384');
    }
}
for (const [name, digest] of Object.entries(frozen.sha256))
    assert.equal(sha(fs.readFileSync(path.join(fixture, name))), digest);
assert.equal(rows.length, 384);
const report = {schema: 1, scope: 'Complete diagnostics/declarations baseline; no inventory or acceptance credit.',
    baseline: frozen.productionBaseline, frozenInputs: frozen.sha256,
    comparisons: rows.length, completeAgreements: rows.filter(row => row.agrees).length,
    completeDifferences: rows.filter(row => !row.agrees).length,
    publishedOnRejectedNativeInputs: rows.filter(row => row.publishedOnRejectedNativeInput).length,
    cases: rows};
fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({...report, cases: undefined}));
