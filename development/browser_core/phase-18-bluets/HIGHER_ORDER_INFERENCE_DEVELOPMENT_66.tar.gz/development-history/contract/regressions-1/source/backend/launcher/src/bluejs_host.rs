// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Launcher supervision and execution for the first isolated BlueJS page
//! host.
//!
//! [`SpawnedBlueJsHost`] owns a separate `blueice-bluejs-host` child, its
//! private Unix socket, and its one-time connection capability. The child
//! owns every [`BlueJsPageRuntime`] VM and program registry; no `Vm`, source
//! text, program handle, or DOM object crosses back into the launcher. Only
//! an exact paused-slot, bounded plain-data debugger preview may now carry a
//! runtime value. A future core page-loader adapter is responsible for deriving
//! [`PageHostDocument`] from an already-authorized navigation. This module
//! deliberately does not let a page or a frontend connect to the child.

use blueice_bluejs::{
    parse, parse_module, BlueJsPageDebuggerExecutionState, BlueJsPageDebuggerFrame,
    BlueJsPageDebuggerLinkedExecutionState, BlueJsPageDebuggerLinkedFrame,
    BlueJsPageDebuggerNestedExecutionState, BlueJsPageDebuggerValueTarget, BlueJsPageOrigin,
    BlueJsPageRuntime, BlueJsPageRuntimeConfig, BlueJsPageRuntimeError, BlueJsProgramHandle,
    BlueJsProgramV1, BlueJsSourceIdentity, CompileError, HeapConfig, HostFunctionError,
    HostObjectFamily, HostObjectKey, HostValue, Module, ParseError, ParsedStatementSpan,
    RuntimeError, Value, Vm, VmConfig, VmDebuggerScopeEntry, VmDebuggerValuePreview,
    VM_DEBUGGER_MAX_SCOPE_ENTRIES, VM_DEBUGGER_MAX_STACK_FRAMES,
};
use blueice_bluets::{
    compile, AuthorizedModule, AuthorizedModuleLoader, AuthorizedModuleResolution, CompilerOptions,
    Contract, ContractPlan, ContractValue, EcmaTarget, ModuleKind, RuntimePolicy, SourceMap,
    ValidationLimits,
};
use blueice_bluets_bluejs::page_host_typings::{
    page_host_document_runtime_bindings_v1, page_host_dom_event_runtime_bindings_v1,
    page_host_dom_mutation_runtime_bindings_v1, page_host_dom_text_runtime_bindings_v1,
    PageHostDocumentTypingsV1,
};
use blueice_bluets_bluejs::{
    compile_direct_module_graph, compile_direct_script, BridgeError, DirectDebugRegistry,
    DirectModuleGraph, DirectPageModuleGraphAttachment, DirectRootSymbolSlot,
    DirectSafePointBinding, DirectScript, RetainedDirectDebugInfo,
};
use blueice_ipc::compiler::CompilerContractValue;
use blueice_ipc::debugger::{
    DebuggerSourceCoordinates, DebuggerStaticMetadataContractRootKind,
    DebuggerStaticMetadataSymbolKind, DEBUGGER_STATIC_METADATA_CONTRACT_DISPLAY_MAX_BYTES,
    DEBUGGER_STATIC_METADATA_CONTRACT_VALIDATION_MAX_COLLECTION_ENTRIES,
    DEBUGGER_STATIC_METADATA_CONTRACT_VALIDATION_MAX_DEPTH,
    DEBUGGER_STATIC_METADATA_CONTRACT_VALIDATION_MAX_NODES,
    DEBUGGER_STATIC_METADATA_CONTRACT_VALIDATION_MAX_STRING_BYTES,
    DEBUGGER_STATIC_METADATA_MAX_CONTRACTS, DEBUGGER_STATIC_METADATA_MAX_SOURCES,
    DEBUGGER_STATIC_METADATA_MAX_SOURCE_SPAN_BYTES, DEBUGGER_STATIC_METADATA_MAX_SYMBOLS,
    DEBUGGER_STATIC_METADATA_MAX_TYPES, DEBUGGER_STATIC_METADATA_SYMBOL_DISPLAY_MAX_BYTES,
    DEBUGGER_STATIC_METADATA_TYPE_DISPLAY_MAX_BYTES,
};
use blueice_ipc::page_host::{
    self, PageHostBlueTsEmissionProfile, PageHostChildStats,
    PageHostDebuggerBlueTsExceptionLocation, PageHostDebuggerBlueTsMetadataContractDisplay,
    PageHostDebuggerBlueTsMetadataContractId, PageHostDebuggerBlueTsMetadataContractLocation,
    PageHostDebuggerBlueTsMetadataContractValidation,
    PageHostDebuggerBlueTsMetadataLoweringSummary, PageHostDebuggerBlueTsMetadataSourceId,
    PageHostDebuggerBlueTsMetadataSourceProvenance, PageHostDebuggerBlueTsMetadataSummary,
    PageHostDebuggerBlueTsMetadataSymbolContract, PageHostDebuggerBlueTsMetadataSymbolDisplay,
    PageHostDebuggerBlueTsMetadataSymbolId, PageHostDebuggerBlueTsMetadataSymbolLocation,
    PageHostDebuggerBlueTsMetadataSymbolType, PageHostDebuggerBlueTsMetadataTypeDisplay,
    PageHostDebuggerBlueTsMetadataTypeId, PageHostDebuggerBlueTsSafePointSpan,
    PageHostDebuggerEmittedOriginalPosition, PageHostDebuggerEmittedPausedRootLocation,
    PageHostDebuggerExecutionState, PageHostDebuggerFrame, PageHostDebuggerLinkedExecutionState,
    PageHostDebuggerLinkedFrame, PageHostDebuggerLinkedSource, PageHostDebuggerLinkedStackFrame,
    PageHostDebuggerLinkedStackSnapshot, PageHostDebuggerLinkedValueSnapshot,
    PageHostDebuggerLinkedValueTarget, PageHostDebuggerMetadataHandle, PageHostDebuggerProgram,
    PageHostDebuggerSafePoint, PageHostDebuggerScopeEntry, PageHostDebuggerStackFrame,
    PageHostDebuggerStackSnapshot, PageHostDebuggerStaticScopeRelation,
    PageHostDebuggerStaticScopeTarget, PageHostDebuggerSystemStackFrame,
    PageHostDebuggerSystemStackSnapshot, PageHostDebuggerValuePreview,
    PageHostDebuggerValueSnapshot, PageHostDebuggerValueTarget, PageHostDocument,
    PageHostDocumentSnapshot, PageHostErrorCode, PageHostModuleGraph, PageHostRealmStats,
    PageHostReply, PageHostRequest, PageHostScript, PageHostScriptKind, PageHostScriptLanguage,
    PageHostScriptOutcome, PageHostScriptReport, PageHostScriptSourcePosition, PageHostSource,
    PageHostStaticResolution, PAGE_HOST_DEBUGGER_MAX_BREAKPOINTS_PER_REALM,
    PAGE_HOST_DEBUGGER_MAX_SAFE_POINTS_PER_PROGRAM, PAGE_HOST_DEBUGGER_MAX_SCOPE_ENTRIES,
    PAGE_HOST_DEBUGGER_MAX_STACK_FRAMES, PAGE_HOST_DOCUMENT_ORIGIN_MAX_BYTES,
    PAGE_HOST_DOCUMENT_TEXT_MAX_BYTES,
};
use blueice_ipc::script::{
    self, ScriptDocumentTarget, ScriptReply, ScriptRequest, SCRIPT_MAX_NAME_BYTES,
    SCRIPT_MAX_TEXT_BYTES,
};
use blueice_net::canonical_http_origin;
use std::cell::RefCell;
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::fs;
use std::io;
use std::os::unix::fs::PermissionsExt;
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::{Path, PathBuf};
use std::process::{Child, Command};
use std::rc::Rc;
use std::sync::atomic::{AtomicU64, Ordering};
use std::thread;
use std::time::{Duration, Instant};

/// Execution/source limits independently enforced by the child. The caller
/// cannot widen them by serializing a larger graph over its private socket.
const MAX_SCRIPTS_PER_DOCUMENT: usize = 256;
const MAX_MODULES_PER_GRAPH: usize = page_host::PAGE_HOST_MAX_MODULES_PER_GRAPH;
const MAX_SOURCE_BYTES_PER_MODULE: usize = 1024 * 1024;
const MAX_SOURCE_BYTES_PER_DOCUMENT: usize = 8 * 1024 * 1024;
// A freshly rebuilt child may spend several seconds in macOS's first-launch
// executable validation before it reaches its socket bind. Keep the deadline
// finite, but do not misclassify that cold start as a dead child.
const STARTUP_TIMEOUT: Duration = Duration::from_secs(15);
/// A child DOM callback must fail before the core's 60-second nested wait.
const SCRIPT_DOM_CALL_WAIT: Duration = Duration::from_secs(30);

/// Static metadata inventory IDs are private to the child but intentionally
/// start in a separate range from child debugger-program IDs. The type-level
/// distinction remains the primary boundary; this disjoint start additionally
/// prevents a plausible-looking numeric program ID from being replayed as a
/// metadata handle by a buggy core adapter.
const CHILD_DEBUGGER_METADATA_ID_NAMESPACE_START: u64 = 1 << 63;

/// Immutable launcher-owner limits for one isolated page-host child.
///
/// Per-realm envelopes and conservative child-wide reservations. Each live
/// realm reserves its full program, root-bytecode, and VM-managed-heap budget
/// before admission. This is not an RSS or fleet memory limit: VM accounting
/// excludes allocator, Rust, registry, source, and operating-system overhead.
/// Only the launcher may select these values before starting a core generation;
/// page, frontend, and page-host IPC cannot inspect or modify them.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BlueJsHostRuntimeLimits {
    pub max_realms: usize,
    pub max_programs_per_realm: usize,
    pub max_bytecode_bytes_per_realm: usize,
    pub max_heap_bytes_per_realm: usize,
    pub max_reserved_programs: usize,
    pub max_reserved_bytecode_bytes: usize,
    pub max_reserved_heap_bytes: usize,
}

impl Default for BlueJsHostRuntimeLimits {
    fn default() -> Self {
        Self::from_runtime_config(BlueJsPageRuntimeConfig::default())
    }
}

impl BlueJsHostRuntimeLimits {
    fn from_runtime_config(runtime: BlueJsPageRuntimeConfig) -> Self {
        Self {
            max_realms: runtime.max_realms,
            max_programs_per_realm: runtime.max_programs_per_realm,
            max_bytecode_bytes_per_realm: runtime.max_bytecode_bytes_per_realm,
            max_heap_bytes_per_realm: runtime.vm.heap.max_heap_bytes,
            max_reserved_programs: runtime
                .max_realms
                .saturating_mul(runtime.max_programs_per_realm),
            max_reserved_bytecode_bytes: runtime
                .max_realms
                .saturating_mul(runtime.max_bytecode_bytes_per_realm),
            max_reserved_heap_bytes: runtime
                .max_realms
                .saturating_mul(runtime.vm.heap.max_heap_bytes),
        }
    }

    /// Rebuilds the one narrow policy surface into the full BlueJS runtime
    /// configuration. All non-resource VM configuration remains the child
    /// default rather than becoming an embedding/deployment API.
    pub fn runtime_config(self) -> Result<BlueJsPageRuntimeConfig, &'static str> {
        if self.max_realms == 0
            || self.max_programs_per_realm == 0
            || self.max_bytecode_bytes_per_realm == 0
            || self.max_heap_bytes_per_realm == 0
            || self.max_reserved_programs == 0
            || self.max_reserved_bytecode_bytes == 0
            || self.max_reserved_heap_bytes == 0
        {
            return Err("BlueJS page-host runtime limits must be non-zero");
        }
        if self.max_reserved_programs < self.max_programs_per_realm
            || self.max_reserved_bytecode_bytes < self.max_bytecode_bytes_per_realm
            || self.max_reserved_heap_bytes < self.max_heap_bytes_per_realm
        {
            return Err("BlueJS child-wide reservations must cover one full realm");
        }
        let defaults = BlueJsPageRuntimeConfig::default();
        let heap = HeapConfig {
            max_heap_bytes: self.max_heap_bytes_per_realm,
            major_threshold_bytes: defaults
                .vm
                .heap
                .major_threshold_bytes
                .min(self.max_heap_bytes_per_realm),
            ..defaults.vm.heap
        };
        let runtime = BlueJsPageRuntimeConfig {
            vm: VmConfig {
                heap,
                ..defaults.vm
            },
            max_realms: self.max_realms,
            max_programs_per_realm: self.max_programs_per_realm,
            max_bytecode_bytes_per_realm: self.max_bytecode_bytes_per_realm,
        };
        // PageRuntime validates its own count and byte bounds, while a VM
        // would otherwise defer malformed heap tuning until the first realm.
        Vm::new(runtime.vm).map_err(|_| "BlueJS page-host heap limits are invalid")?;
        BlueJsPageRuntime::new(runtime)
            .map(|_| runtime)
            .map_err(|_| "BlueJS page-host runtime limits are invalid")
    }
}

struct LiveDocument {
    generation: u64,
    origin: BlueJsPageOrigin,
    click_event_family: Option<HostObjectFamily>,
    pending_click_tasks: VecDeque<PendingClickTask>,
    debugger_execution_control: bool,
    debugger_programs: BTreeMap<u64, ChildDebuggerProgram>,
    /// Compiler-produced maps bound to exact live generated-JavaScript
    /// programs. Direct BlueTS and ordinary JavaScript have no entry.
    emitted_maps: BTreeMap<PageHostDebuggerProgram, BoundEmittedMap>,
    /// Exact child-private breakpoint configuration records. These are not a
    /// VM interruption hook; replacing or closing the realm drops them.
    debugger_breakpoints: BTreeSet<PageHostDebuggerSafePoint>,
    pending_debugger_executions: VecDeque<PendingDebuggerExecution>,
    debugger_execution_states: BTreeMap<PageHostDebuggerProgram, ChildDebuggerExecutionStatus>,
}

/// A core-originated click is bound to its original document, never to a
/// successor realm or a page-supplied target.
#[derive(Clone, Copy)]
struct PendingClickTask {
    generation: u64,
    node_id: u64,
}

// Page-host requests are sequential today: the child must complete the
// current click task and its checkpoint before replying to core. Retain an
// explicit, one-slot per-realm queue so future scheduling cannot silently
// turn this into an unbounded collection of pending page work.
const MAX_PENDING_CLICK_TASKS_PER_REALM: usize = 1;

/// A source-span step can consume no more than this many root instructions
/// before yielding the still-live continuation at an exact root boundary.
/// The count is child-fixed and cannot be widened by a page or debugger peer.
const MAX_BLUETS_SOURCE_STEP_ROOT_INSTRUCTIONS: u16 = 256;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct BlueTsSourceSpanKey {
    source_id: u32,
    start_byte: u32,
    end_byte: u32,
}

/// Private child-only association between a child-minted opaque debugger
/// identity and its BlueJS registry handle. The registry handle never leaves
/// this process; the core separately mints its public debugger identity.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ChildDebuggerProgram {
    program_generation: u64,
    runtime_handle: BlueJsProgramHandle,
    /// Created only on the first authenticated metadata-inventory request
    /// while the matching BlueTS registry attachment is still live. A plain
    /// JavaScript program never receives one.
    metadata: Option<PageHostDebuggerMetadataHandle>,
    /// Snapshotted before another realm execution can replace the VM sidecar.
    /// The entire record remains private to this document and child program.
    exception_location: Option<ChildDebuggerExceptionLocation>,
}

struct BoundEmittedMap {
    generated: PageHostSource,
    map: SourceMap,
    /// Set exactly once when the compiler-produced map is installed beside
    /// its live child program. Matching source bytes alone do not authorize
    /// reuse after a document or program generation changes.
    admitted_for: Option<(u64, PageHostDebuggerProgram)>,
    emission_profile: PageHostBlueTsEmissionProfile,
    top_level_spans: Vec<ParsedStatementSpan>,
    identifier_spans: Vec<blueice_bluejs::ParsedIdentifierSpan>,
    /// Module FunctionDeclarations are instantiated before evaluation and
    /// may share the next executable statement's instruction boundary.
    non_evaluating_top_level_statements: BTreeSet<usize>,
    /// Parser-certified outer/inner ES5 spread-helper call tokens. The
    /// compiled safe points are still checked against the live generation.
    nested_spread_helper: Option<CertifiedNestedSpreadHelper>,
}

struct CertifiedNestedSpreadHelper {
    statement_index: usize,
    name: String,
    source_starts: [usize; 2],
}

impl BoundEmittedMap {
    const MAX_RETAINED_BYTES: usize = 16 * 1024 * 1024;
    const MAX_SEGMENTS: usize = 200_000;

    fn new(
        generated: PageHostSource,
        map: SourceMap,
        emission_profile: PageHostBlueTsEmissionProfile,
        top_level_spans: Vec<ParsedStatementSpan>,
        identifier_spans: Vec<blueice_bluejs::ParsedIdentifierSpan>,
    ) -> Result<Self, &'static str> {
        Self::new_with_non_evaluating(
            generated,
            map,
            emission_profile,
            top_level_spans,
            identifier_spans,
            BTreeSet::new(),
        )
    }

    fn new_with_non_evaluating(
        generated: PageHostSource,
        map: SourceMap,
        emission_profile: PageHostBlueTsEmissionProfile,
        top_level_spans: Vec<ParsedStatementSpan>,
        identifier_spans: Vec<blueice_bluejs::ParsedIdentifierSpan>,
        non_evaluating_top_level_statements: BTreeSet<usize>,
    ) -> Result<Self, &'static str> {
        map.original_position_at(
            &generated.source,
            0,
            0,
            Self::MAX_SEGMENTS,
            Self::MAX_RETAINED_BYTES,
        )
        .map_err(|_| "BlueTS emitted source map is invalid or over budget")?;
        let mut bound = Self {
            generated,
            map,
            admitted_for: None,
            emission_profile,
            top_level_spans,
            identifier_spans,
            non_evaluating_top_level_statements,
            nested_spread_helper: None,
        };
        if bound
            .non_evaluating_top_level_statements
            .iter()
            .any(|index| *index >= bound.top_level_spans.len())
        {
            return Err("BlueTS emitted non-evaluating statement provenance is invalid");
        }
        if bound
            .top_level_spans
            .iter()
            .enumerate()
            .any(|(index, span)| {
                span.start_byte >= span.end_byte
                    || span.end_byte > bound.generated.source.len()
                    || !bound.generated.source.is_char_boundary(span.start_byte)
                    || !bound.generated.source.is_char_boundary(span.end_byte)
                    || index > 0 && bound.top_level_spans[index - 1].end_byte > span.start_byte
            })
        {
            return Err("BlueTS emitted parser provenance is invalid");
        }
        if bound.identifier_spans.iter().any(|span| {
            span.start_byte >= span.end_byte
                || span.end_byte > bound.generated.source.len()
                || !bound.generated.source.is_char_boundary(span.start_byte)
                || !bound.generated.source.is_char_boundary(span.end_byte)
                || {
                    let index = bound
                        .top_level_spans
                        .partition_point(|statement| statement.end_byte <= span.start_byte);
                    bound.top_level_spans.get(index).is_none_or(|statement| {
                        statement.start_byte > span.start_byte || span.end_byte > statement.end_byte
                    })
                }
        }) {
            return Err("BlueTS emitted identifier provenance is invalid");
        }
        bound.nested_spread_helper = bound.certify_nested_spread_helper();
        if bound
            .retained_bytes()
            .is_none_or(|bytes| bytes > Self::MAX_RETAINED_BYTES)
        {
            return Err("BlueTS emitted source map exceeds retention budget");
        }
        Ok(bound)
    }

    fn admit_for(&mut self, document_generation: u64, program: PageHostDebuggerProgram) {
        assert!(
            self.admitted_for.is_none(),
            "an emitted map may be admitted for only one live program"
        );
        self.admitted_for = Some((document_generation, program));
    }

    fn retained_bytes(&self) -> Option<usize> {
        let mut bytes = std::mem::size_of::<Self>()
            .checked_add(std::mem::size_of::<PageHostDebuggerProgram>())?
            .checked_add(
                self.non_evaluating_top_level_statements
                    .len()
                    // A B-tree entry owns more than its usize key. Charge a
                    // conservative whole-node share, not just payload bytes.
                    .checked_mul(128)?,
            )?
            .checked_add(self.generated.canonical_module_id.capacity())?
            .checked_add(self.generated.source.capacity())?
            .checked_add(self.generated.source_hash.capacity())?
            .checked_add(self.map.file.capacity())?
            .checked_add(self.map.source_root.capacity())?
            .checked_add(self.map.mappings.capacity())?;
        bytes = bytes.checked_add(
            self.top_level_spans
                .capacity()
                .checked_mul(std::mem::size_of::<ParsedStatementSpan>())?,
        )?;
        bytes = bytes.checked_add(
            self.identifier_spans
                .capacity()
                .checked_mul(std::mem::size_of::<blueice_bluejs::ParsedIdentifierSpan>())?,
        )?;
        for span in &self.identifier_spans {
            bytes = bytes.checked_add(span.name.capacity())?;
        }
        if let Some(helper) = &self.nested_spread_helper {
            bytes = bytes.checked_add(helper.name.capacity())?;
        }
        for table in [
            &self.map.sources,
            &self.map.sources_content,
            &self.map.names,
        ] {
            bytes = bytes.checked_add(
                table
                    .capacity()
                    .checked_mul(std::mem::size_of::<String>())?,
            )?;
            for value in table {
                bytes = bytes.checked_add(value.capacity())?;
            }
        }
        Some(bytes)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ChildRootSlotLookupError {
    UnknownDocument,
    StaleDocument,
    InvalidProgram,
    InvalidMetadata,
    Unavailable,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ChildDebuggerExceptionLocation {
    safe_point: PageHostDebuggerSafePoint,
    span: PageHostDebuggerBlueTsSafePointSpan,
}

/// Child-private execution state for one retained classic or module root.
/// It has no serializable VM frame, source, bytecode, or completion value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ChildDebuggerExecutionStatus {
    Pending,
    Paused(PageHostDebuggerSafePoint),
    NestedPaused {
        frame: BlueJsPageDebuggerFrame,
        safe_point: PageHostDebuggerSafePoint,
    },
    NestedStepRequested {
        frame: BlueJsPageDebuggerFrame,
        safe_point: PageHostDebuggerSafePoint,
    },
    NestedResumeRequested {
        frame: BlueJsPageDebuggerFrame,
        safe_point: PageHostDebuggerSafePoint,
    },
    LinkedPaused {
        frame: BlueJsPageDebuggerLinkedFrame,
        safe_point: PageHostDebuggerSafePoint,
    },
    LinkedResumeRequested {
        frame: BlueJsPageDebuggerLinkedFrame,
        safe_point: PageHostDebuggerSafePoint,
    },
    StepRequested,
    BlueTsSourceStepRequested {
        origin: BlueTsSourceSpanKey,
        remaining: u16,
    },
    SourceStepLimitReached(PageHostDebuggerSafePoint),
    ResumeRequested,
    Completed,
}

/// A child-local cross-program stack; the v39 same-program wire never sees it.
#[derive(Debug, Clone, PartialEq, Eq)]
struct ChildLinkedStackFrame {
    safe_point: PageHostDebuggerSafePoint,
    scope_entries: Vec<PageHostDebuggerScopeEntry>,
    scope_truncated: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ChildLinkedStackSnapshot {
    frames: [ChildLinkedStackFrame; 2],
    stack_truncated: bool,
    max_scope_entries: u32,
}

impl ChildLinkedStackSnapshot {
    fn to_wire(&self) -> PageHostDebuggerLinkedStackSnapshot {
        PageHostDebuggerLinkedStackSnapshot {
            frames: self
                .frames
                .clone()
                .map(|frame| PageHostDebuggerLinkedStackFrame {
                    safe_point: frame.safe_point,
                    scope_entries: frame.scope_entries,
                    scope_truncated: frame.scope_truncated,
                }),
            stack_truncated: self.stack_truncated,
            max_scope_entries: self.max_scope_entries,
        }
    }

    fn from_wire(snapshot: &PageHostDebuggerLinkedStackSnapshot) -> Self {
        Self {
            frames: snapshot.frames.clone().map(|frame| ChildLinkedStackFrame {
                safe_point: frame.safe_point,
                scope_entries: frame.scope_entries,
                scope_truncated: frame.scope_truncated,
            }),
            stack_truncated: snapshot.stack_truncated,
            max_scope_entries: snapshot.max_scope_entries,
        }
    }
}

/// A document-order declaration retained by the child in an explicitly
/// core-selected debugger-execution document. Classic programs are admitted
/// before the first advance so core can discover an opaque identity; a BlueTS
/// ESM entry is also admitted with its graph. All source-bearing data remains
/// in this child-only queue.
enum DeferredChildExecution {
    JavaScriptClassic {
        handle: BlueJsProgramHandle,
        root_safe_point: Option<PageHostDebuggerSafePoint>,
    },
    JavaScriptModule {
        graph: PageHostModuleGraph,
        programs: BTreeMap<String, BlueJsProgramV1>,
    },
    BlueTsClassic {
        handle: BlueJsProgramHandle,
        root_safe_point: Option<PageHostDebuggerSafePoint>,
    },
    BlueTsModule {
        attachment: DeferredModuleAttachment,
        root_safe_point: Option<PageHostDebuggerSafePoint>,
    },
}

/// A module debugger queue owns the exact installed graph, whether its
/// provenance is direct BlueTS metadata or child-compiled emitted JavaScript.
/// Emitted maps live separately in `LiveDocument::emitted_maps`, keyed by the
/// opaque generation minted for each handle in this attachment.
enum DeferredModuleAttachment {
    Direct(DirectPageModuleGraphAttachment),
    Emitted(EmittedPageModuleGraphAttachment),
}

struct EmittedPageModuleGraphAttachment {
    entry: BlueJsProgramHandle,
    modules: BTreeMap<String, BlueJsProgramHandle>,
}

impl DeferredModuleAttachment {
    fn entry_handle(&self) -> BlueJsProgramHandle {
        match self {
            Self::Direct(attachment) => attachment.entry.handle,
            Self::Emitted(attachment) => attachment.entry,
        }
    }

    fn module_handles(&self) -> Vec<BlueJsProgramHandle> {
        match self {
            Self::Direct(attachment) => attachment
                .modules
                .values()
                .map(|module| module.handle)
                .collect(),
            Self::Emitted(attachment) => attachment.modules.values().copied().collect(),
        }
    }

    #[cfg(test)]
    fn module_handle(&self, module_id: &str) -> Option<BlueJsProgramHandle> {
        match self {
            Self::Direct(attachment) => attachment
                .modules
                .get(module_id)
                .map(|module| module.handle),
            Self::Emitted(attachment) => attachment.modules.get(module_id).copied(),
        }
    }

    fn owned_heap_payload_bytes(&self) -> Option<usize> {
        match self {
            Self::Direct(attachment) => attachment.owned_heap_payload_bytes(),
            Self::Emitted(attachment) => attachment.modules.iter().try_fold(
                std::mem::size_of::<BlueJsProgramHandle>(),
                |bytes, (module_id, _)| {
                    bytes
                        .checked_add(std::mem::size_of::<(String, BlueJsProgramHandle)>())?
                        .checked_add(module_id.capacity())
                },
            ),
        }
    }

    fn execute_in_page_realm(
        &self,
        runtime: &mut BlueJsPageRuntime,
        tab_id: u64,
    ) -> PageHostScriptOutcome {
        match self {
            Self::Direct(attachment) => match attachment.execute_in_page_realm(runtime, tab_id) {
                Ok(_) => PageHostScriptOutcome::Executed,
                Err(error) => rejected(bluets_bridge_category(error)),
            },
            Self::Emitted(attachment) => match runtime.execute_module_graph(
                tab_id,
                attachment.entry,
                attachment.modules.values().copied(),
            ) {
                Ok(_) => PageHostScriptOutcome::Executed,
                Err(error) => rejected(page_runtime_category(error)),
            },
        }
    }
}

struct PendingDebuggerExecution {
    ordinal: u32,
    language: PageHostScriptLanguage,
    kind: PageHostScriptKind,
    program: Option<PageHostDebuggerProgram>,
    nested_safe_point: Option<PageHostDebuggerSafePoint>,
    /// Exact earlier page loader for a System execute-body pause. The fixed
    /// field is bounded by the existing per-document pending-script cap.
    system_loader_program: Option<PageHostDebuggerProgram>,
    linked_safe_point: Option<PageHostDebuggerSafePoint>,
    execution: DeferredChildExecution,
}

#[derive(Clone)]
struct ScriptDomCapability {
    socket_path: PathBuf,
    session_token: String,
    enable_lookup_probe: bool,
    enable_dom_text_profile: bool,
    enable_dom_mutation_profile: bool,
    enable_dom_event_profile: bool,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum PageDomProfile {
    Snapshot,
    Text,
    Mutation,
    Event,
}

impl ScriptDomCapability {
    fn profile(&self) -> PageDomProfile {
        if self.enable_dom_event_profile {
            PageDomProfile::Event
        } else if self.enable_dom_mutation_profile {
            PageDomProfile::Mutation
        } else if self.enable_dom_text_profile {
            PageDomProfile::Text
        } else {
            PageDomProfile::Snapshot
        }
    }
}

/// Child-only script IPC. The core still owns every DOM node and validates
/// the exact target; this client never exposes a raw node ID to page code.
struct ScriptDomClient {
    capability: ScriptDomCapability,
    stream: Option<UnixStream>,
    next_call_id: u64,
}

impl ScriptDomClient {
    fn new(capability: ScriptDomCapability) -> Self {
        Self {
            capability,
            stream: None,
            next_call_id: 1,
        }
    }

    fn connect(&self) -> io::Result<UnixStream> {
        let mut stream = UnixStream::connect(&self.capability.socket_path)?;
        stream.set_read_timeout(Some(SCRIPT_DOM_CALL_WAIT))?;
        stream.set_write_timeout(Some(SCRIPT_DOM_CALL_WAIT))?;
        script::write_script_request(
            &mut stream,
            &ScriptRequest::Hello {
                protocol_version: script::SCRIPT_PROTOCOL_VERSION,
                session_token: self.capability.session_token.clone(),
            },
        )?;
        match script::read_script_reply(&mut stream)? {
            ScriptReply::HelloAck {
                protocol_version: script::SCRIPT_PROTOCOL_VERSION,
            } => Ok(stream),
            _ => Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "core rejected child script capability",
            )),
        }
    }

    fn has_element_by_id(&mut self, target: ScriptDocumentTarget, id: String) -> io::Result<bool> {
        self.get_element_by_id(target, id)
            .map(|node| node.is_some())
    }

    fn get_element_by_id(
        &mut self,
        target: ScriptDocumentTarget,
        id: String,
    ) -> io::Result<Option<u64>> {
        if id.len() > SCRIPT_MAX_NAME_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "script DOM lookup name exceeds its fixed limit",
            ));
        }
        match self.call(target, ScriptRequest::GetElementById { target, id })? {
            ScriptReply::Node { node } => Ok(node),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied child DOM lookup",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM lookup result",
                ))
            }
        }
    }

    fn validate_node(&mut self, target: ScriptDocumentTarget, node: u64) -> io::Result<()> {
        match self.call(target, ScriptRequest::ValidateNode { target, node })? {
            ScriptReply::Ack => Ok(()),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied stale child DOM node",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM validation result",
                ))
            }
        }
    }

    fn create_element(
        &mut self,
        target: ScriptDocumentTarget,
        tag_name: String,
    ) -> io::Result<u64> {
        if tag_name.len() > SCRIPT_MAX_NAME_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "script DOM tag name exceeds its fixed limit",
            ));
        }
        self.created_node(target, ScriptRequest::CreateElement { target, tag_name })
    }

    fn create_text_node(&mut self, target: ScriptDocumentTarget, data: String) -> io::Result<u64> {
        if data.len() > SCRIPT_MAX_TEXT_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "script DOM text exceeds its fixed limit",
            ));
        }
        self.created_node(target, ScriptRequest::CreateTextNode { target, data })
    }

    fn created_node(
        &mut self,
        target: ScriptDocumentTarget,
        request: ScriptRequest,
    ) -> io::Result<u64> {
        match self.call(target, request)? {
            ScriptReply::NodeCreated { node } => Ok(node),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied child DOM node creation",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM creation result",
                ))
            }
        }
    }

    fn append_child(
        &mut self,
        target: ScriptDocumentTarget,
        parent: u64,
        child: u64,
    ) -> io::Result<()> {
        match self.call(
            target,
            ScriptRequest::AppendChild {
                target,
                parent,
                child,
            },
        )? {
            ScriptReply::Ack => Ok(()),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied child DOM append",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM append result",
                ))
            }
        }
    }

    fn get_text_content(&mut self, target: ScriptDocumentTarget, node: u64) -> io::Result<String> {
        match self.call(target, ScriptRequest::GetTextContent { target, node })? {
            ScriptReply::Text { value } if value.len() <= SCRIPT_MAX_TEXT_BYTES => Ok(value),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied child DOM text read",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM text result",
                ))
            }
        }
    }

    fn set_text_content(
        &mut self,
        target: ScriptDocumentTarget,
        node: u64,
        value: String,
    ) -> io::Result<()> {
        if value.len() > SCRIPT_MAX_TEXT_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                "script DOM text exceeds its fixed limit",
            ));
        }
        match self.call(
            target,
            ScriptRequest::SetTextContent {
                target,
                node,
                value,
            },
        )? {
            ScriptReply::Ack => Ok(()),
            ScriptReply::Error { .. } => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    "core denied child DOM text write",
                ))
            }
            _ => {
                self.stream = None;
                Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned an invalid child DOM text mutation result",
                ))
            }
        }
    }

    fn call(
        &mut self,
        target: ScriptDocumentTarget,
        request: ScriptRequest,
    ) -> io::Result<ScriptReply> {
        if self.stream.is_none() {
            self.stream = Some(self.connect()?);
            self.next_call_id = 1;
        }
        let request_id = self.next_call_id;
        let result = (|| {
            let stream = self
                .stream
                .as_mut()
                .expect("script stream was just connected");
            script::write_script_request(
                stream,
                &ScriptRequest::Call {
                    request_id,
                    request: Box::new(request),
                },
            )?;
            match script::read_script_reply(stream)? {
                ScriptReply::CallResult {
                    request_id: reply_id,
                    target: reply_target,
                    reply,
                } if reply_id == request_id && reply_target == target => Ok(*reply),
                _ => Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "core returned a reply for a different script call or document",
                )),
            }
        })();
        if result.is_err() {
            self.stream = None;
        } else {
            let Some(next_call_id) = self.next_call_id.checked_add(1) else {
                self.stream = None;
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "script call ID space exhausted",
                ));
            };
            self.next_call_id = next_call_id;
        }
        result
    }
}

/// The actual state machine running in the child process.
///
/// It accepts only fully selected source records. It has no filesystem or
/// network resolver and gives the parent no VM/program handle. Ordinary
/// realms install only the two fixed core-validated string snapshots; an
/// explicit owner-only proof profile can additionally make boolean or
/// opaque-wrapper DOM lookups, live text reads/writes, or bounded creation
/// and append through the private script socket without exposing numeric
/// node IDs to page code.
pub struct BlueJsChildHost {
    runtime: BlueJsPageRuntime,
    limits: BlueJsHostRuntimeLimits,
    /// Static BlueTS metadata paired with the exact child-local BlueJS
    /// generation that direct lowering admitted. This remains entirely in the
    /// child: the page-host protocol has no source, symbol, type, contract,
    /// or runtime-value inspection operation.
    debug_registry: DirectDebugRegistry,
    documents: BTreeMap<u64, LiveDocument>,
    next_debugger_program_handle: u64,
    next_debugger_program_generation: u64,
    next_debugger_metadata_handle: u64,
    next_debugger_metadata_generation: u64,
    script_dom_capability: Option<ScriptDomCapability>,
    #[cfg(debug_assertions)]
    saved_emitted_map_for_test: Option<BoundEmittedMap>,
}

mod execution_drive;

mod debugger_inspection;

mod debugger_control;
mod emitted_map_lookup;

mod bluets_metadata_details;

mod bluets_metadata_catalog;

mod host_lifecycle;

mod host_supervisor;
pub use host_supervisor::{BlueJsHostCoreConfig, SpawnedBlueJsHost};

mod debugger_mapping;
use debugger_mapping::*;

mod script_execution;
use script_execution::*;

mod document_bindings;
use document_bindings::*;

#[cfg(debug_assertions)]
mod test_artifact_faults;

impl BlueJsChildHost {
    /// Debug-build-only test seam; it is never reachable through page-host IPC.
    #[cfg(debug_assertions)]
    #[doc(hidden)]
    pub fn corrupt_retained_emitted_map_for_test(
        &mut self,
        tab_id: u64,
        document_generation: u64,
        program: PageHostDebuggerProgram,
        mappings: &str,
    ) {
        let document = self.documents.get_mut(&tab_id).expect("live test realm");
        assert_eq!(document.generation, document_generation);
        let bound = document
            .emitted_maps
            .get_mut(&program)
            .expect("live test emitted map");
        bound.map.mappings = mappings.to_string();
        assert_eq!(
            bound.map.original_position_at(
                &bound.generated.source,
                0,
                0,
                BoundEmittedMap::MAX_SEGMENTS,
                BoundEmittedMap::MAX_RETAINED_BYTES,
            ),
            Err(blueice_bluets::SourceMapLookupError::MalformedMap),
            "the test must damage the child-retained map itself"
        );
    }

    fn exact_document(
        &self,
        tab_id: u64,
        document_generation: u64,
    ) -> Result<&LiveDocument, PageHostReply> {
        match self.documents.get(&tab_id) {
            None => Err(unknown_realm()),
            Some(document) if document.generation != document_generation => Err(stale_document()),
            Some(document) => Ok(document),
        }
    }

    fn refresh_debugger_programs(&mut self, tab_id: u64) -> Result<(), ()> {
        let runtime_handles = self.runtime.program_handles(tab_id).map_err(|_| ())?;
        for runtime_handle in runtime_handles {
            self.register_debugger_program(tab_id, runtime_handle)?;
        }
        Ok(())
    }

    /// Returns a stable child-private identity for one currently admitted
    /// runtime program. Refreshes never remint an existing handle: core's
    /// public mapping therefore remains bound to the exact private tuple.
    fn register_debugger_program(
        &mut self,
        tab_id: u64,
        runtime_handle: BlueJsProgramHandle,
    ) -> Result<PageHostDebuggerProgram, ()> {
        if let Some((program_handle, record)) = self
            .documents
            .get(&tab_id)
            .ok_or(())?
            .debugger_programs
            .iter()
            .find(|(_, record)| record.runtime_handle == runtime_handle)
        {
            return Ok(PageHostDebuggerProgram {
                program_handle: *program_handle,
                program_generation: record.program_generation,
            });
        }
        let program_handle = self.next_debugger_program_handle;
        let program_generation = self.next_debugger_program_generation;
        // Keep the numerical ranges disjoint for the process lifetime as a
        // defense in depth beyond the distinct wire types. A pathological
        // child that exhausts the lower program-ID space fails closed rather
        // than minting a value that could resemble a metadata handle.
        if program_handle >= CHILD_DEBUGGER_METADATA_ID_NAMESPACE_START
            || program_generation >= CHILD_DEBUGGER_METADATA_ID_NAMESPACE_START
        {
            return Err(());
        }
        self.next_debugger_program_handle = program_handle.checked_add(1).ok_or(())?;
        self.next_debugger_program_generation = program_generation.checked_add(1).ok_or(())?;
        self.documents
            .get_mut(&tab_id)
            .ok_or(())?
            .debugger_programs
            .insert(
                program_handle,
                ChildDebuggerProgram {
                    program_generation,
                    runtime_handle,
                    metadata: None,
                    exception_location: None,
                },
            );
        Ok(PageHostDebuggerProgram {
            program_handle,
            program_generation,
        })
    }

    /// Mints an inventory-only child metadata identity. Callers must first
    /// prove the matching registry attachment remains live; this helper never
    /// receives or derives compiler metadata.
    fn mint_debugger_metadata_handle(&mut self) -> Result<PageHostDebuggerMetadataHandle, ()> {
        let metadata_handle = self.next_debugger_metadata_handle;
        let metadata_generation = self.next_debugger_metadata_generation;
        self.next_debugger_metadata_handle = metadata_handle.checked_add(1).ok_or(())?;
        self.next_debugger_metadata_generation = metadata_generation.checked_add(1).ok_or(())?;
        Ok(PageHostDebuggerMetadataHandle {
            metadata_handle,
            metadata_generation,
        })
    }
}

impl Default for BlueJsChildHost {
    fn default() -> Self {
        Self::new().expect("the default BlueJS child-host configuration is valid")
    }
}

fn invalid_request() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::InvalidRequest,
        message: "BlueJS page-host request is invalid".to_string(),
    }
}

fn invalid_debugger_state() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::InvalidDebuggerState,
        message: "BlueJS page-host debugger execution state is invalid".to_string(),
    }
}

fn stale_document() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::StaleDocument,
        message: "BlueJS page-host document generation is stale".to_string(),
    }
}

fn unauthorized_artifact() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::UnauthorizedArtifact,
        message: "BlueJS page-host emitted map was not admitted for this program".to_string(),
    }
}

fn unknown_realm() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::UnknownRealm,
        message: "BlueJS page-host realm is unavailable".to_string(),
    }
}

fn resource_limit() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::ResourceLimit,
        message: "BlueJS page-host request exceeds configured policy".to_string(),
    }
}

fn host_failure() -> PageHostReply {
    PageHostReply::Error {
        code: PageHostErrorCode::HostFailure,
        message: "BlueJS page-host could not activate the requested realm".to_string(),
    }
}

/// Serves one launcher-owned connection. The first decoded request must prove
/// possession of the per-spawn session capability before it can affect a
/// realm. A disconnect ends only this peer; the launcher owns restart policy.
pub fn serve_bluejs_host_connection(
    mut stream: UnixStream,
    session_token: &str,
    host: &mut BlueJsChildHost,
) -> io::Result<bool> {
    let first = page_host::read_page_host_request(&mut stream)?;
    let accepted = matches!(
        page_host::negotiate(&first, session_token),
        PageHostReply::HelloAck { .. }
    );
    let reply = page_host::negotiate(&first, session_token);
    page_host::write_page_host_reply(&mut stream, &reply)?;
    if !accepted {
        return Ok(false);
    }

    loop {
        let request = match page_host::read_page_host_request(&mut stream) {
            Ok(request) => request,
            Err(error) if error.kind() == io::ErrorKind::UnexpectedEof => return Ok(false),
            Err(error) => return Err(error),
        };
        let shutting_down = matches!(request, PageHostRequest::Shutdown);
        let reply = host.handle_request(request);
        page_host::write_page_host_reply(&mut stream, &reply)?;
        if shutting_down {
            return Ok(true);
        }
    }
}

/// Runs the child listener until its authenticated launcher asks it to shut
/// down. The listener is bound only at a launcher-created `0600` path and an
/// attacker cannot use a competing same-user connection without the session
/// token. A rejected peer cannot terminate the child or consume a realm.
pub fn serve_bluejs_host_listener(
    listener: UnixListener,
    session_token: String,
    host: &mut BlueJsChildHost,
) -> io::Result<()> {
    for stream in listener.incoming() {
        match stream {
            Ok(stream) => match serve_bluejs_host_connection(stream, &session_token, host) {
                Ok(true) => return Ok(()),
                Ok(false) => continue,
                Err(_) => continue,
            },
            Err(error) => return Err(error),
        }
    }
    Ok(())
}

/// Binds the child socket with owner-only filesystem permissions. The secret
/// session token remains mandatory because pathname permission alone does not
/// distinguish another process of the same user.
pub fn bind_bluejs_host_socket(path: &Path) -> io::Result<UnixListener> {
    let _ = fs::remove_file(path);
    let listener = UnixListener::bind(path)?;
    fs::set_permissions(path, fs::Permissions::from_mode(0o600))?;
    Ok(listener)
}

#[cfg(test)]
mod tests;
