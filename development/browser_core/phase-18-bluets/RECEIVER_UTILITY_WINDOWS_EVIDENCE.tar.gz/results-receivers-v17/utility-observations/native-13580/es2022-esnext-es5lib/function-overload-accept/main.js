function keep(value) { return value; }
export const inferred = keep([1, true]);
