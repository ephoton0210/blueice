class Base {
    value;
    constructor(value) {
        this.value = value;
    }
}
function keep(value) { return value; }
export const inferred = keep([1]);
