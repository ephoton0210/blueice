export function inferred(value) { return value; }
