function keep(value) { return value; }
export const inferred = keep([]);
