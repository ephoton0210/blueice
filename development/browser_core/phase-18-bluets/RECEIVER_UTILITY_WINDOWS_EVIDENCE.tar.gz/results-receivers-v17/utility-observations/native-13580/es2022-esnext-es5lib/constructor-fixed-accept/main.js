function keep(value) { return value; }
export const inferred = keep([1]);
console.log(JSON.stringify(inferred));
