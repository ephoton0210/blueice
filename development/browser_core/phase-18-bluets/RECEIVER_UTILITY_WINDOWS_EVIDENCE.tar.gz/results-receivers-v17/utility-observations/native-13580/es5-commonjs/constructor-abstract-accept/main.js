"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
var Base = /** @class */ (function () {
    function Base(value) {
        this.value = value;
    }
    return Base;
}());
function keep(value) { return value; }
exports.inferred = keep([1]);
