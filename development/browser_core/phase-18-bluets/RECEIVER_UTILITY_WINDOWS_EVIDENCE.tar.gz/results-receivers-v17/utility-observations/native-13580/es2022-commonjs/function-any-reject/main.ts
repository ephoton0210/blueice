declare const args: Parameters<any>;
export const inferred: number = args[0];
