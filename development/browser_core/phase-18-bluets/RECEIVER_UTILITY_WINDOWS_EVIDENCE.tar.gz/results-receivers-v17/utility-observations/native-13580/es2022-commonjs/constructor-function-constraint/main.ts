export type Result = ConstructorParameters<() => number>;
