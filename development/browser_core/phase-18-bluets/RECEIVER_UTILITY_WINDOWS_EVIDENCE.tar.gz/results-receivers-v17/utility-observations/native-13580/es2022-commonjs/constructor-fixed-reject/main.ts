function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<new (item: number) => {id: number}>>(["bad"]);
