declare const value: InstanceType<new <T>(item: T) => {value: T}>;
export const inferred: number = value.value;
