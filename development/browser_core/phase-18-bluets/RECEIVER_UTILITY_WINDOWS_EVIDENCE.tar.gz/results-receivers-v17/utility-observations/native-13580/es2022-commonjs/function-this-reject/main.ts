function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<(this: {id: number}, item: string) => void>>([1]);
