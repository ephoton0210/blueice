export type Result = Parameters<new () => {id: number}>;
