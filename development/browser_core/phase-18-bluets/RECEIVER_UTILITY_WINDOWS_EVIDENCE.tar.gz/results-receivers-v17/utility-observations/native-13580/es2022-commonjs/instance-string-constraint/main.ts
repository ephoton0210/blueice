export type Result = InstanceType<string>;
