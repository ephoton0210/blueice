"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = void 0;
function keep(value) { return value; }
exports.inferred = keep([1, true]);
