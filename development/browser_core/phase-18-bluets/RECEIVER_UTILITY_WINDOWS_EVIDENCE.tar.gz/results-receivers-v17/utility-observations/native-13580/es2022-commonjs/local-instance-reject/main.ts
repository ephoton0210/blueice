// 🧊
type Item<F extends abstract new (...args: any) => any> = F extends abstract new (...args: any) => infer I ? I : never;
function keep<T>(value: T): T { return value; }
export const inferred = keep<Item<new (item: number) => {value: number}>>({value: "bad"});
