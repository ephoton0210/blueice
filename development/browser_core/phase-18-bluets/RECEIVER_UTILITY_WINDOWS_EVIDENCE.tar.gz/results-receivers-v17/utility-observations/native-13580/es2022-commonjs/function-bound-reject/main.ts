function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<<T extends {id: number}>(item: T) => T>>([{id: "bad"}]);
