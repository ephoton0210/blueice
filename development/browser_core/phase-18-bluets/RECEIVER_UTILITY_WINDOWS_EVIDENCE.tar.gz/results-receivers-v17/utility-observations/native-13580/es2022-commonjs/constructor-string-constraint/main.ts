export type Result = ConstructorParameters<string>;
