interface F { (item: string): string; (item: number, flag?: boolean): number; }
function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<F>>(["wrong"]);
