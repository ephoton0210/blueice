declare const args: ConstructorParameters<new <T>(item: T) => {value: T}>;
export const inferred: number = args[0];
