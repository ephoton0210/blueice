function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<(item?: number) => void>>(["bad"]);
