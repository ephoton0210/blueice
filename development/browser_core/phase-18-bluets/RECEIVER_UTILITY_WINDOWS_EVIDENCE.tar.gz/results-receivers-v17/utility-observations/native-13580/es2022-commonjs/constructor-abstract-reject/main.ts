abstract class Base { constructor(public value: number) {} }
function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<typeof Base>>(["bad"]);
