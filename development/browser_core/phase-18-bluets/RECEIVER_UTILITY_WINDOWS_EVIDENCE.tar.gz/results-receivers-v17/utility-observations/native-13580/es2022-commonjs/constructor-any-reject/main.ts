declare const args: ConstructorParameters<any>;
export const inferred: number = args[0];
