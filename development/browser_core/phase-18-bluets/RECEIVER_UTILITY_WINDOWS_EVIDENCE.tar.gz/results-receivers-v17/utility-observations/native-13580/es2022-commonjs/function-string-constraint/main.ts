export type Result = Parameters<string>;
