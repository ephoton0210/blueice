declare const args: Parameters<<T>(item: T) => T>;
export const inferred: number = args[0];
