"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inferred = inferred;
function inferred(value) { return value; }
