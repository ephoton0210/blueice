export type Result = InstanceType<() => number>;
