interface C { new (item: string): {value: string}; new (item: number): {value: number}; }
function keep<T>(value: T): T { return value; }
export const inferred = keep<InstanceType<C>>({value: "bad"});
