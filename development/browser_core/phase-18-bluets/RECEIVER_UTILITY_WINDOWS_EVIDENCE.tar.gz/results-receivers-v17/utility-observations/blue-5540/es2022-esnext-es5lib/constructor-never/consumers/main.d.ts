export declare function inferred(value: ConstructorParameters<never>): never;
