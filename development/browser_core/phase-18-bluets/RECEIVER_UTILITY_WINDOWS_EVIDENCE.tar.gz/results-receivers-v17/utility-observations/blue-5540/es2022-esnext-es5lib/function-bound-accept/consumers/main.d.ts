export declare const inferred: [item: {
    id: number;
}];
