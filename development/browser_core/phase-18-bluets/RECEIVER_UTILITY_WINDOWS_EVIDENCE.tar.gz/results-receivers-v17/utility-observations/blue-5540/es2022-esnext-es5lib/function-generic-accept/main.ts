function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<<T>(item: T) => T>>([1]);
