function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<any>>([1, "ok"]);
