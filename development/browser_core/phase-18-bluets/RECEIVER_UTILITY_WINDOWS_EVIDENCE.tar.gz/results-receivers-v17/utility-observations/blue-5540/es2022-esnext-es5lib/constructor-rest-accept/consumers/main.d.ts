export declare const inferred: [item?: number | undefined, ...tail: string[]];
