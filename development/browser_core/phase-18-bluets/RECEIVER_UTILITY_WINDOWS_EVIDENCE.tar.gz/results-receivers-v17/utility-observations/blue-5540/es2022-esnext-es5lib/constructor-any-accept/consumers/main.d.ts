export declare const inferred: unknown[];
