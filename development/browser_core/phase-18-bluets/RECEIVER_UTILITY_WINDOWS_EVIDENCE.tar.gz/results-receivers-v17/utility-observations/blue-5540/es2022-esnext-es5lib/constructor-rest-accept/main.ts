function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<new (item?: number, ...tail: string[]) => {id: number}>>([1, "ok"]);
