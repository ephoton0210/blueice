declare const console: { log(value: string): void };
function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<new (item: number) => {id: number}>>([1]);
console.log(JSON.stringify(inferred));
