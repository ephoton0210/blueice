import { inferred } from "./main";
const value: [{id: string}] = inferred;
