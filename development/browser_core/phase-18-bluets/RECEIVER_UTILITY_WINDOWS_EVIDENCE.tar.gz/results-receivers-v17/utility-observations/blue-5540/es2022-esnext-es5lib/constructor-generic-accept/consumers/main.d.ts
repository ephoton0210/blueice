export declare const inferred: [item: unknown];
