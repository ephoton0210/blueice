function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<new <T>(item: T) => {value: T}>>([1]);
