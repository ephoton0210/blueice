export function inferred(value: ConstructorParameters<never>): never { return value; }
