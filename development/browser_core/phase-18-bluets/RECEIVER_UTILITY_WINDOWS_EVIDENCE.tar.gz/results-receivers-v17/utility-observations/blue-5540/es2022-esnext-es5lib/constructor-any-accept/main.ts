function keep<T>(value: T): T { return value; }
export const inferred = keep<ConstructorParameters<any>>([1, "ok"]);
