import { inferred } from "./main";
const value: [string?, ...number[]] = inferred;
