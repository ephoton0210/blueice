import { inferred } from "./main";
const value: [number, ...number[]] = inferred;
