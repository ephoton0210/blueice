import { inferred } from "./main";
const value: {value: string} = inferred;
