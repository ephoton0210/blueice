export declare function inferred(value: Parameters<never>): never;
