export const inferred: InstanceType<any> = 1;
