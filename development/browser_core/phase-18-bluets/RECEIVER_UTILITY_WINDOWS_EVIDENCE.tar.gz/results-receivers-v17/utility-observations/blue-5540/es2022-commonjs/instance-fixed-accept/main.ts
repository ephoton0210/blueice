function keep<T>(value: T): T { return value; }
export const inferred = keep<InstanceType<new (item: number) => {value: number}>>({value: 1});
