import { inferred } from "./main";
const value: [number] = inferred;
