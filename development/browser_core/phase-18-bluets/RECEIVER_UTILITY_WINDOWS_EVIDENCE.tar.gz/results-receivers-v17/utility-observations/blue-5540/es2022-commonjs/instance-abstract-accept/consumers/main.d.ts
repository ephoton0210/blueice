declare abstract class Base {
    value: number;
    constructor(value: number);
}
export declare const inferred: Base;
export {};
