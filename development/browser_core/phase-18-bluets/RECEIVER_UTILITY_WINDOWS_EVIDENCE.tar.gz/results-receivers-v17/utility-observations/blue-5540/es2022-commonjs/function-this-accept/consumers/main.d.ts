export declare const inferred: [item: string];
