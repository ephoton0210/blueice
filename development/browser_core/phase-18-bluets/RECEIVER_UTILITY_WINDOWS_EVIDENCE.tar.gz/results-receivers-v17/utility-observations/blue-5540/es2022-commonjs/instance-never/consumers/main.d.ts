export declare function inferred(value: InstanceType<never>): never;
