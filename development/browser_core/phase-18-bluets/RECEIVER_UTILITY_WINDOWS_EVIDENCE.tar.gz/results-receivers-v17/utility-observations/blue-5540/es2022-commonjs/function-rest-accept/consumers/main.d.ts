export declare const inferred: [item: number, ...tail: string[]];
