export declare const inferred: {
    value: number;
};
