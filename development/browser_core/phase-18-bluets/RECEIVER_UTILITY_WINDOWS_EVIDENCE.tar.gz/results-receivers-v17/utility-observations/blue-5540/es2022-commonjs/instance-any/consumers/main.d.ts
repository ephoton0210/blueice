export declare const inferred: InstanceType<any>;
