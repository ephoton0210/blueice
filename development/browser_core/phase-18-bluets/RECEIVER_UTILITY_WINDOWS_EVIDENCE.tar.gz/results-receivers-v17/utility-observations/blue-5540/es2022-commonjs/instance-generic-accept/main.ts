function keep<T>(value: T): T { return value; }
export const inferred = keep<InstanceType<new <T>(item: T) => {value: T}>>({value: 1});
