type Args<F extends (...args: any) => any> = F extends (...args: infer A) => any ? A : never;
function keep<T>(value: T): T { return value; }
export const inferred = keep<Args<(item: number) => string>>([1]);
