export declare const inferred: {
    value: unknown;
};
