export declare const inferred: [item: number, flag?: boolean | undefined];
