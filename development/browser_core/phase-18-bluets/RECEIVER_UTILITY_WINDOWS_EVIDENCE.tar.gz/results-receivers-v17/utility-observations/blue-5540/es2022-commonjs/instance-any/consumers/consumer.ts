import { inferred } from "./main";
const value: never = inferred;
