export function inferred(value: Parameters<never>): never { return value; }
