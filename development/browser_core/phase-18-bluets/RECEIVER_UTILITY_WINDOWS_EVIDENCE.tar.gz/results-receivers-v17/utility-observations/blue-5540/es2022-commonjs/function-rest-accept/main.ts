function keep<T>(value: T): T { return value; }
export const inferred = keep<Parameters<(item: number, ...tail: string[]) => void>>([1, "ok"]);
