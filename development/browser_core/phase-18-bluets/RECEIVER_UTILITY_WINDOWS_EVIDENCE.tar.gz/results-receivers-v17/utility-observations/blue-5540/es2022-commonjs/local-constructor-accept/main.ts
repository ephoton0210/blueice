type Args<F extends abstract new (...args: any) => any> = F extends abstract new (...args: infer A) => any ? A : never;
function keep<T>(value: T): T { return value; }
export const inferred = keep<Args<new (item: number) => {value: number}>>([1]);
