export function inferred(value: InstanceType<never>): never { return value; }
