import { inferred } from "./main";
inferred(1);
