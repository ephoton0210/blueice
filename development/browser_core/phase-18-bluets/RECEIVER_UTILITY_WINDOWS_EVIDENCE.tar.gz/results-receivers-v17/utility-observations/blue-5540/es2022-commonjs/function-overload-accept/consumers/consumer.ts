import { inferred } from "./main";
const value: [string] = inferred;
