export declare const inferred: [item: number];
