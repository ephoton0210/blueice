import { inferred } from "./main";
const value: {value: number} = inferred;
