type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
export function result<E extends Record<string,unknown>>(values:Map<keyof E,List<E[keyof E]>|((key:keyof E,event:E[keyof E])=>void)[]>,key:keyof E,event:E[keyof E]){const found=values.get(key);if(found){return (found as List<E[keyof E]>).slice().map(handler=>handler(event));}}
