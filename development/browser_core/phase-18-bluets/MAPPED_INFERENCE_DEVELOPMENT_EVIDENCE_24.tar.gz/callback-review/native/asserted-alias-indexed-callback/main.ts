type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
export function result<E extends Record<string,unknown>>(values:List<E[keyof E]>|((key:keyof E,event:E[keyof E])=>void)[],event:E[keyof E]){return (values as List<E[keyof E]>).slice().map(handler=>handler(event));}
