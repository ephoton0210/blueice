// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process');
const assert = require('node:assert/strict'), crypto = require('node:crypto');
const repo = process.cwd(), root = __dirname;
const implementation = path.join(repo, 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/lib/typescript.js');
const ts = require(implementation); assert.equal(ts.version, '5.9.3');
const options = {target:'ES2022',module:'CommonJS',strict:true,lib:['ES2022'],declaration:true,outDir:'dist',noEmitOnError:true};
const aliases = 'type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;\n';
const sources=JSON.parse(fs.readFileSync(path.join(root,'sources.json')));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const normalize = (d,cwd) => ({code:d.code,message:ts.flattenDiagnosticMessageText(d.messageText,'\n'),file:d.file?path.relative(cwd,d.file.fileName).replaceAll('\\','/'):null,position:d.file&&d.start!==undefined?{line:d.file.getLineAndCharacterOfPosition(d.start).line+1,column:d.file.getLineAndCharacterOfPosition(d.start).character+1,length:d.length}:null,relatedInformation:(d.relatedInformation||[]).map(r=>normalize(r,cwd))});
const rows=[];
// Calibrate every Native program before replaying either Blue compiler.
for(const [id,source] of sources){
 const cwd=path.join(root,'native',id);fs.mkdirSync(cwd,{recursive:true});fs.writeFileSync(path.join(cwd,'main.ts'),source);
 const parsed=ts.convertCompilerOptionsFromJson(options,cwd);assert.deepEqual(parsed.errors,[]);
 const program=ts.createProgram([path.join(cwd,'main.ts')],parsed.options),diagnostics=ts.getPreEmitDiagnostics(program).map(d=>normalize(d,cwd));
 const declarations={};program.emit(undefined,(name,text)=>{if(name.endsWith('.d.ts'))declarations[path.relative(path.join(cwd,'dist'),name).replaceAll('\\','/')]=text;});
 rows.push({id,source,accepts:diagnostics.length===0,diagnostics,declarations});
}
fs.writeFileSync(path.join(root,'native-reference.json'),JSON.stringify({typescript:ts.version,implementationSha256:sha(fs.readFileSync(implementation)),options,cases:rows},null,2)+'\n',{flag:'wx'});
for(const [name,compiler] of [['acceptedC','target/string-intrinsics-acceptance-20261113-r2/accepted-workspace-cli'],['retiredD','target/mapped-inference-acceptance-20261113-r1/accepted-native-cli']]){
 const observations=[];
 for(const row of rows){
  const cwd=path.join(root,name,row.id);fs.mkdirSync(cwd,{recursive:true});fs.writeFileSync(path.join(cwd,'main.ts'),row.source);fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify({compilerOptions:options,files:['main.ts']},null,2)+'\n');
  const built=cp.spawnSync(path.join(repo,compiler),['build','--config','tsconfig.json','--diagnostics-json'],{cwd,encoding:'utf8'});if(built.error)throw built.error;
  fs.writeFileSync(path.join(cwd,'build.stdout'),built.stdout);fs.writeFileSync(path.join(cwd,'build.stderr'),built.stderr);
  const diagnostics=built.stderr.split(/\r?\n/).filter(Boolean).map(JSON.parse);const declarations={};const dist=path.join(cwd,'dist');if(fs.existsSync(dist))for(const file of fs.readdirSync(dist))if(file.endsWith('.d.ts'))declarations[file]=fs.readFileSync(path.join(dist,file),'utf8');
  const observed={id:row.id,accepts:built.status===0,diagnostics,declarations};observations.push(observed);console.log(name,row.id,built.status,diagnostics.map(d=>d.typescript?.code));
 }
 fs.writeFileSync(path.join(root,name+'-observations.json'),JSON.stringify({compilerSha256:sha(fs.readFileSync(path.join(repo,compiler))),cases:observations},null,2)+'\n',{flag:'wx'});
}
