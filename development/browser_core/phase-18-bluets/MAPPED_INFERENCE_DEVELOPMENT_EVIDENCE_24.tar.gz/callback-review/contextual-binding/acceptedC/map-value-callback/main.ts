type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
export function result<E extends Record<string,unknown>>(values:Map<keyof E,List<E[keyof E]>>,type:keyof E,event:E[keyof E]){const found=values.get(type);if(found){return found.slice().map(handler=>handler(event));}}
