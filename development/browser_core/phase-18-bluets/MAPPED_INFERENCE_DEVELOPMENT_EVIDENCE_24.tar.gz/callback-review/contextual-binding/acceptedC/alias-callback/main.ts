type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
export function result<T>(values:List<T>,event:T){return values.slice().map(handler=>handler(event));}
