export function result<E extends Record<string,unknown>>(values:((event:E[keyof E])=>void)[],event:E[keyof E]){return values.slice().map(handler=>handler(event));}
