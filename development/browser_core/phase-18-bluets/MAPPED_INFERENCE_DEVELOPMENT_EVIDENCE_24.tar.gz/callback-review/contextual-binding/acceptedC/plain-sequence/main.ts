export function result<T>(values:T[]):T[]{return values.slice().map(value=>value);}
