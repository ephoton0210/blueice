export function result<T>(values:((event:T)=>void)[],event:T){return values.slice().map(handler=>handler(event));}
