type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
export function result<E extends Record<string,unknown>>(values:List<E[keyof E]>){return {run<K extends keyof E>(event:E[K]){return values.slice().map(handler=>handler(event));}};}
