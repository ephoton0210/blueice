type Handler<T>=(event:T)=>void; type List<T>=Array<Handler<T>>;
interface Runner<E>{run<K extends keyof E>(event:E[K]):void;} export function result<E extends Record<string,unknown>>(values:List<E[keyof E]>):Runner<E>{return {run<K extends keyof E>(event:E[K]){values.slice().map(handler=>handler(event));}};}
