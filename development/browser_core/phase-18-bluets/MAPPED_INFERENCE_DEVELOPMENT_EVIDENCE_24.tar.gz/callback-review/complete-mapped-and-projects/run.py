# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess

repo = Path('/Users/ephoton/git/blueice-bluets')
root = Path(__file__).resolve().parent
manifest = json.loads((root / 'source-manifest.json').read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = {'scope': 'Authoring full mapped replay and all four unchanged project gates; not formal acceptance',
         'sourceRevision': manifest['sourceRevision'], 'conclusion': 'in_progress', 'steps': []}
env = dict(os.environ, CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
           CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0', RUST_TEST_THREADS='4',
           BLUEICE_BLUETSC_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/typescript/bin/tsc'),
           BLUEICE_ACORN_ORACLE=str(repo / 'target/noinfer-acceptance-20261112/oracles/node_modules/acorn/bin/acorn'),
           BLUEICE_MAPPED_INFERENCE_OBSERVATIONS=str(root / 'observations'),
           BLUEICE_MAPPED_INFERENCE_SOURCE_REVISION=manifest['sourceRevision'],
           FORCE_COLOR='0', CARGO_TERM_COLOR='never')


def save():
    state['recordedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (root / 'measurement.json').write_text(json.dumps(state, indent=2) + '\n')


def check():
    for name, digest in manifest['expectedFiles'].items():
        assert sha(repo / name) == digest, name


def run(label, args):
    check()
    state.update(stage=label, command=args)
    save()
    print('START', label, flush=True)
    log = root / (label + '.log')
    with log.open('xb') as output:
        child = subprocess.Popen(args, cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
        state['childPid'] = child.pid
        save()
        code = child.wait()
    state['steps'].append({'label': label, 'exit': code, 'log': log.name, 'sha256': sha(log)})
    save()
    print('END', label, code, flush=True)
    assert code == 0, (label, code)
    check()


try:
    run('mapped', ['cargo', 'test', '-p', 'blueice-bluets', '--test', 'mapped_inference',
                   '--locked', '--offline', '--', '--include-ignored', '--nocapture'])
    shutil.copy2(repo / 'target/debug/bluetsc', root / 'authoring-cli')
    state['compilerSha256'] = sha(root / 'authoring-cli')
    save()
    for label, script in [('mitt', 'audit.cjs'), ('defu', 'defu-audit.cjs'),
                          ('reproductions', 'defu-reproduce.cjs'), ('interchange', 'defu-interchange.cjs')]:
        run('project-' + label, ['node', str(repo / 'differential-testing/bluets-projects' / script),
            '--compiler', str(root / 'authoring-cli'), '--typescript', env['BLUEICE_BLUETSC_ORACLE'],
            '--source-tree', manifest['backendTree'], '--output', str(root / ('project-' + label))])
        assert sha(repo / 'target/debug/bluetsc') == sha(root / 'authoring-cli') == state['compilerSha256']
    state.update(stage='complete', conclusion='success')
    save()
except BaseException as error:
    state.update(conclusion='failure', error=repr(error))
    save()
    raise
