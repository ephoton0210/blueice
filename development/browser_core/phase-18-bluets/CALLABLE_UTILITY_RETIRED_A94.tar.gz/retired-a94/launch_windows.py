from pathlib import Path
import ast,datetime,hashlib,json,re,shutil,subprocess,sys,tarfile
repo=Path('/Users/ephoton/git/blueice-bluets');parent=Path('/private/tmp/bluets-utility-followup-20261110');root=parent/'windows';root.mkdir(exist_ok=True)
prior=Path('/private/tmp/bluets-next-project-20261110/windows-corrected');helper='/private/tmp/gm3_qga.py';guest=r'B:\BlueIce\gm3-20261109-360d7d921';state={'stage':'preparing-patch'}
def save():state['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(root/'windows-launch.json').write_text(json.dumps(state,indent=2)+'\n')
def call(*args):return subprocess.check_output([sys.executable,helper,*args])
def paths(args):return [p for p in subprocess.check_output(['git',*args],cwd=repo).decode().split(chr(0)) if p]
try:
 save();shutil.copy2(parent/'frozen-source-preflight.json',root/'frozen-source-preflight.json');frozen=json.loads((root/'frozen-source-preflight.json').read_text());old=json.loads((prior/'windows-source-manifest.json').read_text());manifest=json.loads(json.dumps(old))
 support=['development/browser_core/phase-18-bluets/tools/'+name for name in ['record_defu_prerequisites.cjs','record_callable_utilities.cjs','verify_callable_utilities.cjs']]
 selected=paths(['ls-files','-z','--','backend','differential-testing/bluets-projects'])+support;changes=[]
 for name in selected:
  digest=hashlib.sha256((repo/name).read_bytes()).hexdigest()
  if manifest['files'].get(name)!=digest:changes.append(name)
  manifest['files'][name]=digest
 patch=root/'source-patch.tar.gz'
 with tarfile.open(patch,'w:gz') as archive:
  for name in sorted(set(changes),key=lambda p:p.encode()):archive.add(repo/name,arcname=name,recursive=False)
 patchhash=hashlib.sha256(patch.read_bytes()).hexdigest();backend=sorted(paths(['ls-files','-z','--','backend']),key=lambda p:p.encode());assert {p for p in manifest['files'] if p.startswith('backend/')}==set(backend)
 pathhash=hashlib.sha256(chr(0).join(backend).encode()).hexdigest();manifest.update(sourceRevision=frozen['sourceRevision'],followupPatchSha256=patchhash,backendFiles=len(backend),backendPathSetSha256=pathhash,scope='All canonical frozen backend paths including Unicode, plus pinned Native/project regression support.');(root/'windows-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 runner=(prior/'windows-runner.cjs').read_text().replace('results-followups-v11','results-utilities-v12').replace(old['sourceRevision'],frozen['sourceRevision']).replace(old['followupPatchSha256'],patchhash)
 previous="'gc1_object_generic_methods','gm2_incremental_options','project_config','defu_prerequisites'";assert runner.count(previous)==2;runner=runner.replace(previous,previous+",'callable_utilities'")
 point="state.stage='named-cases';save();";assert point in runner
 runner=runner.replace(point,"if(!state.compiler)throw Error('Missing actual compiler receipt');env.BLUEICE_GE5_EXPECTED_COMPILER_SHA256=state.compiler.sha256;env.BLUEICE_CALLABLE_SOURCE_REVISION=state.sourceRevision;env.BLUEICE_CALLABLE_UTILITIES_OBSERVATIONS=path.join(out,'utility-observations');"+point)
 (root/'windows-runner.cjs').write_text(runner)
 start=(prior/'start-windows.ps1').read_text().replace(old['followupPatchSha256'],patchhash);(root/'start-windows.ps1').write_text(start)
 watch=(prior/'watch_windows.py').read_text().replace(str(prior),str(root)).replace('results-followups-v11','results-utilities-v12').replace('followup-evidence-v11','utility-evidence-v12').replace("len(r['followups'])==4","len(r['followups'])==5")
 ast.parse(watch);(root/'watch_windows.py').write_text(watch)
 subprocess.run(['node','--check',str(root/'windows-runner.cjs')],check=True)
 state.update(stage='uploading',sourceRevision=frozen['sourceRevision'],patchSha256=patchhash,changedFiles=len(changes),backendFiles=len(backend));save()
 for local,remote in [('source-patch.tar.gz','followup-patch.tar.gz'),('windows-source-manifest.json','followup-source-manifest.json'),('windows-runner.cjs','followup-runner.cjs')]:call('write',str(root/local),guest+chr(92)+remote)
 (root/'windows-process.json').write_bytes(call('start',str(root/'start-windows.ps1')));state['stage']='running';save();subprocess.run([sys.executable,str(root/'watch_windows.py')],check=True);state.update(stage='complete',conclusion='success');save()
except BaseException as e:state.update(conclusion='failure',error=repr(e));save();raise
